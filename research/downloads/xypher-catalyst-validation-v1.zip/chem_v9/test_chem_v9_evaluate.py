#!/usr/bin/env python3

from __future__ import annotations

import csv
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
from ord_schema.proto import reaction_pb2

sys.path.insert(0, str(Path(__file__).resolve().parent))

import chem_v9_evaluate as evaluate


def write_tsv(path: Path, fields: list[str], rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


class OutcomePathTests(unittest.TestCase):
    @staticmethod
    def reaction_with_yield(value: float) -> reaction_pb2.Reaction:
        reaction = reaction_pb2.Reaction(reaction_id="synthetic")
        product = reaction.outcomes.add().products.add()
        product.is_desired_product = True
        measurement = product.measurements.add()
        measurement.type = reaction_pb2.ProductMeasurement.YIELD
        measurement.percentage.value = value
        return reaction

    def test_unique_desired_percentage_yield(self) -> None:
        self.assertAlmostEqual(
            evaluate.extract_desired_product_yield(self.reaction_with_yield(72.5)),
            72.5,
        )

    def test_missing_duplicate_and_nonfinite_targets_fail(self) -> None:
        with self.assertRaises(ValueError):
            evaluate.extract_desired_product_yield(reaction_pb2.Reaction())
        duplicated = self.reaction_with_yield(10.0)
        product = duplicated.outcomes[0].products[0]
        second = product.measurements.add()
        second.type = reaction_pb2.ProductMeasurement.YIELD
        second.percentage.value = 20.0
        with self.assertRaises(ValueError):
            evaluate.extract_desired_product_yield(duplicated)
        with self.assertRaises(ValueError):
            evaluate.extract_desired_product_yield(self.reaction_with_yield(float("inf")))

    def test_yield_without_percentage_fails(self) -> None:
        reaction = reaction_pb2.Reaction()
        product = reaction.outcomes.add().products.add()
        product.is_desired_product = True
        product.measurements.add().type = reaction_pb2.ProductMeasurement.YIELD
        with self.assertRaises(ValueError):
            evaluate.extract_desired_product_yield(reaction)


class RankAndAggregationTests(unittest.TestCase):
    def test_tie_aware_average_ranks_and_zero_variance(self) -> None:
        np.testing.assert_array_equal(
            evaluate.average_ranks([3.0, 1.0, 1.0, 4.0]),
            np.asarray([3.0, 1.5, 1.5, 4.0]),
        )
        self.assertAlmostEqual(evaluate.spearman_tie_aware([1, 2, 3], [3, 2, 1]), -1.0)
        self.assertEqual(evaluate.spearman_tie_aware([1, 1, 1], [3, 2, 1]), 0.0)

    def test_canonical_duplicate_target_is_arithmetic_mean(self) -> None:
        memberships = [
            evaluate.Membership("r1", "b", "e", "s", 1, 1),
            evaluate.Membership("r2", "b", "e", "s", 1, 1),
            evaluate.Membership("r3", "b", "e", "t", 2, 2),
        ]
        blocks, duplicate_groups = evaluate.aggregate_primary_blocks(
            memberships,
            {"r1": 10.0, "r2": 20.0, "r3": 40.0},
            {"b": "e"},
        )
        self.assertEqual(duplicate_groups, 1)
        self.assertEqual(blocks[0].structure_ids, ("s", "t"))
        self.assertEqual(blocks[0].yields, (15.0, 40.0))

    def test_leave_one_experiment_out_slot_scores(self) -> None:
        memberships = [
            evaluate.Membership("a", "b1", "e1", "a", 1, 1),
            evaluate.Membership("b", "b1", "e1", "b", 2, 2),
            evaluate.Membership("c", "b2", "e2", "c", 1, 2),
            evaluate.Membership("d", "b2", "e2", "d", 2, 3),
        ]
        scores = evaluate.crossfit_slot_rank_percentiles(
            memberships,
            {"a": 10.0, "b": 20.0, "c": 40.0, "d": 30.0},
            {"b1": "e1", "b2": "e2"},
            ("e1", "e2"),
            expected_rows_per_block=2,
        )
        self.assertEqual(scores["e1"], {1: 1.0, 2: 0.0})
        self.assertEqual(scores["e2"], {1: 0.0, 2: 1.0})


class SyntheticEvaluatorTests(unittest.TestCase):
    def make_freeze(self, root: Path) -> tuple[Path, Path]:
        frozen = root / "frozen"
        frozen.mkdir()
        descriptor_rows = []
        candidate = {"a": 1.0, "b": 2.0, "c": 1.0, "d": 2.0}
        for structure_id in ("a", "b", "c", "d"):
            row: dict[str, object] = {"structure_id": structure_id}
            for predictor in evaluate.DESCRIPTOR_PREDICTORS:
                row[predictor] = candidate[structure_id] if predictor in {
                    evaluate.CANDIDATE,
                    evaluate.SECONDARY,
                } else 1.0
            descriptor_rows.append(row)
        write_tsv(
            frozen / "ligand_descriptors.tsv",
            ["structure_id", *evaluate.DESCRIPTOR_PREDICTORS],
            descriptor_rows,
        )
        membership_rows = [
            {"reaction_id": "a", "block_id": "b1", "experiment": "e1", "structure_id": "a", "coded_ligand_slot": 1, "sample_well_row": 1},
            {"reaction_id": "b", "block_id": "b1", "experiment": "e1", "structure_id": "b", "coded_ligand_slot": 2, "sample_well_row": 2},
            {"reaction_id": "c", "block_id": "b2", "experiment": "e2", "structure_id": "c", "coded_ligand_slot": 1, "sample_well_row": 2},
            {"reaction_id": "d", "block_id": "b2", "experiment": "e2", "structure_id": "d", "coded_ligand_slot": 2, "sample_well_row": 3},
        ]
        membership_fields = [
            "reaction_id",
            "block_id",
            "experiment",
            "structure_id",
            "coded_ligand_slot",
            "sample_well_row",
        ]
        write_tsv(frozen / "eligible_memberships.tsv", membership_fields, membership_rows)
        write_tsv(frozen / "loaded_memberships.tsv", membership_fields, membership_rows)
        write_tsv(
            frozen / "blocks.tsv",
            ["block_id", "experiment", "ligand_rows", "primary_included"],
            [
                {"block_id": "b1", "experiment": "e1", "ligand_rows": 2, "primary_included": 1},
                {"block_id": "b2", "experiment": "e2", "ligand_rows": 2, "primary_included": 1},
            ],
        )
        write_tsv(
            frozen / "permutation_strata.tsv",
            ["structure_id", "stratum_id"],
            [
                {"structure_id": "a", "stratum_id": "s1"},
                {"structure_id": "b", "stratum_id": "s1"},
                {"structure_id": "c", "stratum_id": "s2"},
                {"structure_id": "d", "stratum_id": "s2"},
            ],
        )
        targets = root / "targets.tsv"
        write_tsv(
            targets,
            ["reaction_id", "yield_percentage"],
            [
                {"reaction_id": "a", "yield_percentage": 10},
                {"reaction_id": "b", "yield_percentage": 20},
                {"reaction_id": "c", "yield_percentage": 40},
                {"reaction_id": "d", "yield_percentage": 30},
            ],
        )
        return frozen, targets

    def test_exhaustive_joint_rows_fixed_controls_and_seeded_bootstrap(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            frozen, targets = self.make_freeze(Path(directory))
            prepared = evaluate.load_prepared(frozen, targets, enforce_frozen_shape=False)
            mappings = evaluate.enumerate_joint_row_mappings(prepared)
            self.assertEqual(mappings.shape, (4, 4))
            first = evaluate.run_evaluation(
                prepared,
                expected_permutations=4,
                bootstrap_replicates=100,
                bootstrap_lower_index=2,
                bootstrap_upper_index=97,
            )
            second = evaluate.run_evaluation(
                prepared,
                expected_permutations=4,
                bootstrap_replicates=100,
                bootstrap_lower_index=2,
                bootstrap_upper_index=97,
            )
            self.assertEqual(first, second)
            self.assertEqual(first["qa"]["exact_joint_descriptor_row_permutations"], 4)
            self.assertEqual(first["primary"]["exact_permutation_p"]["denominator"], 4)
            self.assertNotIn(
                "exact_permutation_p",
                first["predictors"][evaluate.CROSSFIT_POSITION_CONTROL],
            )
            self.assertTrue(
                first["baseline_competition"]["champion_reselected_per_permutation"]
            )

    def test_inexact_target_coverage_fails_without_row_exclusion(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            frozen, targets = self.make_freeze(Path(directory))
            with targets.open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle, delimiter="\t"))[:-1]
            write_tsv(targets, ["reaction_id", "yield_percentage"], rows)
            with self.assertRaises(ValueError):
                evaluate.load_prepared(frozen, targets, enforce_frozen_shape=False)


if __name__ == "__main__":
    unittest.main()
