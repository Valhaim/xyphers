#!/usr/bin/env python3

from __future__ import annotations

import sys
import unittest
from pathlib import Path

from rdkit import Chem
from ord_schema.proto import reaction_pb2

sys.path.insert(0, str(Path(__file__).resolve().parent))

import chem_v9_prepare as prepare


class OutcomeBlindWireTests(unittest.TestCase):
    def test_outcome_envelope_is_removed_before_parse(self) -> None:
        reaction = reaction_pb2.Reaction(reaction_id="ord-test")
        reaction.outcomes.add().conversion.value = 73.125
        safe, stripped = prepare.strip_reaction_outcomes(reaction.SerializeToString())
        self.assertEqual(stripped, 1)
        decoded = reaction_pb2.Reaction()
        decoded.ParseFromString(safe)
        self.assertEqual(decoded.reaction_id, "ord-test")
        self.assertEqual(len(decoded.outcomes), 0)

    def test_non_outcome_fields_round_trip_byte_exactly(self) -> None:
        reaction = reaction_pb2.Reaction(reaction_id="ord-test")
        identifier = reaction.identifiers.add()
        identifier.type = reaction_pb2.ReactionIdentifier.CUSTOM
        identifier.details = "experiment"
        identifier.value = "experiment-1"
        safe, _ = prepare.strip_reaction_outcomes(reaction.SerializeToString())
        self.assertEqual(safe, reaction.SerializeToString())


class PlacementParserTests(unittest.TestCase):
    def test_xz_alpha_position_and_disambiguator(self) -> None:
        self.assertEqual(
            prepare.parse_sample_position("XZ_01-1_30_1_P14_1"),
            (1, 16, 14, "q1:r16:c14", "alpha"),
        )

    def test_jd_numeric_position(self) -> None:
        self.assertEqual(
            prepare.parse_sample_position("JD-03-08_PLATE3_314"),
            (3, 14, 2, "q3:r14:c02", "numeric"),
        )

    def test_invalid_position_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            prepare.parse_sample_position("XZ_01-1_30_1_P25")


class FrozenCohortTests(unittest.TestCase):
    def test_target_independent_eligibility_examples(self) -> None:
        accepted = Chem.MolFromSmiles("P(c1ccccc1)(c1ccccc1)c1ccccc1")
        direct_ch2 = Chem.MolFromSmiles("P(Cc1ccccc1)(Cc1ccccc1)Cc1ccccc1")
        diphosphine = Chem.MolFromSmiles("P(c1ccccc1)(c1ccccc1)CCP(c1ccccc1)c1ccccc1")
        phosphite = Chem.MolFromSmiles("P(OCC)(OCC)OCC")
        phosphonium_salt = Chem.MolFromSmiles("[B-](F)(F)(F)F.CC(C)(C)[PH+](C(C)(C)C)C(C)(C)C")
        self.assertTrue(prepare.is_frozen_eligible(accepted))
        self.assertFalse(prepare.is_frozen_eligible(direct_ch2))
        self.assertFalse(prepare.is_frozen_eligible(diphosphine))
        self.assertFalse(prepare.is_frozen_eligible(phosphite))
        self.assertFalse(prepare.is_frozen_eligible(phosphonium_salt))


class DescriptorTests(unittest.TestCase):
    def test_exact_walk_is_normalized_and_deterministic(self) -> None:
        molecule = Chem.MolFromSmiles("P(C)(C)C")
        adjacency = prepare.adjacency_from_molecule(molecule)
        p_index = prepare.phosphorus_index(molecule)
        first = prepare.endpoint_distribution(adjacency, p_index, prepare.TAU)
        second = prepare.endpoint_distribution(adjacency, p_index, prepare.TAU)
        self.assertEqual(first, second)
        self.assertEqual(sum(first), 1)

    def test_standardized_complex_adds_only_frozen_rh_co_h_topology(self) -> None:
        molecule = Chem.MolFromSmiles("P(C)(C)C")
        ligand = prepare.adjacency_from_molecule(molecule)
        p_index = prepare.phosphorus_index(molecule)
        complex_graph, p_complex = prepare.standardized_rh_complex(ligand, p_index)
        self.assertEqual(len(complex_graph), len(ligand) + 4)
        self.assertEqual(len(complex_graph[p_complex]), len(ligand[p_index]) + 1)
        self.assertEqual(sorted(len(complex_graph[index]) for index in range(4)), [1, 1, 2, 3])

    def test_descriptor_values_are_stable(self) -> None:
        canonical, _ = prepare.canonicalize_smiles("P(c1ccccc1)(c1ccccc1)c1ccccc1")
        row = prepare.descriptor_row(canonical)
        self.assertEqual(row["all_atom_count"], 34)
        self.assertEqual(row["heavy_atom_count"], 19)
        self.assertEqual(row["endpoint_support_rh_tau5"], 20)
        self.assertEqual(row["s_tau_p_rh_tau5"], "3.885009086958")


class BlockIdentityTests(unittest.TestCase):
    @staticmethod
    def reaction(ligand_id: str, ligand_smiles: str, reaction_id: str) -> reaction_pb2.Reaction:
        reaction = reaction_pb2.Reaction(reaction_id=reaction_id)
        reaction_type = reaction.identifiers.add()
        reaction_type.type = reaction_pb2.ReactionIdentifier.REACTION_TYPE
        reaction_type.value = "C–N coupling"
        experiment = reaction.identifiers.add()
        experiment.type = reaction_pb2.ReactionIdentifier.CUSTOM
        experiment.details = "experiment"
        experiment.value = "experiment-1"
        sample = reaction.identifiers.add()
        sample.type = reaction_pb2.ReactionIdentifier.CUSTOM
        sample.details = "Sample Name_x"
        sample.value = reaction_id
        ligand = reaction.inputs["ligand soln"].components.add()
        ligand.reaction_role = prepare.CATALYST_ROLE
        custom = ligand.identifiers.add()
        custom.type = reaction_pb2.CompoundIdentifier.CUSTOM
        custom.value = ligand_id
        smiles = ligand.identifiers.add()
        smiles.type = reaction_pb2.CompoundIdentifier.SMILES
        smiles.value = ligand_smiles
        solvent = reaction.inputs["ligand soln"].components.add()
        solvent.reaction_role = prepare.SOLVENT_ROLE
        solvent_name = solvent.identifiers.add()
        solvent_name.type = reaction_pb2.CompoundIdentifier.NAME
        solvent_name.value = "DMSO"
        return reaction

    def test_block_hash_ignores_ligand_and_row_identity(self) -> None:
        first = self.reaction("L1", "P(C)(C)C", "ord-1")
        second = self.reaction("L2", "P(CC)(CC)CC", "ord-2")
        self.assertEqual(
            prepare.exact_non_ligand_block_id(first),
            prepare.exact_non_ligand_block_id(second),
        )

    def test_block_hash_retains_experiment(self) -> None:
        first = self.reaction("L1", "P(C)(C)C", "ord-1")
        second = self.reaction("L1", "P(C)(C)C", "ord-2")
        next(identifier for identifier in second.identifiers if identifier.details == "experiment").value = "experiment-2"
        self.assertNotEqual(
            prepare.exact_non_ligand_block_id(first),
            prepare.exact_non_ligand_block_id(second),
        )

    def test_block_hash_retains_ligand_amount(self) -> None:
        first = self.reaction("L1", "P(C)(C)C", "ord-1")
        second = self.reaction("L2", "P(CC)(CC)CC", "ord-2")
        first_ligand = next(
            component
            for component in first.inputs["ligand soln"].components
            if component.reaction_role == prepare.CATALYST_ROLE
        )
        second_ligand = next(
            component
            for component in second.inputs["ligand soln"].components
            if component.reaction_role == prepare.CATALYST_ROLE
        )
        first_ligand.amount.moles.value = 1.0
        first_ligand.amount.moles.units = reaction_pb2.Moles.MICROMOLE
        second_ligand.amount.moles.value = 2.0
        second_ligand.amount.moles.units = reaction_pb2.Moles.MICROMOLE
        self.assertNotEqual(
            prepare.exact_non_ligand_block_id(first),
            prepare.exact_non_ligand_block_id(second),
        )


if __name__ == "__main__":
    unittest.main()
