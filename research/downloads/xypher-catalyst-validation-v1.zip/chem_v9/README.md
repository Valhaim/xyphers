# CHEM-V9 target-blind preparation

This directory contains the pre-reveal CHEM-V9 feature freeze. The extractor discards protobuf field 8 (`Reaction.outcomes`) before decoding each ORD reaction.

Run with the pinned environment:

```bash
uv run --with-requirements research/chemistry/validation/chem_v9/requirements.txt \
  python research/chemistry/validation/chem_v9/chem_v9_prepare.py \
  /path/to/ord_dataset-805ad863feef48579d95d86a728035f4.parquet \
  research/chemistry/validation/chem_v9/frozen
```

Run target-free preparation tests and synthetic-only evaluator tests:

```bash
uv run --with-requirements research/chemistry/validation/chem_v9/requirements.txt \
  python -m unittest -v \
  research/chemistry/validation/chem_v9/test_chem_v9_prepare.py \
  research/chemistry/validation/chem_v9/test_chem_v9_evaluate.py
```

`frozen/extraction_summary.json` is the target-free freeze manifest. It hashes the generated artifacts and every code, test, requirements, README, and preregistration input.

Do not add outcome extraction to `chem_v9_prepare.py`. Do not run either command below until the complete freeze is committed and pushed. The reveal requires one finite target for every row in `loaded_memberships.tsv`, not only the confirmatory eligible cohort.

```bash
uv run --with-requirements research/chemistry/validation/chem_v9/requirements.txt \
  python research/chemistry/validation/chem_v9/chem_v9_evaluate.py extract-targets \
  /path/to/ord_dataset-805ad863feef48579d95d86a728035f4.parquet \
  research/chemistry/validation/chem_v9/frozen/loaded_memberships.tsv \
  /path/to/sealed/chem_v9_targets.tsv

uv run --with-requirements research/chemistry/validation/chem_v9/requirements.txt \
  python research/chemistry/validation/chem_v9/chem_v9_evaluate.py evaluate \
  research/chemistry/validation/chem_v9/frozen \
  /path/to/sealed/chem_v9_targets.tsv \
  /path/to/chem_v9_report.json
```
