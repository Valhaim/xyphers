#!/usr/bin/env python3
"""Prepare the outcome-blind CHEM-V9 ORD feature freeze.

This program never parses Reaction.outcomes. Each opaque Reaction protobuf is
first filtered at the protobuf wire level; top-level field 8 is discarded as an
uninterpreted length-delimited payload. Only the resulting message is decoded.
"""

from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import math
import re
import sys
from dataclasses import dataclass, field
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
from typing import Iterable, Iterator, Sequence

import pyarrow
import pyarrow.parquet as pq
import rdkit
from rdkit import Chem
from ord_schema.proto import reaction_pb2


DATASET_ID = "ord_dataset-805ad863feef48579d95d86a728035f4"
DATASET_SHA256 = "31b7c4762145e5dad973050373cd967bdd85caf3a9858767c83a17fed6c4af36"
DATASET_BYTES = 5_088_296
SOURCE_ROWS = 50_688
SOURCE_ROW_GROUPS = 51
# THUMB td-6706c1: prior-operator horizon frozen before any ORD target access.
TAU = 5
# THUMB td-6706c1: frozen target-blind minimum equals the smallest retained panel.
MIN_PANEL_SIZE = 9
OUTCOMES_FIELD_NUMBER = 8

EXPECTED_REAL_LIGAND_IDS = 164
EXPECTED_EXPERIMENTS = 17
EXPECTED_BLOCKS = 2_112
EXPECTED_LIGAND_BLOCKS = 1_056
EXPECTED_ELIGIBLE_STRUCTURES = 45
EXPECTED_ELIGIBLE_ROWS = 17_632
EXPECTED_LOADED_ROWS = 49_632
EXPECTED_PRIMARY_BLOCKS = 864

ROLE_ENUM = reaction_pb2.Compound.DESCRIPTOR.fields_by_name["reaction_role"].enum_type
CATALYST_ROLE = ROLE_ENUM.values_by_name["CATALYST"].number
REACTANT_ROLE = ROLE_ENUM.values_by_name["REACTANT"].number
REAGENT_ROLE = ROLE_ENUM.values_by_name["REAGENT"].number
SOLVENT_ROLE = ROLE_ENUM.values_by_name["SOLVENT"].number


@dataclass(frozen=True)
class WireField:
    number: int
    wire_type: int
    start: int
    payload_start: int
    end: int


@dataclass
class LigandSource:
    ligand_ids: set[str] = field(default_factory=set)
    names: set[str] = field(default_factory=set)
    source_smiles: set[str] = field(default_factory=set)


@dataclass(frozen=True)
class RawMembership:
    reaction_id: str
    experiment: str
    block_id: str
    ligand_id: str
    canonical_smiles: str | None
    sample_name: str
    coded_recipe: str
    sample_subplate: int
    sample_well_row: int
    sample_well_column: int
    sample_position_id: str
    sample_position_format: str
    run_id: str
    coded_ligand_slot: str
    coded_catalyst_slot: str
    coded_base_slot: str
    coded_electrophile_slot: str
    coded_nucleophile_slot: str
    record_created: str
    record_modified: str


@dataclass
class BlockAccumulator:
    experiment: str
    electrophile_id: str
    nucleophile_id: str
    catalyst_id: str
    base_id: str
    temperature_c: str
    solvent_signature: str
    rows: int = 0
    ligand_rows: int = 0
    no_ligand_rows: int = 0
    ligand_ids: set[str] = field(default_factory=set)
    eligible_rows: int = 0
    eligible_structures: set[str] = field(default_factory=set)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_varint(raw: bytes, offset: int) -> tuple[int, int]:
    value = 0
    shift = 0
    while True:
        if offset >= len(raw):
            raise ValueError("truncated protobuf varint")
        byte = raw[offset]
        offset += 1
        value |= (byte & 0x7F) << shift
        if byte < 0x80:
            return value, offset
        shift += 7
        if shift >= 70:
            raise ValueError("oversized protobuf varint")


def iter_wire_fields(raw: bytes) -> Iterator[WireField]:
    offset = 0
    while offset < len(raw):
        start = offset
        key, offset = _read_varint(raw, offset)
        number = key >> 3
        wire_type = key & 0x07
        payload_start = offset
        if number == 0:
            raise ValueError("invalid protobuf field zero")
        if wire_type == 0:
            _, end = _read_varint(raw, offset)
        elif wire_type == 1:
            end = offset + 8
        elif wire_type == 2:
            size, payload_start = _read_varint(raw, offset)
            end = payload_start + size
        elif wire_type == 5:
            end = offset + 4
        else:
            raise ValueError(f"unsupported protobuf wire type {wire_type}")
        if end > len(raw):
            raise ValueError("truncated protobuf field")
        yield WireField(number, wire_type, start, payload_start, end)
        offset = end


def strip_reaction_outcomes(raw: bytes) -> tuple[bytes, int]:
    """Remove top-level Reaction field 8 without interpreting its payload."""
    safe = bytearray()
    stripped = 0
    for wire_field in iter_wire_fields(raw):
        if wire_field.number == OUTCOMES_FIELD_NUMBER:
            if wire_field.wire_type != 2:
                raise ValueError("Reaction.outcomes is not length-delimited")
            stripped += 1
            continue
        safe.extend(raw[wire_field.start : wire_field.end])
    return bytes(safe), stripped


def parse_feature_reaction(raw: bytes) -> reaction_pb2.Reaction:
    safe, stripped = strip_reaction_outcomes(raw)
    if stripped == 0:
        raise ValueError("Reaction record has no sealed outcomes envelope")
    reaction = reaction_pb2.Reaction()
    reaction.ParseFromString(safe)
    return reaction


def enum_name(field, value: int) -> str:
    return field.enum_type.values_by_number[value].name


def compound_identifier(compound: reaction_pb2.Compound, identifier_type: str) -> str | None:
    type_enum = reaction_pb2.CompoundIdentifier.CompoundIdentifierType
    for identifier in compound.identifiers:
        if type_enum.Name(identifier.type) == identifier_type:
            return identifier.value
    return None


def primary_component(
    reaction: reaction_pb2.Reaction, input_name: str, role: int
) -> reaction_pb2.Compound:
    if input_name not in reaction.inputs:
        raise ValueError(f"missing Reaction.inputs[{input_name!r}]")
    matches = [component for component in reaction.inputs[input_name].components if component.reaction_role == role]
    if len(matches) != 1:
        raise ValueError(f"expected one role={role} component in {input_name!r}, found {len(matches)}")
    return matches[0]


def reaction_identifier(reaction: reaction_pb2.Reaction, details: str) -> str:
    matches = [identifier.value for identifier in reaction.identifiers if identifier.details == details]
    if len(matches) != 1:
        raise ValueError(f"expected one Reaction identifier {details!r}, found {len(matches)}")
    return matches[0]


def parse_sample_position(sample_name: str) -> tuple[int, int, int, str, str]:
    alpha = re.search(r"(?i)_([1-4])_([A-P])([0-9]{1,2})(?:_1)?$", sample_name)
    if alpha:
        subplate = int(alpha.group(1))
        row = ord(alpha.group(2).upper()) - ord("A") + 1
        column = int(alpha.group(3))
        position_format = "alpha"
    else:
        numeric = re.search(r"(?i)plate([1-4])[-_]([0-9]{1,3})$", sample_name)
        if not numeric:
            raise ValueError(f"unrecognized sample position in {sample_name!r}")
        subplate = int(numeric.group(1))
        position = int(numeric.group(2))
        if not 1 <= position <= 384:
            raise ValueError(f"numeric sample well outside 1..384 in {sample_name!r}")
        row = (position - 1) // 24 + 1
        column = (position - 1) % 24 + 1
        position_format = "numeric"
    if not 1 <= column <= 24:
        raise ValueError(f"sample well column outside 1..24 in {sample_name!r}")
    position_id = f"q{subplate}:r{row:02}:c{column:02}"
    return subplate, row, column, position_id, position_format


def coded_slot(coded_recipe: str, sigil: str) -> str:
    match = re.search(rf"(?:^|\.){re.escape(sigil)}([0-9]+)(?:\.|$)", coded_recipe)
    if not match:
        raise ValueError(f"coded recipe has no {sigil} slot: {coded_recipe!r}")
    return match.group(1)


def component_custom_id(reaction: reaction_pb2.Reaction, input_name: str, role: int) -> str:
    component = primary_component(reaction, input_name, role)
    value = compound_identifier(component, "CUSTOM")
    if value is None:
        raise ValueError(f"missing CUSTOM identifier for {input_name!r}")
    return value


def temperature_celsius(reaction: reaction_pb2.Reaction) -> str:
    setpoint = reaction.conditions.temperature.setpoint
    units = enum_name(setpoint.DESCRIPTOR.fields_by_name["units"], setpoint.units)
    if units != "CELSIUS":
        raise ValueError(f"unexpected temperature unit {units}")
    return format(setpoint.value, ".12g")


def solvent_signature(reaction: reaction_pb2.Reaction) -> str:
    entries: list[str] = []
    for input_name in sorted(reaction.inputs):
        reaction_input = reaction.inputs[input_name]
        for component in reaction_input.components:
            if component.reaction_role != SOLVENT_ROLE:
                continue
            custom = compound_identifier(component, "CUSTOM") or ""
            name = compound_identifier(component, "NAME") or ""
            smiles = compound_identifier(component, "SMILES") or ""
            amount_hash = hashlib.sha256(component.amount.SerializeToString(deterministic=True)).hexdigest()
            entries.append(f"{input_name}:{custom}:{name}:{smiles}:{amount_hash}")
    return "|".join(sorted(entries))


def exact_non_ligand_block_id(reaction: reaction_pb2.Reaction) -> str:
    """Hash the full target-free reaction context after removing ligand identity."""
    context = reaction_pb2.Reaction()
    context.CopyFrom(reaction)
    experiment = reaction_identifier(context, "experiment")

    retained_identifiers = []
    for identifier in context.identifiers:
        identifier_type = reaction_pb2.ReactionIdentifier.ReactionIdentifierType.Name(identifier.type)
        if identifier_type == "REACTION_TYPE" or identifier.details == "experiment":
            retained_identifiers.append(identifier.SerializeToString(deterministic=True))
    context.ClearField("identifiers")
    for encoded in sorted(retained_identifiers):
        context.identifiers.add().ParseFromString(encoded)
    if not any(identifier.details == "experiment" and identifier.value == experiment for identifier in context.identifiers):
        raise ValueError("experiment identifier was not retained")

    context.ClearField("reaction_id")
    context.ClearField("provenance")
    ligand_input = context.inputs["ligand soln"]
    ligand_indexes = [
        index for index, component in enumerate(ligand_input.components) if component.reaction_role == CATALYST_ROLE
    ]
    if len(ligand_indexes) != 1:
        raise ValueError(f"expected one ligand component, found {len(ligand_indexes)}")
    ligand_input.components[ligand_indexes[0]].ClearField("identifiers")

    encoded = context.SerializeToString(deterministic=True)
    return hashlib.sha256(encoded).hexdigest()


def canonicalize_smiles(smiles: str) -> tuple[str, Chem.Mol]:
    molecule = Chem.MolFromSmiles(smiles)
    if molecule is None:
        raise ValueError(f"RDKit could not parse ligand SMILES {smiles!r}")
    canonical = Chem.MolToSmiles(molecule, canonical=True, isomericSmiles=True)
    canonical_molecule = Chem.MolFromSmiles(canonical)
    if canonical_molecule is None:
        raise ValueError(f"RDKit could not reparse canonical SMILES {canonical!r}")
    return canonical, canonical_molecule


def phosphorus_index(molecule: Chem.Mol) -> int | None:
    phosphorus = [atom.GetIdx() for atom in molecule.GetAtoms() if atom.GetAtomicNum() == 15]
    return phosphorus[0] if len(phosphorus) == 1 else None


def is_frozen_eligible(molecule: Chem.Mol) -> bool:
    """Target-independent CHEM-V9 structural rule frozen before reveal."""
    # THUMB td-6706c1: target-blind chemical-domain gate frozen in CHEM-V9.
    return not eligibility_exclusions(molecule)


def eligibility_exclusions(molecule: Chem.Mol) -> tuple[str, ...]:
    exclusions: list[str] = []
    if len(Chem.GetMolFrags(molecule)) != 1:
        exclusions.append("disconnected")
    if Chem.GetFormalCharge(molecule) != 0:
        exclusions.append("nonneutral_molecule")
    p_index = phosphorus_index(molecule)
    if p_index is None:
        p_count = sum(atom.GetAtomicNum() == 15 for atom in molecule.GetAtoms())
        exclusions.append(f"phosphorus_count_{p_count}")
        return tuple(exclusions)
    phosphorus = molecule.GetAtomWithIdx(p_index)
    if phosphorus.GetFormalCharge() != 0:
        exclusions.append("charged_phosphorus")
    if phosphorus.GetTotalNumHs() != 0:
        exclusions.append("phosphorus_hydrogen")
    neighbors = list(phosphorus.GetNeighbors())
    if len(neighbors) != 3:
        exclusions.append(f"phosphorus_heavy_degree_{len(neighbors)}")
    if any(atom.GetAtomicNum() != 6 for atom in neighbors):
        exclusions.append("noncarbon_phosphorus_neighbor")
    if any(not atom.GetIsAromatic() and atom.GetTotalNumHs() == 2 for atom in neighbors):
        exclusions.append("direct_p_ch2")
    return tuple(exclusions)


def adjacency_from_molecule(molecule: Chem.Mol) -> list[tuple[int, ...]]:
    adjacency = [set() for _ in range(molecule.GetNumAtoms())]
    for bond in molecule.GetBonds():
        a = bond.GetBeginAtomIdx()
        b = bond.GetEndAtomIdx()
        adjacency[a].add(b)
        adjacency[b].add(a)
    return [tuple(sorted(neighbors)) for neighbors in adjacency]


def phosphorus_component(
    adjacency: Sequence[Sequence[int]], p_index: int
) -> tuple[list[tuple[int, ...]], int]:
    seen = {p_index}
    queue = collections.deque([p_index])
    while queue:
        node = queue.popleft()
        for neighbor in adjacency[node]:
            if neighbor not in seen:
                seen.add(neighbor)
                queue.append(neighbor)
    ordered = sorted(seen)
    remap = {old: new for new, old in enumerate(ordered)}
    component = [tuple(remap[n] for n in adjacency[old] if n in seen) for old in ordered]
    return component, remap[p_index]


def standardized_rh_complex(
    ligand_adjacency: Sequence[Sequence[int]], p_index: int
) -> tuple[list[tuple[int, ...]], int]:
    """Build the prior Rh(CO)(H)(L) topology exactly; bond orders are unit weighted."""
    offset = 4
    adjacency = [set() for _ in range(offset + len(ligand_adjacency))]
    for a, b in ((0, 1), (1, 2), (0, 3)):
        adjacency[a].add(b)
        adjacency[b].add(a)
    for node, neighbors in enumerate(ligand_adjacency):
        for neighbor in neighbors:
            adjacency[node + offset].add(neighbor + offset)
    p_complex = p_index + offset
    adjacency[0].add(p_complex)
    adjacency[p_complex].add(0)
    return [tuple(sorted(neighbors)) for neighbors in adjacency], p_complex


def endpoint_distribution(
    adjacency: Sequence[Sequence[int]], start: int, tau: int
) -> tuple[Fraction, ...]:
    distribution = [Fraction(0, 1) for _ in adjacency]
    distribution[start] = Fraction(1, 1)
    for _ in range(tau):
        next_distribution = [Fraction(0, 1) for _ in adjacency]
        for node, probability in enumerate(distribution):
            if probability == 0:
                continue
            degree = len(adjacency[node])
            if degree == 0:
                continue
            share = probability / degree
            for neighbor in adjacency[node]:
                next_distribution[neighbor] += share
        distribution = next_distribution
    if sum(distribution, Fraction(0, 1)) != 1:
        raise ValueError("endpoint distribution lost probability mass")
    return tuple(distribution)


def shannon_entropy(distribution: Iterable[Fraction]) -> Decimal:
    with localcontext() as context:
        context.prec = 80
        ln_two = Decimal(2).ln()
        entropy = Decimal(0)
        for probability in distribution:
            if probability == 0:
                continue
            decimal_probability = Decimal(probability.numerator) / Decimal(probability.denominator)
            entropy -= decimal_probability * decimal_probability.ln() / ln_two
        return +entropy


def graph_distances(adjacency: Sequence[Sequence[int]], start: int) -> list[int | None]:
    distances: list[int | None] = [None for _ in adjacency]
    distances[start] = 0
    queue = collections.deque([start])
    while queue:
        node = queue.popleft()
        assert distances[node] is not None
        for neighbor in adjacency[node]:
            if distances[neighbor] is None:
                distances[neighbor] = distances[node] + 1
                queue.append(neighbor)
    return distances


def decimal_string(value: Decimal) -> str:
    return format(value.quantize(Decimal("0.000000000001")), "f")


def descriptor_row(canonical_smiles: str) -> dict[str, str | int]:
    heavy_molecule = Chem.MolFromSmiles(canonical_smiles)
    if heavy_molecule is None:
        raise ValueError(f"could not parse canonical SMILES {canonical_smiles!r}")
    molecule = Chem.AddHs(heavy_molecule)
    p_full = phosphorus_index(molecule)
    if p_full is None:
        raise ValueError("eligible ligand no longer has exactly one phosphorus")
    full_adjacency = adjacency_from_molecule(molecule)
    ligand_adjacency, p_ligand = phosphorus_component(full_adjacency, p_full)
    rh_adjacency, p_rh = standardized_rh_complex(ligand_adjacency, p_ligand)

    ligand_endpoint = endpoint_distribution(ligand_adjacency, p_ligand, TAU)
    rh_endpoint = endpoint_distribution(rh_adjacency, p_rh, TAU)
    distances = graph_distances(ligand_adjacency, p_ligand)
    shells = [0 for _ in range(5)]
    balls = [0 for _ in range(5)]
    for distance in distances:
        if distance is None or distance == 0:
            continue
        if distance <= 5:
            shells[distance - 1] += 1
        for radius in range(1, 6):
            if distance <= radius:
                balls[radius - 1] += 1
    branch_excess_r5 = sum(
        max(len(ligand_adjacency[index]) - 2, 0)
        for index, distance in enumerate(distances)
        if distance is not None and distance <= 5
    )
    positive_distances = [distance for distance in distances if distance is not None and distance > 0]
    mean_distance = Fraction(sum(positive_distances), len(positive_distances))

    row: dict[str, str | int] = {
        "s_tau_p_rh_tau5": decimal_string(shannon_entropy(rh_endpoint)),
        "s_tau_p_free_tau5": decimal_string(shannon_entropy(ligand_endpoint)),
        "all_atom_count": len(ligand_adjacency),
        "heavy_atom_count": heavy_molecule.GetNumHeavyAtoms(),
        "all_atom_edge_count": sum(len(neighbors) for neighbors in ligand_adjacency) // 2,
        "endpoint_support_rh_tau5": sum(probability > 0 for probability in rh_endpoint),
        "endpoint_support_free_tau5": sum(probability > 0 for probability in ligand_endpoint),
        "branch_excess_r5": branch_excess_r5,
        "mean_p_distance": decimal_string(Decimal(mean_distance.numerator) / Decimal(mean_distance.denominator)),
        "connected_components": len(Chem.GetMolFrags(heavy_molecule)),
        "formal_charge": Chem.GetFormalCharge(heavy_molecule),
        "p_total_h_count": molecule.GetAtomWithIdx(p_full).GetTotalNumHs(),
    }
    row.update(classical_graph_baselines(molecule, ligand_adjacency))
    for radius in range(1, 6):
        row[f"shell_r{radius}"] = shells[radius - 1]
        row[f"ball_r{radius}"] = balls[radius - 1]
    return row


ATOMIC_WEIGHTS = {
    "H": Decimal("1.008"),
    "Li": Decimal("6.941"),
    "B": Decimal("10.81"),
    "C": Decimal("12.011"),
    "N": Decimal("14.007"),
    "O": Decimal("15.999"),
    "F": Decimal("18.998"),
    "Na": Decimal("22.990"),
    "Mg": Decimal("24.305"),
    "Al": Decimal("26.982"),
    "Si": Decimal("28.086"),
    "P": Decimal("30.974"),
    "S": Decimal("32.065"),
    "Cl": Decimal("35.453"),
    "K": Decimal("39.098"),
    "Ca": Decimal("40.078"),
    "Ti": Decimal("47.867"),
    "Cr": Decimal("51.996"),
    "Mn": Decimal("54.938"),
    "Fe": Decimal("55.845"),
    "Co": Decimal("58.933"),
    "Ni": Decimal("58.693"),
    "Cu": Decimal("63.546"),
    "Zn": Decimal("65.38"),
    "Ge": Decimal("72.63"),
    "Se": Decimal("78.96"),
    "Br": Decimal("79.904"),
    "Zr": Decimal("91.224"),
    "Mo": Decimal("95.95"),
    "Ru": Decimal("101.07"),
    "Rh": Decimal("102.91"),
    "Pd": Decimal("106.42"),
    "Ag": Decimal("107.87"),
    "Sn": Decimal("118.71"),
    "Te": Decimal("127.60"),
    "I": Decimal("126.904"),
    "Hf": Decimal("178.49"),
    "W": Decimal("183.84"),
    "Re": Decimal("186.21"),
    "Os": Decimal("190.23"),
    "Ir": Decimal("192.22"),
    "Pt": Decimal("195.08"),
    "Au": Decimal("196.97"),
}


def classical_graph_baselines(
    molecule: Chem.Mol, adjacency: Sequence[Sequence[int]]
) -> dict[str, str | int]:
    unsupported_elements = sorted(
        {atom.GetSymbol() for atom in molecule.GetAtoms()} - set(ATOMIC_WEIGHTS)
    )
    if unsupported_elements:
        raise ValueError(f"unsupported molecular-weight elements: {unsupported_elements}")
    distances = [graph_distances(adjacency, start) for start in range(len(adjacency))]
    wiener = sum(
        distance
        for row in distances
        for distance in row
        if distance is not None
    ) // 2
    edges = [(node, neighbor) for node, neighbors in enumerate(adjacency) for neighbor in neighbors if node < neighbor]
    zagreb = sum(len(neighbors) ** 2 for neighbors in adjacency)
    with localcontext() as context:
        context.prec = 80
        randic = sum(
            Decimal(1) / Decimal(len(adjacency[a]) * len(adjacency[b])).sqrt()
            for a, b in edges
        )
        distance_sums = [sum(distance for distance in row if distance is not None) for row in distances]
        edge_sum = sum(
            Decimal(1) / Decimal(distance_sums[a] * distance_sums[b]).sqrt()
            for a, b in edges
            if distance_sums[a] > 0 and distance_sums[b] > 0
        )
        m = len(edges)
        n = len(adjacency)
        mu = m - n + 1
        balaban = Decimal(0) if mu + 1 == 0 else Decimal(m) / Decimal(mu + 1) * edge_sum
        molecular_weight = sum(ATOMIC_WEIGHTS[atom.GetSymbol()] for atom in molecule.GetAtoms())
    return {
        "molecular_weight": decimal_string(molecular_weight),
        "wiener_index": wiener,
        "randic_index": decimal_string(randic),
        "zagreb_m1": zagreb,
        "balaban_j": decimal_string(balaban),
    }


def write_tsv(path: Path, fieldnames: Sequence[str], rows: Iterable[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def verify_source(parquet_path: Path) -> pq.ParquetFile:
    if parquet_path.stat().st_size != DATASET_BYTES:
        raise ValueError(f"source byte count mismatch: {parquet_path.stat().st_size}")
    digest = sha256_file(parquet_path)
    if digest != DATASET_SHA256:
        raise ValueError(f"source SHA-256 mismatch: {digest}")
    parquet = pq.ParquetFile(parquet_path)
    metadata = parquet.metadata
    if metadata.num_rows != SOURCE_ROWS or metadata.num_row_groups != SOURCE_ROW_GROUPS:
        raise ValueError("source Parquet dimensions changed")
    schema = parquet.schema_arrow
    if schema.names != ["reaction_id", "reaction"]:
        raise ValueError(f"unexpected physical columns: {schema.names}")
    if schema.metadata is None or schema.metadata.get(b"ord.dataset_id", b"").decode() != DATASET_ID:
        raise ValueError("ORD dataset ID metadata mismatch")
    outcomes_descriptor = reaction_pb2.Reaction.DESCRIPTOR.fields_by_name["outcomes"]
    if outcomes_descriptor.number != OUTCOMES_FIELD_NUMBER:
        raise ValueError("ORD Reaction.outcomes field number changed")
    return parquet


def prepare(parquet_path: Path, output_dir: Path) -> dict[str, object]:
    parquet = verify_source(parquet_path)
    ligands: dict[str, LigandSource] = {}
    raw_memberships: list[RawMembership] = []
    blocks: dict[str, BlockAccumulator] = {}
    experiments: set[str] = set()
    outcome_envelopes_stripped = 0

    for batch in parquet.iter_batches(batch_size=1_024, columns=["reaction_id", "reaction"]):
        for row_index in range(batch.num_rows):
            reaction_id = batch.column(0)[row_index].as_py()
            raw_reaction = batch.column(1)[row_index].as_py()
            safe_bytes, stripped = strip_reaction_outcomes(raw_reaction)
            if stripped == 0:
                raise ValueError(f"{reaction_id}: no sealed outcomes envelope")
            outcome_envelopes_stripped += stripped
            reaction = reaction_pb2.Reaction()
            reaction.ParseFromString(safe_bytes)
            if reaction.reaction_id != reaction_id:
                raise ValueError(f"reaction ID mismatch for {reaction_id}")

            experiment = reaction_identifier(reaction, "experiment")
            sample_name = reaction_identifier(reaction, "Sample Name_x")
            coded_recipe = reaction_identifier(reaction, "coded recipe")
            subplate, well_row, well_column, position_id, position_format = parse_sample_position(
                sample_name
            )
            temperature = temperature_celsius(reaction)
            run_id = f"{experiment}|{temperature}"
            experiments.add(experiment)
            ligand_component = primary_component(reaction, "ligand soln", CATALYST_ROLE)
            ligand_id = compound_identifier(ligand_component, "CUSTOM")
            ligand_name = compound_identifier(ligand_component, "NAME")
            ligand_smiles = compound_identifier(ligand_component, "SMILES")
            if ligand_id is None or ligand_name is None:
                raise ValueError(f"{reaction_id}: incomplete ligand identity")
            canonical_smiles: str | None = None
            if ligand_id != "L_empty":
                if ligand_smiles is None:
                    raise ValueError(f"{reaction_id}: real ligand has no SMILES")
                canonical_smiles, _ = canonicalize_smiles(ligand_smiles)
                source = ligands.setdefault(canonical_smiles, LigandSource())
                source.ligand_ids.add(ligand_id)
                source.names.add(ligand_name)
                source.source_smiles.add(ligand_smiles)

            block_id = exact_non_ligand_block_id(reaction)
            block = blocks.get(block_id)
            if block is None:
                block = BlockAccumulator(
                    experiment=experiment,
                    electrophile_id=component_custom_id(reaction, "electrophile soln", REACTANT_ROLE),
                    nucleophile_id=component_custom_id(reaction, "nucleophile soln", REACTANT_ROLE),
                    catalyst_id=component_custom_id(reaction, "catalyst soln", CATALYST_ROLE),
                    base_id=component_custom_id(reaction, "base", REAGENT_ROLE),
                    temperature_c=temperature,
                    solvent_signature=solvent_signature(reaction),
                )
                blocks[block_id] = block
            if block.experiment != experiment:
                raise ValueError(f"block {block_id} crosses experiments")
            block.rows += 1
            block.ligand_ids.add(ligand_id)
            if ligand_id == "L_empty":
                block.no_ligand_rows += 1
            else:
                block.ligand_rows += 1
            raw_memberships.append(
                RawMembership(
                    reaction_id=reaction_id,
                    experiment=experiment,
                    block_id=block_id,
                    ligand_id=ligand_id,
                    canonical_smiles=canonical_smiles,
                    sample_name=sample_name,
                    coded_recipe=coded_recipe,
                    sample_subplate=subplate,
                    sample_well_row=well_row,
                    sample_well_column=well_column,
                    sample_position_id=position_id,
                    sample_position_format=position_format,
                    run_id=run_id,
                    coded_ligand_slot=coded_slot(coded_recipe, "L"),
                    coded_catalyst_slot=coded_slot(coded_recipe, "C"),
                    coded_base_slot=coded_slot(coded_recipe, "B"),
                    coded_electrophile_slot=coded_slot(coded_recipe, "E"),
                    coded_nucleophile_slot=coded_slot(coded_recipe, "N"),
                    record_created=reaction.provenance.record_created.time.value,
                    record_modified="|".join(
                        event.time.value for event in reaction.provenance.record_modified
                    ),
                )
            )

    real_ligand_ids = {ligand_id for source in ligands.values() for ligand_id in source.ligand_ids}
    eligible_smiles = {
        smiles for smiles in ligands if is_frozen_eligible(Chem.MolFromSmiles(smiles))
    }
    all_structure_ids = {
        smiles: hashlib.sha256(smiles.encode("utf-8")).hexdigest() for smiles in ligands
    }
    structure_ids = {smiles: hashlib.sha256(smiles.encode("utf-8")).hexdigest() for smiles in eligible_smiles}

    loaded_memberships = [
        membership for membership in raw_memberships if membership.canonical_smiles is not None
    ]
    eligible_memberships = [
        membership
        for membership in raw_memberships
        if membership.canonical_smiles is not None and membership.canonical_smiles in eligible_smiles
    ]
    for membership in eligible_memberships:
        structure_id = structure_ids[membership.canonical_smiles]
        block = blocks[membership.block_id]
        block.eligible_rows += 1
        block.eligible_structures.add(structure_id)

    if len(raw_memberships) != SOURCE_ROWS:
        raise ValueError(f"expected {SOURCE_ROWS} memberships, found {len(raw_memberships)}")
    if len(real_ligand_ids) != EXPECTED_REAL_LIGAND_IDS:
        raise ValueError(f"expected {EXPECTED_REAL_LIGAND_IDS} real ligand IDs, found {len(real_ligand_ids)}")
    if len(experiments) != EXPECTED_EXPERIMENTS:
        raise ValueError(f"expected {EXPECTED_EXPERIMENTS} experiments, found {len(experiments)}")
    if len(blocks) != EXPECTED_BLOCKS:
        raise ValueError(f"expected {EXPECTED_BLOCKS} blocks, found {len(blocks)}")
    ligand_blocks = [block for block in blocks.values() if block.ligand_rows > 0]
    no_ligand_blocks = [block for block in blocks.values() if block.no_ligand_rows > 0]
    if len(ligand_blocks) != EXPECTED_LIGAND_BLOCKS or len(no_ligand_blocks) != EXPECTED_LIGAND_BLOCKS:
        raise ValueError("ligand-loaded and no-ligand block counts changed")
    if any(block.rows != 47 or block.ligand_rows != 47 or block.no_ligand_rows != 0 for block in ligand_blocks):
        raise ValueError("ligand-loaded blocks do not contain exactly 47 rows")
    if any(block.rows != 1 or block.ligand_rows != 0 or block.no_ligand_rows != 1 for block in no_ligand_blocks):
        raise ValueError("no-ligand control blocks are not singleton rows")
    if len(eligible_smiles) != EXPECTED_ELIGIBLE_STRUCTURES:
        raise ValueError(f"expected {EXPECTED_ELIGIBLE_STRUCTURES} eligible structures, found {len(eligible_smiles)}")
    if len(eligible_memberships) != EXPECTED_ELIGIBLE_ROWS:
        raise ValueError(f"expected {EXPECTED_ELIGIBLE_ROWS} eligible rows, found {len(eligible_memberships)}")
    if len(loaded_memberships) != EXPECTED_LOADED_ROWS:
        raise ValueError(f"expected {EXPECTED_LOADED_ROWS} loaded rows, found {len(loaded_memberships)}")
    primary_blocks = {
        block_id
        for block_id, block in blocks.items()
        if len(block.eligible_structures) >= MIN_PANEL_SIZE
    }
    if len(primary_blocks) != EXPECTED_PRIMARY_BLOCKS:
        raise ValueError(f"expected {EXPECTED_PRIMARY_BLOCKS} primary blocks, found {len(primary_blocks)}")

    structure_coverage: dict[str, dict[str, set[str] | int]] = {
        structure_id: {"experiments": set(), "blocks": set(), "rows": 0}
        for structure_id in structure_ids.values()
    }
    for membership in eligible_memberships:
        structure_id = structure_ids[membership.canonical_smiles]
        coverage = structure_coverage[structure_id]
        coverage["experiments"].add(membership.experiment)
        coverage["blocks"].add(membership.block_id)
        coverage["rows"] += 1

    descriptor_fields = [
        "structure_id",
        "canonical_smiles",
        "ligand_ids",
        "ligand_names",
        "source_smiles",
        "s_tau_p_rh_tau5",
        "s_tau_p_free_tau5",
        "all_atom_count",
        "heavy_atom_count",
        "all_atom_edge_count",
        "molecular_weight",
        "wiener_index",
        "randic_index",
        "zagreb_m1",
        "balaban_j",
        "shell_r1",
        "shell_r2",
        "shell_r3",
        "shell_r4",
        "shell_r5",
        "ball_r1",
        "ball_r2",
        "ball_r3",
        "ball_r4",
        "ball_r5",
        "endpoint_support_rh_tau5",
        "endpoint_support_free_tau5",
        "branch_excess_r5",
        "mean_p_distance",
        "connected_components",
        "formal_charge",
        "p_total_h_count",
        "reaction_rows",
        "block_count",
        "experiment_count",
    ]
    descriptor_rows = []
    for smiles in sorted(eligible_smiles, key=lambda value: structure_ids[value]):
        structure_id = structure_ids[smiles]
        source = ligands[smiles]
        row: dict[str, object] = {
            "structure_id": structure_id,
            "canonical_smiles": smiles,
            "ligand_ids": "|".join(sorted(source.ligand_ids)),
            "ligand_names": "|".join(sorted(source.names)),
            "source_smiles": "|".join(sorted(source.source_smiles)),
        }
        row.update(descriptor_row(smiles))
        coverage = structure_coverage[structure_id]
        row["reaction_rows"] = coverage["rows"]
        row["block_count"] = len(coverage["blocks"])
        row["experiment_count"] = len(coverage["experiments"])
        descriptor_rows.append(row)

    block_fields = [
        "block_id",
        "experiment",
        "electrophile_id",
        "nucleophile_id",
        "catalyst_id",
        "base_id",
        "temperature_c",
        "solvent_signature",
        "rows",
        "ligand_rows",
        "no_ligand_rows",
        "unique_ligand_ids",
        "eligible_rows",
        "eligible_structures",
        "primary_included",
    ]
    block_rows = []
    for block_id, block in sorted(blocks.items()):
        block_rows.append(
            {
                "block_id": block_id,
                "experiment": block.experiment,
                "electrophile_id": block.electrophile_id,
                "nucleophile_id": block.nucleophile_id,
                "catalyst_id": block.catalyst_id,
                "base_id": block.base_id,
                "temperature_c": block.temperature_c,
                "solvent_signature": block.solvent_signature,
                "rows": block.rows,
                "ligand_rows": block.ligand_rows,
                "no_ligand_rows": block.no_ligand_rows,
                "unique_ligand_ids": len(block.ligand_ids),
                "eligible_rows": block.eligible_rows,
                "eligible_structures": len(block.eligible_structures),
                "primary_included": int(block_id in primary_blocks),
            }
        )

    membership_fields = [
        "reaction_id",
        "block_id",
        "experiment",
        "ligand_id",
        "structure_id",
        "sample_name",
        "coded_recipe",
        "sample_subplate",
        "sample_well_row",
        "sample_well_column",
        "sample_position_id",
        "sample_position_format",
        "run_id",
        "coded_ligand_slot",
        "coded_catalyst_slot",
        "coded_base_slot",
        "coded_electrophile_slot",
        "coded_nucleophile_slot",
        "record_created",
        "record_modified",
    ]
    def membership_row(membership: RawMembership) -> dict[str, object]:
        if membership.canonical_smiles is None:
            raise ValueError("loaded membership unexpectedly has no canonical structure")
        return {
            "reaction_id": membership.reaction_id,
            "block_id": membership.block_id,
            "experiment": membership.experiment,
            "ligand_id": membership.ligand_id,
            "structure_id": all_structure_ids[membership.canonical_smiles],
            "sample_name": membership.sample_name,
            "coded_recipe": membership.coded_recipe,
            "sample_subplate": membership.sample_subplate,
            "sample_well_row": membership.sample_well_row,
            "sample_well_column": membership.sample_well_column,
            "sample_position_id": membership.sample_position_id,
            "sample_position_format": membership.sample_position_format,
            "run_id": membership.run_id,
            "coded_ligand_slot": membership.coded_ligand_slot,
            "coded_catalyst_slot": membership.coded_catalyst_slot,
            "coded_base_slot": membership.coded_base_slot,
            "coded_electrophile_slot": membership.coded_electrophile_slot,
            "coded_nucleophile_slot": membership.coded_nucleophile_slot,
            "record_created": membership.record_created,
            "record_modified": membership.record_modified,
        }

    eligible_membership_rows = [
        membership_row(membership)
        for membership in sorted(eligible_memberships, key=lambda row: row.reaction_id)
    ]
    loaded_membership_rows = [
        membership_row(membership)
        for membership in sorted(loaded_memberships, key=lambda row: row.reaction_id)
    ]

    descriptors_path = output_dir / "ligand_descriptors.tsv"
    blocks_path = output_dir / "blocks.tsv"
    memberships_path = output_dir / "eligible_memberships.tsv"
    loaded_memberships_path = output_dir / "loaded_memberships.tsv"
    cohort_audit_path = output_dir / "cohort_audit.tsv"
    experiment_panels_path = output_dir / "experiment_panels.tsv"
    permutation_strata_path = output_dir / "permutation_strata.tsv"
    alias_audit_path = output_dir / "alias_audit.tsv"
    plate_layout_audit_path = output_dir / "plate_layout_audit.tsv"
    write_tsv(descriptors_path, descriptor_fields, descriptor_rows)
    write_tsv(blocks_path, block_fields, block_rows)
    write_tsv(memberships_path, membership_fields, eligible_membership_rows)
    write_tsv(loaded_memberships_path, membership_fields, loaded_membership_rows)

    cohort_audit_fields = [
        "structure_id",
        "canonical_smiles",
        "ligand_ids",
        "ligand_names",
        "status",
        "exclusion_reasons",
        "connected_components",
        "formal_charge",
        "phosphorus_count",
        "p_formal_charge",
        "p_total_h_count",
    ]
    cohort_audit_rows = []
    exclusion_histogram: collections.Counter[str] = collections.Counter()
    for smiles, source in sorted(ligands.items()):
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            raise ValueError(f"could not reparse cohort SMILES {smiles!r}")
        exclusions = eligibility_exclusions(molecule)
        exclusion_histogram.update(exclusions)
        phosphorus = [atom for atom in molecule.GetAtoms() if atom.GetAtomicNum() == 15]
        cohort_audit_rows.append(
            {
                "structure_id": hashlib.sha256(smiles.encode("utf-8")).hexdigest(),
                "canonical_smiles": smiles,
                "ligand_ids": "|".join(sorted(source.ligand_ids)),
                "ligand_names": "|".join(sorted(source.names)),
                "status": "excluded" if exclusions else "eligible",
                "exclusion_reasons": "|".join(exclusions),
                "connected_components": len(Chem.GetMolFrags(molecule)),
                "formal_charge": Chem.GetFormalCharge(molecule),
                "phosphorus_count": len(phosphorus),
                "p_formal_charge": phosphorus[0].GetFormalCharge() if len(phosphorus) == 1 else "",
                "p_total_h_count": phosphorus[0].GetTotalNumHs() if len(phosphorus) == 1 else "",
            }
        )
    write_tsv(cohort_audit_path, cohort_audit_fields, cohort_audit_rows)

    experiment_order = sorted(experiments)
    panel_counters: dict[str, dict[str, collections.Counter[str]]] = {
        experiment: collections.defaultdict(collections.Counter) for experiment in experiment_order
    }
    for membership in eligible_memberships:
        structure_id = structure_ids[membership.canonical_smiles]
        panel_counters[membership.experiment][membership.block_id][structure_id] += 1
    experiment_panels: dict[str, collections.Counter[str]] = {}
    experiment_panel_fields = [
        "experiment",
        "block_count",
        "eligible_rows_per_block",
        "eligible_structures",
        "rank_estimable",
        "panel_sha256",
        "structure_ids",
    ]
    experiment_panel_rows = []
    for experiment in experiment_order:
        counters = list(panel_counters[experiment].values())
        if not counters:
            raise ValueError(f"experiment {experiment} has no eligible ligand rows")
        if any(counter != counters[0] for counter in counters[1:]):
            raise ValueError(f"eligible panel changes across blocks in {experiment}")
        panel = counters[0]
        experiment_panels[experiment] = panel
        panel_encoding = json.dumps(sorted(panel.items()), separators=(",", ":"))
        experiment_panel_rows.append(
            {
                "experiment": experiment,
                "block_count": len(counters),
                "eligible_rows_per_block": sum(panel.values()),
                "eligible_structures": len(panel),
                "rank_estimable": int(len(panel) >= MIN_PANEL_SIZE),
                "panel_sha256": hashlib.sha256(panel_encoding.encode("utf-8")).hexdigest(),
                "structure_ids": "|".join(sorted(panel)),
            }
        )
    write_tsv(experiment_panels_path, experiment_panel_fields, experiment_panel_rows)

    incidence_strata: dict[tuple[int, ...], list[str]] = collections.defaultdict(list)
    for structure_id in sorted(structure_ids.values()):
        signature = tuple(experiment_panels[experiment].get(structure_id, 0) for experiment in experiment_order)
        incidence_strata[signature].append(structure_id)
    exact_panel_preserving_permutations = math.prod(
        math.factorial(len(members)) for members in incidence_strata.values()
    )
    structure_to_smiles = {structure_id: smiles for smiles, structure_id in structure_ids.items()}
    permutation_fields = [
        "structure_id",
        "ligand_ids",
        "incidence_signature",
        "stratum_id",
        "stratum_size",
        "globally_permutable",
    ]
    permutation_rows = []
    for signature, members in sorted(incidence_strata.items()):
        signature_text = "|".join(
            f"{experiment}:{count}" for experiment, count in zip(experiment_order, signature)
        )
        stratum_id = hashlib.sha256(signature_text.encode("utf-8")).hexdigest()
        for structure_id in sorted(members):
            source = ligands[structure_to_smiles[structure_id]]
            permutation_rows.append(
                {
                    "structure_id": structure_id,
                    "ligand_ids": "|".join(sorted(source.ligand_ids)),
                    "incidence_signature": signature_text,
                    "stratum_id": stratum_id,
                    "stratum_size": len(members),
                    "globally_permutable": int(len(members) > 1),
                }
            )
    write_tsv(permutation_strata_path, permutation_fields, sorted(permutation_rows, key=lambda row: row["structure_id"]))

    canonical_aliases = {smiles: source for smiles, source in ligands.items() if len(source.ligand_ids) > 1}
    alias_block_ids: dict[str, set[str]] = collections.defaultdict(set)
    alias_cooccurrence_block_ids: dict[str, set[str]] = collections.defaultdict(set)
    alias_ids_by_block: dict[tuple[str, str], set[str]] = collections.defaultdict(set)
    for membership in raw_memberships:
        if membership.canonical_smiles not in canonical_aliases:
            continue
        alias_block_ids[membership.canonical_smiles].add(membership.block_id)
        alias_ids_by_block[(membership.canonical_smiles, membership.block_id)].add(membership.ligand_id)
    for (smiles, block_id), ids in alias_ids_by_block.items():
        if len(ids) > 1:
            alias_cooccurrence_block_ids[smiles].add(block_id)
    alias_fields = [
        "structure_id",
        "canonical_smiles",
        "ligand_ids",
        "ligand_names",
        "eligible",
        "blocks_present",
        "blocks_alias_ids_cooccur",
    ]
    alias_rows = []
    for smiles, source in sorted(canonical_aliases.items()):
        alias_rows.append(
            {
                "structure_id": hashlib.sha256(smiles.encode("utf-8")).hexdigest(),
                "canonical_smiles": smiles,
                "ligand_ids": "|".join(sorted(source.ligand_ids)),
                "ligand_names": "|".join(sorted(source.names)),
                "eligible": int(smiles in eligible_smiles),
                "blocks_present": len(alias_block_ids[smiles]),
                "blocks_alias_ids_cooccur": len(alias_cooccurrence_block_ids[smiles]),
            }
        )
    write_tsv(alias_audit_path, alias_fields, alias_rows)

    eligible_placements: dict[tuple[str, str], list[RawMembership]] = collections.defaultdict(list)
    for membership in eligible_memberships:
        eligible_placements[(membership.experiment, structure_ids[membership.canonical_smiles])].append(
            membership
        )
    rows_by_structure: dict[str, set[int]] = collections.defaultdict(set)
    for (_, structure_id), memberships_for_structure in eligible_placements.items():
        rows_by_structure[structure_id].update(
            membership.sample_well_row for membership in memberships_for_structure
        )
    row_movers = {
        structure_id for structure_id, rows in rows_by_structure.items() if len(rows) >= 2
    }
    plate_layout_fields = [
        "experiment",
        "structure_id",
        "ligand_ids",
        "coded_ligand_slots",
        "sample_well_rows",
        "sample_position_ids",
        "run_ids",
        "reaction_rows",
        "blocks",
        "moves_across_slot_rows",
    ]
    plate_layout_rows = []
    for (experiment, structure_id), placement_rows in sorted(eligible_placements.items()):
        plate_layout_rows.append(
            {
                "experiment": experiment,
                "structure_id": structure_id,
                "ligand_ids": "|".join(sorted({row.ligand_id for row in placement_rows})),
                "coded_ligand_slots": "|".join(
                    sorted({row.coded_ligand_slot for row in placement_rows}, key=int)
                ),
                "sample_well_rows": "|".join(
                    str(value) for value in sorted({row.sample_well_row for row in placement_rows})
                ),
                "sample_position_ids": "|".join(
                    sorted({row.sample_position_id for row in placement_rows})
                ),
                "run_ids": "|".join(sorted({row.run_id for row in placement_rows})),
                "reaction_rows": len(placement_rows),
                "blocks": len({row.block_id for row in placement_rows}),
                "moves_across_slot_rows": int(structure_id in row_movers),
            }
        )
    write_tsv(plate_layout_audit_path, plate_layout_fields, plate_layout_rows)

    run_rows: dict[str, list[RawMembership]] = collections.defaultdict(list)
    for membership in raw_memberships:
        run_rows[membership.run_id].append(membership)
    if len(run_rows) != 33:
        raise ValueError(f"expected 33 experiment-temperature runs, found {len(run_rows)}")
    position_format_counts = collections.Counter(
        membership.sample_position_format for membership in raw_memberships
    )
    if position_format_counts != {"alpha": 29_184, "numeric": 21_504}:
        raise ValueError(f"sample position parser coverage changed: {position_format_counts}")
    if any(len(rows) != 1_536 for rows in run_rows.values()):
        raise ValueError("an experiment-temperature run does not contain 1,536 rows")
    if any(len({row.sample_position_id for row in rows}) != 1_536 for rows in run_rows.values()):
        raise ValueError("an experiment-temperature run does not cover 1,536 unique positions")
    temperatures_by_experiment: dict[str, set[str]] = collections.defaultdict(set)
    for run_id in run_rows:
        experiment, temperature = run_id.rsplit("|", 1)
        temperatures_by_experiment[experiment].add(temperature)
    if collections.Counter(map(len, temperatures_by_experiment.values())) != {1: 1, 2: 16}:
        raise ValueError("unexpected experiment temperature-run multiplicity")
    if len(temperatures_by_experiment["XZ-01-1"]) != 1:
        raise ValueError("XZ-01-1 is no longer the single-temperature experiment")
    repeated_position_assignments: dict[tuple[str, str], set[tuple[str, str]]] = collections.defaultdict(set)
    for membership in raw_memberships:
        repeated_position_assignments[(membership.experiment, membership.sample_position_id)].add(
            (membership.ligand_id, membership.coded_recipe)
        )
    if any(len(assignments) != 1 for assignments in repeated_position_assignments.values()):
        raise ValueError("ligand/coded-recipe assignment changes across repeated temperature runs")
    duplicate_coded_recipe_runs = {
        run_id: {
            recipe: count
            for recipe, count in collections.Counter(row.coded_recipe for row in rows).items()
            if count > 1
        }
        for run_id, rows in run_rows.items()
    }
    duplicate_coded_recipe_runs = {
        run_id: recipes for run_id, recipes in duplicate_coded_recipe_runs.items() if recipes
    }
    if len(eligible_placements) != 281 or len(row_movers) != 39:
        raise ValueError("eligible structure placement audit changed")
    if sum(structure_id in row_movers for _, structure_id in eligible_placements) != 266:
        raise ValueError("eligible mover structure-experiment membership count changed")

    unique_ligand_histogram = collections.Counter(len(block.ligand_ids) for block in blocks.values())
    eligible_histogram = collections.Counter(len(block.eligible_structures) for block in blocks.values())
    experiments_histogram = collections.Counter(block.experiment for block in blocks.values())
    freeze_directory = Path(__file__).resolve().parent
    freeze_input_names = (
        "CHEM-V9-Preregistration.md",
        "README.md",
        "chem_v9_evaluate.py",
        "chem_v9_prepare.py",
        "requirements.txt",
        "test_chem_v9_evaluate.py",
        "test_chem_v9_prepare.py",
    )
    summary: dict[str, object] = {
        "blindness": {
            "decoded_outcomes": 0,
            "outcome_field_number": OUTCOMES_FIELD_NUMBER,
            "outcome_envelopes_stripped_without_payload_decode": outcome_envelopes_stripped,
            "physical_parquet_columns": ["reaction_id", "reaction"],
        },
        "cohort": {
            "source_rows": len(raw_memberships),
            "real_ligand_ids": len(real_ligand_ids),
            "canonical_ligand_structures": len(ligands),
            "eligible_structures": len(eligible_smiles),
            "eligible_rows": len(eligible_memberships),
            "loaded_rows": len(loaded_memberships),
            "experiments": len(experiments),
            "primary_experiments": sum(
                len(panel) >= MIN_PANEL_SIZE for panel in experiment_panels.values()
            ),
            "blocks": len(blocks),
            "ligand_loaded_blocks": len(ligand_blocks),
            "no_ligand_control_blocks": len(no_ligand_blocks),
            "exclusion_reason_counts": dict(sorted(exclusion_histogram.items())),
            "primary_blocks_minimum_nine_structures": len(primary_blocks),
            "blocks_by_experiment": dict(sorted(experiments_histogram.items())),
            "unique_ligand_ids_per_block_histogram": {
                str(key): value for key, value in sorted(unique_ligand_histogram.items())
            },
            "eligible_structures_per_block_histogram": {
                str(key): value for key, value in sorted(eligible_histogram.items())
            },
            "panel_preserving_permutation_strata": len(incidence_strata),
            "panel_preserving_permutable_structures": sum(
                len(members) for members in incidence_strata.values() if len(members) > 1
            ),
            "panel_preserving_exact_permutations": exact_panel_preserving_permutations,
            "canonical_alias_structures": len(canonical_aliases),
            "alias_structures_cooccurring_within_any_block": sum(
                bool(blocks) for blocks in alias_cooccurrence_block_ids.values()
            ),
        },
        "plate_layout": {
            "all_source_positions_parsed": len(raw_memberships),
            "alpha_position_rows": sum(
                row.sample_position_format == "alpha" for row in raw_memberships
            ),
            "numeric_position_rows": sum(
                row.sample_position_format == "numeric" for row in raw_memberships
            ),
            "experiment_temperature_runs": len(run_rows),
            "rows_per_run": 1_536,
            "unique_positions_per_run": 1_536,
            "experiments_with_one_temperature": sorted(
                experiment
                for experiment, temperatures in temperatures_by_experiment.items()
                if len(temperatures) == 1
            ),
            "experiments_with_two_temperatures": sum(
                len(temperatures) == 2 for temperatures in temperatures_by_experiment.values()
            ),
            "assignment_constant_across_repeated_temperature_runs": True,
            "eligible_structure_experiment_memberships": len(eligible_placements),
            "eligible_structures_moving_across_slot_rows": len(row_movers),
            "mover_structure_experiment_memberships": sum(
                structure_id in row_movers for _, structure_id in eligible_placements
            ),
            "stationary_eligible_structures": len(eligible_smiles) - len(row_movers),
            "coded_recipe_duplicate_runs": duplicate_coded_recipe_runs,
            "known_coded_recipe_anomaly_reaction_id": "ord-1649402b9d164b50b298f00e1df91351",
            "known_anomaly_impacts_primary_cohort": False,
            "randomization_documented": False,
        },
        "descriptor": {
            "primary": "unweighted endpoint entropy at P in standardized Rh(CO)(H)(L)",
            "secondary_non_rescue": "unweighted endpoint entropy at P in free ligand component",
            "tau": TAU,
            "minimum_panel_size": MIN_PANEL_SIZE,
            "entropy_log_base": 2,
            "propagation_arithmetic": "exact rational",
            "entropy_arithmetic": "Decimal precision 80; output quantized to 12 places",
        },
        "files": {
            "blocks.tsv": sha256_file(blocks_path),
            "alias_audit.tsv": sha256_file(alias_audit_path),
            "cohort_audit.tsv": sha256_file(cohort_audit_path),
            "eligible_memberships.tsv": sha256_file(memberships_path),
            "loaded_memberships.tsv": sha256_file(loaded_memberships_path),
            "experiment_panels.tsv": sha256_file(experiment_panels_path),
            "ligand_descriptors.tsv": sha256_file(descriptors_path),
            "plate_layout_audit.tsv": sha256_file(plate_layout_audit_path),
            "permutation_strata.tsv": sha256_file(permutation_strata_path),
        },
        "freeze_inputs": {
            name: sha256_file(freeze_directory / name) for name in freeze_input_names
        },
        "source": {
            "dataset_id": DATASET_ID,
            "parquet_bytes": DATASET_BYTES,
            "parquet_sha256": DATASET_SHA256,
            "row_groups": SOURCE_ROW_GROUPS,
        },
        "toolchain": {
            "ord_schema": __import__("importlib.metadata").metadata.version("ord-schema"),
            "numpy": __import__("numpy").__version__,
            "protobuf": __import__("google.protobuf").protobuf.__version__,
            "pyarrow": pyarrow.__version__,
            "python": sys.version.split()[0],
            "rdkit": rdkit.__version__,
        },
    }
    summary_path = output_dir / "extraction_summary.json"
    with summary_path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(summary, handle, indent=2, sort_keys=True, ensure_ascii=False)
        handle.write("\n")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("parquet", type=Path, help="official ORD Parquet file")
    parser.add_argument("output_dir", type=Path, help="directory for target-free frozen artifacts")
    arguments = parser.parse_args()
    summary = prepare(arguments.parquet, arguments.output_dir)
    print(json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
