#!/usr/bin/env python3

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import chem_v10_evaluate as evaluate


class RequiredSlotCrossfitTests(unittest.TestCase):
    def test_training_rank_uses_every_loaded_row_but_scores_only_required_slots(self) -> None:
        memberships = [
            evaluate.v9.Membership("a1", "b1", "e1", "a", 1, 1),
            evaluate.v9.Membership("a2", "b1", "e1", "b", 2, 2),
            evaluate.v9.Membership("a3", "b1", "e1", "c", 3, 3),
            evaluate.v9.Membership("b1", "b2", "e2", "a", 1, 1),
            evaluate.v9.Membership("b2", "b2", "e2", "b", 2, 2),
            evaluate.v9.Membership("b3", "b2", "e2", "c", 3, 3),
        ]
        scores = evaluate.crossfit_required_slot_rank_percentiles(
            memberships,
            {"a1": 3.0, "a2": 2.0, "a3": 1.0, "b1": 2.0, "b2": 1.0, "b3": 3.0},
            {"b1": "e1", "b2": "e2"},
            {"e1": {1}, "e2": {1}},
            expected_rows_per_block=3,
        )
        self.assertEqual(scores, {"e1": {1: 0.5}, "e2": {1: 1.0}})

    def test_unrequired_training_only_slot_is_not_a_coverage_failure(self) -> None:
        memberships = [
            evaluate.v9.Membership("a", "b1", "e1", "a", 1, 1),
            evaluate.v9.Membership("b", "b2", "e2", "b", 1, 1),
            evaluate.v9.Membership("x", "b3", "e3", "x", 48, 1),
        ]
        scores = evaluate.crossfit_required_slot_rank_percentiles(
            memberships,
            {"a": 1.0, "b": 2.0, "x": 3.0},
            {"b1": "e1", "b2": "e2", "b3": "e3"},
            {"e1": {1}, "e2": {1}},
            expected_rows_per_block=1,
        )
        self.assertEqual(set(scores), {"e1", "e2"})
        self.assertNotIn(48, scores["e1"])

    def test_held_out_outcomes_cannot_change_held_out_slot_scores(self) -> None:
        memberships = [
            evaluate.v9.Membership("a1", "b1", "e1", "a", 1, 1),
            evaluate.v9.Membership("a2", "b1", "e1", "b", 2, 2),
            evaluate.v9.Membership("a3", "b1", "e1", "c", 3, 3),
            evaluate.v9.Membership("b1", "b2", "e2", "a", 1, 1),
            evaluate.v9.Membership("b2", "b2", "e2", "b", 2, 2),
            evaluate.v9.Membership("b3", "b2", "e2", "c", 3, 3),
        ]
        first = {"a1": 1.0, "a2": 2.0, "a3": 3.0, "b1": 3.0, "b2": 2.0, "b3": 1.0}
        changed_held_out = {**first, "a1": 30.0, "a2": -20.0, "a3": 10.0}
        arguments = (
            memberships,
            {"b1": "e1", "b2": "e2"},
            {"e1": {1, 2}, "e2": {1, 2}},
        )
        before = evaluate.crossfit_required_slot_rank_percentiles(
            arguments[0], first, arguments[1], arguments[2], expected_rows_per_block=3
        )
        after = evaluate.crossfit_required_slot_rank_percentiles(
            arguments[0], changed_held_out, arguments[1], arguments[2], expected_rows_per_block=3
        )
        self.assertEqual(before["e1"], after["e1"])

    def test_wrong_row_count_and_repeated_slot_fail(self) -> None:
        wrong_count = [
            evaluate.v9.Membership("a", "b", "e", "a", 1, 1),
            evaluate.v9.Membership("b", "b", "e", "b", 2, 2),
        ]
        with self.assertRaisesRegex(ValueError, "does not have 3 rows"):
            evaluate.crossfit_required_slot_rank_percentiles(
                wrong_count,
                {"a": 1.0, "b": 2.0},
                {"b": "e"},
                {},
                expected_rows_per_block=3,
            )
        repeated_slot = [
            evaluate.v9.Membership("a", "b", "e", "a", 1, 1),
            evaluate.v9.Membership("b", "b", "e", "b", 1, 2),
        ]
        with self.assertRaisesRegex(ValueError, "repeats a coded ligand slot"):
            evaluate.crossfit_required_slot_rank_percentiles(
                repeated_slot,
                {"a": 1.0, "b": 2.0},
                {"b": "e"},
                {},
                expected_rows_per_block=2,
            )

    def test_missing_required_slot_still_fails(self) -> None:
        memberships = [evaluate.v9.Membership("a", "b1", "e1", "a", 1, 1)]
        with self.assertRaisesRegex(ValueError, "required slot 1"):
            evaluate.crossfit_required_slot_rank_percentiles(
                memberships,
                {"a": 1.0},
                {"b1": "e1"},
                {"e1": {1}},
                expected_rows_per_block=1,
            )


class FrozenArtifactPreflightTests(unittest.TestCase):
    def test_real_frozen_artifacts_have_complete_required_coverage(self) -> None:
        frozen = HERE.parent / "chem_v9" / "frozen"
        report = evaluate.target_free_slot_preflight(frozen)
        self.assertTrue(report["pass"])
        self.assertEqual(report["required_missing_total"], 0)
        self.assertEqual(report["loaded_memberships"], 49_632)
        self.assertEqual(report["duplicate_loaded_reaction_ids"], 0)
        self.assertEqual(report["loaded_blocks"], 1_056)
        self.assertEqual(report["primary_blocks"], 864)
        self.assertEqual(report["malformed_47_row_loaded_blocks"], {})
        self.assertEqual(report["primary_panel_mapping_changes"], {})
        self.assertEqual(report["globally_observed_but_not_required"], [48])
        self.assertEqual(
            report["anomalous_slot_blocks"],
            [
                {
                    "block_id": "00ab912e0eff6a901dbc3314af67dd92b65640918126f7036976b4f64a90b0c8",
                    "experiment": "XZ-01-1",
                    "missing_standard_slots": [16],
                    "extra_slots": [48],
                }
            ],
        )
        self.assertEqual(
            report["slot_48_audit"],
            {
                "globally_observed": True,
                "required_by_any_primary_experiment": False,
                "loaded_rows": 1,
                "source_experiments": ["XZ-01-1"],
            },
        )
        self.assertTrue(
            all(
                not row["missing_required_training_slots"]
                for row in report["coverage_by_held_out_experiment"].values()
            )
        )
        self.assertEqual(
            min(
                row["minimum_training_rows_per_required_slot"]
                for row in report["coverage_by_held_out_experiment"].values()
            ),
            991,
        )

    def test_real_frozen_shape_prepares_with_synthetic_targets(self) -> None:
        frozen = HERE.parent / "chem_v9" / "frozen"
        loaded = evaluate.v9.load_memberships(frozen / "loaded_memberships.tsv")
        with tempfile.TemporaryDirectory() as directory:
            targets = Path(directory) / "synthetic_targets.tsv"
            evaluate.v9.write_tsv(
                targets,
                ("reaction_id", "yield_percentage"),
                (
                    {
                        "reaction_id": row.reaction_id,
                        "yield_percentage": (index * 37) % 101,
                    }
                    for index, row in enumerate(loaded)
                ),
            )
            prepared = evaluate.load_prepared(
                frozen,
                targets,
                enforce_frozen_shape=False,
            )
        self.assertEqual(prepared.loaded_membership_count, 49_632)
        self.assertEqual(prepared.primary_block_count, 864)
        self.assertEqual(len(prepared.experiments), 14)
        self.assertTrue(
            all(
                len(experiment.crossfit_slot_rank_percentiles)
                == len(experiment.panel_indices)
                for experiment in prepared.experiments
            )
        )


if __name__ == "__main__":
    unittest.main()
