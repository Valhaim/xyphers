# CHEM-V10 pre-statistic mechanical repair

CHEM-V10 reuses the hash-verified CHEM-V9 frozen feature artifacts and unchanged inferential core. Its sole change is explicit in `crossfit_required_slot_rank_percentiles`: each held-out experiment requests only the coded slots in its eligible primary panel, while every training block is still ranked over all 47 loaded rows.

Run the target-free preflight and tests before freezing:

```bash
uv run --with-requirements research/chemistry/validation/chem_v10/requirements.txt \
  python research/chemistry/validation/chem_v10/chem_v10_evaluate.py preflight \
  research/chemistry/validation/chem_v9/frozen \
  research/chemistry/validation/chem_v10/frozen/required_slot_preflight.json

uv run --with-requirements research/chemistry/validation/chem_v10/requirements.txt \
  python -m unittest -v \
  research/chemistry/validation/chem_v10/test_chem_v10_evaluate.py
```

Do not run the `evaluate` subcommand until the V10 code, preregistration, preflight, tests, and manifest are committed and pushed. CHEM-V10 is post-reveal, pre-statistic, target-independent repaired corroboration—not a pristine confirmation. Before this freeze, only the target-table header and two reaction-ID-sorted zero-yield rows had been displayed; no target distribution or hypothesis statistic had been inspected.
