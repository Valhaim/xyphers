# Xypher Calorimeter manifest tool

This standalone crate freezes and validates the Calorimeter's pre-execution
identities. It handles canonical JSON, fixture and policy validation, source
and artifact set hashes, a frozen generic reporting policy, schedule
expansion, episode nonces, and the two-stage manifest.

It deliberately contains no allocation-kernel analysis, path-count engine,
eigenvalue solver, action sampler, trajectory runner, or empirical result
schema.

From the repository root:

```sh
cargo run --manifest-path research/physics/xypher-calorimeter-manifest/Cargo.toml -- validate-inputs
cargo run --manifest-path research/physics/xypher-calorimeter-manifest/Cargo.toml -- print-schedule
cargo run --manifest-path research/physics/xypher-calorimeter-manifest/Cargo.toml -- print-implementation-sources
```

The manifest generators require explicit canonical freeze metadata:

```sh
cargo run --manifest-path research/physics/xypher-calorimeter-manifest/Cargo.toml -- \
  generate-core research/physics/derivable/xypher-calorimeter-core-freeze-metadata.json \
  research/physics/derivable/xypher-calorimeter-manifest-core.json

cargo run --manifest-path research/physics/xypher-calorimeter-manifest/Cargo.toml -- \
  generate-final research/physics/derivable/xypher-calorimeter-final-freeze-metadata.json \
  research/physics/derivable/xypher-calorimeter-manifest.json
```

Those two output files are intentionally not generated until their commits,
trees, toolchains, sources, and binaries are final. Both commands require the
exact canonical repository output path and refuse to replace any existing
file, symlink, or other destination.

Core freeze metadata uses the shape below. This is intentionally schematic:
the authoritative required path contracts are the
`*_REQUIRED_SOURCE_PATHS` constants in `src/lib.rs`, and the release dep-info
closure is independently checked against the top-level implementation union.
All path arrays must already be unique and byte-lexicographically sorted.

Component source sets are disjoint semantic ownership partitions. They are
not claimed to be standalone compilation closures. The top-level
`implementation_source_paths` union is load-bearing and must contain every
component source, every repository-local release dep-info input, local and
workspace Cargo manifests, all four lockfiles, development compatibility
sources, controls, and the build/freeze/audit ceremony.

`actor`, `analysis`, `manifest`, and `observer` each require one distinct
binary artifact. They and the build receipt must share the exact target-triple
directory committed at artifact freeze `A`; the claim artifact set is empty.
For the Apple target, every executable must retain exactly one normalized,
component-unique Mach-O UUID under the
`content-hash-linker-generated-required` policy. Flags containing `no_uuid` or
`random_uuid` are rejected. Each component receipt must also bind a sanitized
load probe using the exact argument `--xypher-calorimeter-load-probe`, exit
code `2`, and the SHA-256 of its exact combined stdout/stderr bytes. The build
script additionally requires those bytes to begin with `usage:\n`; the
no-execution Git audit validates the typed receipt and the UUID extracted from
each committed binary.

```json
{
  "artifact_freeze": {
    "commit": "artifact commit A",
    "tree": "tree of A"
  },
  "build_receipt_path": "research/physics/xypher-calorimeter-apparatus/aarch64-apple-darwin/xypher-calorimeter-build-receipt.json",
  "components": {
    "actor": {
      "artifact_paths": [
        "research/physics/xypher-calorimeter-apparatus/aarch64-apple-darwin/xypher-calorimeter-runner"
      ],
      "source_paths": [
        "exact sorted ACTOR_REQUIRED_SOURCE_PATHS"
      ]
    },
    "analysis": {
      "artifact_paths": [
        "research/physics/xypher-calorimeter-apparatus/aarch64-apple-darwin/xypher-calorimeter-analysis"
      ],
      "source_paths": [
        "exact sorted ANALYSIS_REQUIRED_SOURCE_PATHS"
      ]
    },
    "claim": {
      "artifact_paths": [],
      "source_paths": [
        "exact sorted CLAIM_REQUIRED_SOURCE_PATHS, including CAL-CTRL-1"
      ]
    },
    "manifest": {
      "artifact_paths": [
        "research/physics/xypher-calorimeter-apparatus/aarch64-apple-darwin/xypher-calorimeter-manifest"
      ],
      "source_paths": [
        "exact sorted MANIFEST_REQUIRED_SOURCE_PATHS"
      ]
    },
    "observer": {
      "artifact_paths": [
        "research/physics/xypher-calorimeter-apparatus/aarch64-apple-darwin/xypher-calorimeter-observer"
      ],
      "source_paths": [
        "exact sorted OBSERVER_REQUIRED_SOURCE_PATHS"
      ]
    }
  },
  "implementation_freeze": {
    "commit": "implementation commit F",
    "toolchains": {
      "cargo": "verbatim cargo -Vv identity",
      "clang": "verbatim clang identity",
      "clt": "Command Line Tools package identity",
      "ld": "verbatim ld identity",
      "linker": "verbatim configured-linker identity",
      "rust_std": "file-count:tree-sha256",
      "rustc": "verbatim rustc -Vv identity",
      "sdk": "sdk-version:sdk-build-version",
      "target": "aarch64-apple-darwin"
    },
    "tree": "tree of F"
  },
  "implementation_source_paths": [
    "complete exact sorted implementation-source union"
  ],
  "preregistration": {
    "commit": "6e5702b0b33f59c82fde67d075a12907cc76d697",
    "path": "research/physics/derivable/xypher-calorimeter.md"
  },
  "schema": "xypher-calorimeter-core-freeze-metadata.v1"
}
```

Final freeze metadata is smaller:

```json
{
  "core_commit": "40 hexadecimal characters",
  "schema": "xypher-calorimeter-final-freeze-metadata.v1"
}
```

The core directly binds
`research/physics/xypher-calorimeter-genesis-recipe.json` by raw file identity
and hash. It also directly binds
`research/physics/xypher-calorimeter-reporting-policy.json`, including
predeclared aggregation coordinates, simultaneous confidence intervals,
controls, numeric output, and the prohibition on optional stopping. Its 99%
Hoeffding-union bands are conditional-iid pseudorandom reference diagnostics,
not acceptance evidence for correlated within-episode Markov exposures.
Acceptance requires all 1,536 journal-external actor seals and all 93,696
exact decision joins. These seals are produced outside the journal/replay
path by the frozen runner; they are not independent remote witnesses.

Prediction runs occur only after the final manifest is committed and pushed,
and their outputs must be committed and pushed before the first actor
execution. A load-bearing mismatch restarts the implementation freeze,
manifest core, and final manifest. Partition reports are restricted to exact
stationary/transient left-inventory marginals and their mean, variance, and
entropy; they are not contact, current, or temperature claims.

The recipe fixes clean `ProtocolConfig::default` construction,
CAL-MAN-1 relabelled initial balances, all-zero protocol `GENESIS_HASH`, one
validator, an epoch size of 82, and the identity derivation domains.

The final manifest derives both `chain_id` and the Ed25519 validator key from
the raw core hash. No manual execution identity can drift from the file that
also seeds the episode nonces.

`genesis_recipe_hash` is not a ledger-state hash: initial allocations differ
across the schedule. Each episode journal must separately bind and verify its
actual `genesis_ledger_state_hash`; the manifest descriptor already binds the
episode's relabelled initial kernel view.

Artifact paths are accepted only under
`research/physics/xypher-calorimeter-apparatus/`. Release binaries must be
copied there and committed before core generation; ignored `target/` paths are
not reproducible freeze artifacts. The core separately binds source freeze
`F`, artifact freeze `A`, the canonical dual-build receipt, and the complete
implementation source union. Every hashed source and artifact must be a
regular file reached without a symlink in any relative path component, and its
canonical target must remain inside the canonical repository root with exactly
the same slash-joined spelling. Empty path components, doubled separators,
interior `.`, trailing separators, and case-fold aliases are rejected.

`generate-core` and `generate-final` additionally hash the running executable
and require it to match the sole frozen `xypher-calorimeter-manifest` artifact.
The freeze commands should therefore be invoked through the committed
apparatus binary, not an unbound development build.

The tool validates commit and tree fields as canonical lowercase Git object
IDs, but intentionally does not invoke Git. The freeze procedure must also
verify that each named commit exists, that
`git rev-parse <commit>^{tree}` equals the recorded tree, and that the committed
bytes of every source and apparatus path match the raw and set identities.
Before final generation, it must verify that `core_commit` contains the exact
canonical manifest-core bytes at `MANIFEST_CORE_PATH`.

The committed scripts described in
`scripts/README-xypher-calorimeter-freeze.md` implement the clean dual build
and the independent Git-object audit. The manifest also parses the canonical
build recipe and receipt, requires two byte-identical default-feature release
builds, checks the receipt's repository-local dep-info closure against the
implementation union, cross-checks the exact toolchain summary, rejects the
falsified no-UUID artifact policy, and requires typed UUID and load-probe
evidence for all four executables. The breaking recipe, record, and receipt
contracts use their respective `v2` schemas; core and final manifests remain
`v1`.

Metadata supplied to the commands must itself be compact canonical JSON with
lexicographic object keys and exactly one trailing LF. Floats, nulls,
non-ASCII strings, duplicate keys, empirical fields, and result fields are
rejected. The formatted examples above are illustrative; convert a prepared
file into the required byte form before using it:

```sh
cargo run --manifest-path research/physics/xypher-calorimeter-manifest/Cargo.toml -- \
  canonicalize core-freeze-metadata.pretty.json \
  research/physics/derivable/xypher-calorimeter-core-freeze-metadata.json
cargo run --manifest-path research/physics/xypher-calorimeter-manifest/Cargo.toml -- \
  canonicalize final-freeze-metadata.pretty.json \
  research/physics/derivable/xypher-calorimeter-final-freeze-metadata.json
```

Conventional raw-byte SHA-256 sidecars can be written and checked with:

```sh
cargo run --manifest-path research/physics/xypher-calorimeter-manifest/Cargo.toml -- \
  write-sidecar research/physics/xypher-calorimeter-fixtures.json
cargo run --manifest-path research/physics/xypher-calorimeter-manifest/Cargo.toml -- \
  validate-sidecar research/physics/xypher-calorimeter-fixtures.json \
  research/physics/xypher-calorimeter-fixtures.json.sha256
```
