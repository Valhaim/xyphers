#![forbid(unsafe_code)]

use std::env;
use std::fs;
use std::path::{Path, PathBuf};

use xypher_calorimeter_manifest::{
    artifact_set_identity, canonical_json_bytes, default_sidecar_path, expand_schedule,
    raw_file_identity, read_canonical_json, read_canonical_manifest_core,
    required_implementation_source_paths, source_set_identity, validate_canonical_json,
    validate_core_manifest, validate_final_manifest, validate_hash_sidecar, validate_inputs,
    write_canonicalized_json, write_core_manifest, write_final_manifest, write_hash_sidecar,
    FixtureCatalog, PolicyConfig, Result, FIXTURE_CATALOG_PATH, POLICY_CONFIG_PATH,
};

fn usage() -> &'static str {
    "usage:
  xypher-calorimeter-manifest validate-inputs
  xypher-calorimeter-manifest validate-canonical <path>
  xypher-calorimeter-manifest canonicalize <input.json> <output.json>
  xypher-calorimeter-manifest hash-file <path>
  xypher-calorimeter-manifest hash-source-set <set-name> <path>...
  xypher-calorimeter-manifest hash-artifact-set <set-name> <path>...
  xypher-calorimeter-manifest print-schedule
  xypher-calorimeter-manifest print-implementation-sources
  xypher-calorimeter-manifest generate-core <canonical-core-freeze-metadata.json> <canonical-core-output.json>
  xypher-calorimeter-manifest validate-core <manifest-core.json>
  xypher-calorimeter-manifest generate-final <canonical-final-freeze-metadata.json> <canonical-final-output.json>
  xypher-calorimeter-manifest validate-final <final-manifest.json>
  xypher-calorimeter-manifest write-sidecar <path> [output.sha256]
  xypher-calorimeter-manifest validate-sidecar <path> <sidecar.sha256>"
}

fn require_arg(args: &mut impl Iterator<Item = String>, label: &str) -> Result<String> {
    args.next().ok_or_else(|| {
        xypher_calorimeter_manifest::ManifestError::new(format!(
            "missing required argument: {label}"
        ))
    })
}

fn no_extra(args: &mut impl Iterator<Item = String>) -> Result<()> {
    if let Some(extra) = args.next() {
        Err(xypher_calorimeter_manifest::ManifestError::new(format!(
            "unexpected argument: {extra}"
        )))
    } else {
        Ok(())
    }
}

fn print_json<T: serde::Serialize>(value: &T) -> Result<()> {
    print!(
        "{}",
        String::from_utf8(canonical_json_bytes(value)?).map_err(|error| {
            xypher_calorimeter_manifest::ManifestError::new(error.to_string())
        })?
    );
    Ok(())
}

fn run() -> Result<()> {
    let root = Path::new(".");
    let mut args = env::args().skip(1);
    let command = args
        .next()
        .ok_or_else(|| xypher_calorimeter_manifest::ManifestError::new(usage()))?;
    match command.as_str() {
        "validate-inputs" => {
            no_extra(&mut args)?;
            validate_inputs(root)?;
            println!(
                "validated frozen catalog, actor policy, reporting policy, claim contract, genesis recipe, v2 build recipe, and 1536-episode schedule"
            );
        }
        "validate-canonical" => {
            let path = require_arg(&mut args, "path")?;
            no_extra(&mut args)?;
            validate_canonical_json(&fs::read(path)?)?;
            println!("canonical");
        }
        "canonicalize" => {
            let input = require_arg(&mut args, "input.json")?;
            let output = require_arg(&mut args, "output.json")?;
            no_extra(&mut args)?;
            write_canonicalized_json(Path::new(&input), Path::new(&output))?;
            println!("{output}");
        }
        "hash-file" => {
            let path = require_arg(&mut args, "path")?;
            no_extra(&mut args)?;
            print_json(&raw_file_identity(root, &path)?)?;
        }
        "hash-source-set" | "hash-artifact-set" => {
            let set_name = require_arg(&mut args, "set-name")?;
            let paths = args.collect::<Vec<_>>();
            if paths.is_empty() {
                return Err(xypher_calorimeter_manifest::ManifestError::new(
                    "at least one path is required",
                ));
            }
            let identity = if command == "hash-source-set" {
                source_set_identity(root, &set_name, &paths)?
            } else {
                artifact_set_identity(root, &set_name, &paths)?
            };
            print_json(&identity)?;
        }
        "print-schedule" => {
            no_extra(&mut args)?;
            let catalog: FixtureCatalog =
                read_canonical_json(&PathBuf::from(FIXTURE_CATALOG_PATH))?;
            let policy: PolicyConfig = read_canonical_json(&PathBuf::from(POLICY_CONFIG_PATH))?;
            print_json(&expand_schedule(&catalog, &policy)?)?;
        }
        "print-implementation-sources" => {
            no_extra(&mut args)?;
            print_json(&required_implementation_source_paths())?;
        }
        "generate-core" => {
            let metadata = require_arg(&mut args, "freeze-metadata.json")?;
            let output = require_arg(&mut args, "output.json")?;
            no_extra(&mut args)?;
            let manifest = write_core_manifest(root, Path::new(&metadata), Path::new(&output))?;
            println!(
                "wrote {} episodes and {} decisions to {}",
                manifest.schedule.episode_count, manifest.schedule.decision_count, output
            );
        }
        "validate-core" => {
            let path = require_arg(&mut args, "manifest-core.json")?;
            no_extra(&mut args)?;
            let manifest = validate_core_manifest(root, &fs::read(path)?)?;
            println!(
                "validated {} episodes and {} decisions",
                manifest.schedule.episode_count, manifest.schedule.decision_count
            );
        }
        "generate-final" => {
            let metadata = require_arg(&mut args, "final-freeze-metadata.json")?;
            let output = require_arg(&mut args, "output.json")?;
            no_extra(&mut args)?;
            let manifest = write_final_manifest(root, Path::new(&metadata), Path::new(&output))?;
            println!(
                "wrote {} unique episode nonces to {}",
                manifest.schedule.episode_count, output
            );
        }
        "validate-final" => {
            let path = require_arg(&mut args, "final-manifest.json")?;
            no_extra(&mut args)?;
            let core = read_canonical_manifest_core(root)?;
            let manifest = validate_final_manifest(root, &core, &fs::read(path)?)?;
            println!(
                "validated {} unique episode nonces",
                manifest.schedule.episode_count
            );
        }
        "write-sidecar" => {
            let target = PathBuf::from(require_arg(&mut args, "path")?);
            let output = match args.next() {
                Some(path) => PathBuf::from(path),
                None => default_sidecar_path(&target)?,
            };
            no_extra(&mut args)?;
            write_hash_sidecar(&target, &output)?;
            println!("{}", output.display());
        }
        "validate-sidecar" => {
            let target = PathBuf::from(require_arg(&mut args, "path")?);
            let sidecar = PathBuf::from(require_arg(&mut args, "sidecar.sha256")?);
            no_extra(&mut args)?;
            validate_hash_sidecar(&target, &sidecar)?;
            println!("valid");
        }
        _ => {
            return Err(xypher_calorimeter_manifest::ManifestError::new(usage()));
        }
    }
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("{error}");
        std::process::exit(2);
    }
}
