#![forbid(unsafe_code)]

use std::collections::{BTreeMap, BTreeSet};
use std::ffi::OsStr;
use std::fmt;
use std::fs::{self, File, OpenOptions};
use std::io::{self, Write};
use std::path::{Component, Path, PathBuf};

use ed25519_dalek::SigningKey;
use serde::de::{MapAccess, SeqAccess, Visitor};
use serde::{Deserialize, Deserializer, Serialize};
use sha2::{Digest, Sha256};

pub const FIXTURE_CATALOG_PATH: &str = "research/physics/xypher-calorimeter-fixtures.json";
pub const POLICY_CONFIG_PATH: &str = "research/physics/xypher-calorimeter-policy-config.json";
pub const REPORTING_POLICY_PATH: &str = "research/physics/xypher-calorimeter-reporting-policy.json";
pub const CLAIM_CONTRACT_PATH: &str = "research/physics/xypher-calorimeter-claim-contract.json";
pub const GENESIS_RECIPE_PATH: &str = "research/physics/xypher-calorimeter-genesis-recipe.json";
pub const PREREGISTRATION_PATH: &str = "research/physics/derivable/xypher-calorimeter.md";
pub const REPORTING_AMENDMENT_PATH: &str =
    "research/physics/derivable/xypher-calorimeter-amendment-cal-man-1.md";
pub const STATISTICAL_AMENDMENT_PATH: &str =
    "research/physics/derivable/xypher-calorimeter-amendment-cal-stat-1.md";
pub const SEAL_AMENDMENT_PATH: &str =
    "research/physics/derivable/xypher-calorimeter-amendment-cal-seal-1.md";
pub const CONTROL_AMENDMENT_PATH: &str =
    "research/physics/derivable/xypher-calorimeter-amendment-cal-ctrl-1.md";
pub const THEORY_BOUNDARY_PATH: &str = "research/physics/derivable/xypher-calorimeter-theory.md";
pub const MANIFEST_CORE_PATH: &str =
    "research/physics/derivable/xypher-calorimeter-manifest-core.json";
pub const FINAL_MANIFEST_PATH: &str = "research/physics/derivable/xypher-calorimeter-manifest.json";
pub const CORE_FREEZE_METADATA_PATH: &str =
    "research/physics/derivable/xypher-calorimeter-core-freeze-metadata.json";
pub const FINAL_FREEZE_METADATA_PATH: &str =
    "research/physics/derivable/xypher-calorimeter-final-freeze-metadata.json";
pub const PREDICTION_COMMITMENT_PATH: &str =
    "research/physics/derivable/xypher-calorimeter-prediction.commitment.json";
pub const PREDICTION_COMMITMENT_SIDECAR_PATH: &str =
    "research/physics/derivable/xypher-calorimeter-prediction.commitment.json.sha256";
pub const PREDICTION_PATH: &str = PREDICTION_COMMITMENT_PATH;
pub const PREDICTION_SIDECAR_PATH: &str = PREDICTION_COMMITMENT_SIDECAR_PATH;
pub const APPARATUS_PREFIX: &str = "research/physics/xypher-calorimeter-apparatus/";
pub const BUILD_RECIPE_PATH: &str = "research/physics/xypher-calorimeter-build-recipe.json";
pub const BUILD_SCRIPT_PATH: &str = "scripts/build-xypher-calorimeter-apparatus.sh";
pub const BUILD_RECEIPT_BASENAME: &str = "xypher-calorimeter-build-receipt.json";

pub const BASE_PREREGISTRATION_COMMIT: &str = "6e5702b0b33f59c82fde67d075a12907cc76d697";
pub const VIEW_DOMAIN: &str = "xypher-calorimeter/view/v1";
pub const NONCE_DOMAIN: &str = "xypher-calorimeter/episode/v1";
pub const SOURCE_SET_DOMAIN: &str = "xypher-calorimeter/source-set/v1";
pub const ARTIFACT_SET_DOMAIN: &str = "xypher-calorimeter/artifact-set/v1";
pub const IMPLEMENTATION_SOURCE_SET_DOMAIN: &str =
    "xypher-calorimeter/implementation-source-set/v1";
pub const IMPLEMENTATION_SOURCE_SET_NAME: &str = "implementation";
pub const BUILD_RECEIPT_SCHEMA: &str = "xypher-calorimeter-build-receipt.v2";
pub const BUILD_RECORD_SCHEMA: &str = "xypher-calorimeter-build-record.v2";
pub const MACOS_UUID_POLICY: &str = "content-hash-linker-generated-required";
pub const LOAD_PROBE_ARGUMENT: &str = "--xypher-calorimeter-load-probe";
pub const LOAD_PROBE_EXIT_CODE: i32 = 2;
pub const CHAIN_ID_DOMAIN: &str = "xypher-calorimeter/chain-id/v1";
pub const VALIDATOR_KEY_DOMAIN: &str = "xypher-calorimeter/validator-key/v1";
pub const PREDICTION_COMMITMENT_DOMAIN: &str = "xypher-calorimeter/prediction-commitment/v1";
pub const PREDICTION_DOCUMENT_SCHEMA: &str = "xypher-calorimeter-prediction.v2";
pub const PREDICTION_PAYLOAD_SCHEMA: &str = "xypher-calorimeter-prediction-payload.v2";
pub const PREDICTION_COMMITMENT_SCHEMA: &str = "xypher-calorimeter-prediction-commitment.v1";
pub const EXPECTED_PREDICTION_PAYLOAD_SHA256: &str =
    "d97ddb5a8151c01436c37b5f000e80f1ca1003590ab610926cde52ee4ea16ad2";

const CATALOG_SCHEMA: &str = "xypher-calorimeter-fixture-catalog.v1";
const POLICY_SCHEMA: &str = "xypher-calorimeter-policy-config.v1";
const REPORTING_POLICY_SCHEMA: &str = "xypher-calorimeter-reporting-policy.v1";
const CLAIM_SCHEMA: &str = "xypher-calorimeter-claim-contract.v1";
const GENESIS_RECIPE_SCHEMA: &str = "xypher-calorimeter-genesis-recipe.v1";
const BUILD_RECIPE_SCHEMA: &str = "xypher-calorimeter-build-recipe.v2";
pub const CORE_FREEZE_SCHEMA: &str = "xypher-calorimeter-core-freeze-metadata.v1";
pub const CORE_SCHEMA: &str = "xypher-calorimeter-manifest-core.v1";
pub const FINAL_FREEZE_SCHEMA: &str = "xypher-calorimeter-final-freeze-metadata.v1";
pub const FINAL_SCHEMA: &str = "xypher-calorimeter-manifest.v1";
const SCHEDULE_SCHEMA: &str = "xypher-calorimeter-schedule.v1";
pub const ACTOR_REQUIRED_SOURCE_PATHS: [&str; 14] = [
    "futuruna-xypher/lib/calorimeter_transfer_praxion.runa",
    "futuruna-xypher/tests/calorimeter_transfer_praxion_test.runa",
    "research/physics/xypher-calorimeter-runner/Cargo.lock",
    "research/physics/xypher-calorimeter-runner/Cargo.toml",
    "research/physics/xypher-calorimeter-runner/src/development.rs",
    "research/physics/xypher-calorimeter-runner/src/lib.rs",
    "research/physics/xypher-calorimeter-runner/src/main.rs",
    "scripts/check-xypher-calorimeter-differential.sh",
    "thaim-payments/crates/thaim-calorimeter/Cargo.toml",
    "thaim-payments/crates/thaim-calorimeter/examples/development_vectors.rs",
    "thaim-payments/crates/thaim-calorimeter/src/lib.rs",
    "thaim-payments/crates/thaim-praxor/Cargo.toml",
    "thaim-payments/crates/thaim-praxor/src/calorimeter_lab.rs",
    "thaim-payments/crates/thaim-praxor/src/lib.rs",
];
pub const ANALYSIS_REQUIRED_SOURCE_PATHS: [&str; 9] = [
    "research/physics/xypher-calorimeter-analysis/Cargo.lock",
    "research/physics/xypher-calorimeter-analysis/Cargo.toml",
    "research/physics/xypher-calorimeter-analysis/src/exact.rs",
    "research/physics/xypher-calorimeter-analysis/src/fixture.rs",
    "research/physics/xypher-calorimeter-analysis/src/lib.rs",
    "research/physics/xypher-calorimeter-analysis/src/main.rs",
    "research/physics/xypher-calorimeter-analysis/src/markov.rs",
    "research/physics/xypher-calorimeter-analysis/src/spectral.rs",
    "research/physics/xypher-calorimeter-analysis/tests/development_fixtures.rs",
];
pub const CLAIM_REQUIRED_SOURCE_PATHS: [&str; 7] = [
    CONTROL_AMENDMENT_PATH,
    REPORTING_AMENDMENT_PATH,
    SEAL_AMENDMENT_PATH,
    STATISTICAL_AMENDMENT_PATH,
    THEORY_BOUNDARY_PATH,
    PREREGISTRATION_PATH,
    CLAIM_CONTRACT_PATH,
];
pub const MANIFEST_REQUIRED_SOURCE_PATHS: [&str; 4] = [
    "research/physics/xypher-calorimeter-manifest/Cargo.lock",
    "research/physics/xypher-calorimeter-manifest/Cargo.toml",
    "research/physics/xypher-calorimeter-manifest/src/lib.rs",
    "research/physics/xypher-calorimeter-manifest/src/main.rs",
];
pub const OBSERVER_REQUIRED_SOURCE_PATHS: [&str; 10] = [
    "research/physics/xypher-calorimeter-observer/Cargo.lock",
    "research/physics/xypher-calorimeter-observer/Cargo.toml",
    "research/physics/xypher-calorimeter-observer/src/collection.rs",
    "research/physics/xypher-calorimeter-observer/src/commitments.rs",
    "research/physics/xypher-calorimeter-observer/src/development.rs",
    "research/physics/xypher-calorimeter-observer/src/journal.rs",
    "research/physics/xypher-calorimeter-observer/src/kernel.rs",
    "research/physics/xypher-calorimeter-observer/src/lib.rs",
    "research/physics/xypher-calorimeter-observer/src/main.rs",
    "research/physics/xypher-calorimeter-observer/src/tests.rs",
];
pub const IMPLEMENTATION_REQUIRED_SOURCE_PATHS: [&str; 55] = [
    ".gitattributes",
    "research/physics/xypher-calorimeter-analysis/README.md",
    "research/physics/xypher-calorimeter-build-recipe.json",
    "research/physics/xypher-calorimeter-integration/Cargo.lock",
    "research/physics/xypher-calorimeter-integration/Cargo.toml",
    "research/physics/xypher-calorimeter-integration/README.md",
    "research/physics/xypher-calorimeter-integration/src/lib.rs",
    "research/physics/xypher-calorimeter-integration/tests/cross_compat.rs",
    "research/physics/xypher-calorimeter-manifest/README.md",
    "research/physics/xypher-calorimeter-observer/README.md",
    "research/physics/xypher-calorimeter-runner/README.md",
    "scripts/README-xypher-calorimeter-freeze.md",
    "scripts/audit-xypher-calorimeter-freeze.sh",
    "scripts/build-xypher-calorimeter-apparatus.sh",
    "scripts/compare-xypher-calorimeter-builds.sh",
    "thaim-payments/Cargo.lock",
    "thaim-payments/Cargo.toml",
    "thaim-payments/crates/thaim-node/Cargo.toml",
    "thaim-payments/crates/thaim-node/src/calorimeter.rs",
    "thaim-payments/crates/thaim-node/src/consensus.rs",
    "thaim-payments/crates/thaim-node/src/event_loop.rs",
    "thaim-payments/crates/thaim-node/src/lib.rs",
    "thaim-payments/crates/thaim-node/src/network.rs",
    "thaim-payments/crates/thaim-node/src/persistence.rs",
    "thaim-payments/crates/thaim-node/src/replay.rs",
    "thaim-payments/crates/thaim-node/src/roles.rs",
    "thaim-payments/crates/thaim-node/src/run_loop.rs",
    "thaim-payments/crates/thaim-node/src/runner.rs",
    "thaim-payments/crates/thaim-node/src/runtime.rs",
    "thaim-payments/crates/thaim-node/src/service.rs",
    "thaim-payments/crates/thaim-node/src/startup.rs",
    "thaim-payments/crates/thaim-node/src/transport.rs",
    "thaim-payments/crates/thaim-node/src/validator_set.rs",
    "thaim-payments/crates/thaim-praxor/tests/native_allocation_contact.rs",
    "thaim-payments/crates/thaim-praxor/tests/native_contact_identifiability.rs",
    "thaim-payments/crates/thaim-protocol/Cargo.toml",
    "thaim-payments/crates/thaim-protocol/src/address.rs",
    "thaim-payments/crates/thaim-protocol/src/annotation.rs",
    "thaim-payments/crates/thaim-protocol/src/block_ops.rs",
    "thaim-payments/crates/thaim-protocol/src/canonical_math.rs",
    "thaim-payments/crates/thaim-protocol/src/chain_preset.rs",
    "thaim-payments/crates/thaim-protocol/src/crypto.rs",
    "thaim-payments/crates/thaim-protocol/src/emerald.rs",
    "thaim-payments/crates/thaim-protocol/src/genesis.rs",
    "thaim-payments/crates/thaim-protocol/src/ledger.rs",
    "thaim-payments/crates/thaim-protocol/src/lib.rs",
    "thaim-payments/crates/thaim-protocol/src/micro_tau.rs",
    "thaim-payments/crates/thaim-protocol/src/minting.rs",
    "thaim-payments/crates/thaim-protocol/src/protocol.rs",
    "thaim-payments/crates/thaim-protocol/src/ruby_forecast.rs",
    "thaim-payments/crates/thaim-protocol/src/signed_replay.rs",
    "thaim-payments/crates/thaim-protocol/src/state_hash.rs",
    "thaim-payments/crates/thaim-protocol/src/thermo.rs",
    "thaim-payments/crates/thaim-protocol/src/topology.rs",
    "thaim-payments/crates/thaim-protocol/src/types.rs",
];

pub fn required_implementation_source_paths() -> Vec<String> {
    let mut paths = [
        ACTOR_REQUIRED_SOURCE_PATHS.as_slice(),
        ANALYSIS_REQUIRED_SOURCE_PATHS.as_slice(),
        CLAIM_REQUIRED_SOURCE_PATHS.as_slice(),
        MANIFEST_REQUIRED_SOURCE_PATHS.as_slice(),
        OBSERVER_REQUIRED_SOURCE_PATHS.as_slice(),
        IMPLEMENTATION_REQUIRED_SOURCE_PATHS.as_slice(),
    ]
    .into_iter()
    .flatten()
    .map(|path| (*path).to_owned())
    .collect::<Vec<_>>();
    paths.sort_by(|left, right| left.as_bytes().cmp(right.as_bytes()));
    paths.dedup();
    paths
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ManifestError(String);

impl ManifestError {
    pub fn new(message: impl Into<String>) -> Self {
        Self(message.into())
    }
}

impl fmt::Display for ManifestError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

impl std::error::Error for ManifestError {}

impl From<io::Error> for ManifestError {
    fn from(value: io::Error) -> Self {
        Self(value.to_string())
    }
}

impl From<serde_json::Error> for ManifestError {
    fn from(value: serde_json::Error) -> Self {
        Self(value.to_string())
    }
}

impl From<hex::FromHexError> for ManifestError {
    fn from(value: hex::FromHexError) -> Self {
        Self(value.to_string())
    }
}

pub type Result<T> = std::result::Result<T, ManifestError>;

#[derive(Debug, Clone, PartialEq, Eq)]
enum CanonicalValue {
    Bool(bool),
    Integer(serde_json::Number),
    String(String),
    Array(Vec<CanonicalValue>),
    Object(BTreeMap<String, CanonicalValue>),
}

impl<'de> Deserialize<'de> for CanonicalValue {
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_any(CanonicalVisitor)
    }
}

struct CanonicalVisitor;

impl<'de> Visitor<'de> for CanonicalVisitor {
    type Value = CanonicalValue;

    fn expecting(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(
            "canonical JSON containing objects, arrays, booleans, integers, and ASCII strings",
        )
    }

    fn visit_bool<E>(self, value: bool) -> std::result::Result<Self::Value, E> {
        Ok(CanonicalValue::Bool(value))
    }

    fn visit_i64<E>(self, value: i64) -> std::result::Result<Self::Value, E> {
        Ok(CanonicalValue::Integer(value.into()))
    }

    fn visit_u64<E>(self, value: u64) -> std::result::Result<Self::Value, E> {
        Ok(CanonicalValue::Integer(value.into()))
    }

    fn visit_f64<E>(self, _value: f64) -> std::result::Result<Self::Value, E>
    where
        E: serde::de::Error,
    {
        Err(E::custom(
            "floating JSON numbers are forbidden; encode exact decimals as strings",
        ))
    }

    fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
    where
        E: serde::de::Error,
    {
        self.visit_string(value.to_owned())
    }

    fn visit_string<E>(self, value: String) -> std::result::Result<Self::Value, E>
    where
        E: serde::de::Error,
    {
        if !value.is_ascii() {
            return Err(E::custom("non-ASCII JSON string"));
        }
        Ok(CanonicalValue::String(value))
    }

    fn visit_seq<A>(self, mut sequence: A) -> std::result::Result<Self::Value, A::Error>
    where
        A: SeqAccess<'de>,
    {
        let mut values = Vec::new();
        while let Some(value) = sequence.next_element()? {
            values.push(value);
        }
        Ok(CanonicalValue::Array(values))
    }

    fn visit_map<A>(self, mut map: A) -> std::result::Result<Self::Value, A::Error>
    where
        A: MapAccess<'de>,
    {
        let mut values = BTreeMap::new();
        while let Some(key) = map.next_key::<String>()? {
            if !key.is_ascii() {
                return Err(serde::de::Error::custom("non-ASCII JSON object key"));
            }
            let value = map.next_value()?;
            if values.insert(key.clone(), value).is_some() {
                return Err(serde::de::Error::custom(format!(
                    "duplicate JSON object key {key}"
                )));
            }
        }
        Ok(CanonicalValue::Object(values))
    }

    fn visit_none<E>(self) -> std::result::Result<Self::Value, E>
    where
        E: serde::de::Error,
    {
        Err(E::custom("JSON null is forbidden"))
    }

    fn visit_unit<E>(self) -> std::result::Result<Self::Value, E>
    where
        E: serde::de::Error,
    {
        Err(E::custom("JSON null is forbidden"))
    }
}

impl CanonicalValue {
    fn from_json(value: serde_json::Value) -> Result<Self> {
        match value {
            serde_json::Value::Null => Err(ManifestError::new("JSON null is forbidden")),
            serde_json::Value::Bool(value) => Ok(Self::Bool(value)),
            serde_json::Value::Number(value) => {
                if value.is_i64() || value.is_u64() {
                    Ok(Self::Integer(value))
                } else {
                    Err(ManifestError::new(
                        "floating JSON numbers are forbidden; encode exact decimals as strings",
                    ))
                }
            }
            serde_json::Value::String(value) => {
                require_ascii("JSON string", &value)?;
                Ok(Self::String(value))
            }
            serde_json::Value::Array(values) => values
                .into_iter()
                .map(Self::from_json)
                .collect::<Result<Vec<_>>>()
                .map(Self::Array),
            serde_json::Value::Object(values) => {
                let mut object = BTreeMap::new();
                for (key, value) in values {
                    require_ascii("JSON object key", &key)?;
                    object.insert(key, Self::from_json(value)?);
                }
                Ok(Self::Object(object))
            }
        }
    }

    fn canonical_bytes(&self) -> Result<Vec<u8>> {
        let mut bytes = Vec::new();
        self.write_to(&mut bytes)?;
        bytes.push(b'\n');
        Ok(bytes)
    }

    fn write_to(&self, output: &mut Vec<u8>) -> Result<()> {
        match self {
            Self::Bool(value) => {
                output.extend_from_slice(if *value { b"true" } else { b"false" });
            }
            Self::Integer(value) => output.extend_from_slice(value.to_string().as_bytes()),
            Self::String(value) => {
                output.extend_from_slice(serde_json::to_string(value)?.as_bytes());
            }
            Self::Array(values) => {
                output.push(b'[');
                for (index, value) in values.iter().enumerate() {
                    if index > 0 {
                        output.push(b',');
                    }
                    value.write_to(output)?;
                }
                output.push(b']');
            }
            Self::Object(values) => {
                output.push(b'{');
                for (index, (key, value)) in values.iter().enumerate() {
                    if index > 0 {
                        output.push(b',');
                    }
                    output.extend_from_slice(serde_json::to_string(key)?.as_bytes());
                    output.push(b':');
                    value.write_to(output)?;
                }
                output.push(b'}');
            }
        }
        Ok(())
    }
}

pub fn validate_canonical_json(bytes: &[u8]) -> Result<()> {
    let expected = canonicalize_json(bytes)?;
    if expected != bytes {
        return Err(ManifestError::new(
            "JSON is not compact canonical form with lexicographic keys and exactly one LF",
        ));
    }
    Ok(())
}

pub fn canonicalize_json(bytes: &[u8]) -> Result<Vec<u8>> {
    if bytes.starts_with(&[0xef, 0xbb, 0xbf]) {
        return Err(ManifestError::new("UTF-8 BOM is forbidden"));
    }
    let mut deserializer = serde_json::Deserializer::from_slice(bytes);
    let value = CanonicalValue::deserialize(&mut deserializer)?;
    deserializer.end()?;
    value.canonical_bytes()
}

pub fn write_canonicalized_json(input_path: &Path, output_path: &Path) -> Result<()> {
    atomic_write(output_path, &canonicalize_json(&fs::read(input_path)?)?)
}

pub fn canonical_json_bytes<T: Serialize>(value: &T) -> Result<Vec<u8>> {
    CanonicalValue::from_json(serde_json::to_value(value)?)?.canonical_bytes()
}

pub fn write_canonical_json<T: Serialize>(path: &Path, value: &T) -> Result<()> {
    atomic_write(path, &canonical_json_bytes(value)?)
}

pub fn read_canonical_json<T>(path: &Path) -> Result<T>
where
    T: for<'de> Deserialize<'de>,
{
    let bytes = fs::read(path)?;
    validate_canonical_json(&bytes)?;
    Ok(serde_json::from_slice(&bytes)?)
}

fn atomic_write(path: &Path, bytes: &[u8]) -> Result<()> {
    let parent = path
        .parent()
        .ok_or_else(|| ManifestError::new("output path has no parent"))?;
    fs::create_dir_all(parent)?;
    let file_name = path
        .file_name()
        .and_then(|value| value.to_str())
        .ok_or_else(|| ManifestError::new("output filename is not UTF-8"))?;
    let temporary = parent.join(format!(".{file_name}.tmp-{}", std::process::id()));
    let write_result = (|| -> Result<()> {
        let mut file = OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(&temporary)?;
        file.write_all(bytes)?;
        file.sync_all()?;
        fs::rename(&temporary, path)?;
        File::open(parent)?.sync_all()?;
        Ok(())
    })();
    if write_result.is_err() {
        let _ = fs::remove_file(&temporary);
    }
    write_result
}

fn atomic_write_new(path: &Path, bytes: &[u8]) -> Result<()> {
    match fs::symlink_metadata(path) {
        Ok(_) => {
            return Err(ManifestError::new(format!(
                "refusing to replace existing output {}",
                path.display()
            )));
        }
        Err(error) if error.kind() == io::ErrorKind::NotFound => {}
        Err(error) => return Err(error.into()),
    }

    let parent = path
        .parent()
        .ok_or_else(|| ManifestError::new("output path has no parent"))?;
    fs::create_dir_all(parent)?;
    let file_name = path
        .file_name()
        .and_then(|value| value.to_str())
        .ok_or_else(|| ManifestError::new("output filename is not UTF-8"))?;
    let temporary = parent.join(format!(".{file_name}.tmp-{}", std::process::id()));
    let write_result = (|| -> Result<()> {
        let mut file = OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(&temporary)?;
        file.write_all(bytes)?;
        file.sync_all()?;
        fs::hard_link(&temporary, path).map_err(|error| {
            ManifestError::new(format!(
                "refusing to replace or alias existing output {}: {error}",
                path.display()
            ))
        })?;
        fs::remove_file(&temporary)?;
        File::open(parent)?.sync_all()?;
        Ok(())
    })();
    if write_result.is_err() {
        let _ = fs::remove_file(&temporary);
    }
    write_result
}

fn canonical_new_output(
    repo_root: &Path,
    supplied: &Path,
    canonical_relative: &str,
) -> Result<PathBuf> {
    if supplied.as_os_str() != OsStr::new(canonical_relative) {
        return Err(ManifestError::new(format!(
            "output must use the exact canonical repository path {canonical_relative}"
        )));
    }
    validate_repo_path(canonical_relative)?;
    let canonical_root = fs::canonicalize(repo_root)?;
    let mut output = canonical_root;
    let components = Path::new(canonical_relative)
        .components()
        .collect::<Vec<_>>();
    for component in &components[..components.len().saturating_sub(1)] {
        let Component::Normal(name) = component else {
            return Err(ManifestError::new(
                "canonical output contains a non-normal path component",
            ));
        };
        output.push(name);
        let metadata = fs::symlink_metadata(&output)?;
        if metadata.file_type().is_symlink() || !metadata.is_dir() {
            return Err(ManifestError::new(format!(
                "canonical output parent is not a regular repository directory: {canonical_relative}"
            )));
        }
    }
    let final_component = components
        .last()
        .ok_or_else(|| ManifestError::new("canonical output path is empty"))?;
    let Component::Normal(name) = final_component else {
        return Err(ManifestError::new(
            "canonical output filename is not a normal component",
        ));
    };
    output.push(name);
    match fs::symlink_metadata(&output) {
        Ok(_) => Err(ManifestError::new(format!(
            "refusing to replace existing canonical output {canonical_relative}"
        ))),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(output),
        Err(error) => Err(error.into()),
    }
}

fn require_ascii(label: &str, value: &str) -> Result<()> {
    if value.is_ascii() {
        Ok(())
    } else {
        Err(ManifestError::new(format!("{label} must be ASCII")))
    }
}

fn sha256(bytes: &[u8]) -> [u8; 32] {
    Sha256::digest(bytes).into()
}

pub fn raw_sha256_hex(bytes: &[u8]) -> String {
    hex::encode(sha256(bytes))
}

fn encode_text(output: &mut Vec<u8>, value: &str) -> Result<()> {
    require_ascii("encoded text", value)?;
    let length = u32::try_from(value.len())
        .map_err(|_| ManifestError::new("encoded text length exceeds u32"))?;
    output.extend_from_slice(&length.to_be_bytes());
    output.extend_from_slice(value.as_bytes());
    Ok(())
}

fn validate_repo_path(path: &str) -> Result<()> {
    require_ascii("repository path", path)?;
    if path.contains('\\') || path.is_empty() {
        return Err(ManifestError::new(format!(
            "repository path is not normalized: {path}"
        )));
    }
    let parsed = Path::new(path);
    if parsed.is_absolute() {
        return Err(ManifestError::new(format!(
            "repository path must be relative: {path}"
        )));
    }
    let mut normal = Vec::new();
    for component in parsed.components() {
        let Component::Normal(value) = component else {
            return Err(ManifestError::new(format!(
                "repository path is not normalized: {path}"
            )));
        };
        let value = value
            .to_str()
            .ok_or_else(|| ManifestError::new("repository path component is not UTF-8"))?;
        normal.push(value);
    }
    if normal.join("/") != path {
        return Err(ManifestError::new(format!(
            "repository path is not in exact canonical spelling: {path}"
        )));
    }
    Ok(())
}

fn decode_hash(label: &str, value: &str) -> Result<[u8; 32]> {
    if value.len() != 64
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
    {
        return Err(ManifestError::new(format!(
            "{label} must be 64 lowercase hexadecimal characters"
        )));
    }
    let decoded = hex::decode(value)?;
    decoded
        .try_into()
        .map_err(|_| ManifestError::new(format!("{label} must decode to 32 bytes")))
}

fn validate_mach_o_uuid(label: &str, value: &str) -> Result<()> {
    if value.len() != 32
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
        || value.bytes().all(|byte| byte == b'0')
    {
        return Err(ManifestError::new(format!(
            "{label} must be a nonzero value encoded as exactly 32 lowercase hexadecimal characters without hyphens"
        )));
    }
    Ok(())
}

fn is_forbidden_mach_o_uuid_flag(flag: &str) -> bool {
    let normalized = flag.to_ascii_lowercase();
    normalized.contains("no_uuid") || normalized.contains("random_uuid")
}

fn validate_launch_probe(component: &str, probe: &BuildLaunchProbe) -> Result<()> {
    if probe.argument != LOAD_PROBE_ARGUMENT || probe.exit_code != LOAD_PROBE_EXIT_CODE {
        return Err(ManifestError::new(format!(
            "{component} launch probe must use {LOAD_PROBE_ARGUMENT} and exit {LOAD_PROBE_EXIT_CODE}"
        )));
    }
    decode_hash(
        &format!("{component} launch-probe output hash"),
        &probe.output_sha256,
    )?;
    Ok(())
}

fn validate_git_hash(label: &str, value: &str) -> Result<()> {
    if value.len() != 40
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
    {
        return Err(ManifestError::new(format!(
            "{label} must be a 40-character lowercase hexadecimal git object id"
        )));
    }
    Ok(())
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RawFileIdentity {
    pub length_bytes: u64,
    pub path: String,
    pub sha256: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PredictionCommitmentFileIdentity {
    pub length_bytes: String,
    pub path: String,
    pub sha256: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PredictionCanonicalDocumentIdentity {
    pub length_bytes: String,
    pub schema: String,
    pub sha256: String,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PredictionCommitment {
    pub all_load_bearing_prediction_gates_passed: bool,
    pub analysis_artifact: PredictionCommitmentFileIdentity,
    pub canonical_document: PredictionCanonicalDocumentIdentity,
    pub commitment_domain: String,
    pub core_hash: String,
    pub decision_count: String,
    pub episode_count: String,
    pub final_manifest_hash: String,
    pub fixture_catalog_hash: String,
    pub genesis_recipe_hash: String,
    pub payload_hash: String,
    pub payload_schema: String,
    pub policy_config_hash: String,
    pub reporting_policy_hash: String,
    pub schedule_hash: String,
    pub schema: String,
    pub tolerances: serde_json::Value,
}

fn parse_canonical_decimal_u64(label: &str, value: &str) -> Result<u64> {
    if value.is_empty()
        || !value.bytes().all(|byte| byte.is_ascii_digit())
        || (value.len() > 1 && value.starts_with('0'))
    {
        return Err(ManifestError::new(format!(
            "{label} must be a canonical unsigned decimal integer"
        )));
    }
    value
        .parse()
        .map_err(|_| ManifestError::new(format!("{label} exceeds u64")))
}

pub fn validate_prediction_commitment_structure(commitment: &PredictionCommitment) -> Result<()> {
    if !commitment.all_load_bearing_prediction_gates_passed
        || commitment.schema != PREDICTION_COMMITMENT_SCHEMA
        || commitment.commitment_domain != PREDICTION_COMMITMENT_DOMAIN
        || commitment.payload_schema != PREDICTION_PAYLOAD_SCHEMA
        || !commitment.tolerances.is_object()
    {
        return Err(ManifestError::new(
            "prediction commitment schema, gate, domain, or tolerance contract mismatch",
        ));
    }
    validate_repo_path(&commitment.analysis_artifact.path)?;
    let artifact_length = parse_canonical_decimal_u64(
        "prediction analysis artifact length",
        &commitment.analysis_artifact.length_bytes,
    )?;
    if artifact_length == 0 {
        return Err(ManifestError::new(
            "prediction analysis artifact must be nonempty",
        ));
    }
    decode_hash(
        "prediction analysis artifact hash",
        &commitment.analysis_artifact.sha256,
    )?;
    let document_length = parse_canonical_decimal_u64(
        "canonical prediction document length",
        &commitment.canonical_document.length_bytes,
    )?;
    if document_length == 0 {
        return Err(ManifestError::new(
            "canonical prediction document must be nonempty",
        ));
    }
    if commitment.canonical_document.schema != PREDICTION_DOCUMENT_SCHEMA {
        return Err(ManifestError::new(
            "canonical prediction document schema mismatch",
        ));
    }
    decode_hash(
        "canonical prediction document hash",
        &commitment.canonical_document.sha256,
    )?;
    for (label, value) in [
        ("prediction core hash", &commitment.core_hash),
        (
            "prediction final manifest hash",
            &commitment.final_manifest_hash,
        ),
        (
            "prediction fixture catalog hash",
            &commitment.fixture_catalog_hash,
        ),
        (
            "prediction genesis recipe hash",
            &commitment.genesis_recipe_hash,
        ),
        ("prediction payload hash", &commitment.payload_hash),
        (
            "prediction policy config hash",
            &commitment.policy_config_hash,
        ),
        (
            "prediction reporting policy hash",
            &commitment.reporting_policy_hash,
        ),
        ("prediction schedule hash", &commitment.schedule_hash),
    ] {
        decode_hash(label, value)?;
    }
    if parse_canonical_decimal_u64("prediction decision count", &commitment.decision_count)? == 0
        || parse_canonical_decimal_u64("prediction episode count", &commitment.episode_count)? == 0
    {
        return Err(ManifestError::new(
            "prediction decision and episode counts must be positive",
        ));
    }
    Ok(())
}

pub fn validate_frozen_prediction_commitment(commitment: &PredictionCommitment) -> Result<()> {
    validate_prediction_commitment_structure(commitment)?;
    if commitment.payload_hash != EXPECTED_PREDICTION_PAYLOAD_SHA256 {
        return Err(ManifestError::new(
            "prediction commitment scientific payload differs from the frozen transport-only payload",
        ));
    }
    Ok(())
}

fn secure_repo_file_path(repo_root: &Path, path: &str) -> Result<PathBuf> {
    validate_repo_path(path)?;
    let canonical_root = fs::canonicalize(repo_root)?;
    if !fs::metadata(&canonical_root)?.is_dir() {
        return Err(ManifestError::new(
            "canonical repository root is not a directory",
        ));
    }

    let mut current = canonical_root.clone();
    let mut components = Path::new(path).components().peekable();
    while let Some(component) = components.next() {
        let Component::Normal(name) = component else {
            return Err(ManifestError::new(format!(
                "repository path is not normalized: {path}"
            )));
        };
        current.push(name);
        let metadata = fs::symlink_metadata(&current)?;
        if metadata.file_type().is_symlink() {
            return Err(ManifestError::new(format!(
                "repository identity path contains a symlink: {path}"
            )));
        }
        if components.peek().is_some() {
            if !metadata.is_dir() {
                return Err(ManifestError::new(format!(
                    "repository identity parent is not a directory: {path}"
                )));
            }
        } else if !metadata.is_file() {
            return Err(ManifestError::new(format!(
                "repository identity target is not a regular file: {path}"
            )));
        }
    }

    let canonical_target = fs::canonicalize(&current)?;
    if !canonical_target.starts_with(&canonical_root) {
        return Err(ManifestError::new(format!(
            "repository identity target escapes canonical root: {path}"
        )));
    }
    let canonical_relative = canonical_target
        .strip_prefix(&canonical_root)
        .map_err(|_| ManifestError::new("canonical target is outside repository root"))?;
    let canonical_spelling = canonical_relative
        .components()
        .map(|component| {
            let Component::Normal(value) = component else {
                return Err(ManifestError::new(
                    "canonical target contains a non-normal path component",
                ));
            };
            value
                .to_str()
                .map(str::to_owned)
                .ok_or_else(|| ManifestError::new("canonical target path is not UTF-8"))
        })
        .collect::<Result<Vec<_>>>()?
        .join("/");
    if canonical_spelling != path {
        return Err(ManifestError::new(format!(
            "repository path does not match canonical target spelling: {path}"
        )));
    }
    Ok(canonical_target)
}

pub fn raw_file_identity(repo_root: &Path, path: &str) -> Result<RawFileIdentity> {
    let target = secure_repo_file_path(repo_root, path)?;
    let bytes = fs::read(target)?;
    let length_bytes =
        u64::try_from(bytes.len()).map_err(|_| ManifestError::new("file length exceeds u64"))?;
    Ok(RawFileIdentity {
        length_bytes,
        path: path.to_owned(),
        sha256: raw_sha256_hex(&bytes),
    })
}

pub fn read_canonical_manifest_core(repo_root: &Path) -> Result<Vec<u8>> {
    Ok(fs::read(secure_repo_file_path(
        repo_root,
        MANIFEST_CORE_PATH,
    )?)?)
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FileSetIdentity {
    pub domain: String,
    pub files: Vec<RawFileIdentity>,
    pub set_name: String,
    pub sha256: String,
}

fn file_set_identity(
    repo_root: &Path,
    domain: &str,
    set_name: &str,
    paths: &[String],
) -> Result<FileSetIdentity> {
    require_ascii("set name", set_name)?;
    let mut sorted = paths.to_vec();
    sorted.sort_by(|left, right| left.as_bytes().cmp(right.as_bytes()));
    if sorted.windows(2).any(|pair| pair[0] == pair[1]) {
        return Err(ManifestError::new(format!(
            "duplicate path in set {set_name}"
        )));
    }
    let files = sorted
        .iter()
        .map(|path| raw_file_identity(repo_root, path))
        .collect::<Result<Vec<_>>>()?;

    let mut encoded = Vec::new();
    encode_text(&mut encoded, domain)?;
    encode_text(&mut encoded, set_name)?;
    let count =
        u32::try_from(files.len()).map_err(|_| ManifestError::new("file-set count exceeds u32"))?;
    encoded.extend_from_slice(&count.to_be_bytes());
    for file in &files {
        encode_text(&mut encoded, &file.path)?;
        encoded.extend_from_slice(&file.length_bytes.to_be_bytes());
        encoded.extend_from_slice(&decode_hash("raw file hash", &file.sha256)?);
    }
    Ok(FileSetIdentity {
        domain: domain.to_owned(),
        files,
        set_name: set_name.to_owned(),
        sha256: raw_sha256_hex(&encoded),
    })
}

pub fn source_set_identity(
    repo_root: &Path,
    set_name: &str,
    paths: &[String],
) -> Result<FileSetIdentity> {
    file_set_identity(repo_root, SOURCE_SET_DOMAIN, set_name, paths)
}

pub fn artifact_set_identity(
    repo_root: &Path,
    set_name: &str,
    paths: &[String],
) -> Result<FileSetIdentity> {
    file_set_identity(repo_root, ARTIFACT_SET_DOMAIN, set_name, paths)
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct LabelPermutation {
    pub image_by_node: Vec<u32>,
    pub permutation_id: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingPartition {
    pub left_nodes: Vec<u32>,
    pub partition_id: String,
    pub right_nodes: Vec<u32>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Fixture {
    pub account_edges: Vec<[u32; 2]>,
    pub fixture_id: String,
    pub horizons: Vec<u32>,
    pub initial_balances: Vec<Vec<u64>>,
    pub inventory_microtau: u64,
    pub node_count: u32,
    pub permutations: Vec<LabelPermutation>,
    pub reporting_partitions: Vec<ReportingPartition>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FixtureCatalog {
    pub fixtures: Vec<Fixture>,
    pub schema: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FixtureSchedule {
    pub episode_length: u64,
    pub fixture_id: String,
    pub horizon: u32,
    pub spectral_gap: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PolicyConfig {
    pub action_quantum_microtau: u64,
    pub decision_count: u64,
    pub episode_count: u32,
    pub episodes_per_cell: u32,
    pub fixed_receding_horizon: bool,
    pub fixture_decision_counts: BTreeMap<String, u64>,
    pub nonce_domain: String,
    pub schedule_cell_count: u32,
    pub schedule_order: Vec<String>,
    pub schedules: Vec<FixtureSchedule>,
    pub schema: String,
    pub wait_action_multiplicity: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingAcceptance {
    pub exact_decision_join_count: u64,
    pub journal_external_actor_seal_count: u32,
    pub partial_collection_allowed: bool,
    pub require_all_exact_decision_joins: bool,
    pub require_all_journal_external_actor_seals: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingAggregation {
    pub pool_episode_ids: bool,
    pub pool_permutations: bool,
    pub pool_start_indices: bool,
    pub time_convention: String,
    pub transients: Vec<String>,
    pub transition_rows: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingConfidenceIntervals {
    pub acceptance_role: String,
    pub confidence_level: String,
    pub dependence_scope: String,
    pub family: String,
    pub family_size_source: String,
    pub method: String,
    pub radius_formula: String,
    pub randomness_scope: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingExecutionOrder {
    pub load_bearing_mismatch_action: String,
    pub prediction_output_seal: String,
    pub prediction_window: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingLikelihood {
    pub greedy_control: String,
    pub h1_control: String,
    pub log_base: u32,
    pub negative_infinity_encoding: String,
    pub permuted_continuation_control: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingNumericOutput {
    pub exact_integers: String,
    pub exact_probabilities: String,
    pub floating: String,
    pub negative_infinity: String,
    pub positive_infinity: String,
    pub undefined: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingPartitionOutputs {
    pub allowed_outputs: Vec<String>,
    pub forbidden_interpretations: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingPolicy {
    pub acceptance: ReportingAcceptance,
    pub aggregation: ReportingAggregation,
    pub confidence_intervals: ReportingConfidenceIntervals,
    pub exact_probability_absolute_tolerance: String,
    pub execution_order: ReportingExecutionOrder,
    pub kl_negative_tolerance_bits: String,
    pub likelihood: ReportingLikelihood,
    pub mfpt_bellman_absolute_tolerance: String,
    pub minimum_transition_row_exposures: u64,
    pub mixing_total_variation_threshold: String,
    pub numeric_output: ReportingNumericOutput,
    pub optional_stopping: bool,
    pub partition_outputs: ReportingPartitionOutputs,
    pub schema: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClaimDocument {
    pub commit: String,
    pub path: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClaimBoundary {
    pub path: String,
    pub role: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReportingAmendment {
    pub amendment_id: String,
    pub path: String,
    pub role: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClaimLadder {
    pub layer_b_maximum_level: u32,
    pub level_0: String,
    pub level_1: String,
    pub level_2: String,
    pub level_3: String,
    pub new_fundamental_physics_minimum_level: u32,
    pub physical_stochastic_thermodynamics_minimum_level: u32,
    pub pre_execution_maximum_level: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClaimContract {
    pub allowed_pre_execution_claims: Vec<String>,
    pub base_preregistration: ClaimDocument,
    pub claim_ladder: ClaimLadder,
    pub excluded_without_separate_evidence: Vec<String>,
    pub reporting_amendments: Vec<ReportingAmendment>,
    pub schema: String,
    pub theory_boundary: ClaimBoundary,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GenesisAccountConstruction {
    pub account_ids: String,
    pub initial_balances: String,
    pub node_public_keys: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GenesisChainIdDerivation {
    pub domain: String,
    pub formula: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GenesisProtocolConfig {
    pub alpha_base_f64_bits_hex: String,
    pub edge_decay_half_life: u64,
    pub edge_decay_min_weight_f64_bits_hex: String,
    pub min_trade_amount_microtau: u64,
    pub source: String,
    pub walk_horizon: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GenesisLedgerConstruction {
    pub constructor: String,
    pub protocol_config: GenesisProtocolConfig,
    pub required_clean_state: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GenesisValidatorConstruction {
    pub count: u32,
    pub cumulative_delta_st_f64_bits_hex: String,
    pub epoch: u64,
    pub epoch_size: u64,
    pub epoch_size_rule: String,
    pub key_derivation_domain: String,
    pub key_derivation_formula: String,
    pub slot: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GenesisRecipe {
    pub account_construction: GenesisAccountConstruction,
    pub chain_id_derivation: GenesisChainIdDerivation,
    pub consensus_genesis_hash: String,
    pub ledger_construction: GenesisLedgerConstruction,
    pub schema: String,
    pub validator_construction: GenesisValidatorConstruction,
}

pub fn frozen_catalog() -> FixtureCatalog {
    FixtureCatalog {
        fixtures: vec![
            Fixture {
                account_edges: vec![[1, 2], [1, 4], [2, 3], [3, 4]],
                fixture_id: "cycle4_k4".to_owned(),
                horizons: vec![2, 5, 8],
                initial_balances: vec![
                    vec![4, 0, 0, 0],
                    vec![0, 4, 0, 0],
                    vec![3, 1, 0, 0],
                    vec![1, 1, 1, 1],
                ],
                inventory_microtau: 4,
                node_count: 4,
                permutations: vec![
                    LabelPermutation {
                        image_by_node: vec![1, 2, 3, 4],
                        permutation_id: "identity".to_owned(),
                    },
                    LabelPermutation {
                        image_by_node: vec![3, 1, 4, 2],
                        permutation_id: "frozen".to_owned(),
                    },
                ],
                reporting_partitions: vec![ReportingPartition {
                    left_nodes: vec![1, 2],
                    partition_id: "adjacent_2_plus_2".to_owned(),
                    right_nodes: vec![3, 4],
                }],
            },
            Fixture {
                account_edges: vec![[1, 2], [1, 3], [1, 4], [1, 5]],
                fixture_id: "star5_k3".to_owned(),
                horizons: vec![2, 5, 8],
                initial_balances: vec![
                    vec![3, 0, 0, 0, 0],
                    vec![0, 3, 0, 0, 0],
                    vec![2, 1, 0, 0, 0],
                    vec![1, 1, 1, 0, 0],
                ],
                inventory_microtau: 3,
                node_count: 5,
                permutations: vec![
                    LabelPermutation {
                        image_by_node: vec![1, 2, 3, 4, 5],
                        permutation_id: "identity".to_owned(),
                    },
                    LabelPermutation {
                        image_by_node: vec![4, 1, 5, 2, 3],
                        permutation_id: "frozen".to_owned(),
                    },
                ],
                reporting_partitions: vec![
                    ReportingPartition {
                        left_nodes: vec![1, 2],
                        partition_id: "center_plus_one_leaf".to_owned(),
                        right_nodes: vec![3, 4, 5],
                    },
                    ReportingPartition {
                        left_nodes: vec![2, 3],
                        partition_id: "two_leaves".to_owned(),
                        right_nodes: vec![1, 4, 5],
                    },
                ],
            },
        ],
        schema: CATALOG_SCHEMA.to_owned(),
    }
}

pub fn frozen_policy() -> PolicyConfig {
    PolicyConfig {
        action_quantum_microtau: 1,
        decision_count: 93_696,
        episode_count: 1_536,
        episodes_per_cell: 32,
        fixed_receding_horizon: true,
        fixture_decision_counts: BTreeMap::from([
            ("cycle4_k4".to_owned(), 47_104),
            ("star5_k3".to_owned(), 46_592),
        ]),
        nonce_domain: NONCE_DOMAIN.to_owned(),
        schedule_cell_count: 48,
        schedule_order: vec![
            "fixture_id".to_owned(),
            "horizon".to_owned(),
            "start_index".to_owned(),
            "permutation_index".to_owned(),
            "episode_id".to_owned(),
        ],
        schedules: vec![
            FixtureSchedule {
                episode_length: 54,
                fixture_id: "cycle4_k4".to_owned(),
                horizon: 2,
                spectral_gap: "0.1870804289497744".to_owned(),
            },
            FixtureSchedule {
                episode_length: 50,
                fixture_id: "cycle4_k4".to_owned(),
                horizon: 5,
                spectral_gap: "0.2466054708785789".to_owned(),
            },
            FixtureSchedule {
                episode_length: 80,
                fixture_id: "cycle4_k4".to_owned(),
                horizon: 8,
                spectral_gap: "0.2558307622883335".to_owned(),
            },
            FixtureSchedule {
                episode_length: 52,
                fixture_id: "star5_k3".to_owned(),
                horizon: 2,
                spectral_gap: "0.1933721615865024".to_owned(),
            },
            FixtureSchedule {
                episode_length: 50,
                fixture_id: "star5_k3".to_owned(),
                horizon: 5,
                spectral_gap: "0.2506270963709568".to_owned(),
            },
            FixtureSchedule {
                episode_length: 80,
                fixture_id: "star5_k3".to_owned(),
                horizon: 8,
                spectral_gap: "0.2583757968138432".to_owned(),
            },
        ],
        schema: POLICY_SCHEMA.to_owned(),
        wait_action_multiplicity: 1,
    }
}

pub fn frozen_reporting_policy() -> ReportingPolicy {
    ReportingPolicy {
        acceptance: ReportingAcceptance {
            exact_decision_join_count: 93_696,
            journal_external_actor_seal_count: 1_536,
            partial_collection_allowed: false,
            require_all_exact_decision_joins: true,
            require_all_journal_external_actor_seals: true,
        },
        aggregation: ReportingAggregation {
            pool_episode_ids: true,
            pool_permutations: false,
            pool_start_indices: true,
            time_convention:
                "initial boundary t=0; opportunity t uses pre-state t and post-state t+1"
                    .to_owned(),
            transients: vec![
                "fixture_id".to_owned(),
                "horizon".to_owned(),
                "start_index".to_owned(),
                "permutation_index".to_owned(),
                "time_index".to_owned(),
            ],
            transition_rows: vec![
                "fixture_id".to_owned(),
                "horizon".to_owned(),
                "permutation_index".to_owned(),
                "state".to_owned(),
            ],
        },
        confidence_intervals: ReportingConfidenceIntervals {
            acceptance_role: "reference diagnostic only; never acceptance evidence".to_owned(),
            confidence_level: "0.99".to_owned(),
            dependence_scope:
                "conditional-iid pseudorandom reference; within-episode Markov exposures are correlated"
                    .to_owned(),
            family: "all preregistered fixture-horizon-permutation state-action categories"
                .to_owned(),
            family_size_source:
                "complete independent allocation-shell prediction frozen before trajectories"
                    .to_owned(),
            method: "two-sided Hoeffding union bound".to_owned(),
            radius_formula: "sqrt(ln(2*K/0.01)/(2*n)) clipped to [0,1]".to_owned(),
            randomness_scope:
                "public deterministic SHA streams; not a physical random source".to_owned(),
        },
        exact_probability_absolute_tolerance: "0.000000000001".to_owned(),
        execution_order: ReportingExecutionOrder {
            load_bearing_mismatch_action:
                "new implementation freeze, new manifest core, and new final manifest".to_owned(),
            prediction_output_seal:
                "commit and push prediction artifacts before first actor execution".to_owned(),
            prediction_window:
                "after final manifest and all episode nonces are committed and pushed; before first actor execution"
                    .to_owned(),
        },
        kl_negative_tolerance_bits: "0.000000000001".to_owned(),
        likelihood: ReportingLikelihood {
            greedy_control:
                "probability one on the lexicographically first canonical action among maximum continuation weights"
                    .to_owned(),
            h1_control: "recompute the same action-labelled shell with horizon 1".to_owned(),
            log_base: 2,
            negative_infinity_encoding: "negative_infinity".to_owned(),
            permuted_continuation_control:
                "rotate continuation weights left by one across lexicographically sorted canonical actions; one-action rows unchanged"
                    .to_owned(),
        },
        mfpt_bellman_absolute_tolerance: "0.000000001".to_owned(),
        minimum_transition_row_exposures: 100,
        mixing_total_variation_threshold: "0.000001".to_owned(),
        numeric_output: ReportingNumericOutput {
            exact_integers: "unsigned decimal strings".to_owned(),
            exact_probabilities: "decimal numerator and denominator strings".to_owned(),
            floating:
                "shortest round-tripping decimal string plus lowercase 16-hex f64 bits".to_owned(),
            negative_infinity: "negative_infinity".to_owned(),
            positive_infinity: "positive_infinity".to_owned(),
            undefined: "undefined".to_owned(),
        },
        optional_stopping: false,
        partition_outputs: ReportingPartitionOutputs {
            allowed_outputs: vec![
                "exact stationary left-inventory marginal".to_owned(),
                "exact transient left-inventory marginal".to_owned(),
                "left-inventory mean".to_owned(),
                "left-inventory variance".to_owned(),
                "left-inventory Shannon entropy".to_owned(),
            ],
            forbidden_interpretations: vec![
                "contact".to_owned(),
                "current".to_owned(),
                "equation of state".to_owned(),
                "heat".to_owned(),
                "temperature".to_owned(),
            ],
        },
        schema: REPORTING_POLICY_SCHEMA.to_owned(),
    }
}

pub fn frozen_claim_contract() -> ClaimContract {
    ClaimContract {
        allowed_pre_execution_claims: vec![
            "exact finite-volume path-ensemble instrument".to_owned(),
            "fixed receding-horizon Markov instrument".to_owned(),
            "protocol-native realization remains an experimental question".to_owned(),
        ],
        base_preregistration: ClaimDocument {
            commit: BASE_PREREGISTRATION_COMMIT.to_owned(),
            path: PREREGISTRATION_PATH.to_owned(),
        },
        claim_ladder: ClaimLadder {
            layer_b_maximum_level: 3,
            level_0: "replay instrument validated".to_owned(),
            level_1: "engineered digital allocation kernel".to_owned(),
            level_2: "causal-path equilibrium implemented".to_owned(),
            level_3: "engineered allocation statistical mechanics".to_owned(),
            new_fundamental_physics_minimum_level: 8,
            physical_stochastic_thermodynamics_minimum_level: 7,
            pre_execution_maximum_level: 0,
        },
        excluded_without_separate_evidence: vec![
            "new random-walk theorem".to_owned(),
            "thermodynamic equation of state".to_owned(),
            "operational digital temperature".to_owned(),
            "physical heat or work".to_owned(),
            "Landauer dissipation".to_owned(),
            "new fundamental physics".to_owned(),
        ],
        reporting_amendments: vec![
            ReportingAmendment {
                amendment_id: "CAL-MAN-1".to_owned(),
                path: REPORTING_AMENDMENT_PATH.to_owned(),
                role:
                    "reporting partitions, relabelling, manifest identity, and pre-actor spectral schedule admission"
                        .to_owned(),
            },
            ReportingAmendment {
                amendment_id: "CAL-STAT-1".to_owned(),
                path: STATISTICAL_AMENDMENT_PATH.to_owned(),
                role: "aggregation, diagnostics, likelihood controls, partition summaries, numeric encoding, prediction timing, and completeness"
                    .to_owned(),
            },
            ReportingAmendment {
                amendment_id: "CAL-SEAL-1".to_owned(),
                path: SEAL_AMENDMENT_PATH.to_owned(),
                role: "compact prediction commitment, exact pre-actor regeneration, evidence identity binding, and atomic collection publication"
                    .to_owned(),
            },
            ReportingAmendment {
                amendment_id: "CAL-CTRL-1".to_owned(),
                path: CONTROL_AMENDMENT_PATH.to_owned(),
                role: "negative-control evidence map, all-live-recipient scope, and pre-freeze timing correction"
                    .to_owned(),
            },
        ],
        schema: CLAIM_SCHEMA.to_owned(),
        theory_boundary: ClaimBoundary {
            path: THEORY_BOUNDARY_PATH.to_owned(),
            role: "established theory and prior-art boundary".to_owned(),
        },
    }
}

pub fn frozen_genesis_recipe() -> GenesisRecipe {
    GenesisRecipe {
        account_construction: GenesisAccountConstruction {
            account_ids: "ascending integers 1..node_count".to_owned(),
            initial_balances:
                "apply image_by_node to the fixture start_index vector using b^sigma_j=b_sigma^-1(j)"
                    .to_owned(),
            node_public_keys:
                "assign the single validator public key to every controlled account".to_owned(),
        },
        chain_id_derivation: GenesisChainIdDerivation {
            domain: CHAIN_ID_DOMAIN.to_owned(),
            formula: "SHA256(enc_text(domain)||raw_manifest_core_hash)".to_owned(),
        },
        consensus_genesis_hash: "00".repeat(32),
        ledger_construction: GenesisLedgerConstruction {
            constructor: "PaymentLedger::with_genesis_balances".to_owned(),
            protocol_config: GenesisProtocolConfig {
                alpha_base_f64_bits_hex: "4044000000000000".to_owned(),
                edge_decay_half_life: 0,
                edge_decay_min_weight_f64_bits_hex: "3f847ae147ae147b".to_owned(),
                min_trade_amount_microtau: 10_000,
                source: "ProtocolConfig::default".to_owned(),
                walk_horizon: 5,
            },
            required_clean_state: vec![
                "tick zero".to_owned(),
                "empty ledger adjacency".to_owned(),
                "no transfer receipts".to_owned(),
                "no forecasts or forecast bonds".to_owned(),
                "no annotations".to_owned(),
                "no Emerald contracts, fulfillments, expiries, locks, or payouts".to_owned(),
                "no departure burn, slash, bond lock, bond burn, or Emerald burn".to_owned(),
                "no joined or departed nodes".to_owned(),
                "zero entropy, delta-S-tau, surplus, mint, and trade histories".to_owned(),
                "total minted equals closed live inventory".to_owned(),
            ],
        },
        schema: GENESIS_RECIPE_SCHEMA.to_owned(),
        validator_construction: GenesisValidatorConstruction {
            count: 1,
            cumulative_delta_st_f64_bits_hex: "3ff0000000000000".to_owned(),
            epoch: 0,
            epoch_size: 82,
            epoch_size_rule:
                "two plus maximum frozen episode_length so no scheduled height is an epoch-end height"
                    .to_owned(),
            key_derivation_domain: VALIDATOR_KEY_DOMAIN.to_owned(),
            key_derivation_formula:
                "Ed25519SigningKey(SHA256(enc_text(domain)||raw_manifest_core_hash))".to_owned(),
            slot: 0,
        },
    }
}

pub fn validate_fixture_catalog(catalog: &FixtureCatalog) -> Result<()> {
    if catalog != &frozen_catalog() {
        return Err(ManifestError::new(
            "fixture catalog differs from the frozen CAL-MAN-1 catalog",
        ));
    }
    for fixture in &catalog.fixtures {
        validate_fixture_semantics(fixture)?;
    }
    Ok(())
}

fn validate_fixture_semantics(fixture: &Fixture) -> Result<()> {
    let node_count = usize::try_from(fixture.node_count)
        .map_err(|_| ManifestError::new("node count cannot fit usize"))?;
    for balances in &fixture.initial_balances {
        if balances.len() != node_count
            || balances
                .iter()
                .try_fold(0u64, |sum, value| sum.checked_add(*value))
                != Some(fixture.inventory_microtau)
        {
            return Err(ManifestError::new(format!(
                "invalid initial inventory for {}",
                fixture.fixture_id
            )));
        }
    }
    for permutation in &fixture.permutations {
        validate_permutation(&permutation.image_by_node, node_count)?;
    }
    for partition in &fixture.reporting_partitions {
        let mut union = partition.left_nodes.clone();
        union.extend_from_slice(&partition.right_nodes);
        union.sort_unstable();
        if union != (1..=fixture.node_count).collect::<Vec<_>>() {
            return Err(ManifestError::new(format!(
                "reporting partition {} is not a full disjoint node partition",
                partition.partition_id
            )));
        }
    }
    Ok(())
}

pub fn validate_policy_config(policy: &PolicyConfig) -> Result<()> {
    if policy != &frozen_policy() {
        return Err(ManifestError::new(
            "policy configuration differs from the frozen preregistered schedule",
        ));
    }
    Ok(())
}

pub fn validate_reporting_policy(
    reporting: &ReportingPolicy,
    actor_policy: &PolicyConfig,
) -> Result<()> {
    if reporting != &frozen_reporting_policy() {
        return Err(ManifestError::new(
            "reporting policy differs from the frozen generic analysis contract",
        ));
    }
    if reporting.acceptance.journal_external_actor_seal_count != actor_policy.episode_count
        || reporting.acceptance.exact_decision_join_count != actor_policy.decision_count
    {
        return Err(ManifestError::new(
            "reporting acceptance totals differ from the frozen actor schedule",
        ));
    }
    Ok(())
}

pub fn validate_claim_contract(contract: &ClaimContract) -> Result<()> {
    if contract != &frozen_claim_contract() {
        return Err(ManifestError::new(
            "claim contract differs from the frozen preregistration and theory boundary",
        ));
    }
    Ok(())
}

pub fn validate_genesis_recipe(recipe: &GenesisRecipe, policy: &PolicyConfig) -> Result<()> {
    if recipe != &frozen_genesis_recipe() {
        return Err(ManifestError::new(
            "genesis recipe differs from the frozen clean one-validator construction",
        ));
    }
    let maximum_episode_length = policy
        .schedules
        .iter()
        .map(|row| row.episode_length)
        .max()
        .ok_or_else(|| ManifestError::new("policy has no episode lengths"))?;
    let safe_epoch_size = maximum_episode_length
        .checked_add(2)
        .ok_or_else(|| ManifestError::new("maximum episode length cannot fit a safe epoch"))?;
    if recipe.validator_construction.epoch_size != safe_epoch_size {
        return Err(ManifestError::new(
            "genesis validator epoch does not safely contain the longest episode",
        ));
    }
    Ok(())
}

pub fn validate_inputs(repo_root: &Path) -> Result<()> {
    let catalog: FixtureCatalog = read_canonical_json(&repo_root.join(FIXTURE_CATALOG_PATH))?;
    let policy: PolicyConfig = read_canonical_json(&repo_root.join(POLICY_CONFIG_PATH))?;
    let reporting: ReportingPolicy =
        read_preexecution_json(&repo_root.join(REPORTING_POLICY_PATH))?;
    let claims: ClaimContract = read_canonical_json(&repo_root.join(CLAIM_CONTRACT_PATH))?;
    let recipe: GenesisRecipe = read_canonical_json(&repo_root.join(GENESIS_RECIPE_PATH))?;
    let build_recipe: BuildRecipe = read_canonical_json(&repo_root.join(BUILD_RECIPE_PATH))?;
    validate_fixture_catalog(&catalog)?;
    validate_policy_config(&policy)?;
    validate_reporting_policy(&reporting, &policy)?;
    validate_claim_contract(&claims)?;
    validate_genesis_recipe(&recipe, &policy)?;
    validate_build_recipe_contract(&build_recipe)?;
    let schedule = expand_schedule(&catalog, &policy)?;
    validate_schedule(&schedule, &catalog, &policy)?;
    Ok(())
}

fn validate_permutation(image_by_node: &[u32], node_count: usize) -> Result<()> {
    if image_by_node.len() != node_count {
        return Err(ManifestError::new("permutation length mismatch"));
    }
    let expected = (1..=u32::try_from(node_count)
        .map_err(|_| ManifestError::new("node count exceeds u32"))?)
        .collect::<BTreeSet<_>>();
    let actual = image_by_node.iter().copied().collect::<BTreeSet<_>>();
    if actual != expected || actual.len() != image_by_node.len() {
        return Err(ManifestError::new(
            "image_by_node is not a bijection on canonical node labels",
        ));
    }
    Ok(())
}

pub fn relabel_balances(balances: &[u64], image_by_node: &[u32]) -> Result<Vec<u64>> {
    validate_permutation(image_by_node, balances.len())?;
    let mut relabelled = vec![0; balances.len()];
    for (source_index, image) in image_by_node.iter().enumerate() {
        let target_index = usize::try_from(image - 1)
            .map_err(|_| ManifestError::new("permutation image cannot fit usize"))?;
        relabelled[target_index] = balances[source_index];
    }
    Ok(relabelled)
}

pub fn relabel_edges(edges: &[[u32; 2]], image_by_node: &[u32]) -> Result<Vec<[u32; 2]>> {
    validate_permutation(image_by_node, image_by_node.len())?;
    let mut relabelled = Vec::with_capacity(edges.len());
    for [left, right] in edges {
        let left_index = usize::try_from(left - 1)
            .map_err(|_| ManifestError::new("edge endpoint cannot fit usize"))?;
        let right_index = usize::try_from(right - 1)
            .map_err(|_| ManifestError::new("edge endpoint cannot fit usize"))?;
        let mapped_left = *image_by_node
            .get(left_index)
            .ok_or_else(|| ManifestError::new("edge endpoint outside permutation"))?;
        let mapped_right = *image_by_node
            .get(right_index)
            .ok_or_else(|| ManifestError::new("edge endpoint outside permutation"))?;
        relabelled.push([mapped_left.min(mapped_right), mapped_left.max(mapped_right)]);
    }
    relabelled.sort_unstable();
    if relabelled.windows(2).any(|pair| pair[0] == pair[1]) {
        return Err(ManifestError::new(
            "relabelled graph contains duplicate edges",
        ));
    }
    Ok(relabelled)
}

pub fn relabel_partition(
    partition: &ReportingPartition,
    image_by_node: &[u32],
) -> Result<ReportingPartition> {
    validate_permutation(image_by_node, image_by_node.len())?;
    let map_nodes = |nodes: &[u32]| -> Result<Vec<u32>> {
        let mut mapped = nodes
            .iter()
            .map(|node| {
                let index = usize::try_from(node - 1)
                    .map_err(|_| ManifestError::new("partition node cannot fit usize"))?;
                image_by_node
                    .get(index)
                    .copied()
                    .ok_or_else(|| ManifestError::new("partition node outside permutation"))
            })
            .collect::<Result<Vec<_>>>()?;
        mapped.sort_unstable();
        Ok(mapped)
    };
    Ok(ReportingPartition {
        left_nodes: map_nodes(&partition.left_nodes)?,
        partition_id: partition.partition_id.clone(),
        right_nodes: map_nodes(&partition.right_nodes)?,
    })
}

pub fn initial_kernel_view_bytes(
    fixture: &Fixture,
    horizon: u32,
    start_index: u32,
    permutation_index: u8,
    action_quantum_microtau: u64,
) -> Result<Vec<u8>> {
    let start = fixture
        .initial_balances
        .get(
            usize::try_from(start_index)
                .map_err(|_| ManifestError::new("start index cannot fit usize"))?,
        )
        .ok_or_else(|| ManifestError::new("start index outside fixture"))?;
    let permutation = fixture
        .permutations
        .get(usize::from(permutation_index))
        .ok_or_else(|| ManifestError::new("permutation index outside fixture"))?;
    let balances = relabel_balances(start, &permutation.image_by_node)?;
    let edges = relabel_edges(&fixture.account_edges, &permutation.image_by_node)?;

    let mut encoded = Vec::new();
    encode_text(&mut encoded, VIEW_DOMAIN)?;
    encoded.extend_from_slice(&fixture.node_count.to_be_bytes());
    for (index, balance) in balances.iter().enumerate() {
        let account = u32::try_from(index + 1)
            .map_err(|_| ManifestError::new("account index exceeds u32"))?;
        encoded.extend_from_slice(&account.to_be_bytes());
        encoded.extend_from_slice(&balance.to_be_bytes());
    }
    let edge_count =
        u32::try_from(edges.len()).map_err(|_| ManifestError::new("edge count exceeds u32"))?;
    encoded.extend_from_slice(&edge_count.to_be_bytes());
    for [low, high] in edges {
        encoded.extend_from_slice(&low.to_be_bytes());
        encoded.extend_from_slice(&high.to_be_bytes());
    }
    encoded.extend_from_slice(&horizon.to_be_bytes());
    encoded.extend_from_slice(&action_quantum_microtau.to_be_bytes());
    Ok(encoded)
}

pub fn initial_kernel_view_hash(
    fixture: &Fixture,
    horizon: u32,
    start_index: u32,
    permutation_index: u8,
    action_quantum_microtau: u64,
) -> Result<String> {
    Ok(raw_sha256_hex(&initial_kernel_view_bytes(
        fixture,
        horizon,
        start_index,
        permutation_index,
        action_quantum_microtau,
    )?))
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EpisodeDescriptor {
    pub episode_id: u64,
    pub episode_length: u64,
    pub fixture_id: String,
    pub horizon: u32,
    pub initial_kernel_view_hash: String,
    pub permutation_index: u8,
    pub relative_dir: String,
    pub schedule_index: u32,
    pub start_index: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Schedule {
    pub cell_count: u32,
    pub decision_count: u64,
    pub episode_count: u32,
    pub episodes: Vec<EpisodeDescriptor>,
    pub order: Vec<String>,
    pub per_fixture_decision_count: BTreeMap<String, u64>,
    pub schema: String,
}

pub fn expand_schedule(catalog: &FixtureCatalog, policy: &PolicyConfig) -> Result<Schedule> {
    validate_fixture_catalog(catalog)?;
    validate_policy_config(policy)?;
    let mut episodes = Vec::new();
    let mut cell_count = 0u32;
    let mut decision_count = 0u64;
    let mut per_fixture_decision_count = BTreeMap::<String, u64>::new();

    for fixture in &catalog.fixtures {
        for &horizon in &fixture.horizons {
            let row = policy
                .schedules
                .iter()
                .find(|row| row.fixture_id == fixture.fixture_id && row.horizon == horizon)
                .ok_or_else(|| ManifestError::new("missing fixture/horizon schedule row"))?;
            for start_index in 0..fixture.initial_balances.len() {
                for permutation_index in 0..fixture.permutations.len() {
                    cell_count = cell_count
                        .checked_add(1)
                        .ok_or_else(|| ManifestError::new("cell count overflow"))?;
                    for episode_id in 0..u64::from(policy.episodes_per_cell) {
                        let schedule_index = u32::try_from(episodes.len())
                            .map_err(|_| ManifestError::new("schedule index exceeds u32"))?;
                        let start_index = u32::try_from(start_index)
                            .map_err(|_| ManifestError::new("start index exceeds u32"))?;
                        let permutation_index = u8::try_from(permutation_index)
                            .map_err(|_| ManifestError::new("permutation index exceeds u8"))?;
                        let relative_dir = format!(
                            "{schedule_index:04}-{}-h{horizon:02}-s{start_index:02}-p{permutation_index}-e{episode_id:02}",
                            fixture.fixture_id
                        );
                        episodes.push(EpisodeDescriptor {
                            episode_id,
                            episode_length: row.episode_length,
                            fixture_id: fixture.fixture_id.clone(),
                            horizon,
                            initial_kernel_view_hash: initial_kernel_view_hash(
                                fixture,
                                horizon,
                                start_index,
                                permutation_index,
                                policy.action_quantum_microtau,
                            )?,
                            permutation_index,
                            relative_dir,
                            schedule_index,
                            start_index,
                        });
                        decision_count = decision_count
                            .checked_add(row.episode_length)
                            .ok_or_else(|| ManifestError::new("decision count overflow"))?;
                        let fixture_decisions = per_fixture_decision_count
                            .entry(fixture.fixture_id.clone())
                            .or_default();
                        *fixture_decisions = fixture_decisions
                            .checked_add(row.episode_length)
                            .ok_or_else(|| ManifestError::new("fixture decision count overflow"))?;
                    }
                }
            }
        }
    }
    let episode_count = u32::try_from(episodes.len())
        .map_err(|_| ManifestError::new("episode count exceeds u32"))?;
    let schedule = Schedule {
        cell_count,
        decision_count,
        episode_count,
        episodes,
        order: policy.schedule_order.clone(),
        per_fixture_decision_count,
        schema: SCHEDULE_SCHEMA.to_owned(),
    };
    validate_schedule(&schedule, catalog, policy)?;
    Ok(schedule)
}

pub fn validate_schedule(
    schedule: &Schedule,
    catalog: &FixtureCatalog,
    policy: &PolicyConfig,
) -> Result<()> {
    if schedule.schema != SCHEDULE_SCHEMA
        || schedule.cell_count != policy.schedule_cell_count
        || schedule.decision_count != policy.decision_count
        || schedule.episode_count != policy.episode_count
        || schedule.order != policy.schedule_order
        || schedule.per_fixture_decision_count != policy.fixture_decision_counts
        || usize::try_from(schedule.episode_count).ok() != Some(schedule.episodes.len())
    {
        return Err(ManifestError::new(
            "schedule totals or ordering metadata mismatch",
        ));
    }
    let mut coordinates = BTreeSet::new();
    let mut directories = BTreeSet::new();
    for (index, episode) in schedule.episodes.iter().enumerate() {
        if usize::try_from(episode.schedule_index).ok() != Some(index)
            || !coordinates.insert((
                episode.fixture_id.clone(),
                episode.horizon,
                episode.start_index,
                episode.permutation_index,
                episode.episode_id,
            ))
            || !directories.insert(episode.relative_dir.clone())
        {
            return Err(ManifestError::new(
                "duplicate or non-canonical schedule coordinate",
            ));
        }
        let fixture = catalog
            .fixtures
            .iter()
            .find(|fixture| fixture.fixture_id == episode.fixture_id)
            .ok_or_else(|| ManifestError::new("schedule references unknown fixture"))?;
        let expected_hash = initial_kernel_view_hash(
            fixture,
            episode.horizon,
            episode.start_index,
            episode.permutation_index,
            policy.action_quantum_microtau,
        )?;
        if episode.initial_kernel_view_hash != expected_hash {
            return Err(ManifestError::new(
                "schedule initial kernel-view hash mismatch",
            ));
        }
    }
    Ok(())
}

pub fn derive_episode_nonce(
    seed_manifest_hash: [u8; 32],
    episode: &EpisodeDescriptor,
) -> Result<[u8; 32]> {
    let mut encoded = Vec::new();
    encode_text(&mut encoded, NONCE_DOMAIN)?;
    encoded.extend_from_slice(&seed_manifest_hash);
    encode_text(&mut encoded, &episode.fixture_id)?;
    encoded.extend_from_slice(&episode.horizon.to_be_bytes());
    encoded.extend_from_slice(&episode.start_index.to_be_bytes());
    encoded.push(episode.permutation_index);
    encoded.extend_from_slice(&episode.episode_id.to_be_bytes());
    Ok(sha256(&encoded))
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ComponentFreeze {
    pub artifact_paths: Vec<String>,
    pub source_paths: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ImplementationFreeze {
    pub commit: String,
    pub toolchains: BTreeMap<String, String>,
    pub tree: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ArtifactFreeze {
    pub commit: String,
    pub tree: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildReceipt {
    build_record: BuildRecord,
    comparison: BuildComparison,
    schema: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildRecord {
    build: BuildConfiguration,
    build_script_sha256: String,
    ceremony_source_paths: Vec<String>,
    components: BTreeMap<String, BuildComponent>,
    implementation_commit: String,
    implementation_tree: String,
    schema: String,
    system: BuildSystem,
    toolchain: BuildToolchain,
    uname: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildConfiguration {
    cargo_frozen: bool,
    cargo_incremental: String,
    cargo_profile: String,
    default_features: bool,
    environment: BTreeMap<String, String>,
    explicit_features: Vec<String>,
    fresh_cargo_home: bool,
    linker_path: String,
    linker_version: String,
    rustflags: Vec<String>,
    target: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildToolchain {
    cargo_binary_sha256: String,
    cargo_vv: String,
    installed_name: String,
    rust_std_file_count: u64,
    rust_std_tree_sha256: String,
    rustc_binary_sha256: String,
    rustc_vv: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildSystem {
    clang_path: String,
    clang_version: String,
    clt_package: String,
    code_signature_policy: String,
    dep_info_external: BTreeMap<String, BuildExternalInputs>,
    developer_dir: String,
    ld_path: String,
    ld_version: String,
    platform: String,
    sdk_build_version: String,
    sdk_path: String,
    sdk_version: String,
    uuid_policy: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildExternalInputs {
    generated: BuildPathClassIdentity,
    registry: BuildPathClassIdentity,
    rust_std: BuildPathClassIdentity,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildPathClassIdentity {
    count: u64,
    sha256: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildComponent {
    artifact: BuildArtifact,
    cargo_config_paths: Vec<String>,
    cargo_manifest: String,
    cargo_metadata_sha256: String,
    cargo_tree_features_sha256: String,
    dep_info_sources: Vec<String>,
    launch_probe: BuildLaunchProbe,
    local_manifests: Vec<String>,
    local_target_sources: Vec<String>,
    lockfiles: Vec<String>,
    mach_o_uuid: String,
    workspace_manifests: Vec<String>,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildLaunchProbe {
    argument: String,
    exit_code: i32,
    output_sha256: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildArtifact {
    basename: String,
    length_bytes: u64,
    sha256: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildComparison {
    artifact_byte_identical: bool,
    build_count: u32,
    build_record_identical: bool,
    build_record_sha256: String,
    method: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildRecipe {
    apparatus_prefix: String,
    build: BuildRecipeConfiguration,
    build_receipt_basename: String,
    ceremony_source_paths: Vec<String>,
    components: BTreeMap<String, BuildRecipeComponent>,
    schema: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildRecipeConfiguration {
    cargo_fetch: String,
    cargo_frozen: bool,
    cargo_incremental: String,
    cargo_profile: String,
    default_features: bool,
    dual_build_method: String,
    environment: BuildRecipeEnvironment,
    explicit_features: Vec<String>,
    fresh_cargo_home: bool,
    linker_path: String,
    macos_code_signature_policy: String,
    macos_uuid_policy: String,
    rustflags: Vec<String>,
    target: String,
    toolchain: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildRecipeEnvironment {
    fixed: BTreeMap<String, String>,
    source_date_epoch: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BuildRecipeComponent {
    artifact_basename: String,
    cargo_manifest: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PreregistrationFreeze {
    pub commit: String,
    pub path: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CoreFreezeMetadata {
    pub artifact_freeze: ArtifactFreeze,
    pub build_receipt_path: String,
    pub components: BTreeMap<String, ComponentFreeze>,
    pub implementation_freeze: ImplementationFreeze,
    pub implementation_source_paths: Vec<String>,
    pub preregistration: PreregistrationFreeze,
    pub schema: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ComponentIdentity {
    pub artifact_set: FileSetIdentity,
    pub source_set: FileSetIdentity,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PreregistrationIdentity {
    pub commit: String,
    pub file: RawFileIdentity,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CoreManifest {
    pub artifact_freeze: ArtifactFreeze,
    pub build_receipt: RawFileIdentity,
    pub components: BTreeMap<String, ComponentIdentity>,
    pub fixture_catalog: RawFileIdentity,
    pub fixture_catalog_hash: String,
    pub genesis_recipe: RawFileIdentity,
    pub genesis_recipe_hash: String,
    pub implementation_freeze: ImplementationFreeze,
    pub implementation_source_set: FileSetIdentity,
    pub policy_config_hash: String,
    pub policy_configuration: RawFileIdentity,
    pub preregistration: PreregistrationIdentity,
    pub reporting_policy: RawFileIdentity,
    pub reporting_policy_hash: String,
    pub schedule: Schedule,
    pub schema: String,
}

fn validate_component_names<T>(components: &BTreeMap<String, T>) -> Result<()> {
    let actual = components.keys().cloned().collect::<Vec<_>>();
    let expected = vec![
        "actor".to_owned(),
        "analysis".to_owned(),
        "claim".to_owned(),
        "manifest".to_owned(),
        "observer".to_owned(),
    ];
    if actual != expected {
        return Err(ManifestError::new(
            "components must be exactly actor, analysis, claim, manifest, and observer",
        ));
    }
    Ok(())
}

fn validate_sorted_paths(paths: &[String], label: &str) -> Result<()> {
    for path in paths {
        validate_repo_path(path)?;
    }
    if paths
        .windows(2)
        .any(|pair| pair[0].as_bytes() >= pair[1].as_bytes())
    {
        return Err(ManifestError::new(format!(
            "{label} paths must be unique and byte-lexicographically sorted"
        )));
    }
    Ok(())
}

fn validate_durable_artifact_paths(paths: &[String], label: &str) -> Result<()> {
    for path in paths {
        if !path.starts_with(APPARATUS_PREFIX) {
            return Err(ManifestError::new(format!(
                "{label} artifact must be a durable committed copy under {APPARATUS_PREFIX}: {path}"
            )));
        }
    }
    Ok(())
}

fn required_sources(component: &str) -> Result<&'static [&'static str]> {
    match component {
        "actor" => Ok(&ACTOR_REQUIRED_SOURCE_PATHS),
        "analysis" => Ok(&ANALYSIS_REQUIRED_SOURCE_PATHS),
        "claim" => Ok(&CLAIM_REQUIRED_SOURCE_PATHS),
        "manifest" => Ok(&MANIFEST_REQUIRED_SOURCE_PATHS),
        "observer" => Ok(&OBSERVER_REQUIRED_SOURCE_PATHS),
        _ => Err(ManifestError::new(format!(
            "unknown component contract: {component}"
        ))),
    }
}

fn expected_artifact_basename(component: &str) -> Result<Option<&'static str>> {
    match component {
        "actor" => Ok(Some("xypher-calorimeter-runner")),
        "analysis" => Ok(Some("xypher-calorimeter-analysis")),
        "claim" => Ok(None),
        "manifest" => Ok(Some("xypher-calorimeter-manifest")),
        "observer" => Ok(Some("xypher-calorimeter-observer")),
        _ => Err(ManifestError::new(format!(
            "unknown component contract: {component}"
        ))),
    }
}

fn validate_component_contracts(
    components: &BTreeMap<String, (Vec<String>, Vec<String>)>,
) -> Result<()> {
    validate_component_names(components)?;
    let mut source_owners = BTreeMap::<String, String>::new();
    let mut artifact_paths = BTreeSet::<String>::new();

    for (name, (sources, artifacts)) in components {
        for required in required_sources(name)? {
            if !sources.iter().any(|path| path == required) {
                return Err(ManifestError::new(format!(
                    "{name} source-set must bind {required}"
                )));
            }
        }
        for source in sources {
            if let Some(owner) = source_owners.insert(source.clone(), name.clone()) {
                return Err(ManifestError::new(format!(
                    "source path is owned by both {owner} and {name}: {source}"
                )));
            }
        }

        match expected_artifact_basename(name)? {
            None => {
                if !artifacts.is_empty() {
                    return Err(ManifestError::new(
                        "claim artifact-set must be exactly empty",
                    ));
                }
            }
            Some(expected) => {
                if artifacts.len() != 1 {
                    return Err(ManifestError::new(format!(
                        "{name} artifact-set must contain exactly one frozen binary"
                    )));
                }
                let path = &artifacts[0];
                if !artifact_paths.insert(path.clone()) {
                    return Err(ManifestError::new(format!(
                        "artifact path is shared by multiple components: {path}"
                    )));
                }
                let basename = Path::new(path)
                    .file_name()
                    .and_then(|value| value.to_str())
                    .ok_or_else(|| ManifestError::new("artifact basename is not UTF-8"))?;
                if basename != expected {
                    return Err(ManifestError::new(format!(
                        "{name} artifact basename must be {expected}, found {basename}"
                    )));
                }
            }
        }
    }
    Ok(())
}

fn validate_apparatus_target_layout(
    components: &BTreeMap<String, (Vec<String>, Vec<String>)>,
    build_receipt_path: &str,
    target: &str,
) -> Result<()> {
    require_ascii("build target", target)?;
    if target.is_empty()
        || target
            .bytes()
            .any(|byte| !(byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'-'))
    {
        return Err(ManifestError::new(
            "build target must use lowercase alphanumeric target-triple spelling",
        ));
    }
    let target_directory = format!("{APPARATUS_PREFIX}{target}");
    for (name, (_, artifacts)) in components {
        for artifact in artifacts {
            let parent = Path::new(artifact)
                .parent()
                .and_then(Path::to_str)
                .ok_or_else(|| ManifestError::new("artifact parent path is not UTF-8"))?;
            if parent != target_directory {
                return Err(ManifestError::new(format!(
                    "{name} artifact must share the frozen target directory {target_directory}"
                )));
            }
        }
    }
    let expected_receipt = format!("{target_directory}/{BUILD_RECEIPT_BASENAME}");
    if build_receipt_path != expected_receipt {
        return Err(ManifestError::new(format!(
            "build receipt must be {expected_receipt}"
        )));
    }
    Ok(())
}

fn validate_artifact_content_distinct(
    components: &BTreeMap<String, ComponentIdentity>,
) -> Result<()> {
    let mut content_identities = BTreeSet::<(u64, String)>::new();
    for name in ["actor", "analysis", "manifest", "observer"] {
        let component = components
            .get(name)
            .ok_or_else(|| ManifestError::new(format!("missing {name} component")))?;
        let artifact = component
            .artifact_set
            .files
            .first()
            .ok_or_else(|| ManifestError::new(format!("missing {name} artifact")))?;
        if !content_identities.insert((artifact.length_bytes, artifact.sha256.clone())) {
            return Err(ManifestError::new(format!(
                "{name} artifact content identity duplicates another component"
            )));
        }
    }
    Ok(())
}

pub fn validate_manifest_executable_bytes(
    executable_path: &Path,
    components: &BTreeMap<String, ComponentIdentity>,
) -> Result<()> {
    let metadata = fs::symlink_metadata(executable_path)?;
    if metadata.file_type().is_symlink() || !metadata.is_file() {
        return Err(ManifestError::new(
            "running manifest executable must be a regular non-symlink file",
        ));
    }
    let bytes = fs::read(executable_path)?;
    let manifest_artifact = components
        .get("manifest")
        .and_then(|component| component.artifact_set.files.first())
        .ok_or_else(|| ManifestError::new("manifest component has no frozen CLI artifact"))?;
    let length = u64::try_from(bytes.len())
        .map_err(|_| ManifestError::new("running executable length exceeds u64"))?;
    if length != manifest_artifact.length_bytes
        || raw_sha256_hex(&bytes) != manifest_artifact.sha256
    {
        return Err(ManifestError::new(
            "running manifest executable bytes do not match the frozen manifest artifact",
        ));
    }
    Ok(())
}

fn validate_current_manifest_executable(
    components: &BTreeMap<String, ComponentIdentity>,
) -> Result<()> {
    validate_manifest_executable_bytes(&std::env::current_exe()?, components)
}

fn validate_implementation_freeze(freeze: &ImplementationFreeze) -> Result<()> {
    validate_git_hash("implementation freeze commit", &freeze.commit)?;
    validate_git_hash("implementation freeze tree", &freeze.tree)?;
    let expected_toolchains = [
        "cargo", "clang", "clt", "ld", "linker", "rust_std", "rustc", "sdk", "target",
    ];
    if freeze
        .toolchains
        .keys()
        .map(String::as_str)
        .collect::<Vec<_>>()
        != expected_toolchains
    {
        return Err(ManifestError::new(
            "implementation freeze toolchains must be exactly cargo, clang, clt, ld, linker, rust_std, rustc, sdk, and target",
        ));
    }
    for (name, value) in &freeze.toolchains {
        require_ascii("toolchain name", name)?;
        require_ascii("toolchain identity", value)?;
        if name.is_empty() || value.is_empty() {
            return Err(ManifestError::new("toolchain identities cannot be empty"));
        }
    }
    Ok(())
}

fn validate_artifact_freeze(freeze: &ArtifactFreeze) -> Result<()> {
    validate_git_hash("artifact freeze commit", &freeze.commit)?;
    validate_git_hash("artifact freeze tree", &freeze.tree)
}

fn validate_receipt_paths(
    paths: &[String],
    label: &str,
    implementation_sources: &BTreeSet<&str>,
) -> Result<()> {
    validate_sorted_paths(paths, label)?;
    for path in paths {
        if !implementation_sources.contains(path.as_str()) {
            return Err(ManifestError::new(format!(
                "{label} path is absent from the implementation source-set: {path}"
            )));
        }
    }
    Ok(())
}

fn instantiated_build_flag_matches(template: &str, actual: &str) -> bool {
    for placeholder in ["{repo}", "{target_dir}"] {
        if let Some((prefix, suffix)) = template.split_once(placeholder) {
            return actual.starts_with(prefix)
                && actual.ends_with(suffix)
                && actual.len() > prefix.len() + suffix.len();
        }
    }
    template == actual
}

fn validate_build_recipe_contract(recipe: &BuildRecipe) -> Result<()> {
    if recipe.schema != BUILD_RECIPE_SCHEMA
        || recipe.apparatus_prefix != APPARATUS_PREFIX
        || recipe.build_receipt_basename != BUILD_RECEIPT_BASENAME
    {
        return Err(ManifestError::new(
            "build recipe schema or apparatus layout mismatch",
        ));
    }
    let expected_component_names = ["actor", "analysis", "manifest", "observer"]
        .into_iter()
        .map(str::to_owned)
        .collect::<BTreeSet<_>>();
    if recipe.components.keys().cloned().collect::<BTreeSet<_>>() != expected_component_names {
        return Err(ManifestError::new(
            "build recipe components must be exactly actor, analysis, manifest, and observer",
        ));
    }
    let build = &recipe.build;
    if build.cargo_fetch != "locked-network-into-empty-home-then-frozen-offline"
        || build.source_date_epoch_rule() != "implementation-commit-timestamp"
        || build.cargo_profile != "release"
        || !build.cargo_frozen
        || build.cargo_incremental != "0"
        || !build.default_features
        || !build.explicit_features.is_empty()
        || !build.fresh_cargo_home
        || build.dual_build_method != "sequential-clean-detached-same-canonical-source-path"
        || build.macos_code_signature_policy != "adhoc-linker-signed-no-timestamp"
        || build.macos_uuid_policy != MACOS_UUID_POLICY
        || build.linker_path.is_empty()
        || build.target.is_empty()
        || build.toolchain.is_empty()
        || build.rustflags.is_empty()
        || !build
            .rustflags
            .iter()
            .any(|flag| flag.contains("--remap-path-prefix="))
        || build
            .rustflags
            .iter()
            .any(|flag| is_forbidden_mach_o_uuid_flag(flag))
        || build
            .environment
            .fixed
            .get("CARGO_INCREMENTAL")
            .map(String::as_str)
            != Some("0")
        || !build
            .environment
            .fixed
            .contains_key("MACOSX_DEPLOYMENT_TARGET")
    {
        return Err(ManifestError::new(
            "build recipe differs from the frozen release, UUID, environment, or cache policy",
        ));
    }
    validate_sorted_paths(
        &recipe.ceremony_source_paths,
        "build recipe ceremony source",
    )?;
    for (name, component) in &recipe.components {
        let expected_basename = expected_artifact_basename(name)?
            .ok_or_else(|| ManifestError::new("build recipe unexpectedly contains claim"))?;
        if component.artifact_basename != expected_basename {
            return Err(ManifestError::new(format!(
                "{name} build recipe artifact basename must be {expected_basename}"
            )));
        }
        validate_repo_path(&component.cargo_manifest)?;
    }
    Ok(())
}

fn validate_build_recipe(
    repo_root: &Path,
    receipt: &BuildReceipt,
    implementation_sources: &BTreeSet<&str>,
) -> Result<()> {
    let recipe_bytes = fs::read(secure_repo_file_path(repo_root, BUILD_RECIPE_PATH)?)?;
    validate_canonical_json(&recipe_bytes)?;
    let recipe: BuildRecipe = serde_json::from_slice(&recipe_bytes)?;
    validate_build_recipe_contract(&recipe)?;
    let build = &receipt.build_record.build;
    let frozen = &recipe.build;
    if frozen.cargo_fetch != "locked-network-into-empty-home-then-frozen-offline"
        || frozen.source_date_epoch_rule() != "implementation-commit-timestamp"
        || frozen.target != build.target
        || frozen.toolchain != receipt.build_record.toolchain.installed_name
        || frozen.linker_path != build.linker_path
        || frozen.cargo_profile != build.cargo_profile
        || frozen.cargo_frozen != build.cargo_frozen
        || frozen.cargo_incremental != build.cargo_incremental
        || frozen.default_features != build.default_features
        || frozen.explicit_features != build.explicit_features
        || frozen.fresh_cargo_home != build.fresh_cargo_home
        || frozen.dual_build_method != receipt.comparison.method
        || frozen.macos_code_signature_policy != receipt.build_record.system.code_signature_policy
        || frozen.macos_uuid_policy != MACOS_UUID_POLICY
        || frozen.macos_uuid_policy != receipt.build_record.system.uuid_policy
        || frozen.rustflags.len() != build.rustflags.len()
    {
        return Err(ManifestError::new(
            "build receipt differs from the canonical build recipe",
        ));
    }
    let mut actual_fixed_environment = build.environment.clone();
    let source_date_epoch = actual_fixed_environment
        .remove("SOURCE_DATE_EPOCH")
        .ok_or_else(|| ManifestError::new("build receipt has no SOURCE_DATE_EPOCH"))?;
    if source_date_epoch.is_empty()
        || !source_date_epoch.bytes().all(|byte| byte.is_ascii_digit())
        || actual_fixed_environment != frozen.environment.fixed
    {
        return Err(ManifestError::new(
            "build receipt environment differs from the canonical build recipe",
        ));
    }
    for (template, actual) in frozen.rustflags.iter().zip(&build.rustflags) {
        if !instantiated_build_flag_matches(template, actual) {
            return Err(ManifestError::new(
                "build receipt rustflags differ from the canonical build recipe",
            ));
        }
    }
    if recipe.ceremony_source_paths != receipt.build_record.ceremony_source_paths {
        return Err(ManifestError::new(
            "build receipt ceremony sources differ from the canonical build recipe",
        ));
    }
    validate_receipt_paths(
        &recipe.ceremony_source_paths,
        "build recipe ceremony source",
        implementation_sources,
    )?;
    for (name, recipe_component) in &recipe.components {
        let receipt_component = receipt
            .build_record
            .components
            .get(name)
            .ok_or_else(|| ManifestError::new(format!("build receipt is missing {name}")))?;
        if recipe_component.artifact_basename != receipt_component.artifact.basename
            || recipe_component.cargo_manifest != receipt_component.cargo_manifest
        {
            return Err(ManifestError::new(format!(
                "{name} build receipt differs from the canonical build recipe"
            )));
        }
    }
    Ok(())
}

impl BuildRecipeConfiguration {
    fn source_date_epoch_rule(&self) -> &str {
        &self.environment.source_date_epoch
    }
}

fn validate_build_receipt(
    repo_root: &Path,
    identity: &RawFileIdentity,
    implementation_freeze: &ImplementationFreeze,
    components: &BTreeMap<String, ComponentIdentity>,
    implementation_source_set: &FileSetIdentity,
) -> Result<()> {
    validate_raw_identity(repo_root, identity)?;
    let receipt_path = secure_repo_file_path(repo_root, &identity.path)?;
    let bytes = fs::read(receipt_path)?;
    validate_canonical_json(&bytes)?;
    let value: serde_json::Value = serde_json::from_slice(&bytes)?;
    let receipt: BuildReceipt = serde_json::from_value(value.clone())?;
    if receipt.schema != BUILD_RECEIPT_SCHEMA || receipt.build_record.schema != BUILD_RECORD_SCHEMA
    {
        return Err(ManifestError::new("unexpected build receipt schema"));
    }
    if receipt.build_record.implementation_commit != implementation_freeze.commit
        || receipt.build_record.implementation_tree != implementation_freeze.tree
    {
        return Err(ManifestError::new(
            "build receipt implementation commit/tree mismatch",
        ));
    }
    let expected_target = implementation_freeze
        .toolchains
        .get("target")
        .ok_or_else(|| ManifestError::new("implementation freeze has no target triple"))?;
    let build = &receipt.build_record.build;
    if &build.target != expected_target
        || build.cargo_profile != "release"
        || !build.cargo_frozen
        || build.cargo_incremental != "0"
        || !build.default_features
        || !build.explicit_features.is_empty()
        || !build.fresh_cargo_home
    {
        return Err(ManifestError::new(
            "build receipt does not bind the frozen release/default-feature/fresh-cache build",
        ));
    }
    if build.linker_path.is_empty()
        || build.linker_version.is_empty()
        || build.rustflags.is_empty()
        || !build
            .rustflags
            .iter()
            .any(|flag| flag.contains("--remap-path-prefix="))
        || build
            .rustflags
            .iter()
            .any(|flag| is_forbidden_mach_o_uuid_flag(flag))
        || build
            .environment
            .get("CARGO_INCREMENTAL")
            .map(String::as_str)
            != Some("0")
        || !build.environment.contains_key("SOURCE_DATE_EPOCH")
        || !build.environment.contains_key("MACOSX_DEPLOYMENT_TARGET")
    {
        return Err(ManifestError::new(
            "build receipt has a forbidden Mach-O UUID linker flag or is missing a load-bearing linker, environment, or path-remap setting",
        ));
    }
    let toolchain = &receipt.build_record.toolchain;
    for (label, hash) in [
        (
            "build-script hash",
            &receipt.build_record.build_script_sha256,
        ),
        ("rustc binary hash", &toolchain.rustc_binary_sha256),
        ("cargo binary hash", &toolchain.cargo_binary_sha256),
        ("rust-std tree hash", &toolchain.rust_std_tree_sha256),
    ] {
        decode_hash(label, hash)?;
    }
    if toolchain.installed_name.is_empty()
        || toolchain.rustc_vv.is_empty()
        || toolchain.cargo_vv.is_empty()
        || toolchain.rust_std_file_count == 0
        || receipt.build_record.uname.is_empty()
    {
        return Err(ManifestError::new(
            "build receipt toolchain or system identity is incomplete",
        ));
    }
    let system = &receipt.build_record.system;
    if [
        system.clang_path.as_str(),
        system.clang_version.as_str(),
        system.clt_package.as_str(),
        system.code_signature_policy.as_str(),
        system.developer_dir.as_str(),
        system.ld_path.as_str(),
        system.ld_version.as_str(),
        system.platform.as_str(),
        system.sdk_build_version.as_str(),
        system.sdk_path.as_str(),
        system.sdk_version.as_str(),
        system.uuid_policy.as_str(),
    ]
    .contains(&"")
        || system.code_signature_policy != "adhoc-linker-signed-no-timestamp"
        || system.uuid_policy != MACOS_UUID_POLICY
    {
        return Err(ManifestError::new(
            "build receipt system identity, code-signature policy, or Mach-O UUID policy is incomplete",
        ));
    }
    let expected_external_components = ["actor", "analysis", "manifest", "observer"]
        .into_iter()
        .map(str::to_owned)
        .collect::<BTreeSet<_>>();
    if system
        .dep_info_external
        .keys()
        .cloned()
        .collect::<BTreeSet<_>>()
        != expected_external_components
    {
        return Err(ManifestError::new(
            "build receipt external dep-info classes have the wrong component set",
        ));
    }
    for (component, classes) in &system.dep_info_external {
        for (class, identity) in [
            ("generated", &classes.generated),
            ("registry", &classes.registry),
            ("rust_std", &classes.rust_std),
        ] {
            decode_hash(
                &format!("{component} {class} dep-info class hash"),
                &identity.sha256,
            )?;
            let _ = identity.count;
        }
    }
    let expected_toolchains = BTreeMap::from([
        ("cargo".to_owned(), toolchain.cargo_vv.clone()),
        ("clang".to_owned(), system.clang_version.clone()),
        ("clt".to_owned(), system.clt_package.clone()),
        ("ld".to_owned(), system.ld_version.clone()),
        ("linker".to_owned(), build.linker_version.clone()),
        (
            "rust_std".to_owned(),
            format!(
                "{}:{}",
                toolchain.rust_std_file_count, toolchain.rust_std_tree_sha256
            ),
        ),
        ("rustc".to_owned(), toolchain.rustc_vv.clone()),
        (
            "sdk".to_owned(),
            format!("{}:{}", system.sdk_version, system.sdk_build_version),
        ),
        ("target".to_owned(), build.target.clone()),
    ]);
    if implementation_freeze.toolchains != expected_toolchains {
        return Err(ManifestError::new(
            "implementation freeze toolchain summary differs from the build receipt",
        ));
    }
    let comparison = &receipt.comparison;
    if !comparison.artifact_byte_identical
        || !comparison.build_record_identical
        || comparison.build_count != 2
        || comparison.method != "sequential-clean-detached-same-canonical-source-path"
    {
        return Err(ManifestError::new(
            "build receipt does not attest two byte-identical clean builds",
        ));
    }
    let build_record_value = value
        .get("build_record")
        .ok_or_else(|| ManifestError::new("build receipt has no build_record value"))?;
    let expected_build_record_hash = raw_sha256_hex(&canonical_json_bytes(build_record_value)?);
    if comparison.build_record_sha256 != expected_build_record_hash {
        return Err(ManifestError::new(
            "build receipt build_record hash mismatch",
        ));
    }

    let implementation_sources = implementation_source_set
        .files
        .iter()
        .map(|file| file.path.as_str())
        .collect::<BTreeSet<_>>();
    let build_script_identity = implementation_source_set
        .files
        .iter()
        .find(|file| file.path == BUILD_SCRIPT_PATH)
        .ok_or_else(|| {
            ManifestError::new("build script is absent from implementation source-set")
        })?;
    if build_script_identity.sha256 != receipt.build_record.build_script_sha256 {
        return Err(ManifestError::new(
            "build receipt build-script hash differs from the implementation source-set",
        ));
    }
    validate_build_recipe(repo_root, &receipt, &implementation_sources)?;
    validate_receipt_paths(
        &receipt.build_record.ceremony_source_paths,
        "build ceremony source",
        &implementation_sources,
    )?;
    let expected_components = ["actor", "analysis", "manifest", "observer"]
        .into_iter()
        .map(str::to_owned)
        .collect::<BTreeSet<_>>();
    if receipt
        .build_record
        .components
        .keys()
        .cloned()
        .collect::<BTreeSet<_>>()
        != expected_components
    {
        return Err(ManifestError::new(
            "build receipt components must be exactly actor, analysis, manifest, and observer",
        ));
    }
    let mut mach_o_uuids = BTreeSet::new();
    for (name, build_component) in &receipt.build_record.components {
        validate_mach_o_uuid(&format!("{name} Mach-O UUID"), &build_component.mach_o_uuid)?;
        if !mach_o_uuids.insert(build_component.mach_o_uuid.as_str()) {
            return Err(ManifestError::new(format!(
                "{name} Mach-O UUID duplicates another component"
            )));
        }
        validate_launch_probe(name, &build_component.launch_probe)?;
        let artifact = components
            .get(name)
            .and_then(|component| component.artifact_set.files.first())
            .ok_or_else(|| ManifestError::new(format!("missing {name} artifact identity")))?;
        let expected_basename = Path::new(&artifact.path)
            .file_name()
            .and_then(|value| value.to_str())
            .ok_or_else(|| ManifestError::new("artifact basename is not UTF-8"))?;
        if build_component.artifact.basename != expected_basename
            || build_component.artifact.length_bytes != artifact.length_bytes
            || build_component.artifact.sha256 != artifact.sha256
        {
            return Err(ManifestError::new(format!(
                "{name} build receipt artifact identity mismatch"
            )));
        }
        decode_hash(
            &format!("{name} cargo metadata hash"),
            &build_component.cargo_metadata_sha256,
        )?;
        decode_hash(
            &format!("{name} cargo tree/features hash"),
            &build_component.cargo_tree_features_sha256,
        )?;
        validate_repo_path(&build_component.cargo_manifest)?;
        if !implementation_sources.contains(build_component.cargo_manifest.as_str()) {
            return Err(ManifestError::new(format!(
                "{name} cargo manifest is absent from the implementation source-set"
            )));
        }
        for (label, paths) in [
            ("cargo configuration", &build_component.cargo_config_paths),
            ("release dep-info", &build_component.dep_info_sources),
            ("local manifest", &build_component.local_manifests),
            ("local target source", &build_component.local_target_sources),
            ("lockfile", &build_component.lockfiles),
            ("workspace manifest", &build_component.workspace_manifests),
        ] {
            validate_receipt_paths(paths, &format!("{name} {label}"), &implementation_sources)?;
        }
        if build_component.dep_info_sources.is_empty()
            || build_component.local_manifests.is_empty()
            || build_component.local_target_sources.is_empty()
            || build_component.lockfiles.is_empty()
            || !build_component
                .local_manifests
                .contains(&build_component.cargo_manifest)
        {
            return Err(ManifestError::new(format!(
                "{name} build receipt local closure is incomplete"
            )));
        }
    }
    Ok(())
}

fn validate_freeze_metadata(metadata: &CoreFreezeMetadata) -> Result<()> {
    if metadata.schema != CORE_FREEZE_SCHEMA {
        return Err(ManifestError::new("unexpected core freeze metadata schema"));
    }
    if metadata.preregistration.commit != BASE_PREREGISTRATION_COMMIT
        || metadata.preregistration.path != PREREGISTRATION_PATH
    {
        return Err(ManifestError::new(
            "core freeze must bind the frozen base preregistration commit and path",
        ));
    }
    validate_component_names(&metadata.components)?;
    validate_implementation_freeze(&metadata.implementation_freeze)?;
    validate_artifact_freeze(&metadata.artifact_freeze)?;
    if metadata.artifact_freeze.commit == metadata.implementation_freeze.commit
        || metadata.artifact_freeze.tree == metadata.implementation_freeze.tree
    {
        return Err(ManifestError::new(
            "artifact freeze must be distinct from the implementation freeze",
        ));
    }
    validate_repo_path(&metadata.build_receipt_path)?;
    if !metadata.build_receipt_path.starts_with(APPARATUS_PREFIX)
        || Path::new(&metadata.build_receipt_path)
            .file_name()
            .and_then(|value| value.to_str())
            != Some(BUILD_RECEIPT_BASENAME)
    {
        return Err(ManifestError::new(
            "build receipt must be a canonical xypher-calorimeter-build-receipt.json under the apparatus prefix",
        ));
    }
    validate_sorted_paths(
        &metadata.implementation_source_paths,
        "implementation source-set",
    )?;
    if metadata.implementation_source_paths != required_implementation_source_paths() {
        return Err(ManifestError::new(
            "implementation source-set must equal the complete frozen source union",
        ));
    }
    for (name, component) in &metadata.components {
        validate_sorted_paths(&component.source_paths, &format!("{name} source-set"))?;
        validate_sorted_paths(&component.artifact_paths, &format!("{name} artifact-set"))?;
        validate_durable_artifact_paths(&component.artifact_paths, name)?;
    }
    let contracts = metadata
        .components
        .iter()
        .map(|(name, component)| {
            (
                name.clone(),
                (
                    component.source_paths.clone(),
                    component.artifact_paths.clone(),
                ),
            )
        })
        .collect::<BTreeMap<_, _>>();
    validate_component_contracts(&contracts)?;
    validate_apparatus_target_layout(
        &contracts,
        &metadata.build_receipt_path,
        metadata
            .implementation_freeze
            .toolchains
            .get("target")
            .ok_or_else(|| ManifestError::new("implementation freeze has no target triple"))?,
    )?;
    let implementation_sources = metadata
        .implementation_source_paths
        .iter()
        .map(String::as_str)
        .collect::<BTreeSet<_>>();
    for required in IMPLEMENTATION_REQUIRED_SOURCE_PATHS {
        if !implementation_sources.contains(required) {
            return Err(ManifestError::new(format!(
                "implementation source-set must bind {required}"
            )));
        }
    }
    for (name, component) in &metadata.components {
        for path in &component.source_paths {
            if !implementation_sources.contains(path.as_str()) {
                return Err(ManifestError::new(format!(
                    "{name} semantic source partition is absent from the implementation source-set: {path}"
                )));
            }
        }
    }
    Ok(())
}

fn parse_canonical_with_key_scan<T>(bytes: &[u8], allow_nonce_fields: bool) -> Result<T>
where
    T: for<'de> Deserialize<'de>,
{
    validate_canonical_json(bytes)?;
    let mut deserializer = serde_json::Deserializer::from_slice(bytes);
    let value = CanonicalValue::deserialize(&mut deserializer)?;
    deserializer.end()?;
    reject_empirical_fields(&value)?;
    if !allow_nonce_fields {
        reject_named_fields(
            &value,
            &[
                "chain_id",
                "episode_nonce",
                "genesis_hash",
                "genesis_ledger_state_hash",
                "validator_public_key",
            ],
        )?;
    }
    Ok(serde_json::from_slice(bytes)?)
}

fn read_preexecution_json<T>(path: &Path) -> Result<T>
where
    T: for<'de> Deserialize<'de>,
{
    parse_canonical_with_key_scan(&fs::read(path)?, false)
}

fn reject_empirical_fields(value: &CanonicalValue) -> Result<()> {
    reject_named_fields(
        value,
        &[
            "eigenvalue",
            "eigenvalues",
            "empirical",
            "empirical_results",
            "observed_frequency",
            "outcome",
            "outcomes",
            "path_count",
            "path_counts",
            "result",
            "results",
            "sampled_decision",
            "sampled_decisions",
            "trajectories",
            "trajectory",
            "transition_frequencies",
        ],
    )
}

fn reject_named_fields(value: &CanonicalValue, forbidden: &[&str]) -> Result<()> {
    match value {
        CanonicalValue::Array(values) => {
            for value in values {
                reject_named_fields(value, forbidden)?;
            }
        }
        CanonicalValue::Object(values) => {
            for (key, value) in values {
                if forbidden.contains(&key.as_str()) {
                    return Err(ManifestError::new(format!(
                        "forbidden pre-execution field: {key}"
                    )));
                }
                reject_named_fields(value, forbidden)?;
            }
        }
        CanonicalValue::Bool(_) | CanonicalValue::Integer(_) | CanonicalValue::String(_) => {}
    }
    Ok(())
}

pub fn generate_core_manifest(
    repo_root: &Path,
    metadata: &CoreFreezeMetadata,
) -> Result<CoreManifest> {
    validate_freeze_metadata(metadata)?;
    let catalog: FixtureCatalog = read_canonical_json(&repo_root.join(FIXTURE_CATALOG_PATH))?;
    let policy: PolicyConfig = read_canonical_json(&repo_root.join(POLICY_CONFIG_PATH))?;
    let reporting: ReportingPolicy =
        read_preexecution_json(&repo_root.join(REPORTING_POLICY_PATH))?;
    let claims: ClaimContract = read_canonical_json(&repo_root.join(CLAIM_CONTRACT_PATH))?;
    let recipe: GenesisRecipe = read_canonical_json(&repo_root.join(GENESIS_RECIPE_PATH))?;
    validate_fixture_catalog(&catalog)?;
    validate_policy_config(&policy)?;
    validate_reporting_policy(&reporting, &policy)?;
    validate_claim_contract(&claims)?;
    validate_genesis_recipe(&recipe, &policy)?;

    let fixture_catalog = raw_file_identity(repo_root, FIXTURE_CATALOG_PATH)?;
    let genesis_recipe = raw_file_identity(repo_root, GENESIS_RECIPE_PATH)?;
    let policy_configuration = raw_file_identity(repo_root, POLICY_CONFIG_PATH)?;
    let reporting_policy = raw_file_identity(repo_root, REPORTING_POLICY_PATH)?;
    let preregistration_file = raw_file_identity(repo_root, &metadata.preregistration.path)?;
    let build_receipt = raw_file_identity(repo_root, &metadata.build_receipt_path)?;
    let implementation_source_set = file_set_identity(
        repo_root,
        IMPLEMENTATION_SOURCE_SET_DOMAIN,
        IMPLEMENTATION_SOURCE_SET_NAME,
        &metadata.implementation_source_paths,
    )?;
    let mut components = BTreeMap::new();
    for (name, component) in &metadata.components {
        components.insert(
            name.clone(),
            ComponentIdentity {
                artifact_set: artifact_set_identity(repo_root, name, &component.artifact_paths)?,
                source_set: source_set_identity(repo_root, name, &component.source_paths)?,
            },
        );
    }
    validate_artifact_content_distinct(&components)?;
    validate_build_receipt(
        repo_root,
        &build_receipt,
        &metadata.implementation_freeze,
        &components,
        &implementation_source_set,
    )?;
    Ok(CoreManifest {
        artifact_freeze: metadata.artifact_freeze.clone(),
        build_receipt,
        components,
        fixture_catalog_hash: fixture_catalog.sha256.clone(),
        fixture_catalog,
        genesis_recipe_hash: genesis_recipe.sha256.clone(),
        genesis_recipe,
        implementation_freeze: metadata.implementation_freeze.clone(),
        implementation_source_set,
        policy_config_hash: policy_configuration.sha256.clone(),
        policy_configuration,
        preregistration: PreregistrationIdentity {
            commit: metadata.preregistration.commit.clone(),
            file: preregistration_file,
        },
        reporting_policy_hash: reporting_policy.sha256.clone(),
        reporting_policy,
        schedule: expand_schedule(&catalog, &policy)?,
        schema: CORE_SCHEMA.to_owned(),
    })
}

pub fn write_core_manifest(
    repo_root: &Path,
    metadata_path: &Path,
    output_path: &Path,
) -> Result<CoreManifest> {
    let canonical_output = canonical_new_output(repo_root, output_path, MANIFEST_CORE_PATH)?;
    if metadata_path.as_os_str() != OsStr::new(CORE_FREEZE_METADATA_PATH) {
        return Err(ManifestError::new(format!(
            "core freeze metadata must use the exact canonical repository path {CORE_FREEZE_METADATA_PATH}"
        )));
    }
    let bytes = fs::read(secure_repo_file_path(repo_root, CORE_FREEZE_METADATA_PATH)?)?;
    let metadata: CoreFreezeMetadata = parse_canonical_with_key_scan(&bytes, false)?;
    let manifest = generate_core_manifest(repo_root, &metadata)?;
    validate_current_manifest_executable(&manifest.components)?;
    let canonical = canonical_json_bytes(&manifest)?;
    let _: CoreManifest = parse_canonical_with_key_scan(&canonical, false)?;
    atomic_write_new(&canonical_output, &canonical)?;
    Ok(manifest)
}

fn validate_raw_identity(repo_root: &Path, identity: &RawFileIdentity) -> Result<()> {
    if raw_file_identity(repo_root, &identity.path)? != *identity {
        return Err(ManifestError::new(format!(
            "raw file identity mismatch for {}",
            identity.path
        )));
    }
    Ok(())
}

fn validate_file_set(
    repo_root: &Path,
    identity: &FileSetIdentity,
    expected_domain: &str,
) -> Result<()> {
    if identity.domain != expected_domain {
        return Err(ManifestError::new("file-set hash domain mismatch"));
    }
    let paths = identity
        .files
        .iter()
        .map(|file| file.path.clone())
        .collect::<Vec<_>>();
    validate_sorted_paths(&paths, &identity.set_name)?;
    let expected = file_set_identity(repo_root, expected_domain, &identity.set_name, &paths)?;
    if expected != *identity {
        return Err(ManifestError::new(format!(
            "file-set identity mismatch for {}",
            identity.set_name
        )));
    }
    Ok(())
}

pub fn validate_core_manifest(repo_root: &Path, bytes: &[u8]) -> Result<CoreManifest> {
    let manifest: CoreManifest = parse_canonical_with_key_scan(bytes, false)?;
    if manifest.schema != CORE_SCHEMA {
        return Err(ManifestError::new("unexpected manifest-core schema"));
    }
    validate_component_names(&manifest.components)?;
    validate_implementation_freeze(&manifest.implementation_freeze)?;
    validate_artifact_freeze(&manifest.artifact_freeze)?;
    if manifest.artifact_freeze.commit == manifest.implementation_freeze.commit
        || manifest.artifact_freeze.tree == manifest.implementation_freeze.tree
    {
        return Err(ManifestError::new(
            "manifest core artifact freeze is not distinct from the implementation freeze",
        ));
    }
    if !manifest.build_receipt.path.starts_with(APPARATUS_PREFIX)
        || Path::new(&manifest.build_receipt.path)
            .file_name()
            .and_then(|value| value.to_str())
            != Some(BUILD_RECEIPT_BASENAME)
    {
        return Err(ManifestError::new(
            "manifest core build receipt path is outside the apparatus",
        ));
    }
    validate_raw_identity(repo_root, &manifest.build_receipt)?;
    if manifest.implementation_source_set.domain != IMPLEMENTATION_SOURCE_SET_DOMAIN
        || manifest.implementation_source_set.set_name != IMPLEMENTATION_SOURCE_SET_NAME
    {
        return Err(ManifestError::new(
            "manifest core implementation source-set identity mismatch",
        ));
    }
    validate_file_set(
        repo_root,
        &manifest.implementation_source_set,
        IMPLEMENTATION_SOURCE_SET_DOMAIN,
    )?;
    if manifest
        .implementation_source_set
        .files
        .iter()
        .map(|file| file.path.clone())
        .collect::<Vec<_>>()
        != required_implementation_source_paths()
    {
        return Err(ManifestError::new(
            "manifest core implementation source-set differs from the complete frozen source union",
        ));
    }
    validate_git_hash("preregistration commit", &manifest.preregistration.commit)?;
    if manifest.preregistration.commit != BASE_PREREGISTRATION_COMMIT
        || manifest.preregistration.file.path != PREREGISTRATION_PATH
    {
        return Err(ManifestError::new(
            "manifest core does not bind the frozen base preregistration",
        ));
    }
    validate_raw_identity(repo_root, &manifest.preregistration.file)?;
    validate_raw_identity(repo_root, &manifest.fixture_catalog)?;
    validate_raw_identity(repo_root, &manifest.genesis_recipe)?;
    validate_raw_identity(repo_root, &manifest.policy_configuration)?;
    validate_raw_identity(repo_root, &manifest.reporting_policy)?;
    if manifest.fixture_catalog.path != FIXTURE_CATALOG_PATH
        || manifest.genesis_recipe.path != GENESIS_RECIPE_PATH
        || manifest.policy_configuration.path != POLICY_CONFIG_PATH
        || manifest.reporting_policy.path != REPORTING_POLICY_PATH
        || manifest.fixture_catalog_hash != manifest.fixture_catalog.sha256
        || manifest.genesis_recipe_hash != manifest.genesis_recipe.sha256
        || manifest.policy_config_hash != manifest.policy_configuration.sha256
        || manifest.reporting_policy_hash != manifest.reporting_policy.sha256
    {
        return Err(ManifestError::new(
            "manifest core catalog, policy, reporting-policy, or genesis-recipe identity mismatch",
        ));
    }
    for (name, component) in &manifest.components {
        if component.source_set.set_name != *name || component.artifact_set.set_name != *name {
            return Err(ManifestError::new("component set name mismatch"));
        }
        validate_file_set(repo_root, &component.source_set, SOURCE_SET_DOMAIN)?;
        validate_file_set(repo_root, &component.artifact_set, ARTIFACT_SET_DOMAIN)?;
        let artifact_paths = component
            .artifact_set
            .files
            .iter()
            .map(|file| file.path.clone())
            .collect::<Vec<_>>();
        validate_durable_artifact_paths(&artifact_paths, name)?;
    }
    let contracts = manifest
        .components
        .iter()
        .map(|(name, component)| {
            (
                name.clone(),
                (
                    component
                        .source_set
                        .files
                        .iter()
                        .map(|file| file.path.clone())
                        .collect(),
                    component
                        .artifact_set
                        .files
                        .iter()
                        .map(|file| file.path.clone())
                        .collect(),
                ),
            )
        })
        .collect::<BTreeMap<_, _>>();
    validate_component_contracts(&contracts)?;
    validate_apparatus_target_layout(
        &contracts,
        &manifest.build_receipt.path,
        manifest
            .implementation_freeze
            .toolchains
            .get("target")
            .ok_or_else(|| ManifestError::new("manifest core has no target triple"))?,
    )?;
    let implementation_sources = manifest
        .implementation_source_set
        .files
        .iter()
        .map(|file| file.path.as_str())
        .collect::<BTreeSet<_>>();
    for required in IMPLEMENTATION_REQUIRED_SOURCE_PATHS {
        if !implementation_sources.contains(required) {
            return Err(ManifestError::new(format!(
                "manifest core implementation source-set must bind {required}"
            )));
        }
    }
    for (name, component) in &manifest.components {
        for source in &component.source_set.files {
            if !implementation_sources.contains(source.path.as_str()) {
                return Err(ManifestError::new(format!(
                    "{name} semantic source partition is absent from the implementation source-set: {}",
                    source.path
                )));
            }
        }
    }
    validate_artifact_content_distinct(&manifest.components)?;
    validate_build_receipt(
        repo_root,
        &manifest.build_receipt,
        &manifest.implementation_freeze,
        &manifest.components,
        &manifest.implementation_source_set,
    )?;
    let catalog: FixtureCatalog = read_canonical_json(&repo_root.join(FIXTURE_CATALOG_PATH))?;
    let policy: PolicyConfig = read_canonical_json(&repo_root.join(POLICY_CONFIG_PATH))?;
    let reporting: ReportingPolicy =
        read_preexecution_json(&repo_root.join(REPORTING_POLICY_PATH))?;
    let recipe: GenesisRecipe = read_canonical_json(&repo_root.join(GENESIS_RECIPE_PATH))?;
    let claims: ClaimContract = read_preexecution_json(&repo_root.join(CLAIM_CONTRACT_PATH))?;
    validate_fixture_catalog(&catalog)?;
    validate_policy_config(&policy)?;
    validate_reporting_policy(&reporting, &policy)?;
    validate_genesis_recipe(&recipe, &policy)?;
    validate_claim_contract(&claims)?;
    let expected_schedule = expand_schedule(&catalog, &policy)?;
    if manifest.schedule != expected_schedule {
        return Err(ManifestError::new(
            "manifest core schedule does not match frozen inputs",
        ));
    }
    Ok(manifest)
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FinalFreezeMetadata {
    pub core_commit: String,
    pub schema: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DerivedExecutionIdentity {
    pub chain_id: [u8; 32],
    pub validator_public_key: [u8; 32],
    pub validator_secret_key: [u8; 32],
}

fn derive_core_bound_hash(domain: &str, raw_core_hash: [u8; 32]) -> Result<[u8; 32]> {
    let mut encoded = Vec::new();
    encode_text(&mut encoded, domain)?;
    encoded.extend_from_slice(&raw_core_hash);
    Ok(sha256(&encoded))
}

pub fn derive_execution_identity(raw_core_hash: [u8; 32]) -> Result<DerivedExecutionIdentity> {
    let chain_id = derive_core_bound_hash(CHAIN_ID_DOMAIN, raw_core_hash)?;
    let validator_secret_key = derive_core_bound_hash(VALIDATOR_KEY_DOMAIN, raw_core_hash)?;
    let signing_key = SigningKey::from_bytes(&validator_secret_key);
    Ok(DerivedExecutionIdentity {
        chain_id,
        validator_public_key: signing_key.verifying_key().to_bytes(),
        validator_secret_key,
    })
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FinalEpisodeDescriptor {
    pub episode_id: u64,
    pub episode_length: u64,
    pub episode_nonce: String,
    pub fixture_id: String,
    pub horizon: u32,
    pub initial_kernel_view_hash: String,
    pub permutation_index: u8,
    pub relative_dir: String,
    pub schedule_index: u32,
    pub start_index: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FinalSchedule {
    pub cell_count: u32,
    pub decision_count: u64,
    pub episode_count: u32,
    pub episodes: Vec<FinalEpisodeDescriptor>,
    pub order: Vec<String>,
    pub per_fixture_decision_count: BTreeMap<String, u64>,
    pub schema: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FinalManifest {
    pub chain_id: String,
    pub core_commit: String,
    pub core_hash: String,
    pub core_path: String,
    pub fixture_catalog_hash: String,
    pub genesis_recipe_hash: String,
    pub policy_config_hash: String,
    pub reporting_policy_hash: String,
    pub schedule: FinalSchedule,
    pub schema: String,
    pub validator_public_key: String,
}

fn validate_final_freeze_metadata(metadata: &FinalFreezeMetadata) -> Result<()> {
    if metadata.schema != FINAL_FREEZE_SCHEMA {
        return Err(ManifestError::new(
            "unexpected final freeze metadata schema",
        ));
    }
    validate_git_hash("manifest-core commit", &metadata.core_commit)?;
    Ok(())
}

fn final_schedule(schedule: &Schedule, seed_manifest_hash: [u8; 32]) -> Result<FinalSchedule> {
    let mut nonces = BTreeSet::new();
    let episodes = schedule
        .episodes
        .iter()
        .map(|episode| {
            let nonce = derive_episode_nonce(seed_manifest_hash, episode)?;
            if !nonces.insert(nonce) {
                return Err(ManifestError::new("duplicate episode nonce"));
            }
            Ok(FinalEpisodeDescriptor {
                episode_id: episode.episode_id,
                episode_length: episode.episode_length,
                episode_nonce: hex::encode(nonce),
                fixture_id: episode.fixture_id.clone(),
                horizon: episode.horizon,
                initial_kernel_view_hash: episode.initial_kernel_view_hash.clone(),
                permutation_index: episode.permutation_index,
                relative_dir: episode.relative_dir.clone(),
                schedule_index: episode.schedule_index,
                start_index: episode.start_index,
            })
        })
        .collect::<Result<Vec<_>>>()?;
    Ok(FinalSchedule {
        cell_count: schedule.cell_count,
        decision_count: schedule.decision_count,
        episode_count: schedule.episode_count,
        episodes,
        order: schedule.order.clone(),
        per_fixture_decision_count: schedule.per_fixture_decision_count.clone(),
        schema: schedule.schema.clone(),
    })
}

pub fn generate_final_manifest(
    core_path: &Path,
    core_bytes: &[u8],
    core: &CoreManifest,
    metadata: &FinalFreezeMetadata,
) -> Result<FinalManifest> {
    validate_final_freeze_metadata(metadata)?;
    let core_path_text = core_path
        .to_str()
        .ok_or_else(|| ManifestError::new("manifest-core path is not UTF-8"))?;
    validate_repo_path(core_path_text)?;
    if core_path_text != MANIFEST_CORE_PATH {
        return Err(ManifestError::new(
            "final manifest must bind the canonical manifest-core path",
        ));
    }
    let seed_manifest_hash = sha256(core_bytes);
    let execution_identity = derive_execution_identity(seed_manifest_hash)?;
    Ok(FinalManifest {
        chain_id: hex::encode(execution_identity.chain_id),
        core_commit: metadata.core_commit.clone(),
        core_hash: hex::encode(seed_manifest_hash),
        core_path: core_path_text.to_owned(),
        fixture_catalog_hash: core.fixture_catalog_hash.clone(),
        genesis_recipe_hash: core.genesis_recipe_hash.clone(),
        policy_config_hash: core.policy_config_hash.clone(),
        reporting_policy_hash: core.reporting_policy_hash.clone(),
        schedule: final_schedule(&core.schedule, seed_manifest_hash)?,
        schema: FINAL_SCHEMA.to_owned(),
        validator_public_key: hex::encode(execution_identity.validator_public_key),
    })
}

pub fn write_final_manifest(
    repo_root: &Path,
    metadata_path: &Path,
    output_path: &Path,
) -> Result<FinalManifest> {
    let canonical_output = canonical_new_output(repo_root, output_path, FINAL_MANIFEST_PATH)?;
    if metadata_path.as_os_str() != OsStr::new(FINAL_FREEZE_METADATA_PATH) {
        return Err(ManifestError::new(format!(
            "final freeze metadata must use the exact canonical repository path {FINAL_FREEZE_METADATA_PATH}"
        )));
    }
    let metadata_bytes = fs::read(secure_repo_file_path(
        repo_root,
        FINAL_FREEZE_METADATA_PATH,
    )?)?;
    let metadata: FinalFreezeMetadata = parse_canonical_with_key_scan(&metadata_bytes, true)?;
    let core_bytes = read_canonical_manifest_core(repo_root)?;
    let core = validate_core_manifest(repo_root, &core_bytes)?;
    validate_current_manifest_executable(&core.components)?;
    let manifest =
        generate_final_manifest(Path::new(MANIFEST_CORE_PATH), &core_bytes, &core, &metadata)?;
    let canonical = canonical_json_bytes(&manifest)?;
    let _: FinalManifest = parse_canonical_with_key_scan(&canonical, true)?;
    atomic_write_new(&canonical_output, &canonical)?;
    Ok(manifest)
}

pub fn validate_final_manifest(
    repo_root: &Path,
    core_bytes: &[u8],
    final_bytes: &[u8],
) -> Result<FinalManifest> {
    let core = validate_core_manifest(repo_root, core_bytes)?;
    let manifest: FinalManifest = parse_canonical_with_key_scan(final_bytes, true)?;
    if manifest.schema != FINAL_SCHEMA
        || manifest.core_path != MANIFEST_CORE_PATH
        || manifest.core_hash != raw_sha256_hex(core_bytes)
        || manifest.fixture_catalog_hash != core.fixture_catalog_hash
        || manifest.genesis_recipe_hash != core.genesis_recipe_hash
        || manifest.policy_config_hash != core.policy_config_hash
        || manifest.reporting_policy_hash != core.reporting_policy_hash
    {
        return Err(ManifestError::new("final manifest identity mismatch"));
    }
    validate_git_hash("manifest-core commit", &manifest.core_commit)?;
    let identity = derive_execution_identity(sha256(core_bytes))?;
    if manifest.chain_id != hex::encode(identity.chain_id)
        || manifest.validator_public_key != hex::encode(identity.validator_public_key)
    {
        return Err(ManifestError::new(
            "final manifest execution identity is not derived from the raw core hash",
        ));
    }
    let expected = final_schedule(&core.schedule, sha256(core_bytes))?;
    if manifest.schedule != expected {
        return Err(ManifestError::new(
            "final manifest schedule or episode nonce mismatch",
        ));
    }
    Ok(manifest)
}

pub fn hash_sidecar_bytes(target_path: &Path, target_bytes: &[u8]) -> Result<Vec<u8>> {
    let name = target_path
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or_else(|| ManifestError::new("sidecar target filename is not UTF-8"))?;
    require_ascii("sidecar target filename", name)?;
    Ok(format!("{}  {name}\n", raw_sha256_hex(target_bytes)).into_bytes())
}

pub fn write_hash_sidecar(target_path: &Path, output_path: &Path) -> Result<()> {
    let bytes = fs::read(target_path)?;
    atomic_write(output_path, &hash_sidecar_bytes(target_path, &bytes)?)
}

pub fn validate_hash_sidecar(target_path: &Path, sidecar_path: &Path) -> Result<()> {
    let target = fs::read(target_path)?;
    let sidecar = fs::read(sidecar_path)?;
    let expected = hash_sidecar_bytes(target_path, &target)?;
    if sidecar != expected {
        return Err(ManifestError::new("SHA-256 sidecar mismatch"));
    }
    Ok(())
}

pub fn default_sidecar_path(target_path: &Path) -> Result<PathBuf> {
    let name = target_path
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or_else(|| ManifestError::new("sidecar target filename is not UTF-8"))?;
    Ok(target_path.with_file_name(format!("{name}.sha256")))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn write_file(root: &Path, path: &str, bytes: &[u8]) {
        let full = root.join(path);
        fs::create_dir_all(full.parent().unwrap()).unwrap();
        fs::write(full, bytes).unwrap();
    }

    fn install_frozen_inputs(root: &Path) {
        write_file(
            root,
            FIXTURE_CATALOG_PATH,
            &canonical_json_bytes(&frozen_catalog()).unwrap(),
        );
        write_file(
            root,
            POLICY_CONFIG_PATH,
            &canonical_json_bytes(&frozen_policy()).unwrap(),
        );
        write_file(
            root,
            REPORTING_POLICY_PATH,
            &canonical_json_bytes(&frozen_reporting_policy()).unwrap(),
        );
        write_file(
            root,
            CLAIM_CONTRACT_PATH,
            &canonical_json_bytes(&frozen_claim_contract()).unwrap(),
        );
        write_file(
            root,
            GENESIS_RECIPE_PATH,
            &canonical_json_bytes(&frozen_genesis_recipe()).unwrap(),
        );
        write_file(root, PREREGISTRATION_PATH, b"frozen preregistration\n");
        write_file(root, REPORTING_AMENDMENT_PATH, b"frozen amendment\n");
        write_file(
            root,
            STATISTICAL_AMENDMENT_PATH,
            b"frozen statistical amendment\n",
        );
        write_file(root, SEAL_AMENDMENT_PATH, b"frozen seal amendment\n");
        write_file(root, CONTROL_AMENDMENT_PATH, b"frozen control amendment\n");
        write_file(root, THEORY_BOUNDARY_PATH, b"frozen theory boundary\n");
    }

    fn owned_paths(paths: &[&str]) -> Vec<String> {
        paths.iter().map(|path| (*path).to_owned()).collect()
    }

    fn apparatus_path(name: &str) -> String {
        format!("{APPARATUS_PREFIX}test/{name}")
    }

    fn install_test_build_recipe(root: &Path) {
        let recipe = serde_json::json!({
            "apparatus_prefix": APPARATUS_PREFIX,
            "build": {
                "cargo_fetch": "locked-network-into-empty-home-then-frozen-offline",
                "cargo_frozen": true,
                "cargo_incremental": "0",
                "cargo_profile": "release",
                "default_features": true,
                "dual_build_method": "sequential-clean-detached-same-canonical-source-path",
                "environment": {
                    "fixed": {
                        "CARGO_INCREMENTAL": "0",
                        "MACOSX_DEPLOYMENT_TARGET": "test",
                    },
                    "source_date_epoch": "implementation-commit-timestamp",
                },
                "explicit_features": [],
                "fresh_cargo_home": true,
                "linker_path": "/test/clang",
                "macos_code_signature_policy": "adhoc-linker-signed-no-timestamp",
                "macos_uuid_policy": MACOS_UUID_POLICY,
                "rustflags": [
                    "--remap-path-prefix={repo}=/xypher-calorimeter/src",
                    "-Ccodegen-units=1",
                ],
                "target": "test",
                "toolchain": "test",
            },
            "build_receipt_basename": BUILD_RECEIPT_BASENAME,
            "ceremony_source_paths": [
                "research/physics/xypher-calorimeter-manifest/Cargo.toml"
            ],
            "components": {
                "actor": {
                    "artifact_basename": "xypher-calorimeter-runner",
                    "cargo_manifest": "research/physics/xypher-calorimeter-runner/Cargo.toml",
                },
                "analysis": {
                    "artifact_basename": "xypher-calorimeter-analysis",
                    "cargo_manifest": "research/physics/xypher-calorimeter-analysis/Cargo.toml",
                },
                "manifest": {
                    "artifact_basename": "xypher-calorimeter-manifest",
                    "cargo_manifest": "research/physics/xypher-calorimeter-manifest/Cargo.toml",
                },
                "observer": {
                    "artifact_basename": "xypher-calorimeter-observer",
                    "cargo_manifest": "research/physics/xypher-calorimeter-observer/Cargo.toml",
                },
            },
            "schema": BUILD_RECIPE_SCHEMA,
        });
        write_file(
            root,
            BUILD_RECIPE_PATH,
            &canonical_json_bytes(&recipe).unwrap(),
        );
    }

    fn install_test_build_receipt(root: &Path) {
        let component_inputs = [
            (
                "actor",
                "research/physics/xypher-calorimeter-runner/Cargo.toml",
                "research/physics/xypher-calorimeter-runner/Cargo.lock",
                "research/physics/xypher-calorimeter-runner/src/lib.rs",
                "xypher-calorimeter-runner",
            ),
            (
                "analysis",
                "research/physics/xypher-calorimeter-analysis/Cargo.toml",
                "research/physics/xypher-calorimeter-analysis/Cargo.lock",
                "research/physics/xypher-calorimeter-analysis/src/lib.rs",
                "xypher-calorimeter-analysis",
            ),
            (
                "manifest",
                "research/physics/xypher-calorimeter-manifest/Cargo.toml",
                "research/physics/xypher-calorimeter-manifest/Cargo.lock",
                "research/physics/xypher-calorimeter-manifest/src/lib.rs",
                "xypher-calorimeter-manifest",
            ),
            (
                "observer",
                "research/physics/xypher-calorimeter-observer/Cargo.toml",
                "research/physics/xypher-calorimeter-observer/Cargo.lock",
                "research/physics/xypher-calorimeter-observer/src/lib.rs",
                "xypher-calorimeter-observer",
            ),
        ];
        let components = component_inputs
            .into_iter()
            .enumerate()
            .map(
                |(index, (name, manifest, lockfile, source, artifact_basename))| {
                    let artifact =
                        raw_file_identity(root, &apparatus_path(artifact_basename)).unwrap();
                    let mach_o_uuid = format!("{:032x}", index + 1);
                    let launch_probe_hash = format!("{:064x}", index + 11);
                    (
                        name.to_owned(),
                        serde_json::json!({
                            "artifact": {
                                "basename": artifact_basename,
                                "length_bytes": artifact.length_bytes,
                                "sha256": artifact.sha256,
                            },
                            "cargo_config_paths": [],
                            "cargo_manifest": manifest,
                            "cargo_metadata_sha256": "71".repeat(32),
                            "cargo_tree_features_sha256": "72".repeat(32),
                            "dep_info_sources": [source],
                            "launch_probe": {
                                "argument": LOAD_PROBE_ARGUMENT,
                                "exit_code": LOAD_PROBE_EXIT_CODE,
                                "output_sha256": launch_probe_hash,
                            },
                            "local_manifests": [manifest],
                            "local_target_sources": [source],
                            "lockfiles": [lockfile],
                            "mach_o_uuid": mach_o_uuid,
                            "workspace_manifests": [],
                        }),
                    )
                },
            )
            .collect::<serde_json::Map<_, _>>();
        let build_record = serde_json::json!({
            "build": {
                "cargo_frozen": true,
                "cargo_incremental": "0",
                "cargo_profile": "release",
                "default_features": true,
                "environment": {
                    "CARGO_INCREMENTAL": "0",
                    "MACOSX_DEPLOYMENT_TARGET": "test",
                    "SOURCE_DATE_EPOCH": "1",
                },
                "explicit_features": [],
                "fresh_cargo_home": true,
                "linker_path": "/test/clang",
                "linker_version": "test linker",
                "rustflags": [
                    "--remap-path-prefix=/source=/xypher-calorimeter/src",
                    "-Ccodegen-units=1",
                ],
                "target": "test",
            },
            "build_script_sha256": raw_file_identity(root, BUILD_SCRIPT_PATH).unwrap().sha256,
            "ceremony_source_paths": [
                "research/physics/xypher-calorimeter-manifest/Cargo.toml"
            ],
            "components": components,
            "implementation_commit": "1".repeat(40),
            "implementation_tree": "2".repeat(40),
            "schema": BUILD_RECORD_SCHEMA,
            "system": {
                "clang_path": "/test/clang",
                "clang_version": "test clang",
                "clt_package": "test clt",
                "code_signature_policy": "adhoc-linker-signed-no-timestamp",
                "dep_info_external": {
                    "actor": {
                        "generated": {"count": 0, "sha256": "76".repeat(32)},
                        "registry": {"count": 0, "sha256": "77".repeat(32)},
                        "rust_std": {"count": 0, "sha256": "78".repeat(32)},
                    },
                    "analysis": {
                        "generated": {"count": 0, "sha256": "76".repeat(32)},
                        "registry": {"count": 0, "sha256": "77".repeat(32)},
                        "rust_std": {"count": 0, "sha256": "78".repeat(32)},
                    },
                    "manifest": {
                        "generated": {"count": 0, "sha256": "76".repeat(32)},
                        "registry": {"count": 0, "sha256": "77".repeat(32)},
                        "rust_std": {"count": 0, "sha256": "78".repeat(32)},
                    },
                    "observer": {
                        "generated": {"count": 0, "sha256": "76".repeat(32)},
                        "registry": {"count": 0, "sha256": "77".repeat(32)},
                        "rust_std": {"count": 0, "sha256": "78".repeat(32)},
                    },
                },
                "developer_dir": "/test/developer",
                "ld_path": "/test/ld",
                "ld_version": "test ld",
                "platform": "test",
                "sdk_build_version": "test-sdk-build",
                "sdk_path": "/test/sdk",
                "sdk_version": "test-sdk",
                "uuid_policy": MACOS_UUID_POLICY,
            },
            "toolchain": {
                "cargo_binary_sha256": "74".repeat(32),
                "cargo_vv": "cargo test",
                "installed_name": "test",
                "rust_std_file_count": 1,
                "rust_std_tree_sha256": "75".repeat(32),
                "rustc_binary_sha256": "73".repeat(32),
                "rustc_vv": "rustc test",
            },
            "uname": "test",
        });
        let build_record_sha256 = raw_sha256_hex(&canonical_json_bytes(&build_record).unwrap());
        let receipt = serde_json::json!({
            "build_record": build_record,
            "comparison": {
                "artifact_byte_identical": true,
                "build_count": 2,
                "build_record_identical": true,
                "build_record_sha256": build_record_sha256,
                "method": "sequential-clean-detached-same-canonical-source-path",
            },
            "schema": BUILD_RECEIPT_SCHEMA,
        });
        write_file(
            root,
            &apparatus_path(BUILD_RECEIPT_BASENAME),
            &canonical_json_bytes(&receipt).unwrap(),
        );
    }

    fn rewrite_test_build_receipt(root: &Path, mutate: impl FnOnce(&mut serde_json::Value)) {
        let path = root.join(apparatus_path(BUILD_RECEIPT_BASENAME));
        let mut receipt: serde_json::Value =
            serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        mutate(&mut receipt);
        let build_record_hash =
            raw_sha256_hex(&canonical_json_bytes(&receipt["build_record"]).unwrap());
        receipt["comparison"]["build_record_sha256"] = serde_json::Value::String(build_record_hash);
        write_file(
            root,
            &apparatus_path(BUILD_RECEIPT_BASENAME),
            &canonical_json_bytes(&receipt).unwrap(),
        );
    }

    fn install_component_contract_files(root: &Path) {
        for paths in [
            ACTOR_REQUIRED_SOURCE_PATHS.as_slice(),
            ANALYSIS_REQUIRED_SOURCE_PATHS.as_slice(),
            MANIFEST_REQUIRED_SOURCE_PATHS.as_slice(),
            OBSERVER_REQUIRED_SOURCE_PATHS.as_slice(),
        ] {
            for path in paths {
                write_file(root, path, format!("{path}\n").as_bytes());
            }
        }
        for path in IMPLEMENTATION_REQUIRED_SOURCE_PATHS {
            write_file(root, path, format!("{path}\n").as_bytes());
        }
        install_test_build_recipe(root);
        for name in [
            "xypher-calorimeter-runner",
            "xypher-calorimeter-analysis",
            "xypher-calorimeter-manifest",
            "xypher-calorimeter-observer",
        ] {
            let path = apparatus_path(name);
            write_file(root, &path, format!("{name}\n").as_bytes());
        }
        install_test_build_receipt(root);
    }

    fn valid_freeze_metadata() -> CoreFreezeMetadata {
        let implementation_source_paths = required_implementation_source_paths();
        CoreFreezeMetadata {
            artifact_freeze: ArtifactFreeze {
                commit: "3333333333333333333333333333333333333333".to_owned(),
                tree: "4444444444444444444444444444444444444444".to_owned(),
            },
            build_receipt_path: apparatus_path(BUILD_RECEIPT_BASENAME),
            components: BTreeMap::from([
                (
                    "actor".to_owned(),
                    ComponentFreeze {
                        artifact_paths: vec![apparatus_path("xypher-calorimeter-runner")],
                        source_paths: owned_paths(&ACTOR_REQUIRED_SOURCE_PATHS),
                    },
                ),
                (
                    "analysis".to_owned(),
                    ComponentFreeze {
                        artifact_paths: vec![apparatus_path("xypher-calorimeter-analysis")],
                        source_paths: owned_paths(&ANALYSIS_REQUIRED_SOURCE_PATHS),
                    },
                ),
                (
                    "claim".to_owned(),
                    ComponentFreeze {
                        artifact_paths: Vec::new(),
                        source_paths: owned_paths(&CLAIM_REQUIRED_SOURCE_PATHS),
                    },
                ),
                (
                    "manifest".to_owned(),
                    ComponentFreeze {
                        artifact_paths: vec![apparatus_path("xypher-calorimeter-manifest")],
                        source_paths: owned_paths(&MANIFEST_REQUIRED_SOURCE_PATHS),
                    },
                ),
                (
                    "observer".to_owned(),
                    ComponentFreeze {
                        artifact_paths: vec![apparatus_path("xypher-calorimeter-observer")],
                        source_paths: owned_paths(&OBSERVER_REQUIRED_SOURCE_PATHS),
                    },
                ),
            ]),
            implementation_freeze: ImplementationFreeze {
                commit: "1111111111111111111111111111111111111111".to_owned(),
                toolchains: BTreeMap::from([
                    ("cargo".to_owned(), "cargo test".to_owned()),
                    ("clang".to_owned(), "test clang".to_owned()),
                    ("clt".to_owned(), "test clt".to_owned()),
                    ("ld".to_owned(), "test ld".to_owned()),
                    ("linker".to_owned(), "test linker".to_owned()),
                    ("rust_std".to_owned(), format!("1:{}", "75".repeat(32))),
                    ("rustc".to_owned(), "rustc test".to_owned()),
                    ("sdk".to_owned(), "test-sdk:test-sdk-build".to_owned()),
                    ("target".to_owned(), "test".to_owned()),
                ]),
                tree: "2222222222222222222222222222222222222222".to_owned(),
            },
            implementation_source_paths,
            preregistration: PreregistrationFreeze {
                commit: BASE_PREREGISTRATION_COMMIT.to_owned(),
                path: PREREGISTRATION_PATH.to_owned(),
            },
            schema: CORE_FREEZE_SCHEMA.to_owned(),
        }
    }

    #[test]
    fn canonical_json_is_strict() {
        assert!(validate_canonical_json(b"{\"a\":1,\"b\":[true,\"x\"]}\n").is_ok());
        assert!(validate_canonical_json(b"{\"b\":1,\"a\":2}\n").is_err());
        assert!(validate_canonical_json(b"{\"a\":1.0}\n").is_err());
        assert!(validate_canonical_json(b"{\"a\":null}\n").is_err());
        assert!(validate_canonical_json(b"{\"a\":1,\"a\":2}\n").is_err());
        assert!(validate_canonical_json("{\"a\":\"\u{e5}\"}\n".as_bytes()).is_err());
        assert!(validate_canonical_json(b"{\"a\":1}\n\n").is_err());
        assert!(validate_canonical_json(b"{\"a\":1}").is_err());
        assert_eq!(
            canonicalize_json(b"{ \"b\": 2, \"a\": 1 }").unwrap(),
            b"{\"a\":1,\"b\":2}\n"
        );
    }

    #[test]
    fn hash_text_is_lowercase_and_fixed_width() {
        assert!(decode_hash("hash", &"ab".repeat(32)).is_ok());
        assert!(decode_hash("hash", &"AB".repeat(32)).is_err());
        assert!(decode_hash("hash", &"ab".repeat(31)).is_err());
        assert!(validate_mach_o_uuid("uuid", &"ab".repeat(16)).is_ok());
        assert!(validate_mach_o_uuid("uuid", &"00".repeat(16)).is_err());
        assert!(validate_mach_o_uuid("uuid", &"AB".repeat(16)).is_err());
        assert!(validate_mach_o_uuid("uuid", "00112233-4455-6677-8899-aabbccddeeff").is_err());
        assert!(is_forbidden_mach_o_uuid_flag("-Clink-arg=-Wl,-no_uuid"));
        assert!(is_forbidden_mach_o_uuid_flag("-Clink-arg=-Wl,-random_uuid"));
        assert!(!is_forbidden_mach_o_uuid_flag("-Ccodegen-units=16"));
        assert!(validate_git_hash("commit", &"cd".repeat(20)).is_ok());
        assert!(validate_git_hash("commit", &"CD".repeat(20)).is_err());
        assert!(validate_durable_artifact_paths(
            &["target/release/calorimeter".to_owned()],
            "actor"
        )
        .is_err());
        assert!(validate_durable_artifact_paths(
            &[format!("{APPARATUS_PREFIX}test/actor")],
            "actor"
        )
        .is_ok());
    }

    #[test]
    fn launch_probe_contract_is_exact() {
        let valid = BuildLaunchProbe {
            argument: LOAD_PROBE_ARGUMENT.to_owned(),
            exit_code: LOAD_PROBE_EXIT_CODE,
            output_sha256: "ab".repeat(32),
        };
        validate_launch_probe("actor", &valid).unwrap();

        let mut wrong_argument = BuildLaunchProbe {
            argument: "--help".to_owned(),
            ..valid
        };
        assert!(validate_launch_probe("actor", &wrong_argument)
            .unwrap_err()
            .to_string()
            .contains(LOAD_PROBE_ARGUMENT));
        wrong_argument.argument = LOAD_PROBE_ARGUMENT.to_owned();
        wrong_argument.exit_code = 0;
        assert!(validate_launch_probe("actor", &wrong_argument).is_err());
        wrong_argument.exit_code = LOAD_PROBE_EXIT_CODE;
        wrong_argument.output_sha256 = "AB".repeat(32);
        assert!(validate_launch_probe("actor", &wrong_argument).is_err());
    }

    #[test]
    fn launchable_uuid_receipt_is_accepted_and_legacy_uuid_flags_are_rejected() {
        let temporary = tempfile::tempdir().unwrap();
        let root = temporary.path();
        install_frozen_inputs(root);
        install_component_contract_files(root);
        generate_core_manifest(root, &valid_freeze_metadata()).unwrap();

        rewrite_test_build_receipt(root, |receipt| {
            receipt["schema"] =
                serde_json::Value::String("xypher-calorimeter-build-receipt.v1".to_owned());
            receipt["build_record"]["schema"] =
                serde_json::Value::String("xypher-calorimeter-build-record.v1".to_owned());
        });
        assert!(generate_core_manifest(root, &valid_freeze_metadata())
            .unwrap_err()
            .to_string()
            .contains("unexpected build receipt schema"));

        for forbidden_flag in ["-Clink-arg=-Wl,-no_uuid", "-Clink-arg=-Wl,-random_uuid"] {
            install_test_build_receipt(root);
            rewrite_test_build_receipt(root, |receipt| {
                receipt["build_record"]["build"]["rustflags"] = serde_json::json!([
                    "--remap-path-prefix=/source=/xypher-calorimeter/src",
                    forbidden_flag,
                ]);
            });
            let error = generate_core_manifest(root, &valid_freeze_metadata()).unwrap_err();
            assert!(error
                .to_string()
                .contains("forbidden Mach-O UUID linker flag"));
        }

        install_test_build_receipt(root);
        rewrite_test_build_receipt(root, |receipt| {
            receipt["build_record"]["system"]["uuid_policy"] =
                serde_json::Value::String("linker-uuid-disabled".to_owned());
        });
        assert!(generate_core_manifest(root, &valid_freeze_metadata())
            .unwrap_err()
            .to_string()
            .contains("Mach-O UUID policy"));

        install_test_build_receipt(root);
        rewrite_test_build_receipt(root, |receipt| {
            let actor_uuid = receipt["build_record"]["components"]["actor"]["mach_o_uuid"]
                .as_str()
                .unwrap()
                .to_owned();
            receipt["build_record"]["components"]["observer"]["mach_o_uuid"] =
                serde_json::Value::String(actor_uuid);
        });
        assert!(generate_core_manifest(root, &valid_freeze_metadata())
            .unwrap_err()
            .to_string()
            .contains("duplicates another component"));
    }

    #[test]
    fn checked_in_inputs_are_exact_and_canonical() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR"))
            .parent()
            .and_then(Path::parent)
            .and_then(Path::parent)
            .unwrap();
        validate_inputs(root).unwrap();
    }

    #[test]
    fn relabelling_matches_cal_man_1_semantics() {
        let catalog = frozen_catalog();
        let cycle = &catalog.fixtures[0];
        let cycle_permutation = &cycle.permutations[1].image_by_node;
        assert_eq!(
            relabel_balances(&cycle.initial_balances[2], cycle_permutation).unwrap(),
            vec![1, 0, 3, 0]
        );
        assert_eq!(
            relabel_edges(&cycle.account_edges, cycle_permutation).unwrap(),
            vec![[1, 3], [1, 4], [2, 3], [2, 4]]
        );
        assert_eq!(
            relabel_partition(&cycle.reporting_partitions[0], cycle_permutation)
                .unwrap()
                .left_nodes,
            vec![1, 3]
        );

        let star = &catalog.fixtures[1];
        let star_permutation = &star.permutations[1].image_by_node;
        assert_eq!(
            relabel_balances(&star.initial_balances[3], star_permutation).unwrap(),
            vec![1, 0, 0, 1, 1]
        );
        assert_eq!(
            relabel_edges(&star.account_edges, star_permutation).unwrap(),
            vec![[1, 4], [2, 4], [3, 4], [4, 5]]
        );
        let partitions = star
            .reporting_partitions
            .iter()
            .map(|partition| relabel_partition(partition, star_permutation).unwrap())
            .collect::<Vec<_>>();
        assert_eq!(partitions[0].left_nodes, vec![1, 4]);
        assert_eq!(partitions[0].right_nodes, vec![2, 3, 5]);
        assert_eq!(partitions[1].left_nodes, vec![1, 5]);
        assert_eq!(partitions[1].right_nodes, vec![2, 3, 4]);
    }

    #[test]
    fn schedule_has_frozen_order_and_totals() {
        let schedule = expand_schedule(&frozen_catalog(), &frozen_policy()).unwrap();
        assert_eq!(schedule.cell_count, 48);
        assert_eq!(schedule.episode_count, 1_536);
        assert_eq!(schedule.decision_count, 93_696);
        assert_eq!(schedule.per_fixture_decision_count["cycle4_k4"], 47_104);
        assert_eq!(schedule.per_fixture_decision_count["star5_k3"], 46_592);
        assert_eq!(
            schedule.episodes[0].relative_dir,
            "0000-cycle4_k4-h02-s00-p0-e00"
        );
        assert_eq!(
            schedule.episodes[0].initial_kernel_view_hash,
            "1f60316fad2a47a58ac35a0885309e22e9852275c31063f0d1fdfd9a60f81f24"
        );
        assert_eq!(
            schedule.episodes[31].relative_dir,
            "0031-cycle4_k4-h02-s00-p0-e31"
        );
        assert_eq!(
            schedule.episodes[32].relative_dir,
            "0032-cycle4_k4-h02-s00-p1-e00"
        );
        assert_eq!(
            schedule.episodes.last().unwrap().relative_dir,
            "1535-star5_k3-h08-s03-p1-e31"
        );
        assert_eq!(
            schedule.episodes.last().unwrap().initial_kernel_view_hash,
            "f83c8d8d8ffae83abe6dedc39e9d7da72b53ed5145d349335eb29c5b7ebc598f"
        );
        let recipe = frozen_genesis_recipe();
        assert_eq!(recipe.validator_construction.epoch_size, 82);
        assert!((1..=80).all(|height| (height + 1) % 82 != 0 && height / 82 == 0));
    }

    #[test]
    fn reporting_policy_freezes_collection_and_interpretation_boundaries() {
        let reporting = frozen_reporting_policy();
        validate_reporting_policy(&reporting, &frozen_policy()).unwrap();
        assert_eq!(
            reporting.acceptance.journal_external_actor_seal_count,
            1_536
        );
        assert_eq!(reporting.acceptance.exact_decision_join_count, 93_696);
        assert!(!reporting.acceptance.partial_collection_allowed);
        assert_eq!(
            reporting.confidence_intervals.acceptance_role,
            "reference diagnostic only; never acceptance evidence"
        );
        assert!(reporting
            .confidence_intervals
            .dependence_scope
            .contains("Markov exposures are correlated"));
        assert_eq!(
            reporting.likelihood.negative_infinity_encoding,
            "negative_infinity"
        );
        assert_eq!(reporting.kl_negative_tolerance_bits, "0.000000000001");
        assert_eq!(reporting.mfpt_bellman_absolute_tolerance, "0.000000001");
        assert_eq!(
            reporting.partition_outputs.forbidden_interpretations,
            vec![
                "contact",
                "current",
                "equation of state",
                "heat",
                "temperature"
            ]
        );
        let claims = frozen_claim_contract();
        assert_eq!(
            claims
                .reporting_amendments
                .iter()
                .map(|amendment| amendment.amendment_id.as_str())
                .collect::<Vec<_>>(),
            vec!["CAL-MAN-1", "CAL-STAT-1", "CAL-SEAL-1", "CAL-CTRL-1"]
        );
    }

    #[test]
    fn synthetic_episode_nonces_are_unique() {
        let schedule = expand_schedule(&frozen_catalog(), &frozen_policy()).unwrap();
        let seed = [0x42; 32];
        assert_eq!(
            hex::encode(derive_episode_nonce(seed, &schedule.episodes[0]).unwrap()),
            "f75de06440998025a5c8acaccd89bd36447ef750a5e4546f0cd66e21db04ee9f"
        );
        let nonces = schedule
            .episodes
            .iter()
            .map(|episode| derive_episode_nonce(seed, episode).unwrap())
            .collect::<BTreeSet<_>>();
        assert_eq!(nonces.len(), 1_536);
    }

    #[test]
    fn file_set_hashes_are_ordered_and_domain_separated() {
        let temporary = tempfile::tempdir().unwrap();
        write_file(temporary.path(), "a", b"A\n");
        write_file(temporary.path(), "b", b"B\n");
        let forward = vec!["a".to_owned(), "b".to_owned()];
        let reverse = vec!["b".to_owned(), "a".to_owned()];
        let source_forward = source_set_identity(temporary.path(), "actor", &forward).unwrap();
        let source_reverse = source_set_identity(temporary.path(), "actor", &reverse).unwrap();
        let artifact = artifact_set_identity(temporary.path(), "actor", &forward).unwrap();
        assert_eq!(source_forward, source_reverse);
        assert_ne!(source_forward.sha256, artifact.sha256);
        assert_eq!(source_forward.files[0].path, "a");
        assert_eq!(source_forward.files[0].length_bytes, 2);
        assert_ne!(
            raw_file_identity(temporary.path(), "a").unwrap().sha256,
            raw_sha256_hex(b"A")
        );
    }

    #[test]
    fn empirical_fields_are_rejected() {
        let bytes = b"{\"components\":{},\"outcomes\":[]}\n";
        let error = parse_canonical_with_key_scan::<CoreFreezeMetadata>(bytes, false).unwrap_err();
        assert!(error.to_string().contains("outcomes"));
        let reporting =
            b"{\"outcomes\":[],\"schema\":\"xypher-calorimeter-reporting-policy.v1\"}\n";
        let error = parse_canonical_with_key_scan::<ReportingPolicy>(reporting, false).unwrap_err();
        assert!(error.to_string().contains("outcomes"));
    }

    #[test]
    fn ephemeral_core_and_final_manifests_round_trip() {
        let temporary = tempfile::tempdir().unwrap();
        let root = temporary.path();
        install_frozen_inputs(root);
        install_component_contract_files(root);
        let metadata = valid_freeze_metadata();
        let core = generate_core_manifest(root, &metadata).unwrap();
        let core_bytes = canonical_json_bytes(&core).unwrap();
        validate_core_manifest(root, &core_bytes).unwrap();
        assert!(!String::from_utf8_lossy(&core_bytes).contains("episode_nonce"));

        let final_metadata = FinalFreezeMetadata {
            core_commit: "3333333333333333333333333333333333333333".to_owned(),
            schema: FINAL_FREEZE_SCHEMA.to_owned(),
        };
        let final_manifest = generate_final_manifest(
            Path::new(MANIFEST_CORE_PATH),
            &core_bytes,
            &core,
            &final_metadata,
        )
        .unwrap();
        let final_bytes = canonical_json_bytes(&final_manifest).unwrap();
        let checked = validate_final_manifest(root, &core_bytes, &final_bytes).unwrap();
        assert_eq!(checked.schedule.episodes.len(), 1_536);
        assert_eq!(checked.reporting_policy_hash, core.reporting_policy_hash);
        assert_eq!(
            checked.schedule.episodes[0].episode_nonce,
            hex::encode(
                derive_episode_nonce(sha256(&core_bytes), &core.schedule.episodes[0]).unwrap()
            )
        );
        assert!(!String::from_utf8_lossy(&final_bytes).contains("\"outcomes\""));
    }

    #[test]
    fn load_bearing_manifest_outputs_are_canonical_and_new_only() {
        let temporary = tempfile::tempdir().unwrap();
        let root = temporary.path();
        install_frozen_inputs(root);
        install_component_contract_files(root);
        write_file(
            root,
            &apparatus_path("xypher-calorimeter-manifest"),
            &fs::read(std::env::current_exe().unwrap()).unwrap(),
        );
        install_test_build_receipt(root);

        write_file(
            root,
            CORE_FREEZE_METADATA_PATH,
            &canonical_json_bytes(&valid_freeze_metadata()).unwrap(),
        );
        for output_alias in [
            "noncanonical-core.json".to_owned(),
            MANIFEST_CORE_PATH.replacen('/', "//", 1),
            MANIFEST_CORE_PATH.replace("/xypher", "/./xypher"),
            format!("{MANIFEST_CORE_PATH}/"),
        ] {
            assert!(write_core_manifest(
                root,
                Path::new(CORE_FREEZE_METADATA_PATH),
                Path::new(&output_alias)
            )
            .unwrap_err()
            .to_string()
            .contains("exact canonical repository path"));
        }
        for metadata_alias in [
            CORE_FREEZE_METADATA_PATH.replacen('/', "//", 1),
            CORE_FREEZE_METADATA_PATH.replace("/xypher", "/./xypher"),
            format!("{CORE_FREEZE_METADATA_PATH}/"),
        ] {
            assert!(write_core_manifest(
                root,
                Path::new(&metadata_alias),
                Path::new(MANIFEST_CORE_PATH)
            )
            .unwrap_err()
            .to_string()
            .contains("exact canonical repository path"));
        }
        let core = write_core_manifest(
            root,
            Path::new(CORE_FREEZE_METADATA_PATH),
            Path::new(MANIFEST_CORE_PATH),
        )
        .unwrap();
        assert_eq!(core.schedule.episode_count, 1_536);
        let core_bytes = fs::read(root.join(MANIFEST_CORE_PATH)).unwrap();
        assert!(write_core_manifest(
            root,
            Path::new(CORE_FREEZE_METADATA_PATH),
            Path::new(MANIFEST_CORE_PATH)
        )
        .unwrap_err()
        .to_string()
        .contains("refusing to replace"));
        assert_eq!(fs::read(root.join(MANIFEST_CORE_PATH)).unwrap(), core_bytes);

        write_file(
            root,
            FINAL_FREEZE_METADATA_PATH,
            &canonical_json_bytes(&FinalFreezeMetadata {
                core_commit: "5555555555555555555555555555555555555555".to_owned(),
                schema: FINAL_FREEZE_SCHEMA.to_owned(),
            })
            .unwrap(),
        );
        for output_alias in [
            "noncanonical-final.json".to_owned(),
            FINAL_MANIFEST_PATH.replacen('/', "//", 1),
            FINAL_MANIFEST_PATH.replace("/xypher", "/./xypher"),
            format!("{FINAL_MANIFEST_PATH}/"),
        ] {
            assert!(write_final_manifest(
                root,
                Path::new(FINAL_FREEZE_METADATA_PATH),
                Path::new(&output_alias)
            )
            .unwrap_err()
            .to_string()
            .contains("exact canonical repository path"));
        }
        for metadata_alias in [
            FINAL_FREEZE_METADATA_PATH.replacen('/', "//", 1),
            FINAL_FREEZE_METADATA_PATH.replace("/xypher", "/./xypher"),
            format!("{FINAL_FREEZE_METADATA_PATH}/"),
        ] {
            assert!(write_final_manifest(
                root,
                Path::new(&metadata_alias),
                Path::new(FINAL_MANIFEST_PATH)
            )
            .unwrap_err()
            .to_string()
            .contains("exact canonical repository path"));
        }
        let final_manifest = write_final_manifest(
            root,
            Path::new(FINAL_FREEZE_METADATA_PATH),
            Path::new(FINAL_MANIFEST_PATH),
        )
        .unwrap();
        assert_eq!(final_manifest.schedule.episode_count, 1_536);
        let final_bytes = fs::read(root.join(FINAL_MANIFEST_PATH)).unwrap();
        assert!(write_final_manifest(
            root,
            Path::new(FINAL_FREEZE_METADATA_PATH),
            Path::new(FINAL_MANIFEST_PATH)
        )
        .unwrap_err()
        .to_string()
        .contains("refusing to replace"));
        assert_eq!(
            fs::read(root.join(FINAL_MANIFEST_PATH)).unwrap(),
            final_bytes
        );
    }

    #[cfg(unix)]
    #[test]
    fn final_generation_rejects_a_symlinked_canonical_core() {
        use std::os::unix::fs::symlink;

        let temporary = tempfile::tempdir().unwrap();
        let root = temporary.path();
        install_frozen_inputs(root);
        install_component_contract_files(root);
        let core = generate_core_manifest(root, &valid_freeze_metadata()).unwrap();
        write_file(
            root,
            "external-core.json",
            &canonical_json_bytes(&core).unwrap(),
        );
        symlink(
            root.join("external-core.json"),
            root.join(MANIFEST_CORE_PATH),
        )
        .unwrap();
        write_file(
            root,
            FINAL_FREEZE_METADATA_PATH,
            &canonical_json_bytes(&FinalFreezeMetadata {
                core_commit: "5555555555555555555555555555555555555555".to_owned(),
                schema: FINAL_FREEZE_SCHEMA.to_owned(),
            })
            .unwrap(),
        );

        let error = write_final_manifest(
            root,
            Path::new(FINAL_FREEZE_METADATA_PATH),
            Path::new(FINAL_MANIFEST_PATH),
        )
        .unwrap_err();
        assert!(error.to_string().contains("contains a symlink"));
        assert!(!root.join(FINAL_MANIFEST_PATH).exists());
    }

    #[test]
    fn manually_constructed_cores_cannot_bypass_component_contracts() {
        let temporary = tempfile::tempdir().unwrap();
        let root = temporary.path();
        install_frozen_inputs(root);
        install_component_contract_files(root);
        let core = generate_core_manifest(root, &valid_freeze_metadata()).unwrap();
        let manifest_executable = root.join(apparatus_path("xypher-calorimeter-manifest"));
        validate_manifest_executable_bytes(&manifest_executable, &core.components).unwrap();
        assert!(validate_manifest_executable_bytes(
            &root.join(apparatus_path("xypher-calorimeter-runner")),
            &core.components
        )
        .unwrap_err()
        .to_string()
        .contains("do not match"));

        let validate_error = |candidate: &CoreManifest| {
            validate_core_manifest(root, &canonical_json_bytes(candidate).unwrap()).unwrap_err()
        };

        let claim_artifact = apparatus_path("xypher-calorimeter-claim");
        write_file(root, &claim_artifact, b"claim artifact\n");
        let mut bad = core.clone();
        bad.components.get_mut("claim").unwrap().artifact_set =
            artifact_set_identity(root, "claim", std::slice::from_ref(&claim_artifact)).unwrap();
        assert!(validate_error(&bad).to_string().contains("exactly empty"));

        let second_actor_artifact = format!("{APPARATUS_PREFIX}second/xypher-calorimeter-runner");
        write_file(root, &second_actor_artifact, b"second actor\n");
        let mut bad = core.clone();
        bad.components.get_mut("actor").unwrap().artifact_set = artifact_set_identity(
            root,
            "actor",
            &[
                apparatus_path("xypher-calorimeter-runner"),
                second_actor_artifact,
            ],
        )
        .unwrap();
        assert!(validate_error(&bad)
            .to_string()
            .contains("exactly one frozen binary"));

        let wrong_actor_artifact = apparatus_path("wrong-runner-name");
        write_file(root, &wrong_actor_artifact, b"wrong actor\n");
        let mut bad = core.clone();
        bad.components.get_mut("actor").unwrap().artifact_set =
            artifact_set_identity(root, "actor", std::slice::from_ref(&wrong_actor_artifact))
                .unwrap();
        assert!(validate_error(&bad)
            .to_string()
            .contains("artifact basename must be"));

        let mut missing_actor_source = owned_paths(&ACTOR_REQUIRED_SOURCE_PATHS);
        missing_actor_source.remove(0);
        let mut bad = core.clone();
        bad.components.get_mut("actor").unwrap().source_set =
            source_set_identity(root, "actor", &missing_actor_source).unwrap();
        assert!(validate_error(&bad)
            .to_string()
            .contains(ACTOR_REQUIRED_SOURCE_PATHS[0]));

        let mut duplicate_analysis_sources = owned_paths(&ANALYSIS_REQUIRED_SOURCE_PATHS);
        duplicate_analysis_sources.push(ACTOR_REQUIRED_SOURCE_PATHS[0].to_owned());
        duplicate_analysis_sources.sort();
        let mut bad = core.clone();
        bad.components.get_mut("analysis").unwrap().source_set =
            source_set_identity(root, "analysis", &duplicate_analysis_sources).unwrap();
        assert!(validate_error(&bad)
            .to_string()
            .contains("owned by both actor and analysis"));

        let actor_artifact = apparatus_path("xypher-calorimeter-runner");
        let mut bad = core.clone();
        bad.components.get_mut("analysis").unwrap().artifact_set =
            artifact_set_identity(root, "analysis", std::slice::from_ref(&actor_artifact)).unwrap();
        assert!(validate_error(&bad)
            .to_string()
            .contains("shared by multiple components"));

        let actor_bytes = fs::read(root.join(apparatus_path("xypher-calorimeter-runner"))).unwrap();
        write_file(
            root,
            &apparatus_path("xypher-calorimeter-analysis"),
            &actor_bytes,
        );
        assert!(generate_core_manifest(root, &valid_freeze_metadata())
            .unwrap_err()
            .to_string()
            .contains("content identity duplicates"));
        let mut bad = core.clone();
        bad.components.get_mut("analysis").unwrap().artifact_set = artifact_set_identity(
            root,
            "analysis",
            &[apparatus_path("xypher-calorimeter-analysis")],
        )
        .unwrap();
        assert!(validate_error(&bad)
            .to_string()
            .contains("content identity duplicates"));

        let mut source_alias = core.clone();
        source_alias
            .components
            .get_mut("actor")
            .unwrap()
            .source_set
            .files[0]
            .path = ACTOR_REQUIRED_SOURCE_PATHS[0].replacen('/', "//", 1);
        assert!(validate_error(&source_alias)
            .to_string()
            .contains("canonical spelling"));

        let mut artifact_alias = core.clone();
        artifact_alias
            .components
            .get_mut("actor")
            .unwrap()
            .artifact_set
            .files[0]
            .path = format!("{APPARATUS_PREFIX}./test/xypher-calorimeter-runner");
        assert!(validate_error(&artifact_alias)
            .to_string()
            .contains("canonical spelling"));
    }

    #[test]
    fn core_validation_reloads_the_frozen_claim_contract() {
        let temporary = tempfile::tempdir().unwrap();
        let root = temporary.path();
        install_frozen_inputs(root);
        install_component_contract_files(root);
        let mut core = generate_core_manifest(root, &valid_freeze_metadata()).unwrap();

        let mut claims = frozen_claim_contract();
        claims
            .allowed_pre_execution_claims
            .push("unfrozen extra claim".to_owned());
        write_file(
            root,
            CLAIM_CONTRACT_PATH,
            &canonical_json_bytes(&claims).unwrap(),
        );
        core.components.get_mut("claim").unwrap().source_set =
            source_set_identity(root, "claim", &owned_paths(&CLAIM_REQUIRED_SOURCE_PATHS)).unwrap();
        let implementation_paths = core
            .implementation_source_set
            .files
            .iter()
            .map(|file| file.path.clone())
            .collect::<Vec<_>>();
        core.implementation_source_set = file_set_identity(
            root,
            IMPLEMENTATION_SOURCE_SET_DOMAIN,
            IMPLEMENTATION_SOURCE_SET_NAME,
            &implementation_paths,
        )
        .unwrap();
        let error =
            validate_core_manifest(root, &canonical_json_bytes(&core).unwrap()).unwrap_err();
        assert!(error.to_string().contains("claim contract differs"));
    }

    #[cfg(unix)]
    #[test]
    fn raw_identities_reject_symlink_targets_and_parents() {
        use std::os::unix::fs::symlink;

        let repository = tempfile::tempdir().unwrap();
        let outside = tempfile::tempdir().unwrap();
        write_file(outside.path(), "outside.bin", b"outside\n");
        symlink(
            outside.path().join("outside.bin"),
            repository.path().join("outside-link"),
        )
        .unwrap();
        assert!(raw_file_identity(repository.path(), "outside-link")
            .unwrap_err()
            .to_string()
            .contains("symlink"));

        write_file(repository.path(), "real/inside.bin", b"inside\n");
        symlink("real", repository.path().join("inside-parent-link")).unwrap();
        assert!(
            raw_file_identity(repository.path(), "inside-parent-link/inside.bin")
                .unwrap_err()
                .to_string()
                .contains("symlink")
        );

        fs::create_dir(repository.path().join("directory-target")).unwrap();
        assert!(raw_file_identity(repository.path(), "directory-target")
            .unwrap_err()
            .to_string()
            .contains("regular file"));
    }

    #[test]
    fn raw_identities_and_component_metadata_reject_textual_path_aliases() {
        let repository = tempfile::tempdir().unwrap();
        write_file(repository.path(), "canonical/file.bin", b"identity\n");
        for alias in [
            "canonical//file.bin",
            "canonical/./file.bin",
            "canonical/file.bin/",
        ] {
            assert!(raw_file_identity(repository.path(), alias)
                .unwrap_err()
                .to_string()
                .contains("canonical spelling"));
        }

        let valid = valid_freeze_metadata();
        let mut source_alias = valid.clone();
        source_alias
            .components
            .get_mut("analysis")
            .unwrap()
            .source_paths
            .push(ACTOR_REQUIRED_SOURCE_PATHS[0].replacen('/', "//", 1));
        source_alias
            .components
            .get_mut("analysis")
            .unwrap()
            .source_paths
            .sort();
        assert!(validate_freeze_metadata(&source_alias)
            .unwrap_err()
            .to_string()
            .contains("canonical spelling"));

        let mut apparatus_alias = valid;
        apparatus_alias
            .components
            .get_mut("actor")
            .unwrap()
            .artifact_paths[0] = format!("{APPARATUS_PREFIX}./test/xypher-calorimeter-runner");
        assert!(validate_freeze_metadata(&apparatus_alias)
            .unwrap_err()
            .to_string()
            .contains("canonical spelling"));
    }

    #[test]
    fn component_names_require_manifest_self_identity() {
        let four = BTreeMap::from([
            ("actor".to_owned(), ()),
            ("analysis".to_owned(), ()),
            ("claim".to_owned(), ()),
            ("observer".to_owned(), ()),
        ]);
        assert!(validate_component_names(&four).is_err());
        let five = BTreeMap::from([
            ("actor".to_owned(), ()),
            ("analysis".to_owned(), ()),
            ("claim".to_owned(), ()),
            ("manifest".to_owned(), ()),
            ("observer".to_owned(), ()),
        ]);
        validate_component_names(&five).unwrap();

        let valid = valid_freeze_metadata();
        validate_freeze_metadata(&valid).unwrap();

        let mut claim_artifact = valid.clone();
        claim_artifact
            .components
            .get_mut("claim")
            .unwrap()
            .artifact_paths = vec![apparatus_path("xypher-calorimeter-claim")];
        assert!(validate_freeze_metadata(&claim_artifact)
            .unwrap_err()
            .to_string()
            .contains("exactly empty"));

        let mut missing_source = valid;
        missing_source
            .components
            .get_mut("observer")
            .unwrap()
            .source_paths
            .remove(0);
        assert!(validate_freeze_metadata(&missing_source)
            .unwrap_err()
            .to_string()
            .contains(OBSERVER_REQUIRED_SOURCE_PATHS[0]));
    }

    #[test]
    fn execution_identity_is_core_bound_and_matches_declared_domains() {
        let core_hash = [0x42; 32];
        let identity = derive_execution_identity(core_hash).unwrap();

        let mut chain_preimage = Vec::new();
        chain_preimage.extend_from_slice(&(CHAIN_ID_DOMAIN.len() as u32).to_be_bytes());
        chain_preimage.extend_from_slice(CHAIN_ID_DOMAIN.as_bytes());
        chain_preimage.extend_from_slice(&core_hash);
        assert_eq!(identity.chain_id, sha256(&chain_preimage));
        assert_eq!(
            hex::encode(identity.chain_id),
            "7527d38d8e755d8330af0b7188cecdbad4c93f5e4b1e35aa604a0627519f8385"
        );

        let mut key_preimage = Vec::new();
        key_preimage.extend_from_slice(&(VALIDATOR_KEY_DOMAIN.len() as u32).to_be_bytes());
        key_preimage.extend_from_slice(VALIDATOR_KEY_DOMAIN.as_bytes());
        key_preimage.extend_from_slice(&core_hash);
        assert_eq!(identity.validator_secret_key, sha256(&key_preimage));
        assert_eq!(
            hex::encode(identity.validator_secret_key),
            "3c9942f14f1fdf0fc2b117a05f9d3f14d5a6d63eeaa8125c15d5b125156e3f82"
        );
        assert_eq!(
            identity.validator_public_key,
            SigningKey::from_bytes(&identity.validator_secret_key)
                .verifying_key()
                .to_bytes()
        );
        assert_ne!(identity, derive_execution_identity([0x43; 32]).unwrap());
    }

    #[test]
    fn prediction_commitment_contract_is_strict_and_string_encoded() {
        let commitment = PredictionCommitment {
            all_load_bearing_prediction_gates_passed: true,
            analysis_artifact: PredictionCommitmentFileIdentity {
                length_bytes: "1".to_owned(),
                path: "development/analysis".to_owned(),
                sha256: "00".repeat(32),
            },
            canonical_document: PredictionCanonicalDocumentIdentity {
                length_bytes: "3".to_owned(),
                schema: PREDICTION_DOCUMENT_SCHEMA.to_owned(),
                sha256: raw_sha256_hex(b"{}\n"),
            },
            commitment_domain: PREDICTION_COMMITMENT_DOMAIN.to_owned(),
            core_hash: "11".repeat(32),
            decision_count: "1".to_owned(),
            episode_count: "1".to_owned(),
            final_manifest_hash: "22".repeat(32),
            fixture_catalog_hash: "33".repeat(32),
            genesis_recipe_hash: "44".repeat(32),
            payload_hash: "55".repeat(32),
            payload_schema: PREDICTION_PAYLOAD_SCHEMA.to_owned(),
            policy_config_hash: "66".repeat(32),
            reporting_policy_hash: "77".repeat(32),
            schedule_hash: "88".repeat(32),
            schema: PREDICTION_COMMITMENT_SCHEMA.to_owned(),
            tolerances: serde_json::json!({"absolute_tolerance": "0.0"}),
        };
        validate_prediction_commitment_structure(&commitment).unwrap();
        assert!(validate_frozen_prediction_commitment(&commitment).is_err());
        let bytes = canonical_json_bytes(&commitment).unwrap();
        validate_canonical_json(&bytes).unwrap();

        let mut malformed = commitment.clone();
        malformed.canonical_document.length_bytes = "03".to_owned();
        assert!(validate_prediction_commitment_structure(&malformed).is_err());

        let mut wrong_domain = commitment.clone();
        wrong_domain.commitment_domain = "xypher-calorimeter/prediction-commitment/v2".to_owned();
        assert!(validate_prediction_commitment_structure(&wrong_domain).is_err());

        let mut frozen = commitment;
        frozen.payload_hash = EXPECTED_PREDICTION_PAYLOAD_SHA256.to_owned();
        validate_frozen_prediction_commitment(&frozen).unwrap();
        frozen.payload_hash = "ff".repeat(32);
        assert!(validate_frozen_prediction_commitment(&frozen).is_err());
    }

    #[test]
    fn sidecars_bind_exact_bytes_and_filename() {
        let expected = hash_sidecar_bytes(Path::new("catalog.json"), b"{}\n").unwrap();
        let text = String::from_utf8(expected).unwrap();
        assert!(text.ends_with("  catalog.json\n"));
        assert!(text.starts_with(&raw_sha256_hex(b"{}\n")));
    }
}
