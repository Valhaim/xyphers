use num_bigint::BigUint;
use xypher_calorimeter_analysis::{
    compare_kernels, symmetric_eigendecomposition, Action, Analysis, DenseMatrix, ExactKernel,
    Fixture, StateShell,
};

const TOLERANCE: f64 = 1.0e-12;

fn triangle_fixture() -> Fixture {
    Fixture::new(3, [(0, 1), (1, 2), (0, 2)], 2).expect("valid triangle fixture")
}

fn path_fixture() -> Fixture {
    Fixture::new(4, [(0, 1), (1, 2), (2, 3)], 3).expect("valid path fixture")
}

fn assert_close(actual: f64, expected: f64) {
    assert!(
        (actual - expected).abs() <= TOLERANCE,
        "expected {expected:.16}, got {actual:.16}"
    );
}

#[test]
fn weak_composition_shell_is_canonical_and_action_labelled() {
    let shell = StateShell::enumerate(triangle_fixture()).expect("shell");
    assert_eq!(shell.state_count(), 6);
    assert_eq!(
        shell.states(),
        &[
            vec![0, 0, 2],
            vec![0, 1, 1],
            vec![0, 2, 0],
            vec![1, 0, 1],
            vec![1, 1, 0],
            vec![2, 0, 0],
        ]
    );

    for state in 0..shell.state_count() {
        assert_eq!(
            shell
                .actions(state)
                .expect("actions")
                .iter()
                .filter(|step| step.action == Action::Wait)
                .count(),
            1
        );
        assert_eq!(shell.adjacency()[state][state], 1);
        for target in 0..shell.state_count() {
            assert_eq!(
                shell.adjacency()[state][target],
                shell.adjacency()[target][state]
            );
        }
    }
}

#[test]
fn triangle_path_counts_and_stationary_law_match_hand_derived_anchors() {
    let shell = StateShell::enumerate(triangle_fixture()).expect("shell");
    let concentrated = shell.state_index(&[2, 0, 0]).expect("concentrated");
    let split = shell.state_index(&[1, 1, 0]).expect("split");

    let horizon_two = ExactKernel::build(shell.clone(), 2).expect("H=2");
    assert_eq!(
        horizon_two.path_count(1, concentrated).expect("c1"),
        &BigUint::from(3_u8)
    );
    assert_eq!(
        horizon_two.path_count(1, split).expect("c1"),
        &BigUint::from(5_u8)
    );
    assert_eq!(
        horizon_two.path_count(2, concentrated).expect("c2"),
        &BigUint::from(13_u8)
    );
    assert_eq!(
        horizon_two.path_count(2, split).expect("c2"),
        &BigUint::from(21_u8)
    );

    let candidate_weights = horizon_two
        .candidate_weights(concentrated)
        .expect("candidate weights");
    assert_eq!(candidate_weights.len(), 3);
    assert_eq!(candidate_weights[0].action, Action::Wait);
    assert_eq!(candidate_weights[0].weight, BigUint::from(3_u8));
    assert_eq!(candidate_weights[1].weight, BigUint::from(5_u8));
    assert_eq!(candidate_weights[2].weight, BigUint::from(5_u8));
    assert_eq!(
        horizon_two
            .transition_ratio(concentrated, concentrated)
            .expect("wait ratio")
            .numerator(),
        &BigUint::from(3_u8)
    );
    assert_eq!(
        horizon_two
            .transition_ratio(concentrated, concentrated)
            .expect("wait ratio")
            .denominator(),
        &BigUint::from(13_u8)
    );
    assert_eq!(
        horizon_two
            .stationary_ratio(concentrated)
            .expect("stationary")
            .numerator(),
        &BigUint::from(13_u8)
    );
    assert_eq!(
        horizon_two
            .stationary_ratio(concentrated)
            .expect("stationary")
            .denominator(),
        &BigUint::from(144_u16)
    );
    assert_eq!(
        horizon_two
            .stationary_ratio(split)
            .expect("stationary")
            .numerator(),
        &BigUint::from(35_u8)
    );
    assert_eq!(
        horizon_two
            .stationary_ratio(split)
            .expect("stationary")
            .denominator(),
        &BigUint::from(144_u16)
    );

    let checks = horizon_two.verify_exact();
    assert!(checks.all_passed());
    assert!(checks.cycle_balance.basis_cycles > 0);

    let exact_transient = horizon_two
        .exact_delta_transient(concentrated, 2)
        .expect("exact delta transient");
    assert_eq!(exact_transient.len(), 3);
    assert!(exact_transient.iter().all(|point| point.is_normalized()));
    assert_eq!(
        exact_transient[1]
            .probability(concentrated)
            .expect("one-step return")
            .numerator(),
        &BigUint::from(3_u8)
    );
    assert_eq!(
        exact_transient[1]
            .probability(concentrated)
            .expect("one-step return")
            .denominator(),
        &BigUint::from(13_u8)
    );
    assert_eq!(
        exact_transient[2]
            .probability(concentrated)
            .expect("two-step return")
            .numerator(),
        &BigUint::from(193_u16)
    );
    assert_eq!(
        exact_transient[2]
            .probability(concentrated)
            .expect("two-step return")
            .denominator(),
        &BigUint::from(1_183_u16)
    );

    let horizon_four = ExactKernel::build(shell, 4).expect("H=4");
    assert_eq!(
        horizon_four
            .path_count(4, concentrated)
            .expect("c4 concentrated"),
        &BigUint::from(233_u16)
    );
}

#[test]
fn path_counts_and_horizon_one_stationary_law_match_combinatorial_anchors() {
    let shell = StateShell::enumerate(path_fixture()).expect("shell");
    assert_eq!(shell.state_count(), 20);
    let endpoint = shell.state_index(&[3, 0, 0, 0]).expect("endpoint state");

    let horizon_three = ExactKernel::build(shell.clone(), 3).expect("H=3");
    assert_eq!(
        horizon_three.path_count(1, endpoint).expect("c1"),
        &BigUint::from(2_u8)
    );
    assert_eq!(
        horizon_three.path_count(3, endpoint).expect("c3"),
        &BigUint::from(20_u8)
    );
    assert!(horizon_three.verify_exact().all_passed());
    let moved = horizon_three
        .shell()
        .state_index(&[2, 1, 0, 0])
        .expect("moved state");
    let exact_transient = horizon_three
        .exact_delta_transient(endpoint, 1)
        .expect("exact transient");
    assert_eq!(
        exact_transient[1]
            .probability(endpoint)
            .expect("wait probability")
            .numerator(),
        &BigUint::from(3_u8)
    );
    assert_eq!(
        exact_transient[1]
            .probability(endpoint)
            .expect("wait probability")
            .denominator(),
        &BigUint::from(10_u8)
    );
    assert_eq!(
        exact_transient[1]
            .probability(moved)
            .expect("move probability")
            .numerator(),
        &BigUint::from(7_u8)
    );
    assert_eq!(
        exact_transient[1]
            .probability(moved)
            .expect("move probability")
            .denominator(),
        &BigUint::from(10_u8)
    );

    let horizon_one = ExactKernel::build(shell, 1).expect("H=1");
    assert_eq!(
        horizon_one
            .stationary_ratio(endpoint)
            .expect("stationary")
            .numerator(),
        &BigUint::from(1_u8)
    );
    assert_eq!(
        horizon_one
            .stationary_ratio(endpoint)
            .expect("stationary")
            .denominator(),
        &BigUint::from(40_u8)
    );
}

#[test]
fn exact_permutation_covariance_maps_states_actions_counts_kernel_and_stationary_law() {
    let triangle = ExactKernel::build(StateShell::enumerate(triangle_fixture()).expect("shell"), 4)
        .expect("triangle kernel");
    let triangle_report = triangle
        .verify_permutation_covariance(&[2, 0, 1])
        .expect("triangle covariance");
    assert!(triangle_report.all_passed());
    assert_ne!(
        triangle_report.state_mapping,
        (0..triangle.shell().state_count()).collect::<Vec<_>>()
    );

    let path = ExactKernel::build(StateShell::enumerate(path_fixture()).expect("shell"), 3)
        .expect("path kernel");
    let path_report = path
        .verify_permutation_covariance(&[2, 0, 3, 1])
        .expect("path covariance");
    assert!(path_report.state_covariance);
    assert!(path_report.action_covariance);
    assert!(path_report.candidate_weight_covariance);
    assert!(path_report.path_count_covariance);
    assert!(path_report.transition_covariance);
    assert!(path_report.stationary_covariance);
    assert!(path_report.all_passed());

    assert!(path.verify_permutation_covariance(&[0, 0, 2, 3]).is_err());
    assert!(path.verify_permutation_covariance(&[0, 1, 2]).is_err());
}

#[test]
fn reversible_spectrum_entropy_and_localization_reports_are_consistent() {
    let horizon_one = Analysis::build(triangle_fixture(), 1).expect("H=1 analysis");
    let horizon_two = Analysis::build(triangle_fixture(), 2).expect("H=2 analysis");
    let horizon_four = Analysis::build(triangle_fixture(), 4).expect("H=4 analysis");

    for analysis in [&horizon_one, &horizon_two, &horizon_four] {
        assert!(analysis.exact_checks().all_passed());
        assert_close(analysis.spectral().eigenvalues[0], 1.0);
        assert!(analysis.spectral().spectral_gap > 0.0);
        assert!(analysis.spectral().spectral_gap <= 1.0);
        assert!(
            analysis.entropy().entropy_rate_bits_per_step
                <= analysis.entropy().topological_entropy_bits_per_step + TOLERANCE
        );
        assert!(analysis.entropy().entropy_rate_deficit_bits_per_step >= -TOLERANCE);
        assert!(analysis.equilibrium().inverse_participation_ratio > 0.0);
        assert!(analysis.equilibrium().participation_ratio <= 6.0 + TOLERANCE);
        assert!(analysis.equilibrium().normalized_participation_ratio <= 1.0 + TOLERANCE);
        assert!(analysis.equilibrium().localization_excess >= -TOLERANCE);
        assert!(
            analysis.equilibrium().perron_square_total_variation >= 0.0
                && analysis.equilibrium().perron_square_total_variation <= 1.0
        );
        assert!(analysis.residuals().maximum_row_sum_residual <= TOLERANCE);
        assert!(analysis.residuals().maximum_stationarity_residual <= TOLERANCE);
        assert!(analysis.residuals().maximum_detailed_balance_residual <= TOLERANCE);
        assert!(analysis.spectral().maximum_eigenpair_residual <= TOLERANCE);
        assert!(
            analysis
                .spectral()
                .maximum_normalized_eigenpair_residual_upper_bound
                <= TOLERANCE
        );
        assert!(analysis.spectral().maximum_orthogonality_residual <= TOLERANCE);
        assert!(analysis.spectral().maximum_reconstruction_residual <= TOLERANCE);
        assert!(
            analysis.spectral().spectral_gap
                >= analysis.spectral().spectral_gap_certificate.gap_lower_bound
        );
        assert!(
            analysis.spectral().spectral_gap
                <= analysis.spectral().spectral_gap_certificate.gap_upper_bound
        );
        assert_eq!(
            analysis.spectral().eigenvalues.len(),
            analysis
                .spectral()
                .normalized_eigenpair_residual_upper_bounds
                .len()
        );
    }

    assert!(
        horizon_four.equilibrium().perron_square_total_variation
            < horizon_one.equilibrium().perron_square_total_variation
    );
    let comparison = compare_kernels(&horizon_one, &horizon_two).expect("comparison");
    assert!(comparison.stationary_total_variation > 0.0);
    assert!(comparison.maximum_row_total_variation > 0.0);
}

#[test]
fn transient_reports_contract_relative_entropy_and_reach_stationarity() {
    let analysis = Analysis::build(path_fixture(), 3).expect("analysis");
    let endpoint = analysis
        .exact()
        .shell()
        .state_index(&[3, 0, 0, 0])
        .expect("endpoint");
    let transient = analysis
        .transient_from_state(endpoint, 160)
        .expect("transient");
    assert_eq!(transient.points.len(), 161);
    let exact_points = transient
        .exact_delta_points
        .as_ref()
        .expect("delta transient preserves exact distributions");
    assert_eq!(exact_points.len(), transient.points.len());
    assert!(exact_points.iter().all(|point| point.is_normalized()));
    for (exact, numerical) in exact_points.iter().zip(&transient.points) {
        for (probability, expected) in exact
            .distribution
            .to_f64()
            .expect("exact distribution conversion")
            .iter()
            .zip(&numerical.distribution)
        {
            assert_close(*probability, *expected);
        }
    }
    for pair in transient.points.windows(2) {
        assert!(
            pair[1].relative_entropy_bits <= pair[0].relative_entropy_bits + TOLERANCE,
            "KL increased at opportunity {}",
            pair[1].opportunity
        );
    }
    let final_point = transient.points.last().expect("final point");
    assert!(final_point.total_variation_to_stationary < 1.0e-6);
    assert!(transient.first_below_mixing_threshold.is_some());
    for point in &transient.points {
        assert_close(point.distribution.iter().sum(), 1.0);
        assert!(point.endpoint_entropy_bits >= 0.0);
    }
}

#[test]
fn complete_first_passage_and_exact_return_predictions_obey_kac_identity() {
    let analysis = Analysis::build(triangle_fixture(), 1).expect("analysis");
    let concentrated = analysis
        .exact()
        .shell()
        .state_index(&[2, 0, 0])
        .expect("concentrated");
    let split = analysis
        .exact()
        .shell()
        .state_index(&[1, 1, 0])
        .expect("split");
    let report = analysis.first_passage().expect("first passage");
    assert!(report.maximum_bellman_residual <= TOLERANCE);

    assert_close(report.mean_return[concentrated], 8.0);
    assert_close(report.mean_return[split], 24.0 / 5.0);
    assert_eq!(
        report.exact_mean_return[concentrated].numerator(),
        &BigUint::from(8_u8)
    );
    assert_eq!(
        report.exact_mean_return[concentrated].denominator(),
        &BigUint::from(1_u8)
    );
    for source in 0..analysis.stationary().len() {
        for target in 0..analysis.stationary().len() {
            let prediction = report
                .mean_first_passage(source, target)
                .expect("ordered pair");
            if source == target {
                assert_eq!(prediction, 0.0);
            } else {
                assert!(prediction.is_finite() && prediction > 0.0);
            }
        }
        assert_close(
            report.mean_return[source],
            1.0 / analysis.stationary()[source],
        );
    }
}

#[test]
fn deterministic_jacobi_solver_matches_a_closed_form_spectrum() {
    let matrix = DenseMatrix::from_rows(vec![vec![2.0, 1.0], vec![1.0, 2.0]]).expect("matrix");
    let first = symmetric_eigendecomposition(&matrix).expect("spectrum");
    let second = symmetric_eigendecomposition(&matrix).expect("repeat");
    assert_eq!(first, second);
    assert_close(first.eigenvalues[0], 3.0);
    assert_close(first.eigenvalues[1], 1.0);
    assert!(first.maximum_eigenpair_residual <= TOLERANCE);
    assert!(first.maximum_orthogonality_residual <= TOLERANCE);
    assert!(first.maximum_reconstruction_residual <= TOLERANCE);
    let leading = first.eigenvector(0).expect("leading vector");
    assert_close(leading[0], 1.0 / 2.0_f64.sqrt());
    assert_close(leading[1], 1.0 / 2.0_f64.sqrt());

    let asymmetric = DenseMatrix::from_rows(vec![vec![1.0, 0.1], vec![0.0, 1.0]]).expect("matrix");
    assert!(symmetric_eigendecomposition(&asymmetric).is_err());
}

#[test]
fn malformed_fixtures_are_rejected_before_shell_construction() {
    assert!(Fixture::new(0, [], 1).is_err());
    assert!(Fixture::new(2, [(0, 0)], 1).is_err());
    assert!(Fixture::new(2, [(0, 1), (1, 0)], 1).is_err());
    assert!(Fixture::new(3, [(0, 1)], 1).is_err());
    assert!(Fixture::new(2, [(0, 2)], 1).is_err());
    assert!(Fixture::new(2, [(0, 1)], 0).is_err());
}
