use num_bigint::BigUint;
use xypher_calorimeter_analysis::{
    check_exists_beta_compatibility, check_qh_channel_compatibility, compare_qh_weak_contact,
    frozen_constructibility_report, Action, CoordinateOrigin, ExactKernel, ExactRatio, Fixture,
    FrozenContactMode, FrozenContactPair, FrozenCurrentDirection, StateResolution, StateShell,
    StationaryCompatibilityProfile, FROZEN_NODE_COUNT, FROZEN_SLOT_COUNT, FROZEN_STATE_COUNT,
};

fn ratio(numerator: u64, denominator: u64) -> ExactRatio {
    ExactRatio::new(BigUint::from(numerator), BigUint::from(denominator))
        .expect("valid exact ratio")
}

fn frozen_triangle_kernel() -> ExactKernel {
    ExactKernel::build(
        StateShell::enumerate(
            Fixture::new(3, [(0, 1), (0, 2), (1, 2)], 3).expect("triangle fixture"),
        )
        .expect("triangle shell"),
        2,
    )
    .expect("triangle kernel")
}

fn contact_kernels(horizon: usize) -> (ExactKernel, ExactKernel) {
    let isolated =
        Fixture::new_disconnected_support(4, [(0, 1), (2, 3)], 2).expect("isolated fixture");
    let joined = Fixture::new(4, [(0, 1), (1, 2), (2, 3)], 2).expect("joined fixture");
    (
        ExactKernel::build(
            StateShell::enumerate(isolated).expect("isolated shell"),
            horizon,
        )
        .expect("isolated kernel"),
        ExactKernel::build(
            StateShell::enumerate(joined).expect("joined shell"),
            horizon,
        )
        .expect("joined kernel"),
    )
}

#[test]
fn frozen_qh_candidate_is_rejected_before_any_contact_trajectory() {
    let kernel = frozen_triangle_kernel();
    assert_eq!(kernel.shell().state_count(), 10);
    let x = kernel
        .shell()
        .state_index(&[3, 0, 0])
        .expect("named state x");
    let y = kernel
        .shell()
        .state_index(&[2, 1, 0])
        .expect("named state y");
    assert_eq!(kernel.path_count(1, x).unwrap(), &BigUint::from(3_u8));
    assert_eq!(kernel.path_count(2, x).unwrap(), &BigUint::from(13_u8));
    assert_eq!(kernel.path_count(1, y).unwrap(), &BigUint::from(5_u8));
    assert_eq!(kernel.path_count(2, y).unwrap(), &BigUint::from(25_u8));

    let profile = StationaryCompatibilityProfile::from_exact_kernel(
        &kernel,
        vec![0; kernel.shell().state_count()],
        vec![ExactRatio::one(); kernel.shell().state_count()],
        CoordinateOrigin::Predeclared,
        StateResolution::ExactLabeledState,
    )
    .expect("frozen exact-state profile");
    let stationary = check_exists_beta_compatibility(&profile).expect("stationary report");
    assert!(!stationary.compatible());
    assert_eq!(stationary.reduced_weights[x], ratio(39, 1));
    assert_eq!(stationary.reduced_weights[y], ratio(125, 1));

    let channels =
        check_qh_channel_compatibility(&kernel, &profile, &ExactRatio::one()).expect("channels");
    assert!(channels.theorem_compatible);
    assert!(!channels.fixed_beta_compatible);
    assert!(!channels.compatible());
    let witness = channels
        .witnesses
        .iter()
        .find(|candidate| {
            candidate.source == x
                && candidate.action == Action::Transfer { from: 0, to: 1 }
                && candidate.successor == y
        })
        .expect("x-to-y witness");
    assert_eq!(witness.forward_probability, ratio(5, 13));
    assert_eq!(witness.reverse_probability, ratio(3, 25));
    assert_eq!(witness.observed_ratio, ratio(125, 39));
    assert_eq!(witness.fixed_boltzmann_ratio, ExactRatio::one());

    for (horizon, changed, joined_probability) in [
        (1, 12, ratio(1, 4)),
        (2, 16, ratio(5, 16)),
        (5, 16, ratio(281, 835)),
    ] {
        let (isolated, joined) = contact_kernels(horizon);
        let contact = compare_qh_weak_contact(&isolated, &joined).expect("contact comparison");
        assert_eq!(contact.state_count, 10);
        assert_eq!(contact.retained_channel_count, 16);
        assert_eq!(contact.changed_channel_count, changed);
        assert!(!contact.all_retained_channels_unchanged());
        let channel = contact
            .channels
            .iter()
            .find(|candidate| {
                candidate.source_allocation == [1, 0, 1, 0]
                    && candidate.label.from == 0
                    && candidate.label.to == 1
            })
            .expect("contact witness");
        assert_eq!(channel.isolated_probability, ratio(1, 3));
        assert_eq!(channel.joined_probability, joined_probability);
    }

    let native_trajectory_admitted = stationary.compatible()
        && channels.compatible()
        && [1, 2, 5].into_iter().all(|horizon| {
            let (isolated, joined) = contact_kernels(horizon);
            compare_qh_weak_contact(&isolated, &joined)
                .is_ok_and(|report| report.all_retained_channels_unchanged())
        });
    assert!(!native_trajectory_admitted);
}

#[test]
fn frozen_fixed_affordance_control_passes_every_exact_constructibility_gate() {
    let report = frozen_constructibility_report().expect("constructibility report");
    assert!(report.all_passed());
    assert_eq!(report.node_count, FROZEN_NODE_COUNT);
    assert_eq!(report.state_count, FROZEN_STATE_COUNT);
    assert_eq!(report.slot_count, FROZEN_SLOT_COUNT);
    assert_eq!(report.universal_channel_probability, ratio(1, 23));
    assert_eq!(report.isolated_kernel.mode, FrozenContactMode::Isolated);

    let expected = [
        (FrozenContactPair::T2T3, 30, ratio(1, 138)),
        (FrozenContactPair::T3T4, 24, ratio(2, 345)),
        (FrozenContactPair::T2T4, 28, ratio(3, 230)),
    ];
    for (pair, component_count, ordered_current) in expected {
        let pair_report = report
            .pairs
            .iter()
            .find(|candidate| candidate.pair == pair)
            .expect("pair report");
        assert_eq!(pair_report.kernel.mode, FrozenContactMode::Pair(pair));
        assert_eq!(pair_report.internal_channel_instances_checked, 8_192);
        assert!(pair_report.internal_hazards_preserved);
        assert_eq!(pair_report.components.len(), component_count);
        assert!(pair_report.all_components_closed);
        assert!(pair_report.all_components_irreducible);
        assert!(pair_report.common_product_invariant);
        assert_eq!(
            pair_report.fresh_clone_current.direction,
            FrozenCurrentDirection::Zero
        );
        assert_eq!(
            pair_report.fresh_clone_current.net_magnitude,
            ExactRatio::zero()
        );
        assert_eq!(
            pair_report.ordered_current.direction,
            FrozenCurrentDirection::LeftToRight
        );
        assert_eq!(pair_report.ordered_current.net_magnitude, ordered_current);
        assert!(pair_report.ordered_current.exact_prediction);
    }
}
