use num_bigint::{BigInt, BigUint};
use num_traits::{One, Zero};
use std::collections::BTreeSet;
use xypher_calorimeter_analysis::{
    causal_stack_generator, frozen_adaptive_contact_report, BalanceFiber, ContinuousChannelClass,
    GateVerdict, SignedValueSign,
};

#[test]
fn frozen_adaptive_contact_predictions_match_without_a_trajectory() {
    let report = frozen_adaptive_contact_report().expect("frozen CAL-ADAPT report");
    assert!(report.matches_preregistered_predictions());

    assert_eq!(report.monotone.full_reverse_support, GateVerdict::Failed);
    assert!(report.monotone.monotone_reverse_obstruction);
    assert_eq!(report.monotone.transient_states, ["z0"]);
    assert!(!report.monotone.full_support_stationary_exists);

    let witness = report
        .apparent_reciprocity
        .lumpability_witness
        .as_ref()
        .expect("strong-lumpability witness");
    assert_eq!(witness.left_state, "A0");
    assert_eq!(witness.right_state, "A1");
    assert_eq!(witness.destination, BalanceFiber::B);
    assert_eq!(witness.left_probability.numerator(), &BigUint::one());
    assert_eq!(witness.right_probability.numerator(), &BigUint::zero());
    assert!(
        report
            .apparent_reciprocity
            .existential_fiber_support_reciprocal
    );
    assert_eq!(
        report
            .apparent_reciprocity
            .projected_reference_detailed_balance,
        GateVerdict::NotApplicable
    );

    assert!(report.lumpable_control.full_support_stationary_exists);
    assert!(!report.lumpable_control.stationary_law_unique);
    assert_eq!(report.lumpable_control.communicating_classes.len(), 2);

    assert_eq!(report.reversible_square.channel_count, 12);
    assert!(report
        .reversible_square
        .all_applicable_positive_gates_passed());
    assert_eq!(report.ma_ablation.full_reverse_support, GateVerdict::Failed);
    assert_eq!(report.mb_ablation.full_reverse_support, GateVerdict::Failed);
    assert!(report.ma_ablation.strong_lumpability.passed());
    assert!(report.mb_ablation.strong_lumpability.passed());
    assert!(report
        .ma_ablation
        .projected_reference_detailed_balance
        .passed());
    assert!(report
        .mb_ablation
        .projected_reference_detailed_balance
        .passed());
    assert_eq!(
        report.ma_ablation.reference_detailed_balance,
        GateVerdict::Failed
    );
    assert_eq!(
        report.mb_ablation.reference_detailed_balance,
        GateVerdict::Failed
    );
}

#[test]
fn causal_stack_enumerates_labeled_reverse_channels_and_exact_macro_law() {
    let generator = causal_stack_generator(3, 2).expect("ternary causal stack");
    let report = generator.verify().expect("ternary exact report");
    assert!(report.all_applicable_positive_gates_passed());
    assert_eq!(report.state_count, 13);
    assert_eq!(report.replacement_count, 42);
    assert_eq!(report.pop_count, 12);
    assert_eq!(report.append_count, 12);
    assert_eq!(report.contacted_channel_count, 66);
    assert_eq!(
        report.exit_rates_by_level,
        [
            BigUint::from(5_u8),
            BigUint::from(6_u8),
            BigUint::from(3_u8)
        ]
    );

    let ids = generator
        .contacted_channels()
        .iter()
        .map(|channel| channel.id.as_str())
        .collect::<BTreeSet<_>>();
    assert_eq!(ids.len(), generator.contacted_channels().len());
    for channel in generator.contacted_channels() {
        assert_eq!(channel.rate, BigUint::one());
        assert_eq!(channel.multiplicity, 1);
        assert!(ids.contains(channel.reverse_id.as_str()));
        if let ContinuousChannelClass::Replace { from, to, .. } = channel.class {
            assert_ne!(from, to);
        }
    }

    let top = generator
        .states()
        .iter()
        .position(|state| state.energy_level == 2)
        .expect("top energy state");
    let top_appends = generator
        .contacted_channels()
        .iter()
        .filter(|channel| {
            channel.source == top && matches!(channel.class, ContinuousChannelClass::Append { .. })
        })
        .count();
    assert_eq!(top_appends, 3);

    let signed = generator.signed_matrix().expect("signed generator");
    for (source, row) in signed.iter().enumerate() {
        assert_eq!(
            row.iter().fold(BigInt::zero(), |sum, value| sum + value),
            BigInt::zero()
        );
        assert_eq!(
            row[source],
            -BigInt::from(report.diagonal_exit_rates[source].clone())
        );
    }
}

#[test]
fn causal_stack_generator_extrapolates_beyond_frozen_tables() {
    let report = causal_stack_generator(2, 3)
        .expect("metamorphic stack")
        .verify()
        .expect("metamorphic report");
    assert!(report.all_applicable_positive_gates_passed());
    assert_eq!(report.state_count, 15);
    assert_eq!(report.replacement_count, 34);
    assert_eq!(report.pop_count, 14);
    assert_eq!(report.append_count, 14);
    assert_eq!(report.contacted_channel_count, 62);
    assert_eq!(
        report.macro_multiplicities,
        [
            BigUint::from(8_u8),
            BigUint::from(4_u8),
            BigUint::from(2_u8),
            BigUint::one(),
        ]
    );
    assert_eq!(
        report.exit_rates_by_level,
        [
            BigUint::from(4_u8),
            BigUint::from(5_u8),
            BigUint::from(4_u8),
            BigUint::from(2_u8),
        ]
    );
    assert!(report
        .equilibrium_currents
        .iter()
        .all(|current| current.sign == SignedValueSign::Zero));

    let second = causal_stack_generator(4, 1)
        .expect("second metamorphic stack")
        .verify()
        .expect("second metamorphic report");
    assert!(second.all_applicable_positive_gates_passed());
    assert_eq!(second.state_count, 5);
    assert_eq!(second.replacement_count, 12);
    assert_eq!(second.pop_count, 4);
    assert_eq!(second.append_count, 4);
}

#[test]
fn causal_stack_rejects_degenerate_domains() {
    assert!(causal_stack_generator(0, 2).is_err());
    assert!(causal_stack_generator(1, 2).is_err());
    assert!(causal_stack_generator(2, 0).is_err());
}
