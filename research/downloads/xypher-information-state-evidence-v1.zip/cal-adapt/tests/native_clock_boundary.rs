use num_bigint::BigUint;
use xypher_calorimeter_analysis::{
    frozen_native_clock_report, verify_bundle_additivity, verify_cycle_affinity,
    verify_exact_rate_tetrads, BalanceFiber, ExactCycleAffinity, ExactRatio, GateVerdict,
    GraphFixtureKind, NativeDepartureLaw, NativeGraphClock, SourceOddsCase,
};

fn ratio(numerator: u64, denominator: u64) -> ExactRatio {
    ExactRatio::new(BigUint::from(numerator), BigUint::from(denominator))
        .expect("exact native-clock test ratio")
}

fn odds_case(
    cases: &[SourceOddsCase],
    departure: NativeDepartureLaw,
    clock: NativeGraphClock,
) -> &SourceOddsCase {
    cases
        .iter()
        .find(|case| case.departure == departure && case.clock == clock)
        .expect("frozen source-odds case")
}

#[test]
fn fixtures_a_and_b_preserve_the_frozen_embedded_equivalences() {
    let report = frozen_native_clock_report().expect("native-clock report");

    assert!(report.k1_graph_clock.kernels_equal);
    assert_eq!(
        report.k1_graph_clock.raw_exit_rates,
        [ratio(1, 1), ratio(2, 1), ratio(1, 1)]
    );
    assert_eq!(
        report.k1_graph_clock.normalized_exit_rates,
        [ratio(1, 1), ratio(1, 1), ratio(1, 1)]
    );
    assert_ne!(
        report.k1_graph_clock.raw_exit_rates,
        report.k1_graph_clock.normalized_exit_rates
    );

    assert_eq!(report.k2_load_laws.len(), 4);
    for graph in [GraphFixtureKind::UnitPath, GraphFixtureKind::WeightedPath] {
        for clock in [NativeGraphClock::RawEdge, NativeGraphClock::NormalizedNode] {
            let case = report
                .k2_load_laws
                .iter()
                .find(|case| case.graph == graph && case.clock == clock)
                .expect("frozen K=2 case");
            assert!(case.kernels_equal);
            assert_eq!(case.per_unit_kernel, case.occupied_site_kernel);
        }
    }
}

#[test]
fn fixture_c_derives_the_four_swapped_state_odds_cases() {
    let report = frozen_native_clock_report().expect("native-clock report");
    assert_eq!(report.k3_source_odds.len(), 4);

    let per_unit_raw = odds_case(
        &report.k3_source_odds,
        NativeDepartureLaw::PerUnit,
        NativeGraphClock::RawEdge,
    );
    assert_eq!(per_unit_raw.plus, ratio(1, 1));
    assert_eq!(per_unit_raw.minus, ratio(1, 4));
    assert_eq!(per_unit_raw.quotient, ratio(4, 1));
    assert_eq!(per_unit_raw.product, ratio(1, 4));

    let occupied_raw = odds_case(
        &report.k3_source_odds,
        NativeDepartureLaw::OccupiedSite,
        NativeGraphClock::RawEdge,
    );
    assert_eq!(occupied_raw.plus, ratio(1, 2));
    assert_eq!(occupied_raw.minus, ratio(1, 2));
    assert_eq!(occupied_raw.quotient, ratio(1, 1));
    assert_eq!(occupied_raw.product, ratio(1, 4));

    let per_unit_node = odds_case(
        &report.k3_source_odds,
        NativeDepartureLaw::PerUnit,
        NativeGraphClock::NormalizedNode,
    );
    assert_eq!(per_unit_node.plus, ratio(2, 1));
    assert_eq!(per_unit_node.minus, ratio(1, 2));
    assert_eq!(per_unit_node.quotient, ratio(4, 1));
    assert_eq!(per_unit_node.product, ratio(1, 1));

    let occupied_node = odds_case(
        &report.k3_source_odds,
        NativeDepartureLaw::OccupiedSite,
        NativeGraphClock::NormalizedNode,
    );
    assert_eq!(occupied_node.plus, ratio(1, 1));
    assert_eq!(occupied_node.minus, ratio(1, 1));
    assert_eq!(occupied_node.quotient, ratio(1, 1));
    assert_eq!(occupied_node.product, ratio(1, 1));
}

#[test]
fn fixture_d_preserves_jump_order_and_thinned_poisson_parameters() {
    let report = frozen_native_clock_report().expect("native-clock report");

    assert!(report.state_clock_gauge.kernels_equal);
    assert_eq!(
        report.state_clock_gauge.base_kernel,
        report.state_clock_gauge.transformed_kernel
    );
    assert_eq!(
        report.state_clock_gauge.changed_exit_states,
        [report.state_clock_gauge.multiplied_state]
    );
    assert_eq!(
        report.state_clock_gauge.transformed_exit_rates[report.state_clock_gauge.multiplied_state],
        report.state_clock_gauge.base_exit_rates[report.state_clock_gauge.multiplied_state]
            .checked_multiply(&ratio(2, 1))
            .unwrap()
    );

    assert_eq!(
        report.thinning_gauge.direct.opportunity_intensity,
        ratio(1, 1)
    );
    assert_eq!(
        report.thinning_gauge.direct.retention_probability,
        ratio(1, 1)
    );
    assert_eq!(
        report.thinning_gauge.thinned.opportunity_intensity,
        ratio(2, 1)
    );
    assert_eq!(
        report.thinning_gauge.thinned.retention_probability,
        ratio(1, 2)
    );
    assert_eq!(report.thinning_gauge.direct.accepted_intensity, ratio(1, 1));
    assert_eq!(
        report.thinning_gauge.thinned.accepted_intensity,
        ratio(1, 1)
    );
    assert!(report.thinning_gauge.accepted_intensities_equal);
    assert!(report.thinning_gauge.homogeneous_poisson_laws_equal);
}

#[test]
fn fixture_e_checks_tetrads_bundle_additivity_and_contact_ratios() {
    let report = frozen_native_clock_report().expect("native-clock report");

    assert!(report.separable_tetrads.balanced);
    assert_eq!(report.separable_tetrads.rectangle_count, 1);
    assert!(report.separable_tetrads.first_imbalance.is_none());
    assert!(!report.nonseparable_tetrads.balanced);
    let tetrad = report
        .nonseparable_tetrads
        .first_imbalance
        .expect("nonzero tetrad");
    assert_eq!(tetrad.diagonal_product, ratio(3, 1));
    assert_eq!(tetrad.off_diagonal_product, ratio(2, 1));

    assert!(report.additive_bundle.additive);
    assert_eq!(report.additive_bundle.identity_count, 10);
    assert!(!report.occupied_site_bundle.additive);
    let bundle = report
        .occupied_site_bundle
        .first_failure
        .expect("occupied-site additivity failure");
    assert_eq!((bundle.left_bundle, bundle.right_bundle), (1, 1));
    assert_eq!(bundle.combined_hazard, BigUint::from(1_u8));
    assert_eq!(bundle.separate_hazard, BigUint::from(2_u8));

    assert_eq!(report.graph_contact.raw_retained_ratio, ratio(1, 1));
    assert_eq!(report.graph_contact.raw_control_ratio, ratio(1, 1));
    assert_eq!(report.graph_contact.raw_ratio_in_ratios, ratio(1, 1));
    assert_eq!(report.graph_contact.normalized_retained_ratio, ratio(1, 2));
    assert_eq!(report.graph_contact.normalized_control_ratio, ratio(1, 1));
    assert_eq!(report.graph_contact.normalized_ratio_in_ratios, ratio(1, 2));
}

#[test]
fn fixture_f_checks_exact_affinities_reverse_support_and_hidden_state() {
    let report = frozen_native_clock_report().expect("native-clock report");

    assert!(report.symmetric_cycle.global_reverse_support);
    assert!(report.symmetric_cycle.selected_cycle_reverse_support);
    assert!(report.symmetric_cycle.selected_unsupported_edges.is_empty());
    assert_eq!(report.symmetric_cycle.cycle_ratio, Some(ratio(1, 1)));
    assert_eq!(report.symmetric_cycle.affinity, ExactCycleAffinity::Zero);

    assert!(report.biased_cycle.global_reverse_support);
    assert!(report.biased_cycle.selected_cycle_reverse_support);
    assert!(report.biased_cycle.selected_unsupported_edges.is_empty());
    assert_eq!(report.biased_cycle.cycle_ratio, Some(ratio(8, 1)));
    assert_eq!(
        report.biased_cycle.affinity,
        ExactCycleAffinity::LogRatio(ratio(8, 1))
    );

    assert!(!report.missing_reverse_cycle.global_reverse_support);
    assert_eq!(
        report.missing_reverse_cycle.global_missing_reverse_channels,
        [(0, 1)]
    );
    assert!(!report.missing_reverse_cycle.selected_cycle_reverse_support);
    assert_eq!(
        report.missing_reverse_cycle.selected_unsupported_edges,
        [(0, 1)]
    );
    assert!(report.missing_reverse_cycle.cycle_ratio.is_none());
    assert_eq!(
        report.missing_reverse_cycle.affinity,
        ExactCycleAffinity::MissingReverse
    );

    assert_eq!(report.hidden_state.lumpable_control, GateVerdict::Passed);
    assert_eq!(
        report.hidden_state.apparent_reciprocity,
        GateVerdict::Failed
    );
    let witness = report
        .hidden_state
        .apparent_reciprocity_witness
        .as_ref()
        .expect("strong-lumpability witness");
    assert_eq!(witness.left_state, "A0");
    assert_eq!(witness.right_state, "A1");
    assert_eq!(witness.destination, BalanceFiber::B);
    assert_eq!(witness.left_probability, ratio(1, 1));
    assert_eq!(witness.right_probability, ratio(0, 1));
    assert!(report.all_preregistered_predictions_match());
}

#[test]
fn cycle_affinity_separates_global_from_selected_reverse_support() {
    let report = verify_cycle_affinity(
        &[
            vec![ratio(0, 1), ratio(1, 1), ratio(1, 1), ratio(1, 1)],
            vec![ratio(1, 1), ratio(0, 1), ratio(1, 1), ratio(0, 1)],
            vec![ratio(1, 1), ratio(1, 1), ratio(0, 1), ratio(0, 1)],
            vec![ratio(0, 1), ratio(0, 1), ratio(0, 1), ratio(0, 1)],
        ],
        &[0, 1, 2],
    )
    .expect("off-cycle reverse-support report");

    assert!(!report.global_reverse_support);
    assert_eq!(report.global_missing_reverse_channels, [(0, 3)]);
    assert!(report.selected_cycle_reverse_support);
    assert!(report.selected_unsupported_edges.is_empty());
    assert_eq!(report.cycle_ratio, Some(ratio(1, 1)));
    assert_eq!(report.affinity, ExactCycleAffinity::Zero);
}

#[test]
fn cycle_affinity_marks_a_both_zero_selected_edge_unsupported() {
    let report = verify_cycle_affinity(
        &[
            vec![ratio(0, 1), ratio(0, 1), ratio(1, 1)],
            vec![ratio(0, 1), ratio(0, 1), ratio(1, 1)],
            vec![ratio(1, 1), ratio(1, 1), ratio(0, 1)],
        ],
        &[0, 1, 2],
    )
    .expect("both-zero selected-edge report");

    assert!(report.global_reverse_support);
    assert!(report.global_missing_reverse_channels.is_empty());
    assert!(!report.selected_cycle_reverse_support);
    assert_eq!(report.selected_unsupported_edges, [(0, 1)]);
    assert!(report.cycle_ratio.is_none());
    assert_eq!(report.affinity, ExactCycleAffinity::MissingReverse);
}

#[test]
fn aggregate_gate_rejects_mutated_values_and_duplicate_case_coverage() {
    let report = frozen_native_clock_report().expect("native-clock report");
    assert!(report.all_preregistered_predictions_match());

    let mut fixture_a = report.clone();
    fixture_a.k1_graph_clock.raw_exit_rates[1] = ratio(3, 1);
    assert!(!fixture_a.all_preregistered_predictions_match());

    let mut fixture_b_duplicate = report.clone();
    fixture_b_duplicate.k2_load_laws[1] = fixture_b_duplicate.k2_load_laws[0].clone();
    assert!(!fixture_b_duplicate.all_preregistered_predictions_match());

    let mut fixture_b_kernel = report.clone();
    fixture_b_kernel.k2_load_laws[0].per_unit_kernel[0][0] = ratio(1, 1);
    fixture_b_kernel.k2_load_laws[0].occupied_site_kernel[0][0] = ratio(1, 1);
    assert!(fixture_b_kernel.k2_load_laws[0].kernels_equal);
    assert!(!fixture_b_kernel.all_preregistered_predictions_match());

    let mut fixture_c = report.clone();
    fixture_c.k3_source_odds[0].plus = ratio(9, 1);
    assert!(!fixture_c.all_preregistered_predictions_match());

    let mut fixture_c_duplicate = report.clone();
    fixture_c_duplicate.k3_source_odds[1] = fixture_c_duplicate.k3_source_odds[0].clone();
    assert!(!fixture_c_duplicate.all_preregistered_predictions_match());

    let mut fixture_d = report.clone();
    fixture_d.state_clock_gauge.base_kernel[0][0] = ratio(1, 1);
    fixture_d.state_clock_gauge.transformed_kernel[0][0] = ratio(1, 1);
    assert!(fixture_d.state_clock_gauge.kernels_equal);
    assert!(!fixture_d.all_preregistered_predictions_match());

    let mut fixture_e = report.clone();
    fixture_e.graph_contact.raw_retained_ratio = ratio(2, 1);
    assert!(!fixture_e.all_preregistered_predictions_match());

    let mut fixture_f = report;
    fixture_f.symmetric_cycle.global_reverse_support = false;
    assert!(!fixture_f.all_preregistered_predictions_match());
}

#[test]
fn generic_exact_gates_reject_malformed_inputs() {
    assert!(verify_exact_rate_tetrads(&[vec![ratio(1, 1)]]).is_err());
    assert!(
        verify_exact_rate_tetrads(&[vec![ratio(1, 1), ratio(2, 1)], vec![ratio(1, 1)]]).is_err()
    );
    assert!(verify_bundle_additivity(&[BigUint::from(1_u8), BigUint::from(1_u8)]).is_err());
    assert!(verify_cycle_affinity(&[vec![ratio(0, 1)]], &[0]).is_err());
}
