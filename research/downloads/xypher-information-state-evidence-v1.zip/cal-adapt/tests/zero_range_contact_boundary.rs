use num_bigint::{BigInt, BigUint};
use num_traits::{One, Zero};
use std::collections::BTreeMap;
use xypher_calorimeter_analysis::{
    compare_retained_zero_range_rates, edge_clock_spec, enumerate_labeled_projection_counts,
    integer_rate_matrix, linear_departure, normalized_node_clock_spec, occupied_site_departure,
    ExactRatio, ExactSignedRatio, ZeroRangeChannelLabel, ZeroRangeGenerator, ZeroRangeSpec,
};

fn bu(value: u64) -> BigUint {
    BigUint::from(value)
}

fn ratio(numerator: u64, denominator: u64) -> ExactRatio {
    ExactRatio::new(bu(numerator), bu(denominator)).expect("exact test ratio")
}

fn adjacency(rows: &[&[u64]]) -> Vec<Vec<BigUint>> {
    rows.iter()
        .map(|row| row.iter().copied().map(bu).collect())
        .collect()
}

fn reference(generator: &ZeroRangeGenerator, expected: &[(u64, u64)]) {
    assert_eq!(generator.reference().len(), expected.len());
    for (actual, &(numerator, denominator)) in generator.reference().iter().zip(expected.iter()) {
        assert_eq!(actual, &ratio(numerator, denominator));
    }
}

fn probability(
    generator: &ZeroRangeGenerator,
    allocation: &[u32],
    numerator: u64,
    denominator: u64,
) {
    let state = generator
        .state_index(allocation)
        .expect("expected occupancy state");
    assert_eq!(generator.reference()[state], ratio(numerator, denominator));
}

fn sum(values: impl IntoIterator<Item = ExactRatio>) -> ExactRatio {
    values
        .into_iter()
        .try_fold(ExactRatio::zero(), |total, value| total.checked_add(&value))
        .expect("exact sum")
}

fn preregistered_gates(generator: &ZeroRangeGenerator) {
    let report = generator.verify().expect("positive gate report");
    assert!(report.all_positive_gates_passed());

    let node_count = generator.spec().node_count();
    assert!(node_count > 1);
    let permutation = (0..node_count)
        .map(|old| (old + 1) % node_count)
        .collect::<Vec<_>>();
    assert!(generator
        .permutation_covariance(&permutation)
        .expect("permutation report")
        .all_passed());

    let removed = generator.channels().first().expect("positive channel");
    let ablated = generator
        .with_channel_removed(&ZeroRangeChannelLabel {
            source_allocation: generator.states()[removed.source].clone(),
            from: removed.from,
            to: removed.to,
        })
        .expect("single-channel ablation");
    let ablated_report = ablated.verify().expect("ablation report");
    assert_eq!(ablated.channels().len() + 1, generator.channels().len());
    assert!(!ablated_report.reverse_support);
    assert!(!ablated_report.reference_stationary);
    assert!(!ablated_report.reference_detailed_balance);
    assert!(!ablated_report.all_positive_gates_passed());
}

#[test]
fn symmetric_primary_derives_multinomial_rates_fluxes_and_labeled_degeneracy() {
    let spec = ZeroRangeSpec::new(
        2,
        integer_rate_matrix(&[&[0, 1], &[1, 0]]).expect("two-site rates"),
        linear_departure(2),
        vec![BigUint::one(), BigUint::one()],
    )
    .expect("primary spec");
    let generator = ZeroRangeGenerator::from_spec(spec).expect("primary generator");
    let report = generator.verify().expect("primary report");

    preregistered_gates(&generator);
    assert!(report.all_positive_gates_passed());
    assert_eq!(report.state_count, 3);
    assert_eq!(report.channel_count, 4);
    assert_eq!(generator.states(), &[vec![2, 0], vec![1, 1], vec![0, 2]]);
    assert_eq!(generator.normalizer(), &ratio(2, 1));
    reference(&generator, &[(1, 4), (1, 2), (1, 4)]);

    assert_eq!(generator.channel_rate(&[2, 0], 0, 1).unwrap(), ratio(2, 1));
    assert_eq!(generator.channel_rate(&[1, 1], 1, 0).unwrap(), ratio(1, 1));
    assert_eq!(generator.channel_rate(&[1, 1], 0, 1).unwrap(), ratio(1, 1));
    assert_eq!(generator.channel_rate(&[0, 2], 1, 0).unwrap(), ratio(2, 1));
    assert_eq!(
        generator.stationary_flux(&[2, 0], 0, 1).unwrap(),
        ratio(1, 2)
    );
    assert_eq!(
        generator.stationary_flux(&[1, 1], 1, 0).unwrap(),
        ratio(1, 2)
    );
    assert_eq!(
        generator.stationary_flux(&[1, 1], 0, 1).unwrap(),
        ratio(1, 2)
    );
    assert_eq!(
        generator.stationary_flux(&[0, 2], 1, 0).unwrap(),
        ratio(1, 2)
    );

    let labeled = enumerate_labeled_projection_counts(2, 2).expect("labeled placements");
    assert_eq!(
        labeled,
        BTreeMap::from([
            (vec![0, 2], bu(1)),
            (vec![1, 1], bu(2)),
            (vec![2, 0], bu(1)),
        ])
    );
}

#[test]
fn departure_ablation_changes_the_law_without_changing_support() {
    let rates = integer_rate_matrix(&[&[0, 1], &[1, 0]]).expect("two-site rates");
    let linear = ZeroRangeGenerator::from_spec(
        ZeroRangeSpec::new(2, rates.clone(), linear_departure(2), vec![bu(1), bu(1)]).unwrap(),
    )
    .unwrap();
    let one_clock = ZeroRangeGenerator::from_spec(
        ZeroRangeSpec::new(2, rates, occupied_site_departure(2), vec![bu(1), bu(1)]).unwrap(),
    )
    .unwrap();

    preregistered_gates(&linear);
    preregistered_gates(&one_clock);
    assert_eq!(linear.states(), one_clock.states());
    assert_eq!(linear.channels().len(), one_clock.channels().len());
    reference(&one_clock, &[(1, 3), (1, 3), (1, 3)]);
    assert_ne!(linear.reference(), one_clock.reference());
    assert_eq!(one_clock.channel_rate(&[2, 0], 0, 1).unwrap(), ratio(1, 1));
}

#[test]
fn asymmetric_held_out_fixture_recovers_generator_normalizer_and_fluxes() {
    let generator = ZeroRangeGenerator::from_spec(
        ZeroRangeSpec::new(
            2,
            integer_rate_matrix(&[&[0, 2], &[1, 0]]).unwrap(),
            linear_departure(2),
            vec![bu(1), bu(2)],
        )
        .unwrap(),
    )
    .unwrap();

    preregistered_gates(&generator);
    assert_eq!(generator.normalizer(), &ratio(9, 2));
    assert_eq!(
        generator.raw_reference_weights(),
        &[ratio(1, 2), ratio(2, 1), ratio(2, 1)]
    );
    reference(&generator, &[(1, 9), (4, 9), (4, 9)]);
    assert_eq!(
        generator.signed_generator(),
        &[
            vec![
                ExactSignedRatio::from_integer(-4),
                ExactSignedRatio::from_integer(4),
                ExactSignedRatio::from_integer(0),
            ],
            vec![
                ExactSignedRatio::from_integer(1),
                ExactSignedRatio::from_integer(-3),
                ExactSignedRatio::from_integer(2),
            ],
            vec![
                ExactSignedRatio::from_integer(0),
                ExactSignedRatio::from_integer(2),
                ExactSignedRatio::from_integer(-2),
            ],
        ]
    );
    assert_eq!(
        generator.stationary_flux(&[2, 0], 0, 1).unwrap(),
        ratio(4, 9)
    );
    assert_eq!(
        generator.stationary_flux(&[1, 1], 0, 1).unwrap(),
        ratio(8, 9)
    );
}

#[test]
fn edge_and_normalized_node_clocks_have_distinct_path_laws_and_quench_behavior() {
    let path = adjacency(&[&[0, 1, 0], &[1, 0, 1], &[0, 1, 0]]);
    let triangle = adjacency(&[&[0, 1, 1], &[1, 0, 1], &[1, 1, 0]]);
    let edge_path = ZeroRangeGenerator::from_spec(
        edge_clock_spec(2, path.clone(), linear_departure(2)).unwrap(),
    )
    .unwrap();
    let node_path = ZeroRangeGenerator::from_spec(
        normalized_node_clock_spec(2, path.clone(), linear_departure(2)).unwrap(),
    )
    .unwrap();
    let edge_triangle = ZeroRangeGenerator::from_spec(
        edge_clock_spec(2, triangle.clone(), linear_departure(2)).unwrap(),
    )
    .unwrap();
    let node_triangle = ZeroRangeGenerator::from_spec(
        normalized_node_clock_spec(2, triangle, linear_departure(2)).unwrap(),
    )
    .unwrap();

    preregistered_gates(&edge_path);
    preregistered_gates(&node_path);
    preregistered_gates(&edge_triangle);
    preregistered_gates(&node_triangle);
    reference(
        &edge_path,
        &[(1, 9), (2, 9), (2, 9), (1, 9), (2, 9), (1, 9)],
    );
    reference(
        &node_path,
        &[(1, 16), (1, 4), (1, 8), (1, 4), (1, 4), (1, 16)],
    );
    assert_eq!(edge_triangle.reference(), edge_path.reference());
    assert_eq!(node_triangle.reference(), edge_path.reference());

    let edge_contact = compare_retained_zero_range_rates(&edge_path, &edge_triangle).unwrap();
    assert!(edge_contact.all_retained_rates_unchanged());
    assert_eq!(edge_contact.retained_channel_count, 12);

    let node_contact = compare_retained_zero_range_rates(&node_path, &node_triangle).unwrap();
    assert_eq!(node_contact.retained_channel_count, 12);
    assert_eq!(node_contact.unchanged_channel_count, 6);
    assert_eq!(node_contact.changed_channel_count, 6);
    assert_eq!(
        node_path.channel_rate(&[2, 0, 0], 0, 1).unwrap(),
        ratio(2, 1)
    );
    assert_eq!(
        node_triangle.channel_rate(&[2, 0, 0], 0, 1).unwrap(),
        ratio(1, 1)
    );
}

#[test]
fn continuous_time_and_event_index_sampling_are_kept_distinct() {
    let path = adjacency(&[&[0, 1, 0], &[1, 0, 1], &[0, 1, 0]]);
    let triangle = adjacency(&[&[0, 1, 1], &[1, 0, 1], &[1, 1, 0]]);
    let path =
        ZeroRangeGenerator::from_spec(edge_clock_spec(1, path, linear_departure(1)).unwrap())
            .unwrap();
    let triangle =
        ZeroRangeGenerator::from_spec(edge_clock_spec(1, triangle, linear_departure(1)).unwrap())
            .unwrap();

    preregistered_gates(&path);
    preregistered_gates(&triangle);
    reference(&path, &[(1, 3), (1, 3), (1, 3)]);
    reference(&triangle, &[(1, 3), (1, 3), (1, 3)]);
    reference_activity(&path, &[(1, 4), (1, 2), (1, 4)]);
    assert_eq!(
        path.embedded_jump_kernel().unwrap(),
        vec![
            vec![ratio(0, 1), ratio(1, 1), ratio(0, 1)],
            vec![ratio(1, 2), ratio(0, 1), ratio(1, 2)],
            vec![ratio(0, 1), ratio(1, 1), ratio(0, 1)],
        ]
    );
    assert_eq!(
        path.signed_generator()[0][0],
        ExactSignedRatio::from_integer(-1)
    );
    assert_eq!(
        triangle.signed_generator()[0][0],
        ExactSignedRatio::from_integer(-2)
    );
    assert_eq!(path.channel_rate(&[1, 0, 0], 0, 1).unwrap(), ratio(1, 1));
    assert_eq!(
        triangle.channel_rate(&[1, 0, 0], 0, 1).unwrap(),
        ratio(1, 1)
    );
    assert_ne!(
        path.embedded_jump_kernel().unwrap(),
        triangle.embedded_jump_kernel().unwrap()
    );
}

fn reference_activity(generator: &ZeroRangeGenerator, expected: &[(u64, u64)]) {
    let activity = generator.activity_biased_reference().expect("activity law");
    assert_eq!(activity.len(), expected.len());
    for (actual, &(numerator, denominator)) in activity.iter().zip(expected.iter()) {
        assert_eq!(actual, &ratio(numerator, denominator));
    }
}

#[test]
fn generic_nonlinear_law_prevents_factorial_or_fixture_hard_coding() {
    let generator = ZeroRangeGenerator::from_spec(
        ZeroRangeSpec::new(
            3,
            integer_rate_matrix(&[&[0, 2, 3], &[1, 0, 3], &[1, 2, 0]]).unwrap(),
            vec![bu(0), bu(2), bu(5), bu(7)],
            vec![bu(1), bu(2), bu(3)],
        )
        .unwrap(),
    )
    .unwrap();
    let report = generator.verify().unwrap();

    preregistered_gates(&generator);
    assert!(report.all_positive_gates_passed());
    assert_eq!(report.state_count, 10);
    assert_eq!(report.channel_count, 36);
    assert_eq!(generator.normalizer(), &ratio(513, 140));
    for (allocation, numerator) in [
        ([3, 0, 0], 2),
        ([2, 1, 0], 14),
        ([2, 0, 1], 21),
        ([1, 2, 0], 28),
        ([1, 1, 1], 105),
        ([1, 0, 2], 63),
        ([0, 3, 0], 16),
        ([0, 2, 1], 84),
        ([0, 1, 2], 126),
        ([0, 0, 3], 54),
    ] {
        probability(&generator, &allocation, numerator, 513);
    }
    assert_eq!(
        generator.channel_rate(&[2, 1, 0], 0, 1).unwrap(),
        ratio(10, 1)
    );
    assert_eq!(
        generator.channel_rate(&[1, 2, 0], 1, 0).unwrap(),
        ratio(5, 1)
    );
    assert_eq!(
        generator.stationary_flux(&[2, 1, 0], 0, 1).unwrap(),
        ratio(140, 513)
    );
    assert_eq!(
        generator.stationary_flux(&[1, 2, 0], 1, 0).unwrap(),
        ratio(140, 513)
    );
}

#[test]
fn larger_held_out_case_is_covariant_under_a_noninvolutive_permutation() {
    let generator = ZeroRangeGenerator::from_spec(
        ZeroRangeSpec::new(
            3,
            integer_rate_matrix(&[&[0, 2, 3, 4], &[1, 0, 3, 4], &[1, 2, 0, 4], &[1, 2, 3, 0]])
                .unwrap(),
            linear_departure(3),
            vec![bu(1), bu(2), bu(3), bu(4)],
        )
        .unwrap(),
    )
    .unwrap();

    let report = generator.verify().unwrap();
    preregistered_gates(&generator);
    assert!(report.all_positive_gates_passed());
    assert_eq!(report.state_count, 20);
    assert_eq!(report.channel_count, 120);
    assert_eq!(generator.normalizer(), &ratio(500, 3));
    assert_eq!(
        generator.reference()[generator.state_index(&[2, 1, 0, 0]).unwrap()],
        ratio(3, 500)
    );
    assert_eq!(
        generator.reference()[generator.state_index(&[1, 1, 0, 1]).unwrap()],
        ratio(6, 125)
    );
    assert_eq!(
        generator.channel_rate(&[2, 1, 0, 0], 0, 3).unwrap(),
        ratio(8, 1)
    );
    assert_eq!(
        generator.channel_rate(&[1, 1, 0, 1], 3, 0).unwrap(),
        ratio(1, 1)
    );
    assert_eq!(
        generator.stationary_flux(&[2, 1, 0, 0], 0, 3).unwrap(),
        ratio(6, 125)
    );

    let permutation = [2, 0, 3, 1];
    assert!(generator
        .permutation_covariance(&permutation)
        .unwrap()
        .all_passed());
    let permuted =
        ZeroRangeGenerator::from_spec(generator.spec().permuted(&permutation).unwrap()).unwrap();
    assert_eq!(
        permuted.channel_rate(&[1, 0, 2, 0], 2, 1).unwrap(),
        ratio(8, 1)
    );
}

#[test]
fn weighted_normalized_clock_divides_by_source_strength() {
    let graph = adjacency(&[&[0, 2, 0], &[2, 0, 3], &[0, 3, 0]]);
    let generator = ZeroRangeGenerator::from_spec(
        normalized_node_clock_spec(2, graph, linear_departure(2)).unwrap(),
    )
    .unwrap();

    preregistered_gates(&generator);
    reference(
        &generator,
        &[(1, 25), (1, 5), (3, 25), (1, 4), (3, 10), (9, 100)],
    );
    assert_eq!(
        generator.channel_rate(&[0, 2, 0], 1, 0).unwrap(),
        ratio(4, 5)
    );
    assert_eq!(
        generator.channel_rate(&[0, 2, 0], 1, 2).unwrap(),
        ratio(6, 5)
    );
    assert_eq!(
        generator.stationary_flux(&[0, 2, 0], 1, 0).unwrap(),
        ratio(1, 5)
    );
    assert_eq!(
        generator.stationary_flux(&[0, 2, 0], 1, 2).unwrap(),
        ratio(3, 10)
    );
}

#[test]
fn missing_direct_reverse_fails_reciprocity_even_when_the_chain_is_strongly_connected() {
    let generator = ZeroRangeGenerator::from_spec(
        ZeroRangeSpec::new(
            1,
            integer_rate_matrix(&[&[0, 1, 1], &[0, 0, 1], &[1, 1, 0]]).unwrap(),
            linear_departure(1),
            vec![bu(1), bu(1), bu(1)],
        )
        .unwrap(),
    )
    .unwrap();
    let report = generator.verify().unwrap();

    assert!(report.strongly_connected);
    assert!(report.stationary_law_unique);
    assert!(!report.reverse_support);
    assert_eq!(report.missing_reverse_channels.len(), 1);
    assert!(!report.reversible_weight_condition);
    assert!(!report.reference_stationary);
    assert!(!report.reference_detailed_balance);
    assert!(!report.all_positive_gates_passed());
    assert_eq!(
        generator.signed_generator(),
        &[
            vec![
                ExactSignedRatio::from_integer(-2),
                ExactSignedRatio::from_integer(1),
                ExactSignedRatio::from_integer(1),
            ],
            vec![
                ExactSignedRatio::from_integer(0),
                ExactSignedRatio::from_integer(-1),
                ExactSignedRatio::from_integer(1),
            ],
            vec![
                ExactSignedRatio::from_integer(1),
                ExactSignedRatio::from_integer(1),
                ExactSignedRatio::from_integer(-2),
            ],
        ]
    );
}

#[test]
fn disconnected_reciprocal_support_has_stationary_product_mixture_but_no_unique_law() {
    let generator = ZeroRangeGenerator::from_spec(
        ZeroRangeSpec::new(
            2,
            integer_rate_matrix(&[&[0, 1, 0, 0], &[1, 0, 0, 0], &[0, 0, 0, 1], &[0, 0, 1, 0]])
                .unwrap(),
            linear_departure(2),
            vec![bu(1), bu(1), bu(1), bu(1)],
        )
        .unwrap(),
    )
    .unwrap();
    let report = generator.verify().unwrap();

    assert_eq!(report.state_count, 10);
    assert_eq!(report.channel_count, 16);
    assert!(report.reverse_support);
    assert!(report.reversible_weight_condition);
    assert!(report.reference_stationary);
    assert!(report.reference_detailed_balance);
    assert!(!report.strongly_connected);
    assert!(!report.stationary_law_unique);
    assert_eq!(report.communicating_classes.len(), 3);
    let mut class_sizes = report
        .communicating_classes
        .iter()
        .map(|class| class.states.len())
        .collect::<Vec<_>>();
    class_sizes.sort_unstable();
    assert_eq!(class_sizes, [3, 3, 4]);
    assert!(report
        .communicating_classes
        .iter()
        .all(|class| class.closed));

    let class_mass = |left_inventory: u32| {
        sum(generator
            .states()
            .iter()
            .enumerate()
            .filter(|(_, state)| state[0] + state[1] == left_inventory)
            .map(|(index, _)| generator.reference()[index].clone()))
    };
    assert_eq!(class_mass(0), ratio(1, 4));
    assert_eq!(class_mass(1), ratio(1, 2));
    assert_eq!(class_mass(2), ratio(1, 4));
}

#[test]
fn invalid_boundaries_are_rejected_without_repairing_the_input() {
    assert!(ZeroRangeSpec::new(
        0,
        integer_rate_matrix(&[&[0, 1], &[1, 0]]).unwrap(),
        vec![BigUint::zero()],
        vec![bu(1), bu(1)],
    )
    .is_err());
    assert!(ZeroRangeSpec::new(
        2,
        integer_rate_matrix(&[&[0, 1], &[1, 0]]).unwrap(),
        vec![bu(0), bu(1), bu(0)],
        vec![bu(1), bu(1)],
    )
    .is_err());
    assert!(edge_clock_spec(
        2,
        adjacency(&[&[0, 1, 0, 0], &[1, 0, 0, 0], &[0, 0, 0, 1], &[0, 0, 1, 0],]),
        linear_departure(2),
    )
    .is_err());
    assert!(normalized_node_clock_spec(1, adjacency(&[&[0]]), linear_departure(1),).is_err());

    let generator = ZeroRangeGenerator::from_spec(
        ZeroRangeSpec::new(
            1,
            integer_rate_matrix(&[&[0, 1], &[1, 0]]).unwrap(),
            linear_departure(1),
            vec![bu(1), bu(1)],
        )
        .unwrap(),
    )
    .unwrap();
    assert!(generator.permutation_covariance(&[0, 0]).is_err());
    assert!(generator.permutation_covariance(&[0]).is_err());
}

#[test]
fn signed_exact_ratio_reduces_fractional_generator_entries() {
    let value = ExactSignedRatio::new(BigInt::from(-6), bu(8)).unwrap();
    assert_eq!(value.numerator(), &BigInt::from(-3));
    assert_eq!(value.denominator(), &bu(4));
}
