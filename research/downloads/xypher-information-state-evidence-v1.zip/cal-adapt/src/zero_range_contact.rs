use crate::{AnalysisError, ExactRatio, Result};
use num_bigint::{BigInt, BigUint};
use num_integer::Integer;
use num_traits::{One, Zero};
use std::collections::{BTreeMap, VecDeque};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactSignedRatio {
    numerator: BigInt,
    denominator: BigUint,
}

impl ExactSignedRatio {
    pub fn new(numerator: BigInt, denominator: BigUint) -> Result<Self> {
        if denominator.is_zero() {
            return Err(AnalysisError::new(
                "signed exact ratio has a zero denominator",
            ));
        }
        if numerator.is_zero() {
            return Ok(Self::zero());
        }
        let divisor = numerator.magnitude().gcd(&denominator);
        Ok(Self {
            numerator: numerator / BigInt::from(divisor.clone()),
            denominator: denominator / divisor,
        })
    }

    pub fn zero() -> Self {
        Self {
            numerator: BigInt::zero(),
            denominator: BigUint::one(),
        }
    }

    pub fn from_integer(value: i64) -> Self {
        Self {
            numerator: BigInt::from(value),
            denominator: BigUint::one(),
        }
    }

    pub fn from_unsigned(value: &ExactRatio) -> Self {
        Self {
            numerator: BigInt::from(value.numerator().clone()),
            denominator: value.denominator().clone(),
        }
    }

    pub fn numerator(&self) -> &BigInt {
        &self.numerator
    }

    pub fn denominator(&self) -> &BigUint {
        &self.denominator
    }

    pub fn is_zero(&self) -> bool {
        self.numerator.is_zero()
    }

    pub fn negated(&self) -> Self {
        Self {
            numerator: -self.numerator.clone(),
            denominator: self.denominator.clone(),
        }
    }

    pub fn checked_add(&self, other: &Self) -> Result<Self> {
        Self::new(
            &self.numerator * BigInt::from(other.denominator.clone())
                + &other.numerator * BigInt::from(self.denominator.clone()),
            &self.denominator * &other.denominator,
        )
    }

    pub fn checked_multiply_unsigned(&self, other: &ExactRatio) -> Result<Self> {
        Self::new(
            &self.numerator * BigInt::from(other.numerator().clone()),
            &self.denominator * other.denominator(),
        )
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ZeroRangeSpec {
    inventory: u32,
    kappa: Vec<Vec<ExactRatio>>,
    departure: Vec<BigUint>,
    reversible_weights: Vec<BigUint>,
}

impl ZeroRangeSpec {
    pub fn new(
        inventory: u32,
        kappa: Vec<Vec<ExactRatio>>,
        departure: Vec<BigUint>,
        reversible_weights: Vec<BigUint>,
    ) -> Result<Self> {
        if inventory == 0 {
            return Err(AnalysisError::new("zero-range inventory must be positive"));
        }
        let node_count = reversible_weights.len();
        if node_count == 0 {
            return Err(AnalysisError::new("zero-range graph has no nodes"));
        }
        if reversible_weights.iter().any(BigUint::is_zero) {
            return Err(AnalysisError::new(
                "zero-range reversible weights must be positive",
            ));
        }
        if kappa.len() != node_count || kappa.iter().any(|row| row.len() != node_count) {
            return Err(AnalysisError::new(
                "zero-range rate matrix has the wrong dimensions",
            ));
        }
        if kappa
            .iter()
            .enumerate()
            .any(|(index, row)| !row[index].numerator().is_zero())
        {
            return Err(AnalysisError::new(
                "zero-range rate matrix must have a zero diagonal",
            ));
        }
        if departure.len() != inventory as usize + 1 {
            return Err(AnalysisError::new(
                "zero-range departure law must cover occupancies zero through K",
            ));
        }
        if !departure[0].is_zero() || departure.iter().skip(1).any(BigUint::is_zero) {
            return Err(AnalysisError::new(
                "zero-range departure law requires u(0)=0 and u(n)>0 for n>0",
            ));
        }
        Ok(Self {
            inventory,
            kappa,
            departure,
            reversible_weights,
        })
    }

    pub fn inventory(&self) -> u32 {
        self.inventory
    }

    pub fn node_count(&self) -> usize {
        self.reversible_weights.len()
    }

    pub fn kappa(&self) -> &[Vec<ExactRatio>] {
        &self.kappa
    }

    pub fn departure(&self) -> &[BigUint] {
        &self.departure
    }

    pub fn reversible_weights(&self) -> &[BigUint] {
        &self.reversible_weights
    }

    pub fn permuted(&self, old_to_new: &[usize]) -> Result<Self> {
        validate_permutation(self.node_count(), old_to_new)?;
        let mut weights = vec![BigUint::zero(); self.node_count()];
        let mut kappa = zero_ratio_matrix(self.node_count());
        for old in 0..self.node_count() {
            weights[old_to_new[old]] = self.reversible_weights[old].clone();
            for other in 0..self.node_count() {
                kappa[old_to_new[old]][old_to_new[other]] = self.kappa[old][other].clone();
            }
        }
        Self::new(self.inventory, kappa, self.departure.clone(), weights)
    }
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct ZeroRangeChannelLabel {
    pub source_allocation: Vec<u32>,
    pub from: usize,
    pub to: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ZeroRangeChannel {
    pub source: usize,
    pub target: usize,
    pub from: usize,
    pub to: usize,
    pub rate: ExactRatio,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ZeroRangeCommunicatingClass {
    pub states: Vec<usize>,
    pub closed: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ZeroRangeReport {
    pub state_count: usize,
    pub expected_state_count: BigUint,
    pub channel_count: usize,
    pub state_count_matches: bool,
    pub inventory_conservation: bool,
    pub generator_row_conservation: bool,
    pub reversible_weight_condition: bool,
    pub reverse_support: bool,
    pub missing_reverse_channels: Vec<ZeroRangeChannelLabel>,
    pub reference_positive: bool,
    pub reference_normalized: bool,
    pub reference_stationary: bool,
    pub reference_detailed_balance: bool,
    pub strongly_connected: bool,
    pub stationary_law_unique: bool,
    pub communicating_classes: Vec<ZeroRangeCommunicatingClass>,
}

impl ZeroRangeReport {
    pub fn all_positive_gates_passed(&self) -> bool {
        self.state_count_matches
            && self.inventory_conservation
            && self.generator_row_conservation
            && self.reversible_weight_condition
            && self.reverse_support
            && self.reference_positive
            && self.reference_normalized
            && self.reference_stationary
            && self.reference_detailed_balance
            && self.strongly_connected
            && self.stationary_law_unique
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ZeroRangePermutationReport {
    pub state_covariance: bool,
    pub channel_covariance: bool,
    pub rate_covariance: bool,
    pub reference_covariance: bool,
    pub generator_covariance: bool,
}

impl ZeroRangePermutationReport {
    pub fn all_passed(&self) -> bool {
        self.state_covariance
            && self.channel_covariance
            && self.rate_covariance
            && self.reference_covariance
            && self.generator_covariance
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RetainedZeroRangeRate {
    pub label: ZeroRangeChannelLabel,
    pub before: ExactRatio,
    pub after: ExactRatio,
    pub unchanged: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RetainedZeroRangeRateReport {
    pub retained_channel_count: usize,
    pub unchanged_channel_count: usize,
    pub changed_channel_count: usize,
    pub channels: Vec<RetainedZeroRangeRate>,
}

impl RetainedZeroRangeRateReport {
    pub fn all_retained_rates_unchanged(&self) -> bool {
        self.changed_channel_count == 0
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ZeroRangeGenerator {
    spec: ZeroRangeSpec,
    states: Vec<Vec<u32>>,
    state_index: BTreeMap<Vec<u32>, usize>,
    channels: Vec<ZeroRangeChannel>,
    raw_reference_weights: Vec<ExactRatio>,
    normalizer: ExactRatio,
    reference: Vec<ExactRatio>,
    signed_generator: Vec<Vec<ExactSignedRatio>>,
}

impl ZeroRangeGenerator {
    pub fn from_spec(spec: ZeroRangeSpec) -> Result<Self> {
        let mut states = Vec::new();
        enumerate_weak_compositions_descending(
            spec.inventory,
            spec.node_count(),
            &mut Vec::new(),
            &mut states,
        );
        let state_index = states
            .iter()
            .cloned()
            .enumerate()
            .map(|(index, state)| (state, index))
            .collect::<BTreeMap<_, _>>();

        let mut channels = Vec::new();
        for (source, state) in states.iter().enumerate() {
            for from in 0..spec.node_count() {
                let occupancy = state[from];
                if occupancy == 0 {
                    continue;
                }
                for to in 0..spec.node_count() {
                    if from == to || spec.kappa[from][to].numerator().is_zero() {
                        continue;
                    }
                    let mut successor = state.clone();
                    successor[from] -= 1;
                    successor[to] += 1;
                    let target = *state_index.get(&successor).ok_or_else(|| {
                        AnalysisError::new("generated zero-range successor is outside the shell")
                    })?;
                    let rate = multiply_ratio_by_integer(
                        &spec.kappa[from][to],
                        &spec.departure[occupancy as usize],
                    )?;
                    channels.push(ZeroRangeChannel {
                        source,
                        target,
                        from,
                        to,
                        rate,
                    });
                }
            }
        }

        let raw_reference_weights = states
            .iter()
            .map(|state| raw_reference_weight(&spec, state))
            .collect::<Result<Vec<_>>>()?;
        let normalizer = sum_ratios(&raw_reference_weights)?;
        let reference = raw_reference_weights
            .iter()
            .map(|weight| divide_ratios(weight, &normalizer))
            .collect::<Result<Vec<_>>>()?;

        let signed_generator = signed_generator_from_channels(states.len(), &channels)?;

        Ok(Self {
            spec,
            states,
            state_index,
            channels,
            raw_reference_weights,
            normalizer,
            reference,
            signed_generator,
        })
    }

    pub fn spec(&self) -> &ZeroRangeSpec {
        &self.spec
    }

    pub fn states(&self) -> &[Vec<u32>] {
        &self.states
    }

    pub fn channels(&self) -> &[ZeroRangeChannel] {
        &self.channels
    }

    pub fn raw_reference_weights(&self) -> &[ExactRatio] {
        &self.raw_reference_weights
    }

    pub fn normalizer(&self) -> &ExactRatio {
        &self.normalizer
    }

    pub fn reference(&self) -> &[ExactRatio] {
        &self.reference
    }

    pub fn signed_generator(&self) -> &[Vec<ExactSignedRatio>] {
        &self.signed_generator
    }

    pub fn state_index(&self, allocation: &[u32]) -> Option<usize> {
        self.state_index.get(allocation).copied()
    }

    pub fn with_channel_removed(&self, label: &ZeroRangeChannelLabel) -> Result<Self> {
        let source = self
            .state_index(&label.source_allocation)
            .ok_or_else(|| AnalysisError::new("zero-range channel source is outside the shell"))?;
        let position = self
            .channels
            .iter()
            .position(|channel| {
                channel.source == source && channel.from == label.from && channel.to == label.to
            })
            .ok_or_else(|| AnalysisError::new("zero-range channel does not exist"))?;
        let mut ablated = self.clone();
        ablated.channels.remove(position);
        ablated.signed_generator =
            signed_generator_from_channels(ablated.states.len(), &ablated.channels)?;
        Ok(ablated)
    }

    pub fn channel_rate(&self, allocation: &[u32], from: usize, to: usize) -> Result<ExactRatio> {
        if from >= self.spec.node_count() || to >= self.spec.node_count() || from == to {
            return Err(AnalysisError::new(
                "zero-range channel label is outside the graph",
            ));
        }
        let source = self
            .state_index(allocation)
            .ok_or_else(|| AnalysisError::new("zero-range allocation is outside the shell"))?;
        Ok(self
            .channels
            .iter()
            .find(|channel| channel.source == source && channel.from == from && channel.to == to)
            .map_or_else(ExactRatio::zero, |channel| channel.rate.clone()))
    }

    pub fn stationary_flux(
        &self,
        allocation: &[u32],
        from: usize,
        to: usize,
    ) -> Result<ExactRatio> {
        let source = self
            .state_index(allocation)
            .ok_or_else(|| AnalysisError::new("zero-range allocation is outside the shell"))?;
        self.reference[source].checked_multiply(&self.channel_rate(allocation, from, to)?)
    }

    pub fn exit_rate(&self, state: usize) -> Result<ExactRatio> {
        if state >= self.states.len() {
            return Err(AnalysisError::new("zero-range state index is out of range"));
        }
        sum_ratios(
            &self
                .channels
                .iter()
                .filter(|channel| channel.source == state)
                .map(|channel| channel.rate.clone())
                .collect::<Vec<_>>(),
        )
    }

    pub fn embedded_jump_kernel(&self) -> Result<Vec<Vec<ExactRatio>>> {
        let mut kernel = zero_ratio_matrix(self.states.len());
        for (source, row) in kernel.iter_mut().enumerate() {
            let exit_rate = self.exit_rate(source)?;
            if exit_rate.numerator().is_zero() {
                row[source] = ExactRatio::one();
                continue;
            }
            for channel in self
                .channels
                .iter()
                .filter(|channel| channel.source == source)
            {
                let probability = divide_ratios(&channel.rate, &exit_rate)?;
                row[channel.target] = row[channel.target].checked_add(&probability)?;
            }
        }
        Ok(kernel)
    }

    pub fn activity_biased_reference(&self) -> Result<Vec<ExactRatio>> {
        let activity_weights = (0..self.states.len())
            .map(|state| self.reference[state].checked_multiply(&self.exit_rate(state)?))
            .collect::<Result<Vec<_>>>()?;
        let normalizer = sum_ratios(&activity_weights)?;
        if normalizer.numerator().is_zero() {
            return Err(AnalysisError::new(
                "zero-range generator has no positive jump activity",
            ));
        }
        activity_weights
            .iter()
            .map(|weight| divide_ratios(weight, &normalizer))
            .collect()
    }

    pub fn verify(&self) -> Result<ZeroRangeReport> {
        let expected_state_count = binomial_biguint(
            self.spec.inventory as usize + self.spec.node_count() - 1,
            self.spec.node_count() - 1,
        );
        let state_count_matches = expected_state_count == BigUint::from(self.states.len());
        let inventory_conservation = self.channels.iter().all(|channel| {
            let source = &self.states[channel.source];
            let target = &self.states[channel.target];
            source.iter().copied().sum::<u32>() == self.spec.inventory
                && target.iter().copied().sum::<u32>() == self.spec.inventory
                && source[channel.from] == target[channel.from] + 1
                && source[channel.to] + 1 == target[channel.to]
                && (0..self.spec.node_count())
                    .filter(|&node| node != channel.from && node != channel.to)
                    .all(|node| source[node] == target[node])
        });
        let generator_row_conservation = self.signed_generator.iter().all(|row| {
            row.iter()
                .try_fold(ExactSignedRatio::zero(), |sum, value| {
                    sum.checked_add(value)
                })
                .is_ok_and(|sum| sum.is_zero())
        });
        let reversible_weight_condition = (0..self.spec.node_count()).all(|from| {
            (0..self.spec.node_count()).all(|to| {
                multiply_ratio_by_integer(
                    &self.spec.kappa[from][to],
                    &self.spec.reversible_weights[from],
                )
                .is_ok_and(|forward| {
                    multiply_ratio_by_integer(
                        &self.spec.kappa[to][from],
                        &self.spec.reversible_weights[to],
                    )
                    .is_ok_and(|reverse| forward == reverse)
                })
            })
        });

        let channel_lookup = self
            .channels
            .iter()
            .map(|channel| {
                (
                    (channel.source, channel.target, channel.from, channel.to),
                    channel,
                )
            })
            .collect::<BTreeMap<_, _>>();
        let mut missing_reverse_channels = Vec::new();
        let mut reference_detailed_balance = true;
        for channel in &self.channels {
            let reverse =
                channel_lookup.get(&(channel.target, channel.source, channel.to, channel.from));
            let Some(reverse) = reverse else {
                missing_reverse_channels.push(ZeroRangeChannelLabel {
                    source_allocation: self.states[channel.source].clone(),
                    from: channel.from,
                    to: channel.to,
                });
                reference_detailed_balance = false;
                continue;
            };
            let forward_flux = self.reference[channel.source].checked_multiply(&channel.rate)?;
            let reverse_flux = self.reference[reverse.source].checked_multiply(&reverse.rate)?;
            reference_detailed_balance &= forward_flux == reverse_flux;
        }
        missing_reverse_channels.sort();
        let reverse_support = missing_reverse_channels.is_empty();

        let reference_positive = self
            .reference
            .iter()
            .all(|weight| !weight.numerator().is_zero());
        let reference_normalized = sum_ratios(&self.reference)? == ExactRatio::one();
        let reference_stationary = (0..self.states.len()).all(|target| {
            (0..self.states.len())
                .try_fold(ExactSignedRatio::zero(), |sum, source| {
                    sum.checked_add(
                        &self.signed_generator[source][target]
                            .checked_multiply_unsigned(&self.reference[source])?,
                    )
                })
                .is_ok_and(|sum| sum.is_zero())
        });

        let (communicating_classes, strongly_connected) = communicating_classes(self);
        let stationary_law_unique = communicating_classes
            .iter()
            .filter(|class| class.closed)
            .count()
            == 1;

        Ok(ZeroRangeReport {
            state_count: self.states.len(),
            expected_state_count,
            channel_count: self.channels.len(),
            state_count_matches,
            inventory_conservation,
            generator_row_conservation,
            reversible_weight_condition,
            reverse_support,
            missing_reverse_channels,
            reference_positive,
            reference_normalized,
            reference_stationary,
            reference_detailed_balance,
            strongly_connected,
            stationary_law_unique,
            communicating_classes,
        })
    }

    pub fn permutation_covariance(
        &self,
        old_to_new: &[usize],
    ) -> Result<ZeroRangePermutationReport> {
        validate_permutation(self.spec.node_count(), old_to_new)?;
        let permuted = Self::from_spec(self.spec.permuted(old_to_new)?)?;
        let mut state_mapping = vec![0usize; self.states.len()];
        let mut state_covariance = true;
        let mut reference_covariance = true;
        for (old_index, state) in self.states.iter().enumerate() {
            let mapped_state = permute_allocation(state, old_to_new);
            let Some(new_index) = permuted.state_index(&mapped_state) else {
                state_covariance = false;
                continue;
            };
            state_mapping[old_index] = new_index;
            reference_covariance &= self.reference[old_index] == permuted.reference[new_index];
        }

        let mut channel_covariance = true;
        let mut rate_covariance = true;
        for channel in &self.channels {
            let mapped_allocation = permute_allocation(&self.states[channel.source], old_to_new);
            let mapped_from = old_to_new[channel.from];
            let mapped_to = old_to_new[channel.to];
            let mapped_rate = permuted.channel_rate(&mapped_allocation, mapped_from, mapped_to)?;
            channel_covariance &= !mapped_rate.numerator().is_zero();
            rate_covariance &= channel.rate == mapped_rate;
        }

        let generator_covariance = state_covariance
            && (0..self.states.len()).all(|source| {
                (0..self.states.len()).all(|target| {
                    self.signed_generator[source][target]
                        == permuted.signed_generator[state_mapping[source]][state_mapping[target]]
                })
            });

        Ok(ZeroRangePermutationReport {
            state_covariance,
            channel_covariance,
            rate_covariance,
            reference_covariance,
            generator_covariance,
        })
    }
}

pub fn linear_departure(inventory: u32) -> Vec<BigUint> {
    (0..=inventory).map(BigUint::from).collect()
}

pub fn occupied_site_departure(inventory: u32) -> Vec<BigUint> {
    (0..=inventory)
        .map(|occupancy| {
            if occupancy == 0 {
                BigUint::zero()
            } else {
                BigUint::one()
            }
        })
        .collect()
}

pub fn integer_rate_matrix(values: &[&[u64]]) -> Result<Vec<Vec<ExactRatio>>> {
    let node_count = values.len();
    if values.iter().any(|row| row.len() != node_count) {
        return Err(AnalysisError::new("integer rate matrix must be square"));
    }
    values
        .iter()
        .map(|row| {
            row.iter()
                .map(|&value| ExactRatio::new(BigUint::from(value), BigUint::one()))
                .collect()
        })
        .collect()
}

pub fn edge_clock_spec(
    inventory: u32,
    adjacency: Vec<Vec<BigUint>>,
    departure: Vec<BigUint>,
) -> Result<ZeroRangeSpec> {
    let strengths = validate_undirected_adjacency(&adjacency)?;
    let _ = strengths;
    let kappa = adjacency
        .iter()
        .map(|row| {
            row.iter()
                .map(|weight| ExactRatio::new(weight.clone(), BigUint::one()))
                .collect::<Result<Vec<_>>>()
        })
        .collect::<Result<Vec<_>>>()?;
    ZeroRangeSpec::new(
        inventory,
        kappa,
        departure,
        vec![BigUint::one(); adjacency.len()],
    )
}

pub fn normalized_node_clock_spec(
    inventory: u32,
    adjacency: Vec<Vec<BigUint>>,
    departure: Vec<BigUint>,
) -> Result<ZeroRangeSpec> {
    let strengths = validate_undirected_adjacency(&adjacency)?;
    let kappa = adjacency
        .iter()
        .enumerate()
        .map(|(source, row)| {
            row.iter()
                .map(|weight| ExactRatio::new(weight.clone(), strengths[source].clone()))
                .collect::<Result<Vec<_>>>()
        })
        .collect::<Result<Vec<_>>>()?;
    ZeroRangeSpec::new(inventory, kappa, departure, strengths)
}

pub fn compare_retained_zero_range_rates(
    before: &ZeroRangeGenerator,
    after: &ZeroRangeGenerator,
) -> Result<RetainedZeroRangeRateReport> {
    if before.spec.inventory != after.spec.inventory
        || before.spec.node_count() != after.spec.node_count()
        || before.spec.departure != after.spec.departure
        || before.states != after.states
    {
        return Err(AnalysisError::new(
            "retained-rate comparison requires the same occupancy shell and departure law",
        ));
    }
    let mut channels = Vec::new();
    for channel in &before.channels {
        let allocation = before.states[channel.source].clone();
        let after_rate = after.channel_rate(&allocation, channel.from, channel.to)?;
        channels.push(RetainedZeroRangeRate {
            label: ZeroRangeChannelLabel {
                source_allocation: allocation,
                from: channel.from,
                to: channel.to,
            },
            before: channel.rate.clone(),
            unchanged: channel.rate == after_rate,
            after: after_rate,
        });
    }
    let unchanged_channel_count = channels.iter().filter(|channel| channel.unchanged).count();
    let retained_channel_count = channels.len();
    Ok(RetainedZeroRangeRateReport {
        retained_channel_count,
        unchanged_channel_count,
        changed_channel_count: retained_channel_count - unchanged_channel_count,
        channels,
    })
}

pub fn enumerate_labeled_projection_counts(
    node_count: usize,
    inventory: u32,
) -> Result<BTreeMap<Vec<u32>, BigUint>> {
    if node_count == 0 || inventory == 0 {
        return Err(AnalysisError::new(
            "labeled projection requires positive nodes and inventory",
        ));
    }
    let mut counts = BTreeMap::new();
    enumerate_labeled_placements(
        node_count,
        inventory,
        0,
        &mut vec![0u32; node_count],
        &mut counts,
    );
    Ok(counts)
}

fn enumerate_labeled_placements(
    node_count: usize,
    inventory: u32,
    unit: u32,
    occupancy: &mut [u32],
    counts: &mut BTreeMap<Vec<u32>, BigUint>,
) {
    if unit == inventory {
        *counts
            .entry(occupancy.to_vec())
            .or_insert_with(BigUint::zero) += BigUint::one();
        return;
    }
    for node in 0..node_count {
        occupancy[node] += 1;
        enumerate_labeled_placements(node_count, inventory, unit + 1, occupancy, counts);
        occupancy[node] -= 1;
    }
}

fn validate_undirected_adjacency(adjacency: &[Vec<BigUint>]) -> Result<Vec<BigUint>> {
    let node_count = adjacency.len();
    if node_count == 0 || adjacency.iter().any(|row| row.len() != node_count) {
        return Err(AnalysisError::new(
            "undirected adjacency must be a nonempty square matrix",
        ));
    }
    for (from, row) in adjacency.iter().enumerate() {
        if !row[from].is_zero() {
            return Err(AnalysisError::new(
                "undirected adjacency must have a zero diagonal",
            ));
        }
        for (to, reverse_row) in adjacency.iter().enumerate() {
            if row[to] != reverse_row[from] {
                return Err(AnalysisError::new("undirected adjacency must be symmetric"));
            }
        }
    }
    let strengths = adjacency
        .iter()
        .map(|row| row.iter().fold(BigUint::zero(), |sum, value| sum + value))
        .collect::<Vec<_>>();
    if strengths.iter().any(BigUint::is_zero) {
        return Err(AnalysisError::new(
            "undirected adjacency contains an isolated node",
        ));
    }
    let mut reached = vec![false; node_count];
    let mut queue = VecDeque::from([0usize]);
    reached[0] = true;
    while let Some(from) = queue.pop_front() {
        for (to, weight) in adjacency[from].iter().enumerate() {
            if !weight.is_zero() && !reached[to] {
                reached[to] = true;
                queue.push_back(to);
            }
        }
    }
    if reached.iter().any(|value| !value) {
        return Err(AnalysisError::new(
            "undirected adjacency support is disconnected",
        ));
    }
    Ok(strengths)
}

fn raw_reference_weight(spec: &ZeroRangeSpec, state: &[u32]) -> Result<ExactRatio> {
    let mut weight = ExactRatio::one();
    for (node, &occupancy) in state.iter().enumerate() {
        let numerator = spec.reversible_weights[node].pow(occupancy);
        let denominator = (1..=occupancy).fold(BigUint::one(), |product, level| {
            product * &spec.departure[level as usize]
        });
        weight = weight.checked_multiply(&ExactRatio::new(numerator, denominator)?)?;
    }
    Ok(weight)
}

fn multiply_ratio_by_integer(value: &ExactRatio, scale: &BigUint) -> Result<ExactRatio> {
    ExactRatio::new(value.numerator() * scale, value.denominator().clone())
}

fn divide_ratios(numerator: &ExactRatio, denominator: &ExactRatio) -> Result<ExactRatio> {
    if denominator.numerator().is_zero() {
        return Err(AnalysisError::new("cannot divide by an exact zero"));
    }
    ExactRatio::new(
        numerator.numerator() * denominator.denominator(),
        numerator.denominator() * denominator.numerator(),
    )
}

fn sum_ratios(values: &[ExactRatio]) -> Result<ExactRatio> {
    values
        .iter()
        .try_fold(ExactRatio::zero(), |sum, value| sum.checked_add(value))
}

fn zero_ratio_matrix(size: usize) -> Vec<Vec<ExactRatio>> {
    vec![vec![ExactRatio::zero(); size]; size]
}

fn zero_signed_matrix(size: usize) -> Vec<Vec<ExactSignedRatio>> {
    vec![vec![ExactSignedRatio::zero(); size]; size]
}

fn signed_generator_from_channels(
    state_count: usize,
    channels: &[ZeroRangeChannel],
) -> Result<Vec<Vec<ExactSignedRatio>>> {
    let mut signed_generator = zero_signed_matrix(state_count);
    let mut exit_rates = vec![ExactRatio::zero(); state_count];
    for channel in channels {
        signed_generator[channel.source][channel.target] = signed_generator[channel.source]
            [channel.target]
            .checked_add(&ExactSignedRatio::from_unsigned(&channel.rate))?;
        exit_rates[channel.source] = exit_rates[channel.source].checked_add(&channel.rate)?;
    }
    for (state, exit_rate) in exit_rates.iter().enumerate() {
        signed_generator[state][state] = signed_generator[state][state]
            .checked_add(&ExactSignedRatio::from_unsigned(exit_rate).negated())?;
    }
    Ok(signed_generator)
}

fn enumerate_weak_compositions_descending(
    remaining: u32,
    slots: usize,
    prefix: &mut Vec<u32>,
    states: &mut Vec<Vec<u32>>,
) {
    if slots == 1 {
        prefix.push(remaining);
        states.push(prefix.clone());
        prefix.pop();
        return;
    }
    for value in (0..=remaining).rev() {
        prefix.push(value);
        enumerate_weak_compositions_descending(remaining - value, slots - 1, prefix, states);
        prefix.pop();
    }
}

fn communicating_classes(
    generator: &ZeroRangeGenerator,
) -> (Vec<ZeroRangeCommunicatingClass>, bool) {
    let state_count = generator.states.len();
    let mut reachable = vec![vec![false; state_count]; state_count];
    for (start, row) in reachable.iter_mut().enumerate() {
        let mut queue = VecDeque::from([start]);
        row[start] = true;
        while let Some(source) = queue.pop_front() {
            for channel in generator
                .channels
                .iter()
                .filter(|channel| channel.source == source)
            {
                if !row[channel.target] {
                    row[channel.target] = true;
                    queue.push_back(channel.target);
                }
            }
        }
    }

    let strongly_connected = reachable.iter().all(|row| row.iter().all(|value| *value));
    let mut assigned = vec![false; state_count];
    let mut classes = Vec::new();
    for seed in 0..state_count {
        if assigned[seed] {
            continue;
        }
        let states = (0..state_count)
            .filter(|&candidate| reachable[seed][candidate] && reachable[candidate][seed])
            .collect::<Vec<_>>();
        for &state in &states {
            assigned[state] = true;
        }
        let closed = states.iter().all(|&source| {
            generator
                .channels
                .iter()
                .filter(|channel| channel.source == source)
                .all(|channel| states.contains(&channel.target))
        });
        classes.push(ZeroRangeCommunicatingClass { states, closed });
    }
    (classes, strongly_connected)
}

fn validate_permutation(node_count: usize, old_to_new: &[usize]) -> Result<()> {
    if old_to_new.len() != node_count {
        return Err(AnalysisError::new(
            "zero-range node permutation has the wrong length",
        ));
    }
    let mut seen = vec![false; node_count];
    for &mapped in old_to_new {
        if mapped >= node_count || seen[mapped] {
            return Err(AnalysisError::new(
                "zero-range node permutation is not a bijection",
            ));
        }
        seen[mapped] = true;
    }
    Ok(())
}

fn permute_allocation(allocation: &[u32], old_to_new: &[usize]) -> Vec<u32> {
    let mut permuted = vec![0u32; allocation.len()];
    for (old, &occupancy) in allocation.iter().enumerate() {
        permuted[old_to_new[old]] = occupancy;
    }
    permuted
}

fn binomial_biguint(n: usize, k: usize) -> BigUint {
    let k = k.min(n - k);
    (0..k).fold(BigUint::one(), |value, index| {
        value * BigUint::from(n - index) / BigUint::from(index + 1)
    })
}
