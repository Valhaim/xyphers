use crate::exact::biguint_log2;
use crate::spectral::{symmetric_eigendecomposition, DenseMatrix};
use crate::{
    AnalysisError, ExactChecks, ExactKernel, ExactRatio, ExactTransientPoint, Fixture, Result,
    StateShell,
};

pub const MIXING_TV_THRESHOLD: f64 = 1.0e-6;
pub const KL_NEGATIVE_TOLERANCE_BITS: f64 = 1.0e-12;
pub const MFPT_BELLMAN_TOLERANCE: f64 = 1.0e-9;

// THUMB td-fbdd6c: frozen numerical QA tolerances, not model parameters.
pub const PROBABILITY_TOLERANCE: f64 = 1.0e-12;
const LINEAR_PIVOT_TOLERANCE: f64 = 1.0e-14;
const SMALL_NEGATIVE_TOLERANCE: f64 = 1.0e-10;

#[derive(Clone, Debug, PartialEq)]
pub struct SpectralReport {
    pub eigenvalues: Vec<f64>,
    pub eigenvector_norm_lower_bounds: Vec<f64>,
    pub eigenvector_norm_upper_bounds: Vec<f64>,
    pub normalized_eigenpair_residual_upper_bounds: Vec<f64>,
    /// `1 - max_{k >= 2} |lambda_k|` for the reversible kernel.
    pub spectral_gap: f64,
    pub spectral_gap_certificate: SpectralGapCertificate,
    pub subdominant_eigenvalue: f64,
    pub relaxation_scale: f64,
    pub jacobi_sweeps: usize,
    pub global_eigenvalue_error_upper_bound: f64,
    pub maximum_off_diagonal: f64,
    pub maximum_eigenpair_residual: f64,
    pub maximum_normalized_eigenpair_residual_upper_bound: f64,
    pub maximum_orthogonality_residual: f64,
    pub orthogonality_frobenius_residual_upper_bound: f64,
    pub maximum_reconstruction_residual: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct SpectralInterval {
    pub lower_bound: f64,
    pub upper_bound: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct SpectralGapCertificate {
    pub gap_lower_bound: f64,
    pub gap_upper_bound: f64,
    pub mode_modulus_intervals: Vec<SpectralInterval>,
    pub next_distinct_modulus_upper_bound: f64,
    pub stationary_modulus_lower_bound: f64,
    pub subdominant_cluster_indices: Vec<usize>,
    pub subdominant_modulus_lower_bound: f64,
    pub subdominant_modulus_upper_bound: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct EquilibriumMetrics {
    pub shannon_entropy_bits: f64,
    pub effective_state_count: f64,
    pub inverse_participation_ratio: f64,
    pub participation_ratio: f64,
    pub normalized_participation_ratio: f64,
    pub localization_excess: f64,
    pub maximum_state_mass: f64,
    pub maximum_mass_states: Vec<usize>,
    pub perron_square_total_variation: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct EntropyMetrics {
    pub entropy_rate_bits_per_step: f64,
    pub topological_entropy_bits_per_step: f64,
    pub entropy_rate_deficit_bits_per_step: f64,
    pub stationary_mean_path_entropy_bits: f64,
    pub minimum_path_entropy_bits: f64,
    pub maximum_path_entropy_bits: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct NumericalResiduals {
    pub maximum_row_sum_residual: f64,
    pub maximum_stationarity_residual: f64,
    pub maximum_detailed_balance_residual: f64,
    pub symmetric_similarity_asymmetry: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct TransientPoint {
    pub opportunity: usize,
    pub distribution: Vec<f64>,
    pub total_variation_to_stationary: f64,
    pub relative_entropy_bits: f64,
    pub endpoint_entropy_bits: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct TransientReport {
    pub points: Vec<TransientPoint>,
    pub first_below_mixing_threshold: Option<usize>,
    pub exact_delta_points: Option<Vec<ExactTransientPoint>>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct FirstPassageReport {
    state_count: usize,
    mean_first_passage: Vec<f64>,
    pub mean_return: Vec<f64>,
    pub exact_mean_return: Vec<ExactRatio>,
    pub maximum_bellman_residual: f64,
}

impl FirstPassageReport {
    pub fn mean_first_passage(&self, source: usize, target: usize) -> Result<f64> {
        if source >= self.state_count || target >= self.state_count {
            return Err(AnalysisError::new("first-passage index is out of range"));
        }
        Ok(self.mean_first_passage[source * self.state_count + target])
    }

    pub fn mean_first_passage_matrix(&self) -> &[f64] {
        &self.mean_first_passage
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct KernelComparison {
    pub stationary_total_variation: f64,
    pub maximum_row_total_variation: f64,
    pub entropy_rate_delta_bits_per_step: f64,
    pub spectral_gap_delta: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Analysis {
    exact: ExactKernel,
    exact_checks: ExactChecks,
    transition: DenseMatrix,
    stationary: Vec<f64>,
    perron_square: Vec<f64>,
    spectral: SpectralReport,
    equilibrium: EquilibriumMetrics,
    entropy: EntropyMetrics,
    residuals: NumericalResiduals,
}

impl Analysis {
    pub fn build(fixture: Fixture, horizon: usize) -> Result<Self> {
        let shell = StateShell::enumerate(fixture)?;
        let exact = ExactKernel::build(shell, horizon)?;
        let exact_checks = exact.verify_exact();
        if !exact_checks.all_passed() {
            return Err(AnalysisError::new(
                "independently constructed kernel failed an exact identity",
            ));
        }

        let state_count = exact.shell().state_count();
        let transition = DenseMatrix::from_rows(
            (0..state_count)
                .map(|source| {
                    (0..state_count)
                        .map(|target| exact.transition_ratio(source, target)?.to_f64())
                        .collect()
                })
                .collect::<Result<Vec<Vec<f64>>>>()?,
        )?;
        let stationary: Vec<f64> = (0..state_count)
            .map(|state| exact.stationary_ratio(state)?.to_f64())
            .collect::<Result<_>>()?;
        validate_probability_vector(&stationary)?;

        let symmetric_similarity = reversible_similarity(&transition, &stationary)?;
        let symmetric_similarity_asymmetry = symmetric_similarity.max_asymmetry();
        let q_spectrum = symmetric_eigendecomposition(&symmetric_similarity)?;
        if (q_spectrum.eigenvalues[0] - 1.0).abs() > 10.0 * PROBABILITY_TOLERANCE {
            return Err(AnalysisError::new(
                "reversible spectrum does not contain the stationary eigenvalue",
            ));
        }
        let spectral_gap_certificate = spectral_gap_certificate(&q_spectrum)?;
        let (subdominant_eigenvalue, subdominant_modulus) = q_spectrum.eigenvalues[1..]
            .iter()
            .copied()
            .map(|eigenvalue| (eigenvalue, eigenvalue.abs()))
            .max_by(|left, right| {
                left.1
                    .total_cmp(&right.1)
                    .then_with(|| left.0.total_cmp(&right.0))
            })
            .unwrap_or((0.0, 0.0));
        let raw_gap = 1.0 - subdominant_modulus;
        if raw_gap < -PROBABILITY_TOLERANCE {
            return Err(AnalysisError::new(
                "subdominant eigenvalue lies outside the stochastic range",
            ));
        }
        let spectral_gap = raw_gap.max(0.0);
        if spectral_gap < spectral_gap_certificate.gap_lower_bound
            || spectral_gap > spectral_gap_certificate.gap_upper_bound
        {
            return Err(AnalysisError::new(
                "Jacobi spectral-gap estimate lies outside its residual certificate",
            ));
        }
        let spectral = SpectralReport {
            eigenvalues: q_spectrum.eigenvalues,
            eigenvector_norm_lower_bounds: q_spectrum.eigenvector_norm_lower_bounds,
            eigenvector_norm_upper_bounds: q_spectrum.eigenvector_norm_upper_bounds,
            normalized_eigenpair_residual_upper_bounds: q_spectrum
                .normalized_eigenpair_residual_upper_bounds,
            spectral_gap,
            spectral_gap_certificate,
            subdominant_eigenvalue,
            relaxation_scale: if spectral_gap > 0.0 {
                1.0 / spectral_gap
            } else {
                f64::INFINITY
            },
            jacobi_sweeps: q_spectrum.sweeps,
            global_eigenvalue_error_upper_bound: q_spectrum.global_eigenvalue_error_upper_bound,
            maximum_off_diagonal: q_spectrum.maximum_off_diagonal,
            maximum_eigenpair_residual: q_spectrum.maximum_eigenpair_residual,
            maximum_normalized_eigenpair_residual_upper_bound: q_spectrum
                .maximum_normalized_eigenpair_residual_upper_bound,
            maximum_orthogonality_residual: q_spectrum.maximum_orthogonality_residual,
            orthogonality_frobenius_residual_upper_bound: q_spectrum
                .orthogonality_frobenius_residual_upper_bound,
            maximum_reconstruction_residual: q_spectrum.maximum_reconstruction_residual,
        };

        let action_adjacency = DenseMatrix::from_rows(
            exact
                .shell()
                .adjacency()
                .iter()
                .map(|row| row.iter().map(|&value| f64::from(value)).collect())
                .collect(),
        )?;
        let adjacency_spectrum = symmetric_eigendecomposition(&action_adjacency)?;
        let perron_eigenvalue = adjacency_spectrum.eigenvalues[0];
        if perron_eigenvalue <= 0.0 {
            return Err(AnalysisError::new(
                "action adjacency has no positive Perron eigenvalue",
            ));
        }
        let perron_vector = adjacency_spectrum.eigenvector(0)?;
        let perron_square_normalization: f64 =
            perron_vector.iter().map(|value| value * value).sum();
        if !perron_square_normalization.is_finite() || perron_square_normalization <= 0.0 {
            return Err(AnalysisError::new("invalid Perron eigenvector norm"));
        }
        let perron_square: Vec<f64> = perron_vector
            .iter()
            .map(|value| value * value / perron_square_normalization)
            .collect();
        validate_probability_vector(&perron_square)?;

        let equilibrium_entropy_bits = shannon_entropy_bits(&stationary);
        let inverse_participation_ratio: f64 = stationary
            .iter()
            .map(|probability| probability * probability)
            .sum();
        let participation_ratio = 1.0 / inverse_participation_ratio;
        let maximum_weight = exact
            .stationary_weights()
            .iter()
            .max()
            .ok_or_else(|| AnalysisError::new("stationary law is empty"))?;
        let maximum_mass_states: Vec<usize> = exact
            .stationary_weights()
            .iter()
            .enumerate()
            .filter_map(|(state, weight)| (weight == maximum_weight).then_some(state))
            .collect();
        let maximum_state_mass = ExactRatio::new(
            maximum_weight.clone(),
            exact.stationary_normalization().clone(),
        )?
        .to_f64()?;
        let equilibrium = EquilibriumMetrics {
            shannon_entropy_bits: equilibrium_entropy_bits,
            effective_state_count: 2.0_f64.powf(equilibrium_entropy_bits),
            inverse_participation_ratio,
            participation_ratio,
            normalized_participation_ratio: participation_ratio / state_count as f64,
            localization_excess: state_count as f64 * inverse_participation_ratio - 1.0,
            maximum_state_mass,
            maximum_mass_states,
            perron_square_total_variation: total_variation(&stationary, &perron_square),
        };

        let entropy_rate_bits_per_step = stationary
            .iter()
            .enumerate()
            .map(|(state, &mass)| mass * shannon_entropy_bits(transition.row(state)))
            .sum();
        let topological_entropy_bits_per_step = perron_eigenvalue.log2();
        let path_entropies: Vec<f64> = exact
            .path_counts(horizon)?
            .iter()
            .map(biguint_log2)
            .collect::<Result<_>>()?;
        let stationary_mean_path_entropy_bits = stationary
            .iter()
            .zip(&path_entropies)
            .map(|(mass, entropy)| mass * entropy)
            .sum();
        let minimum_path_entropy_bits = path_entropies
            .iter()
            .copied()
            .min_by(f64::total_cmp)
            .ok_or_else(|| AnalysisError::new("path entropy vector is empty"))?;
        let maximum_path_entropy_bits = path_entropies
            .iter()
            .copied()
            .max_by(f64::total_cmp)
            .ok_or_else(|| AnalysisError::new("path entropy vector is empty"))?;
        let entropy = EntropyMetrics {
            entropy_rate_bits_per_step,
            topological_entropy_bits_per_step,
            entropy_rate_deficit_bits_per_step: topological_entropy_bits_per_step
                - entropy_rate_bits_per_step,
            stationary_mean_path_entropy_bits,
            minimum_path_entropy_bits,
            maximum_path_entropy_bits,
        };

        let residuals =
            numerical_residuals(&transition, &stationary, symmetric_similarity_asymmetry);
        if residuals.maximum_row_sum_residual > PROBABILITY_TOLERANCE
            || residuals.maximum_stationarity_residual > PROBABILITY_TOLERANCE
            || residuals.maximum_detailed_balance_residual > PROBABILITY_TOLERANCE
        {
            return Err(AnalysisError::new(
                "floating projection exceeded the frozen probability tolerance",
            ));
        }

        Ok(Self {
            exact,
            exact_checks,
            transition,
            stationary,
            perron_square,
            spectral,
            equilibrium,
            entropy,
            residuals,
        })
    }

    pub fn exact(&self) -> &ExactKernel {
        &self.exact
    }

    pub fn exact_checks(&self) -> &ExactChecks {
        &self.exact_checks
    }

    pub fn transition(&self) -> &DenseMatrix {
        &self.transition
    }

    pub fn stationary(&self) -> &[f64] {
        &self.stationary
    }

    pub fn perron_square_limit(&self) -> &[f64] {
        &self.perron_square
    }

    pub fn spectral(&self) -> &SpectralReport {
        &self.spectral
    }

    pub fn equilibrium(&self) -> &EquilibriumMetrics {
        &self.equilibrium
    }

    pub fn entropy(&self) -> &EntropyMetrics {
        &self.entropy
    }

    pub fn residuals(&self) -> &NumericalResiduals {
        &self.residuals
    }

    pub fn transient_from_state(&self, state: usize, steps: usize) -> Result<TransientReport> {
        let exact_delta_points = self.exact.exact_delta_transient(state, steps)?;
        let distributions: Vec<Vec<f64>> = exact_delta_points
            .iter()
            .map(|point| point.distribution.to_f64())
            .collect::<Result<_>>()?;
        self.transient_report(distributions, Some(exact_delta_points))
    }

    pub fn exact_delta_transient(
        &self,
        state: usize,
        steps: usize,
    ) -> Result<Vec<ExactTransientPoint>> {
        self.exact.exact_delta_transient(state, steps)
    }

    pub fn transient(&self, initial: &[f64], steps: usize) -> Result<TransientReport> {
        validate_probability_vector(initial)?;
        if initial.len() != self.stationary.len() {
            return Err(AnalysisError::new(
                "initial distribution has the wrong state count",
            ));
        }

        let mut distribution = initial.to_vec();
        let mut distributions = Vec::with_capacity(steps + 1);
        for opportunity in 0..=steps {
            distributions.push(distribution.clone());
            if opportunity < steps {
                distribution = self.transition.multiply_row_vector(&distribution)?;
                validate_probability_vector(&distribution)?;
            }
        }
        self.transient_report(distributions, None)
    }

    fn transient_report(
        &self,
        distributions: Vec<Vec<f64>>,
        exact_delta_points: Option<Vec<ExactTransientPoint>>,
    ) -> Result<TransientReport> {
        let mut points = Vec::with_capacity(distributions.len());
        for (opportunity, distribution) in distributions.into_iter().enumerate() {
            validate_probability_vector(&distribution)?;
            points.push(TransientPoint {
                opportunity,
                total_variation_to_stationary: total_variation(&distribution, &self.stationary),
                relative_entropy_bits: relative_entropy_bits(&distribution, &self.stationary)?,
                endpoint_entropy_bits: shannon_entropy_bits(&distribution),
                distribution,
            });
        }
        let first_below_mixing_threshold = points
            .iter()
            .find(|point| point.total_variation_to_stationary < MIXING_TV_THRESHOLD)
            .map(|point| point.opportunity);
        Ok(TransientReport {
            points,
            first_below_mixing_threshold,
            exact_delta_points,
        })
    }

    pub fn first_passage(&self) -> Result<FirstPassageReport> {
        let state_count = self.stationary.len();
        let mut mean_first_passage = vec![0.0; state_count * state_count];

        for target in 0..state_count {
            if state_count == 1 {
                break;
            }
            let retained: Vec<usize> = (0..state_count).filter(|&state| state != target).collect();
            let mut system = vec![vec![0.0; retained.len()]; retained.len()];
            for (row, &source) in retained.iter().enumerate() {
                for (column, &other) in retained.iter().enumerate() {
                    system[row][column] = if source == other { 1.0 } else { 0.0 }
                        - self.transition.get(source, other);
                }
            }
            let solution = solve_linear_system(system, vec![1.0; retained.len()])?;
            for (&source, value) in retained.iter().zip(solution) {
                if value < -SMALL_NEGATIVE_TOLERANCE {
                    return Err(AnalysisError::new(
                        "mean first-passage solver returned a negative time",
                    ));
                }
                mean_first_passage[source * state_count + target] = value.max(0.0);
            }
        }

        let exact_mean_return: Vec<ExactRatio> = self
            .exact
            .stationary_weights()
            .iter()
            .map(|weight| {
                ExactRatio::new(
                    self.exact.stationary_normalization().clone(),
                    weight.clone(),
                )
            })
            .collect::<Result<_>>()?;
        let mean_return = exact_mean_return
            .iter()
            .map(ExactRatio::to_f64)
            .collect::<Result<_>>()?;
        let mut maximum_bellman_residual = 0.0_f64;
        for source in 0..state_count {
            for target in 0..state_count {
                if source == target {
                    continue;
                }
                let continuation: f64 = (0..state_count)
                    .map(|next| {
                        self.transition.get(source, next)
                            * mean_first_passage[next * state_count + target]
                    })
                    .sum();
                maximum_bellman_residual = maximum_bellman_residual.max(
                    (mean_first_passage[source * state_count + target] - (1.0 + continuation))
                        .abs(),
                );
            }
        }
        if maximum_bellman_residual > MFPT_BELLMAN_TOLERANCE {
            return Err(AnalysisError::new(format!(
                "mean first-passage Bellman residual {maximum_bellman_residual:.3e} \
                 exceeds acceptance tolerance"
            )));
        }

        Ok(FirstPassageReport {
            state_count,
            mean_first_passage,
            mean_return,
            exact_mean_return,
            maximum_bellman_residual,
        })
    }
}

pub fn compare_kernels(left: &Analysis, right: &Analysis) -> Result<KernelComparison> {
    if left.exact.shell().fixture() != right.exact.shell().fixture()
        || left.exact.shell().states() != right.exact.shell().states()
    {
        return Err(AnalysisError::new(
            "kernel comparison requires the same fixture and state ordering",
        ));
    }

    let maximum_row_total_variation = left
        .transition
        .rows()
        .zip(right.transition.rows())
        .map(|(left_row, right_row)| total_variation(left_row, right_row))
        .fold(0.0_f64, f64::max);
    Ok(KernelComparison {
        stationary_total_variation: total_variation(&left.stationary, &right.stationary),
        maximum_row_total_variation,
        entropy_rate_delta_bits_per_step: right.entropy.entropy_rate_bits_per_step
            - left.entropy.entropy_rate_bits_per_step,
        spectral_gap_delta: right.spectral.spectral_gap - left.spectral.spectral_gap,
    })
}

fn reversible_similarity(transition: &DenseMatrix, stationary: &[f64]) -> Result<DenseMatrix> {
    if transition.size() != stationary.len() {
        return Err(AnalysisError::new(
            "stationary law and transition matrix shapes differ",
        ));
    }
    DenseMatrix::from_rows(
        (0..transition.size())
            .map(|source| {
                (0..transition.size())
                    .map(|target| {
                        if stationary[target] <= 0.0 {
                            return Err(AnalysisError::new("stationary law lacks full support"));
                        }
                        Ok(stationary[source].sqrt() * transition.get(source, target)
                            / stationary[target].sqrt())
                    })
                    .collect()
            })
            .collect::<Result<Vec<Vec<f64>>>>()?,
    )
}

#[derive(Clone, Debug)]
struct ModulusCluster {
    indices: Vec<usize>,
    lower_bound: f64,
    upper_bound: f64,
}

fn spectral_gap_certificate(
    spectrum: &crate::spectral::SymmetricSpectrum,
) -> Result<SpectralGapCertificate> {
    if spectrum.eigenvalues.len() < 2 {
        return Err(AnalysisError::new(
            "spectral-gap certificate requires a nontrivial complete spectrum",
        ));
    }

    let global_radius = spectrum.global_eigenvalue_error_upper_bound;
    if !global_radius.is_finite() || global_radius <= 0.0 {
        return Err(AnalysisError::new(
            "spectral-gap certificate requires a positive full-spectrum error bound",
        ));
    }
    let mode_modulus_intervals = spectrum
        .eigenvalues
        .iter()
        .map(|&eigenvalue| {
            let modulus = eigenvalue.abs();
            SpectralInterval {
                lower_bound: if modulus <= global_radius {
                    0.0
                } else {
                    next_down_nonnegative(modulus - global_radius)
                },
                upper_bound: next_up_nonnegative(modulus + global_radius),
            }
        })
        .collect::<Vec<_>>();

    let stationary_lower = next_down(spectrum.eigenvalues[0] - global_radius);
    let stationary_upper = next_up(spectrum.eigenvalues[0] + global_radius);
    if stationary_lower > 1.0 || stationary_upper < 1.0 {
        return Err(AnalysisError::new(
            "stationary eigenvalue is outside its residual interval",
        ));
    }

    let mut intervals = mode_modulus_intervals[1..]
        .iter()
        .cloned()
        .enumerate()
        .map(|(offset, interval)| (offset + 1, interval))
        .collect::<Vec<_>>();
    intervals.sort_by(|left, right| {
        left.1
            .lower_bound
            .total_cmp(&right.1.lower_bound)
            .then_with(|| left.1.upper_bound.total_cmp(&right.1.upper_bound))
            .then_with(|| left.0.cmp(&right.0))
    });

    let mut clusters = Vec::<ModulusCluster>::new();
    for (index, interval) in intervals {
        if let Some(cluster) = clusters.last_mut() {
            if interval.lower_bound <= cluster.upper_bound {
                cluster.indices.push(index);
                cluster.lower_bound = cluster.lower_bound.min(interval.lower_bound);
                cluster.upper_bound = cluster.upper_bound.max(interval.upper_bound);
                continue;
            }
        }
        clusters.push(ModulusCluster {
            indices: vec![index],
            lower_bound: interval.lower_bound,
            upper_bound: interval.upper_bound,
        });
    }
    let subdominant_cluster = clusters
        .last()
        .ok_or_else(|| AnalysisError::new("spectrum has no nonstationary mode"))?;
    let next_distinct_modulus_upper_bound = if clusters.len() > 1 {
        clusters[clusters.len() - 2].upper_bound
    } else {
        0.0
    };
    if subdominant_cluster.lower_bound <= next_distinct_modulus_upper_bound {
        return Err(AnalysisError::new(
            "subdominant modulus cluster is not separated from the next distinct cluster",
        ));
    }
    let stationary_modulus_lower_bound = mode_modulus_intervals[0].lower_bound;
    if stationary_modulus_lower_bound <= subdominant_cluster.upper_bound {
        return Err(AnalysisError::new(
            "stationary mode is not separated from the subdominant modulus cluster",
        ));
    }

    let mut subdominant_cluster_indices = subdominant_cluster.indices.clone();
    subdominant_cluster_indices.sort_unstable();
    let gap_lower_bound = next_down_nonnegative((1.0 - subdominant_cluster.upper_bound).max(0.0));
    let gap_upper_bound = next_up_nonnegative(1.0 - subdominant_cluster.lower_bound).min(1.0);
    if !gap_lower_bound.is_finite()
        || !gap_upper_bound.is_finite()
        || gap_lower_bound <= 0.0
        || gap_lower_bound > gap_upper_bound
    {
        return Err(AnalysisError::new(
            "residual-derived spectral-gap interval is invalid",
        ));
    }

    Ok(SpectralGapCertificate {
        gap_lower_bound,
        gap_upper_bound,
        mode_modulus_intervals,
        next_distinct_modulus_upper_bound,
        stationary_modulus_lower_bound,
        subdominant_cluster_indices,
        subdominant_modulus_lower_bound: subdominant_cluster.lower_bound,
        subdominant_modulus_upper_bound: subdominant_cluster.upper_bound,
    })
}

fn next_up(value: f64) -> f64 {
    if value.is_nan() || value == f64::INFINITY {
        return value;
    }
    if value == -0.0 {
        return f64::from_bits(1);
    }
    if value >= 0.0 {
        f64::from_bits(value.to_bits() + 1)
    } else {
        f64::from_bits(value.to_bits() - 1)
    }
}

fn next_down(value: f64) -> f64 {
    if value.is_nan() || value == f64::NEG_INFINITY {
        return value;
    }
    if value == 0.0 {
        return -f64::from_bits(1);
    }
    if value > 0.0 {
        f64::from_bits(value.to_bits() - 1)
    } else {
        f64::from_bits(value.to_bits() + 1)
    }
}

fn next_up_nonnegative(value: f64) -> f64 {
    next_up(value.max(0.0))
}

fn next_down_nonnegative(value: f64) -> f64 {
    if value <= 0.0 {
        0.0
    } else {
        next_down(value)
    }
}

fn numerical_residuals(
    transition: &DenseMatrix,
    stationary: &[f64],
    symmetric_similarity_asymmetry: f64,
) -> NumericalResiduals {
    let maximum_row_sum_residual = transition
        .rows()
        .map(|row| (row.iter().sum::<f64>() - 1.0).abs())
        .fold(0.0_f64, f64::max);
    let propagated = transition
        .multiply_row_vector(stationary)
        .unwrap_or_else(|_| vec![f64::NAN; stationary.len()]);
    let maximum_stationarity_residual = propagated
        .iter()
        .zip(stationary)
        .map(|(actual, expected)| (actual - expected).abs())
        .fold(0.0_f64, f64::max);
    let mut maximum_detailed_balance_residual = 0.0_f64;
    for source in 0..transition.size() {
        for target in 0..transition.size() {
            maximum_detailed_balance_residual = maximum_detailed_balance_residual.max(
                (stationary[source] * transition.get(source, target)
                    - stationary[target] * transition.get(target, source))
                .abs(),
            );
        }
    }
    NumericalResiduals {
        maximum_row_sum_residual,
        maximum_stationarity_residual,
        maximum_detailed_balance_residual,
        symmetric_similarity_asymmetry,
    }
}

fn validate_probability_vector(distribution: &[f64]) -> Result<()> {
    if distribution.is_empty() {
        return Err(AnalysisError::new(
            "probability distribution must not be empty",
        ));
    }
    if distribution
        .iter()
        .any(|value| !value.is_finite() || *value < 0.0)
    {
        return Err(AnalysisError::new(
            "probability distribution contains an invalid entry",
        ));
    }
    let residual = (distribution.iter().sum::<f64>() - 1.0).abs();
    if residual > PROBABILITY_TOLERANCE {
        return Err(AnalysisError::new(format!(
            "probability distribution has normalization residual {residual:.3e}"
        )));
    }
    Ok(())
}

fn shannon_entropy_bits(distribution: &[f64]) -> f64 {
    distribution
        .iter()
        .filter(|&&probability| probability > 0.0)
        .map(|probability| -probability * probability.log2())
        .sum()
}

fn relative_entropy_bits(distribution: &[f64], stationary: &[f64]) -> Result<f64> {
    if distribution.len() != stationary.len() {
        return Err(AnalysisError::new(
            "relative entropy distributions have different shapes",
        ));
    }
    let mut divergence = 0.0;
    for (&probability, &reference) in distribution.iter().zip(stationary) {
        if probability > 0.0 {
            if reference <= 0.0 {
                return Err(AnalysisError::new(
                    "relative entropy reference lacks full support",
                ));
            }
            divergence += probability * (probability / reference).log2();
        }
    }
    if divergence < -KL_NEGATIVE_TOLERANCE_BITS {
        return Err(AnalysisError::new(format!(
            "relative entropy fell below the frozen negative tolerance: {divergence:.3e} bits"
        )));
    }
    Ok(if divergence < 0.0 { 0.0 } else { divergence })
}

fn total_variation(left: &[f64], right: &[f64]) -> f64 {
    0.5 * left
        .iter()
        .zip(right)
        .map(|(left, right)| (left - right).abs())
        .sum::<f64>()
}

fn solve_linear_system(mut matrix: Vec<Vec<f64>>, mut right: Vec<f64>) -> Result<Vec<f64>> {
    let size = matrix.len();
    if right.len() != size || matrix.iter().any(|row| row.len() != size) {
        return Err(AnalysisError::new("linear system shape mismatch"));
    }
    for column in 0..size {
        let pivot = (column..size)
            .max_by(|&left, &right_row| {
                matrix[left][column]
                    .abs()
                    .total_cmp(&matrix[right_row][column].abs())
                    .then_with(|| right_row.cmp(&left))
            })
            .ok_or_else(|| AnalysisError::new("linear system has no pivot"))?;
        if matrix[pivot][column].abs() <= LINEAR_PIVOT_TOLERANCE {
            return Err(AnalysisError::new("linear system is numerically singular"));
        }
        matrix.swap(column, pivot);
        right.swap(column, pivot);

        let pivot_value = matrix[column][column];
        for entry in &mut matrix[column][column..] {
            *entry /= pivot_value;
        }
        right[column] /= pivot_value;
        let normalized_pivot_row = matrix[column].clone();

        for row in 0..size {
            if row == column {
                continue;
            }
            let factor = matrix[row][column];
            if factor == 0.0 {
                continue;
            }
            for (entry, pivot_entry) in matrix[row][column..]
                .iter_mut()
                .zip(&normalized_pivot_row[column..])
            {
                *entry -= factor * pivot_entry;
            }
            right[row] -= factor * right[column];
        }
    }
    if right.iter().any(|value| !value.is_finite()) {
        return Err(AnalysisError::new(
            "linear solver returned a non-finite value",
        ));
    }
    Ok(right)
}

#[cfg(test)]
mod tests {
    use super::{relative_entropy_bits, spectral_gap_certificate};
    use crate::spectral::{symmetric_eigendecomposition, DenseMatrix};

    #[test]
    fn materially_negative_relative_entropy_is_rejected() {
        let error = relative_entropy_bits(&[0.5, 0.5], &[0.6, 0.6])
            .expect_err("negative KL must fail the acceptance gate");
        assert!(error.to_string().contains("negative tolerance"));
    }

    #[test]
    fn full_basis_bound_covers_a_collective_mode_below_the_jacobi_pivot_threshold() {
        let size = 35;
        let block_size = size - 1;
        let coupling = 1.0e-14;
        let mut rows = vec![vec![0.0; size]; size];
        rows[0][0] = 1.0;
        for (row_index, row) in rows.iter_mut().enumerate().skip(1) {
            row[row_index] = 0.5;
            for (column_index, value) in row.iter_mut().enumerate().skip(1) {
                if row_index != column_index {
                    *value = coupling;
                }
            }
        }
        let spectrum = symmetric_eigendecomposition(&DenseMatrix::from_rows(rows).expect("matrix"))
            .expect("spectrum");
        assert_eq!(spectrum.sweeps, 0);
        let certificate = spectral_gap_certificate(&spectrum).expect("certificate");
        let exact_subdominant = 0.5 + (block_size - 1) as f64 * coupling;
        let exact_gap = 1.0 - exact_subdominant;
        assert!(certificate.gap_lower_bound <= exact_gap);
        assert!(certificate.gap_upper_bound >= exact_gap);
        assert_eq!(certificate.subdominant_cluster_indices.len(), block_size);
    }

    #[test]
    fn spectral_certificate_preserves_a_degenerate_subdominant_cluster() {
        let spectrum = symmetric_eigendecomposition(
            &DenseMatrix::from_rows(vec![
                vec![1.0, 0.0, 0.0, 0.0],
                vec![0.0, 0.8, 0.0, 0.0],
                vec![0.0, 0.0, 0.8, 0.0],
                vec![0.0, 0.0, 0.0, 0.5],
            ])
            .expect("matrix"),
        )
        .expect("spectrum");
        let certificate = spectral_gap_certificate(&spectrum).expect("certificate");
        assert_eq!(certificate.subdominant_cluster_indices, vec![1, 2]);
        assert!(certificate.gap_lower_bound <= 0.2);
        assert!(certificate.gap_upper_bound >= 0.2);
        assert!(certificate.subdominant_modulus_lower_bound > 0.5);
    }
}
