use crate::{Action, AnalysisError, Result, StateShell};
use num_bigint::BigUint;
use num_integer::Integer;
use num_traits::{One, ToPrimitive, Zero};
use std::collections::{BTreeSet, VecDeque};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactRatio {
    numerator: BigUint,
    denominator: BigUint,
}

impl ExactRatio {
    pub fn new(numerator: BigUint, denominator: BigUint) -> Result<Self> {
        if denominator.is_zero() {
            return Err(AnalysisError::new("exact ratio has a zero denominator"));
        }
        let divisor = numerator.gcd(&denominator);
        Ok(Self {
            numerator: numerator / &divisor,
            denominator: denominator / divisor,
        })
    }

    pub fn numerator(&self) -> &BigUint {
        &self.numerator
    }

    pub fn denominator(&self) -> &BigUint {
        &self.denominator
    }

    pub fn zero() -> Self {
        Self {
            numerator: BigUint::zero(),
            denominator: BigUint::one(),
        }
    }

    pub fn one() -> Self {
        Self {
            numerator: BigUint::one(),
            denominator: BigUint::one(),
        }
    }

    pub fn checked_add(&self, other: &Self) -> Result<Self> {
        let shared_denominator = self.denominator.gcd(&other.denominator);
        let self_scale = &other.denominator / &shared_denominator;
        let other_scale = &self.denominator / &shared_denominator;
        Self::new(
            &self.numerator * &self_scale + &other.numerator * &other_scale,
            &self.denominator * self_scale,
        )
    }

    pub fn checked_multiply(&self, other: &Self) -> Result<Self> {
        let left_cancellation = self.numerator.gcd(&other.denominator);
        let right_cancellation = other.numerator.gcd(&self.denominator);
        Self::new(
            (&self.numerator / &left_cancellation) * (&other.numerator / &right_cancellation),
            (&self.denominator / &right_cancellation) * (&other.denominator / &left_cancellation),
        )
    }

    pub fn to_f64(&self) -> Result<f64> {
        if self.numerator.is_zero() {
            return Ok(0.0);
        }
        if let (Some(numerator), Some(denominator)) =
            (self.numerator.to_f64(), self.denominator.to_f64())
        {
            let value = numerator / denominator;
            if value.is_finite() && value > 0.0 {
                return Ok(value);
            }
        }

        let log_ratio = biguint_log2(&self.numerator)? - biguint_log2(&self.denominator)?;
        let value = 2.0_f64.powf(log_ratio);
        if !value.is_finite() || value == 0.0 {
            return Err(AnalysisError::new(
                "exact ratio is outside the positive finite f64 range",
            ));
        }
        Ok(value)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CandidateWeight {
    pub action: Action,
    pub successor: usize,
    pub weight: BigUint,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactDistribution {
    numerators: Vec<BigUint>,
    denominator: BigUint,
}

impl ExactDistribution {
    fn new(numerators: Vec<BigUint>, denominator: BigUint) -> Result<Self> {
        if denominator.is_zero() {
            return Err(AnalysisError::new(
                "exact distribution has a zero denominator",
            ));
        }
        if numerators
            .iter()
            .fold(BigUint::zero(), |sum, value| sum + value)
            != denominator
        {
            return Err(AnalysisError::new("exact distribution is not normalized"));
        }
        Ok(Self {
            numerators,
            denominator,
        })
    }

    pub fn numerators(&self) -> &[BigUint] {
        &self.numerators
    }

    pub fn denominator(&self) -> &BigUint {
        &self.denominator
    }

    pub fn probability(&self, state: usize) -> Result<ExactRatio> {
        let numerator = self
            .numerators
            .get(state)
            .cloned()
            .ok_or_else(|| AnalysisError::new("transient state index is out of range"))?;
        ExactRatio::new(numerator, self.denominator.clone())
    }

    pub fn to_f64(&self) -> Result<Vec<f64>> {
        self.numerators
            .iter()
            .map(|numerator| {
                ExactRatio {
                    numerator: numerator.clone(),
                    denominator: self.denominator.clone(),
                }
                .to_f64()
            })
            .collect()
    }

    pub fn is_normalized(&self) -> bool {
        self.numerators
            .iter()
            .fold(BigUint::zero(), |sum, numerator| sum + numerator)
            == self.denominator
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactTransientPoint {
    pub opportunity: usize,
    pub distribution: ExactDistribution,
}

impl ExactTransientPoint {
    pub fn probability(&self, state: usize) -> Result<ExactRatio> {
        self.distribution.probability(state)
    }

    pub fn is_normalized(&self) -> bool {
        self.distribution.is_normalized()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PermutationCovarianceReport {
    pub state_mapping: Vec<usize>,
    pub state_covariance: bool,
    pub action_covariance: bool,
    pub candidate_weight_covariance: bool,
    pub path_count_covariance: bool,
    pub transition_covariance: bool,
    pub stationary_covariance: bool,
}

impl PermutationCovarianceReport {
    pub fn all_passed(&self) -> bool {
        self.state_covariance
            && self.action_covariance
            && self.candidate_weight_covariance
            && self.path_count_covariance
            && self.transition_covariance
            && self.stationary_covariance
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CycleBalanceReport {
    pub basis_cycles: usize,
    pub balanced_cycles: usize,
    pub unbalanced_cycles: Vec<Vec<usize>>,
}

impl CycleBalanceReport {
    pub fn all_balanced(&self) -> bool {
        self.basis_cycles == self.balanced_cycles
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactChecks {
    pub path_count_recurrence: bool,
    pub row_stochasticity: bool,
    pub reverse_support: bool,
    pub stationarity: bool,
    pub detailed_balance: bool,
    pub cycle_balance: CycleBalanceReport,
}

impl ExactChecks {
    pub fn all_passed(&self) -> bool {
        self.path_count_recurrence
            && self.row_stochasticity
            && self.reverse_support
            && self.stationarity
            && self.detailed_balance
            && self.cycle_balance.all_balanced()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactKernel {
    shell: StateShell,
    horizon: usize,
    path_counts: Vec<Vec<BigUint>>,
    transition_numerators: Vec<Vec<BigUint>>,
    stationary_weights: Vec<BigUint>,
    stationary_normalization: BigUint,
}

impl ExactKernel {
    pub fn build(shell: StateShell, horizon: usize) -> Result<Self> {
        if horizon == 0 {
            return Err(AnalysisError::new("kernel horizon must be at least one"));
        }

        let state_count = shell.state_count();
        let mut path_counts = Vec::with_capacity(horizon + 1);
        path_counts.push(vec![BigUint::one(); state_count]);
        for depth in 1..=horizon {
            path_counts.push(multiply_adjacency_vector(
                shell.adjacency(),
                &path_counts[depth - 1],
            )?);
        }

        let mut transition_numerators = vec![vec![BigUint::zero(); state_count]; state_count];
        for (source, row) in transition_numerators.iter_mut().enumerate() {
            for (target, entry) in row.iter_mut().enumerate() {
                let multiplicity = shell.adjacency()[source][target];
                if multiplicity > 0 {
                    *entry = BigUint::from(multiplicity) * &path_counts[horizon - 1][target];
                }
            }
        }

        let stationary_weights: Vec<BigUint> = (0..state_count)
            .map(|state| &path_counts[horizon][state] * &path_counts[horizon - 1][state])
            .collect();
        let stationary_normalization = stationary_weights
            .iter()
            .fold(BigUint::zero(), |sum, weight| sum + weight);
        if stationary_normalization.is_zero() {
            return Err(AnalysisError::new(
                "stationary normalization unexpectedly vanished",
            ));
        }

        Ok(Self {
            shell,
            horizon,
            path_counts,
            transition_numerators,
            stationary_weights,
            stationary_normalization,
        })
    }

    pub fn shell(&self) -> &StateShell {
        &self.shell
    }

    pub fn horizon(&self) -> usize {
        self.horizon
    }

    pub fn path_counts(&self, depth: usize) -> Result<&[BigUint]> {
        self.path_counts
            .get(depth)
            .map(Vec::as_slice)
            .ok_or_else(|| AnalysisError::new("path-count depth is outside the built horizon"))
    }

    pub fn path_count(&self, depth: usize, state: usize) -> Result<&BigUint> {
        self.path_counts(depth)?
            .get(state)
            .ok_or_else(|| AnalysisError::new("state index is out of range"))
    }

    pub fn candidate_weights(&self, state: usize) -> Result<Vec<CandidateWeight>> {
        let continuation = &self.path_counts[self.horizon - 1];
        Ok(self
            .shell
            .actions(state)?
            .iter()
            .map(|step| CandidateWeight {
                action: step.action.clone(),
                successor: step.successor,
                weight: continuation[step.successor].clone(),
            })
            .collect())
    }

    pub fn exact_delta_transient(
        &self,
        initial_state: usize,
        steps: usize,
    ) -> Result<Vec<ExactTransientPoint>> {
        let state_count = self.shell.state_count();
        if initial_state >= state_count {
            return Err(AnalysisError::new("initial state index is out of range"));
        }

        let common_transition_denominator = self.path_counts[self.horizon]
            .iter()
            .fold(BigUint::one(), |common, denominator| {
                common.lcm(denominator)
            });
        let scaled_transition: Vec<Vec<BigUint>> = (0..state_count)
            .map(|source| {
                let row_scale =
                    &common_transition_denominator / &self.path_counts[self.horizon][source];
                self.transition_numerators[source]
                    .iter()
                    .map(|numerator| numerator * &row_scale)
                    .collect()
            })
            .collect();

        let mut numerators = vec![BigUint::zero(); state_count];
        numerators[initial_state] = BigUint::one();
        let mut denominator = BigUint::one();
        let mut points = Vec::with_capacity(steps + 1);
        for opportunity in 0..=steps {
            let point = ExactTransientPoint {
                opportunity,
                distribution: ExactDistribution::new(numerators.clone(), denominator.clone())?,
            };
            if !point.is_normalized() {
                return Err(AnalysisError::new(
                    "exact transient distribution is not normalized",
                ));
            }
            points.push(point);

            if opportunity < steps {
                let mut next_numerators = vec![BigUint::zero(); state_count];
                for (source, source_numerator) in numerators.iter().enumerate() {
                    if source_numerator.is_zero() {
                        continue;
                    }
                    for (target, scaled_weight) in scaled_transition[source].iter().enumerate() {
                        if scaled_weight.is_zero() {
                            continue;
                        }
                        next_numerators[target] += source_numerator * scaled_weight;
                    }
                }
                denominator *= &common_transition_denominator;
                let common_divisor =
                    next_numerators
                        .iter()
                        .fold(denominator.clone(), |divisor, numerator| {
                            if divisor.is_one() {
                                divisor
                            } else {
                                divisor.gcd(numerator)
                            }
                        });
                if common_divisor > BigUint::one() {
                    denominator /= &common_divisor;
                    for numerator in &mut next_numerators {
                        *numerator /= &common_divisor;
                    }
                }
                numerators = next_numerators;
            }
        }
        Ok(points)
    }

    /// Checks exact covariance under the node relabelling `old_node -> new_node`.
    pub fn verify_permutation_covariance(
        &self,
        node_permutation: &[usize],
    ) -> Result<PermutationCovarianceReport> {
        let fixture = self.shell.fixture();
        let permuted_fixture = fixture.permuted(node_permutation)?;
        let permuted = Self::build(StateShell::enumerate(permuted_fixture)?, self.horizon)?;

        let state_mapping: Vec<usize> = self
            .shell
            .states()
            .iter()
            .map(|state| {
                let mapped_state = fixture.permute_state(state, node_permutation)?;
                permuted
                    .shell
                    .state_index(&mapped_state)
                    .ok_or_else(|| AnalysisError::new("co-permuted state is absent"))
            })
            .collect::<Result<_>>()?;
        let state_covariance = {
            let unique: BTreeSet<usize> = state_mapping.iter().copied().collect();
            unique.len() == self.shell.state_count()
                && state_mapping
                    .iter()
                    .enumerate()
                    .all(|(old_state, &new_state)| {
                        fixture
                            .permute_state(&self.shell.states()[old_state], node_permutation)
                            .is_ok_and(|expected| expected == permuted.shell.states()[new_state])
                    })
        };

        let action_covariance = (0..self.shell.state_count()).all(|old_state| {
            let new_state = state_mapping[old_state];
            let mut expected = match self.shell.actions(old_state).and_then(|actions| {
                actions
                    .iter()
                    .map(|step| {
                        Ok((
                            step.action.permuted(node_permutation)?,
                            state_mapping[step.successor],
                        ))
                    })
                    .collect::<Result<Vec<_>>>()
            }) {
                Ok(actions) => actions,
                Err(_) => return false,
            };
            let mut actual: Vec<_> = match permuted.shell.actions(new_state) {
                Ok(actions) => actions
                    .iter()
                    .map(|step| (step.action.clone(), step.successor))
                    .collect(),
                Err(_) => return false,
            };
            expected.sort();
            actual.sort();
            expected == actual
        });
        let candidate_weight_covariance = (0..self.shell.state_count()).all(|old_state| {
            let new_state = state_mapping[old_state];
            let mut expected = match self.candidate_weights(old_state).and_then(|candidates| {
                candidates
                    .into_iter()
                    .map(|candidate| {
                        Ok((
                            candidate.action.permuted(node_permutation)?,
                            state_mapping[candidate.successor],
                            candidate.weight,
                        ))
                    })
                    .collect::<Result<Vec<_>>>()
            }) {
                Ok(candidates) => candidates,
                Err(_) => return false,
            };
            let mut actual: Vec<_> = match permuted.candidate_weights(new_state) {
                Ok(candidates) => candidates
                    .into_iter()
                    .map(|candidate| (candidate.action, candidate.successor, candidate.weight))
                    .collect(),
                Err(_) => return false,
            };
            expected.sort();
            actual.sort();
            expected == actual
        });

        let path_count_covariance = (0..=self.horizon).all(|depth| {
            (0..self.shell.state_count()).all(|old_state| {
                self.path_counts[depth][old_state]
                    == permuted.path_counts[depth][state_mapping[old_state]]
            })
        });
        let transition_covariance = (0..self.shell.state_count()).all(|old_source| {
            (0..self.shell.state_count()).all(|old_target| {
                self.transition_ratio(old_source, old_target)
                    .is_ok_and(|old_ratio| {
                        permuted
                            .transition_ratio(state_mapping[old_source], state_mapping[old_target])
                            .is_ok_and(|new_ratio| old_ratio == new_ratio)
                    })
            })
        });
        let stationary_covariance = (0..self.shell.state_count()).all(|old_state| {
            self.stationary_ratio(old_state).is_ok_and(|old_ratio| {
                permuted
                    .stationary_ratio(state_mapping[old_state])
                    .is_ok_and(|new_ratio| old_ratio == new_ratio)
            })
        });

        Ok(PermutationCovarianceReport {
            state_mapping,
            state_covariance,
            action_covariance,
            candidate_weight_covariance,
            path_count_covariance,
            transition_covariance,
            stationary_covariance,
        })
    }

    pub fn transition_ratio(&self, source: usize, target: usize) -> Result<ExactRatio> {
        let numerator = self
            .transition_numerators
            .get(source)
            .and_then(|row| row.get(target))
            .cloned()
            .ok_or_else(|| AnalysisError::new("transition index is out of range"))?;
        ExactRatio::new(numerator, self.path_counts[self.horizon][source].clone())
    }

    pub fn stationary_ratio(&self, state: usize) -> Result<ExactRatio> {
        let numerator = self
            .stationary_weights
            .get(state)
            .cloned()
            .ok_or_else(|| AnalysisError::new("state index is out of range"))?;
        ExactRatio::new(numerator, self.stationary_normalization.clone())
    }

    pub fn stationary_weights(&self) -> &[BigUint] {
        &self.stationary_weights
    }

    pub fn stationary_normalization(&self) -> &BigUint {
        &self.stationary_normalization
    }

    pub fn transition_numerators(&self) -> &[Vec<BigUint>] {
        &self.transition_numerators
    }

    pub fn verify_exact(&self) -> ExactChecks {
        let state_count = self.shell.state_count();
        let path_count_recurrence = (1..=self.horizon).all(|depth| {
            multiply_adjacency_vector(self.shell.adjacency(), &self.path_counts[depth - 1])
                .is_ok_and(|row| row == self.path_counts[depth])
        });

        let row_stochasticity = (0..state_count).all(|source| {
            let row_sum = self.transition_numerators[source]
                .iter()
                .fold(BigUint::zero(), |sum, value| sum + value);
            row_sum == self.path_counts[self.horizon][source]
        });

        let reverse_support = (0..state_count).all(|source| {
            (0..state_count).all(|target| {
                self.transition_numerators[source][target].is_zero()
                    == self.transition_numerators[target][source].is_zero()
            })
        });

        let stationarity = (0..state_count).all(|target| {
            let incoming = (0..state_count).fold(BigUint::zero(), |sum, source| {
                sum + &self.path_counts[self.horizon - 1][source]
                    * &self.transition_numerators[source][target]
            });
            incoming == self.stationary_weights[target]
        });

        let detailed_balance = (0..state_count).all(|source| {
            (0..state_count).all(|target| {
                let forward = &self.stationary_weights[source]
                    * &self.transition_numerators[source][target]
                    * &self.path_counts[self.horizon][target];
                let reverse = &self.stationary_weights[target]
                    * &self.transition_numerators[target][source]
                    * &self.path_counts[self.horizon][source];
                forward == reverse
            })
        });

        ExactChecks {
            path_count_recurrence,
            row_stochasticity,
            reverse_support,
            stationarity,
            detailed_balance,
            cycle_balance: self.verify_cycle_balance(),
        }
    }

    fn verify_cycle_balance(&self) -> CycleBalanceReport {
        let cycles = fundamental_cycles(&self.transition_numerators);
        let mut balanced_cycles = 0;
        let mut unbalanced_cycles = Vec::new();
        for cycle in &cycles {
            if self.cycle_is_balanced(cycle) {
                balanced_cycles += 1;
            } else {
                unbalanced_cycles.push(cycle.clone());
            }
        }
        CycleBalanceReport {
            basis_cycles: cycles.len(),
            balanced_cycles,
            unbalanced_cycles,
        }
    }

    fn cycle_is_balanced(&self, cycle: &[usize]) -> bool {
        if cycle.len() < 3 {
            return true;
        }
        let mut forward_numerator = BigUint::one();
        let mut forward_denominator = BigUint::one();
        let mut reverse_numerator = BigUint::one();
        let mut reverse_denominator = BigUint::one();

        for index in 0..cycle.len() {
            let source = cycle[index];
            let target = cycle[(index + 1) % cycle.len()];
            forward_numerator *= &self.transition_numerators[source][target];
            forward_denominator *= &self.path_counts[self.horizon][source];
            reverse_numerator *= &self.transition_numerators[target][source];
            reverse_denominator *= &self.path_counts[self.horizon][target];
        }

        forward_numerator * reverse_denominator == reverse_numerator * forward_denominator
    }
}

fn multiply_adjacency_vector(adjacency: &[Vec<u32>], vector: &[BigUint]) -> Result<Vec<BigUint>> {
    if adjacency.len() != vector.len() || adjacency.iter().any(|row| row.len() != vector.len()) {
        return Err(AnalysisError::new(
            "adjacency and path-count vector shapes differ",
        ));
    }
    Ok(adjacency
        .iter()
        .map(|row| {
            row.iter()
                .zip(vector)
                .fold(BigUint::zero(), |sum, (&multiplicity, value)| {
                    if multiplicity == 0 {
                        sum
                    } else {
                        sum + BigUint::from(multiplicity) * value
                    }
                })
        })
        .collect())
}

fn fundamental_cycles(transition_numerators: &[Vec<BigUint>]) -> Vec<Vec<usize>> {
    let state_count = transition_numerators.len();
    if state_count <= 1 {
        return Vec::new();
    }

    let mut support = vec![Vec::new(); state_count];
    let mut support_edges = Vec::new();
    for source in 0..state_count {
        for target in (source + 1)..state_count {
            if !transition_numerators[source][target].is_zero()
                || !transition_numerators[target][source].is_zero()
            {
                support[source].push(target);
                support[target].push(source);
                support_edges.push((source, target));
            }
        }
    }

    let mut tree = vec![Vec::new(); state_count];
    let mut tree_edges = BTreeSet::new();
    let mut visited = vec![false; state_count];
    let mut queue = VecDeque::from([0]);
    visited[0] = true;
    while let Some(source) = queue.pop_front() {
        for &target in &support[source] {
            if !visited[target] {
                visited[target] = true;
                queue.push_back(target);
                tree[source].push(target);
                tree[target].push(source);
                tree_edges.insert((source.min(target), source.max(target)));
            }
        }
    }

    support_edges
        .into_iter()
        .filter(|edge| !tree_edges.contains(edge))
        .filter_map(|(source, target)| tree_path(&tree, source, target))
        .collect()
}

fn tree_path(tree: &[Vec<usize>], source: usize, target: usize) -> Option<Vec<usize>> {
    let mut predecessor = vec![None; tree.len()];
    let mut queue = VecDeque::from([source]);
    predecessor[source] = Some(source);
    while let Some(node) = queue.pop_front() {
        if node == target {
            break;
        }
        for &neighbor in &tree[node] {
            if predecessor[neighbor].is_none() {
                predecessor[neighbor] = Some(node);
                queue.push_back(neighbor);
            }
        }
    }
    predecessor[target]?;

    let mut reverse_path = vec![target];
    let mut cursor = target;
    while cursor != source {
        cursor = predecessor[cursor]?;
        reverse_path.push(cursor);
    }
    reverse_path.reverse();
    Some(reverse_path)
}

pub(crate) fn biguint_log2(value: &BigUint) -> Result<f64> {
    if value.is_zero() {
        return Err(AnalysisError::new("logarithm of zero BigUint"));
    }
    let bits = value.bits();
    let shift = bits.saturating_sub(53);
    let top = (value >> shift)
        .to_u64()
        .ok_or_else(|| AnalysisError::new("failed to extract BigUint mantissa"))?;
    Ok((top as f64).log2() + shift as f64)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Fixture;

    fn bipartite_two_state_shell() -> StateShell {
        StateShell::enumerate(
            Fixture::new(2, [(0, 1)], 1).expect("valid two-node development fixture"),
        )
        .expect("two-state allocation shell")
    }

    #[test]
    fn removing_wait_exposes_period_two_on_a_bipartite_development_shell() {
        let shell = bipartite_two_state_shell();
        let left = shell.state_index(&[1, 0]).expect("left state");
        let right = shell.state_index(&[0, 1]).expect("right state");
        let mut no_wait = shell.adjacency().to_vec();
        for (state, row) in no_wait.iter_mut().enumerate() {
            row[state] = 0;
        }

        let mut initial = vec![BigUint::zero(); shell.state_count()];
        initial[left] = BigUint::one();
        let after_one = multiply_adjacency_vector(&no_wait, &initial).expect("one step");
        let after_two = multiply_adjacency_vector(&no_wait, &after_one).expect("two steps");

        assert_eq!(after_one[left], BigUint::zero());
        assert_eq!(after_one[right], BigUint::one());
        assert_eq!(after_two[left], BigUint::one());
        assert_eq!(after_two[right], BigUint::zero());
    }

    #[test]
    fn directed_asymmetry_is_rejected_by_the_exact_theorem_gates() {
        let shell = bipartite_two_state_shell();
        let left = shell.state_index(&[1, 0]).expect("left state");
        let right = shell.state_index(&[0, 1]).expect("right state");
        let mut kernel = ExactKernel::build(shell, 1).expect("symmetric development kernel");

        kernel.transition_numerators[left][left] += BigUint::one();
        kernel.transition_numerators[left][right] = BigUint::zero();

        let checks = kernel.verify_exact();
        assert!(checks.row_stochasticity);
        assert!(!checks.reverse_support);
        assert!(!checks.stationarity);
        assert!(!checks.detailed_balance);
        assert!(!checks.all_passed());
    }

    #[test]
    fn path_count_recurrence_preserves_action_label_multiplicity() {
        let continuation = vec![BigUint::from(3_u8), BigUint::from(5_u8)];
        let action_labelled = vec![vec![1, 2], vec![2, 1]];
        let binary_support = vec![vec![1, 1], vec![1, 1]];

        let labelled =
            multiply_adjacency_vector(&action_labelled, &continuation).expect("labelled count");
        let collapsed =
            multiply_adjacency_vector(&binary_support, &continuation).expect("binary count");

        assert_eq!(labelled, vec![BigUint::from(13_u8), BigUint::from(11_u8)]);
        assert_eq!(collapsed, vec![BigUint::from(8_u8), BigUint::from(8_u8)]);
        assert_ne!(labelled, collapsed);
    }
}
