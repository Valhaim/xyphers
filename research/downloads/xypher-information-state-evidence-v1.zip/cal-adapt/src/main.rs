#![forbid(unsafe_code)]

use std::collections::{BTreeMap, BTreeSet};
use std::env;
use std::fmt;
use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::{Component, Path, PathBuf};

use num_bigint::BigUint;
use num_integer::Integer;
use num_traits::Zero;
use serde::{Deserialize, Serialize};
use xypher_calorimeter_analysis::{
    compare_kernels, Action, Analysis, ExactDistribution, ExactKernel, ExactRatio,
    Fixture as AnalysisFixture, SpectralGapCertificate, KL_NEGATIVE_TOLERANCE_BITS,
    MFPT_BELLMAN_TOLERANCE, MIXING_TV_THRESHOLD, PROBABILITY_TOLERANCE,
};
use xypher_calorimeter_manifest::{
    canonical_json_bytes, default_sidecar_path, hash_sidecar_bytes, raw_sha256_hex,
    read_canonical_json, relabel_balances, relabel_edges, relabel_partition,
    validate_claim_contract, validate_core_manifest, validate_final_manifest,
    validate_fixture_catalog, validate_frozen_prediction_commitment, validate_genesis_recipe,
    validate_policy_config, validate_prediction_commitment_structure, validate_reporting_policy,
    ClaimContract, ComponentIdentity, CoreManifest, FinalEpisodeDescriptor, FinalManifest,
    Fixture as ManifestFixture, FixtureCatalog, GenesisRecipe, PolicyConfig,
    PredictionCanonicalDocumentIdentity, PredictionCommitment, PredictionCommitmentFileIdentity,
    RawFileIdentity, ReportingPartition, ReportingPolicy, CLAIM_CONTRACT_PATH, FINAL_MANIFEST_PATH,
    FIXTURE_CATALOG_PATH, GENESIS_RECIPE_PATH, MANIFEST_CORE_PATH, POLICY_CONFIG_PATH,
    PREDICTION_COMMITMENT_DOMAIN, PREDICTION_COMMITMENT_SCHEMA, PREDICTION_DOCUMENT_SCHEMA,
    PREDICTION_PATH, PREDICTION_PAYLOAD_SCHEMA, PREDICTION_SIDECAR_PATH, REPORTING_POLICY_PATH,
};

const KERNEL_SCHEMA: &str = "xypher-calorimeter-kernel-prediction.v2";
const ANALYSIS_SCHEMA: &str = "xypher-calorimeter-empirical-analysis.v1";
const COLLECTION_INDEX_SCHEMA: &str = "xypher-calorimeter-normalized-collection.v1";
const TRAJECTORY_SCHEMA: &str = "xypher-calorimeter-trajectory.v1";
const COLLECTION_INDEX_FILE: &str = "collection-index.json";
const PROVENANCE_LABEL: &str = "verified-under-committed-calorimeter-apparatus";
const PROVENANCE_CAVEAT: &str =
    "apparatus consistency only; no binary remote attestation; unjournalled calls are not excluded";
const MODEL_PRIMARY: &str = "q_h";
const MODEL_H1: &str = "h1";
const MODEL_GREEDY: &str = "greedy";
const MODEL_ROTATED: &str = "left_rotated";

#[derive(Debug)]
struct CliError(String);

impl CliError {
    fn new(message: impl Into<String>) -> Self {
        Self(message.into())
    }
}

impl fmt::Display for CliError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(formatter)
    }
}

impl std::error::Error for CliError {}

impl From<std::io::Error> for CliError {
    fn from(value: std::io::Error) -> Self {
        Self(value.to_string())
    }
}

impl From<serde_json::Error> for CliError {
    fn from(value: serde_json::Error) -> Self {
        Self(value.to_string())
    }
}

impl From<xypher_calorimeter_analysis::AnalysisError> for CliError {
    fn from(value: xypher_calorimeter_analysis::AnalysisError) -> Self {
        Self(value.to_string())
    }
}

impl From<xypher_calorimeter_manifest::ManifestError> for CliError {
    fn from(value: xypher_calorimeter_manifest::ManifestError) -> Self {
        Self(value.to_string())
    }
}

type Result<T> = std::result::Result<T, CliError>;

fn usage() -> &'static str {
    "usage:
  xypher-calorimeter-analysis predict --repo-root <path> --core <path> --manifest <path> --output <path>
  xypher-calorimeter-analysis verify-prediction --repo-root <path> --core <path> --manifest <path> --predictions <path> --expected-commitment-length-bytes <u64> --expected-commitment-sha256 <hex> --expected-sidecar-length-bytes <u64> --expected-sidecar-sha256 <hex>
  xypher-calorimeter-analysis analyze --repo-root <path> --core <path> --manifest <path> --predictions <path> --normalized <path> --output <path>"
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ExpectedPredictionIdentities {
    commitment_length_bytes: u64,
    commitment_sha256: String,
    sidecar_length_bytes: u64,
    sidecar_sha256: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum Command {
    Predict {
        repo_root: PathBuf,
        core: PathBuf,
        manifest: PathBuf,
        output: PathBuf,
    },
    VerifyPrediction {
        repo_root: PathBuf,
        core: PathBuf,
        manifest: PathBuf,
        predictions: PathBuf,
        expected_identities: ExpectedPredictionIdentities,
    },
    Analyze {
        repo_root: PathBuf,
        core: PathBuf,
        manifest: PathBuf,
        predictions: PathBuf,
        normalized: PathBuf,
        output: PathBuf,
    },
}

fn parse_from(args: impl IntoIterator<Item = String>) -> Result<Command> {
    let mut args = args.into_iter();
    let command = args.next().ok_or_else(|| CliError::new(usage()))?;
    let mut values = BTreeMap::<String, String>::new();
    while let Some(flag) = args.next() {
        if !flag.starts_with("--") {
            return Err(CliError::new(format!(
                "unexpected positional argument {flag}\n{}",
                usage()
            )));
        }
        let value = args
            .next()
            .ok_or_else(|| CliError::new(format!("missing value for {flag}\n{}", usage())))?;
        if values.insert(flag.clone(), value).is_some() {
            return Err(CliError::new(format!(
                "duplicate option {flag}\n{}",
                usage()
            )));
        }
    }
    let required = |values: &mut BTreeMap<String, String>, key: &str| {
        values
            .remove(key)
            .ok_or_else(|| CliError::new(format!("missing {key}\n{}", usage())))
    };
    let parsed = match command.as_str() {
        "predict" => Command::Predict {
            repo_root: PathBuf::from(required(&mut values, "--repo-root")?),
            core: PathBuf::from(required(&mut values, "--core")?),
            manifest: PathBuf::from(required(&mut values, "--manifest")?),
            output: PathBuf::from(required(&mut values, "--output")?),
        },
        "verify-prediction" => {
            let commitment_sha256 = required(&mut values, "--expected-commitment-sha256")?;
            validate_lower_hex(
                "expected prediction commitment SHA-256",
                &commitment_sha256,
                64,
            )?;
            let sidecar_sha256 = required(&mut values, "--expected-sidecar-sha256")?;
            validate_lower_hex("expected prediction sidecar SHA-256", &sidecar_sha256, 64)?;
            Command::VerifyPrediction {
                repo_root: PathBuf::from(required(&mut values, "--repo-root")?),
                core: PathBuf::from(required(&mut values, "--core")?),
                manifest: PathBuf::from(required(&mut values, "--manifest")?),
                predictions: PathBuf::from(required(&mut values, "--predictions")?),
                expected_identities: ExpectedPredictionIdentities {
                    commitment_length_bytes: parse_canonical_u64(
                        "expected prediction commitment length",
                        &required(&mut values, "--expected-commitment-length-bytes")?,
                    )?,
                    commitment_sha256,
                    sidecar_length_bytes: parse_canonical_u64(
                        "expected prediction sidecar length",
                        &required(&mut values, "--expected-sidecar-length-bytes")?,
                    )?,
                    sidecar_sha256,
                },
            }
        }
        "analyze" => Command::Analyze {
            repo_root: PathBuf::from(required(&mut values, "--repo-root")?),
            core: PathBuf::from(required(&mut values, "--core")?),
            manifest: PathBuf::from(required(&mut values, "--manifest")?),
            predictions: PathBuf::from(required(&mut values, "--predictions")?),
            normalized: PathBuf::from(required(&mut values, "--normalized")?),
            output: PathBuf::from(required(&mut values, "--output")?),
        },
        _ => return Err(CliError::new(usage())),
    };
    if let Some((unknown, _)) = values.into_iter().next() {
        return Err(CliError::new(format!(
            "unknown option {unknown}\n{}",
            usage()
        )));
    }
    Ok(parsed)
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct FiniteF64 {
    bits: String,
    decimal: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(untagged)]
enum F64Doc {
    Finite(FiniteF64),
    Special(String),
}

impl F64Doc {
    fn from_value(value: f64) -> Self {
        if value.is_nan() {
            Self::Special("undefined".to_owned())
        } else if value == f64::INFINITY {
            Self::Special("positive_infinity".to_owned())
        } else if value == f64::NEG_INFINITY {
            Self::Special("negative_infinity".to_owned())
        } else {
            Self::Finite(FiniteF64 {
                bits: format!("{:016x}", value.to_bits()),
                decimal: value.to_string(),
            })
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ExactRatioDoc {
    denominator: String,
    numerator: String,
}

impl ExactRatioDoc {
    fn from_ratio(ratio: &ExactRatio) -> Self {
        Self {
            denominator: ratio.denominator().to_str_radix(10),
            numerator: ratio.numerator().to_str_radix(10),
        }
    }

    fn to_ratio(&self) -> Result<ExactRatio> {
        ExactRatio::new(
            parse_biguint("exact numerator", &self.numerator)?,
            parse_biguint("exact denominator", &self.denominator)?,
        )
        .map_err(Into::into)
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ExactDistributionDoc {
    denominator: String,
    numerators: Vec<String>,
}

impl ExactDistributionDoc {
    fn from_distribution(distribution: &ExactDistribution) -> Self {
        Self {
            denominator: distribution.denominator().to_str_radix(10),
            numerators: distribution
                .numerators()
                .iter()
                .map(|value| value.to_str_radix(10))
                .collect(),
        }
    }

    fn from_parts(numerators: &[BigUint], denominator: &BigUint) -> Self {
        Self {
            denominator: denominator.to_str_radix(10),
            numerators: numerators
                .iter()
                .map(|value| value.to_str_radix(10))
                .collect(),
        }
    }

    fn probabilities(&self) -> Result<Vec<f64>> {
        let denominator = parse_biguint("distribution denominator", &self.denominator)?;
        self.numerators
            .iter()
            .map(|numerator| {
                ExactRatio::new(
                    parse_biguint("distribution numerator", numerator)?,
                    denominator.clone(),
                )?
                .to_f64()
                .map_err(Into::into)
            })
            .collect()
    }
}

fn parse_biguint(label: &str, value: &str) -> Result<BigUint> {
    if value.is_empty() || !value.bytes().all(|byte| byte.is_ascii_digit()) {
        return Err(CliError::new(format!(
            "{label} is not an unsigned decimal string"
        )));
    }
    BigUint::parse_bytes(value.as_bytes(), 10)
        .ok_or_else(|| CliError::new(format!("{label} cannot be parsed")))
}

fn parse_unsigned<T>(label: &str, value: &str) -> Result<T>
where
    T: std::str::FromStr,
{
    if value.is_empty() || !value.bytes().all(|byte| byte.is_ascii_digit()) {
        return Err(CliError::new(format!(
            "{label} is not an unsigned decimal string"
        )));
    }
    value
        .parse()
        .map_err(|_| CliError::new(format!("{label} is outside its integer range")))
}

fn parse_canonical_u64(label: &str, value: &str) -> Result<u64> {
    let parsed = parse_unsigned::<u64>(label, value)?;
    if parsed.to_string() != value {
        return Err(CliError::new(format!("{label} is not canonically encoded")));
    }
    Ok(parsed)
}

fn parse_finite_positive_f64(label: &str, value: &str) -> Result<f64> {
    let parsed = value
        .parse::<f64>()
        .map_err(|_| CliError::new(format!("{label} is not a decimal f64")))?;
    if !parsed.is_finite() || parsed <= 0.0 || parsed.to_string() != value {
        return Err(CliError::new(format!(
            "{label} is not a canonical finite positive f64"
        )));
    }
    Ok(parsed)
}

fn parse_positive_decimal_f64(label: &str, value: &str) -> Result<f64> {
    let parsed = value
        .parse::<f64>()
        .map_err(|_| CliError::new(format!("{label} is not a decimal f64")))?;
    if !parsed.is_finite() || parsed <= 0.0 {
        return Err(CliError::new(format!(
            "{label} is not a finite positive f64"
        )));
    }
    Ok(parsed)
}

fn parse_unit_interval_f64(label: &str, value: &str) -> Result<f64> {
    let parsed = value
        .parse::<f64>()
        .map_err(|_| CliError::new(format!("{label} is not a decimal f64")))?;
    if !parsed.is_finite() || parsed <= 0.0 || parsed >= 1.0 {
        return Err(CliError::new(format!(
            "{label} is not strictly between zero and one"
        )));
    }
    Ok(parsed)
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
enum ActionDoc {
    Wait,
    Transfer {
        from: String,
        quantum_microtau: String,
        to: String,
    },
}

impl ActionDoc {
    fn from_action(action: &Action, quantum: u64) -> Result<Self> {
        match action {
            Action::Wait => Ok(Self::Wait),
            Action::Transfer { from, to } => Ok(Self::Transfer {
                from: u32::try_from(from + 1)
                    .map_err(|_| CliError::new("action source exceeds u32"))?
                    .to_string(),
                quantum_microtau: quantum.to_string(),
                to: u32::try_from(to + 1)
                    .map_err(|_| CliError::new("action target exceeds u32"))?
                    .to_string(),
            }),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct StateDoc {
    balances_microtau: Vec<String>,
    state_index: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ActionProbabilityDoc {
    action: ActionDoc,
    continuation_weight: String,
    greedy_probability: ExactRatioDoc,
    h1_probability: ExactRatioDoc,
    left_rotated_probability: ExactRatioDoc,
    multiplicity: String,
    primary_probability: ExactRatioDoc,
    successor_state: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct SuccessorProbabilityDoc {
    multiplicity: String,
    probability: ExactRatioDoc,
    successor_state: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ActionRowDoc {
    actions: Vec<ActionProbabilityDoc>,
    source_state: String,
    successor_probabilities: Vec<SuccessorProbabilityDoc>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PathCountDoc {
    counts: Vec<String>,
    depth: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ExactChecksDoc {
    balanced_basis_cycle_count: String,
    basis_cycle_count: String,
    cycle_balance: bool,
    detailed_balance: bool,
    path_count_recurrence: bool,
    reverse_support: bool,
    row_stochasticity: bool,
    stationarity: bool,
    unbalanced_cycles: Vec<Vec<String>>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PermutationCovarianceDoc {
    action_covariance: bool,
    all_passed: bool,
    candidate_weight_covariance: bool,
    path_count_covariance: bool,
    state_covariance: bool,
    state_mapping: Vec<String>,
    stationary_covariance: bool,
    transition_covariance: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PartitionDefinitionDoc {
    left_nodes: Vec<String>,
    partition_id: String,
    right_nodes: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PartitionMarginalDoc {
    entropy_bits: F64Doc,
    left_inventory_mean_microtau: F64Doc,
    left_inventory_mean_microtau_exact: ExactRatioDoc,
    left_inventory_variance_microtau_squared: F64Doc,
    left_inventory_variance_microtau_squared_exact: ExactRatioDoc,
    marginal: ExactDistributionDoc,
    partition_id: String,
    support_microtau: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct TransientPointDoc {
    endpoint_entropy_bits: F64Doc,
    exact_state_distribution: ExactDistributionDoc,
    opportunity: String,
    partition_marginals: Vec<PartitionMarginalDoc>,
    relative_entropy_bits: F64Doc,
    total_variation_to_stationary: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct StartTransientDoc {
    first_below_mixing_threshold: String,
    initial_state: String,
    points: Vec<TransientPointDoc>,
    start_index: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct SpectralDoc {
    eigenvalues: Vec<F64Doc>,
    eigenvector_norm_lower_bounds: Vec<F64Doc>,
    eigenvector_norm_upper_bounds: Vec<F64Doc>,
    global_eigenvalue_error_upper_bound: F64Doc,
    jacobi_sweeps: String,
    maximum_eigenpair_residual: F64Doc,
    maximum_normalized_eigenpair_residual_upper_bound: F64Doc,
    maximum_off_diagonal: F64Doc,
    maximum_orthogonality_residual: F64Doc,
    maximum_reconstruction_residual: F64Doc,
    normalized_eigenpair_residual_upper_bounds: Vec<F64Doc>,
    orthogonality_frobenius_residual_upper_bound: F64Doc,
    relaxation_scale: F64Doc,
    spectral_gap: F64Doc,
    spectral_gap_certificate: SpectralGapCertificateDoc,
    subdominant_eigenvalue: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct SpectralIntervalDoc {
    lower_bound: F64Doc,
    upper_bound: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct SpectralGapCertificateDoc {
    gap_interval: SpectralIntervalDoc,
    mode_modulus_intervals: Vec<SpectralIntervalDoc>,
    next_distinct_modulus_upper_bound: F64Doc,
    stationary_modulus_lower_bound: F64Doc,
    subdominant_cluster_indices: Vec<String>,
    subdominant_modulus_interval: SpectralIntervalDoc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct SpectralScheduleAdmissionDoc {
    all_passed: bool,
    canonical_gap_certificate: SpectralGapCertificateDoc,
    canonical_interval_episode_length: String,
    declared_gap: F64Doc,
    frozen_episode_length: String,
    intersection_gap_interval: SpectralIntervalDoc,
    relabelled_gap_certificate: SpectralGapCertificateDoc,
    relabelled_interval_episode_length: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct EquilibriumDoc {
    effective_state_count: F64Doc,
    inverse_participation_ratio: F64Doc,
    localization_excess: F64Doc,
    maximum_mass_states: Vec<String>,
    maximum_state_mass: F64Doc,
    normalized_participation_ratio: F64Doc,
    participation_ratio: F64Doc,
    perron_square_limit: Vec<F64Doc>,
    perron_square_total_variation: F64Doc,
    shannon_entropy_bits: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct EntropyDoc {
    entropy_rate_bits_per_step: F64Doc,
    entropy_rate_deficit_bits_per_step: F64Doc,
    maximum_path_entropy_bits: F64Doc,
    minimum_path_entropy_bits: F64Doc,
    stationary_mean_path_entropy_bits: F64Doc,
    topological_entropy_bits_per_step: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct NumericalResidualsDoc {
    maximum_detailed_balance_residual: F64Doc,
    maximum_row_sum_residual: F64Doc,
    maximum_stationarity_residual: F64Doc,
    symmetric_similarity_asymmetry: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct H1ComparisonDoc {
    entropy_rate_delta_bits_per_step: F64Doc,
    maximum_row_total_variation: F64Doc,
    spectral_gap_delta: F64Doc,
    stationary_total_variation: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct StationaryFlowDoc {
    current_denominator: String,
    current_magnitude_numerator: String,
    current_sign: String,
    forward_flux: ExactRatioDoc,
    reverse_flux: ExactRatioDoc,
    source_state: String,
    target_state: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct FirstPassageDoc {
    kac_mean_return: Vec<F64Doc>,
    kac_mean_return_exact: Vec<ExactRatioDoc>,
    maximum_bellman_residual: F64Doc,
    mean_first_passage: Vec<Vec<F64Doc>>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct KernelPrediction {
    action_rows: Vec<ActionRowDoc>,
    edges: Vec<[String; 2]>,
    entropy: EntropyDoc,
    equilibrium: EquilibriumDoc,
    episode_length: String,
    exact_checks: ExactChecksDoc,
    fixed_category_count: String,
    fixture_id: String,
    h1_comparison: H1ComparisonDoc,
    horizon: String,
    inventory_microtau: String,
    node_count: String,
    numerical_residuals: NumericalResidualsDoc,
    partition_definitions: Vec<PartitionDefinitionDoc>,
    path_counts: Vec<PathCountDoc>,
    permutation_covariance: PermutationCovarianceDoc,
    permutation_id: String,
    permutation_index: String,
    schema: String,
    schedule_spectral_gap: F64Doc,
    spectral: SpectralDoc,
    spectral_schedule_admission: SpectralScheduleAdmissionDoc,
    state_shell: Vec<StateDoc>,
    stationary_distribution: ExactDistributionDoc,
    stationary_flows: Vec<StationaryFlowDoc>,
    stationary_partition_marginals: Vec<PartitionMarginalDoc>,
    transients: Vec<StartTransientDoc>,
    first_passage: FirstPassageDoc,
    unit_quantum_microtau: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PredictionPayload {
    fixed_category_count: String,
    kernels: Vec<KernelPrediction>,
    schema: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ToleranceContractDoc {
    exact_probability_absolute_tolerance: F64Doc,
    kl_negative_tolerance_bits: F64Doc,
    mfpt_bellman_absolute_tolerance: F64Doc,
    mixing_total_variation_threshold: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ReportFileIdentity {
    length_bytes: String,
    path: String,
    sha256: String,
}

impl From<&RawFileIdentity> for ReportFileIdentity {
    fn from(value: &RawFileIdentity) -> Self {
        Self {
            length_bytes: value.length_bytes.to_string(),
            path: value.path.clone(),
            sha256: value.sha256.clone(),
        }
    }
}

impl From<&LocalRawFileIdentity> for ReportFileIdentity {
    fn from(value: &LocalRawFileIdentity) -> Self {
        Self {
            length_bytes: value.length_bytes.to_string(),
            path: value.path.clone(),
            sha256: value.sha256.clone(),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PredictionDocument {
    all_load_bearing_prediction_gates_passed: bool,
    analysis_artifact: ReportFileIdentity,
    core_hash: String,
    decision_count: String,
    episode_count: String,
    final_manifest_hash: String,
    fixture_catalog_hash: String,
    genesis_recipe_hash: String,
    payload: PredictionPayload,
    payload_hash: String,
    policy_config_hash: String,
    reporting_policy_hash: String,
    schedule_hash: String,
    schema: String,
    tolerances: ToleranceContractDoc,
}

struct FrozenBundle {
    analysis_artifact: RawFileIdentity,
    catalog: FixtureCatalog,
    core: CoreManifest,
    core_hash: String,
    final_manifest: FinalManifest,
    final_manifest_hash: String,
    policy: PolicyConfig,
    reporting: ReportingPolicy,
}

fn canonical_repository_root(repo_root: &Path) -> Result<PathBuf> {
    let resolved = fs::canonicalize(repo_root)?;
    if !resolved.is_dir() {
        return Err(CliError::new("repository root is not a directory"));
    }
    Ok(resolved)
}

fn absolute_without_parent(path: &Path, label: &str) -> Result<PathBuf> {
    let mut absolute = if path.is_absolute() {
        PathBuf::new()
    } else {
        fs::canonicalize(env::current_dir()?)?
    };
    for component in path.components() {
        match component {
            Component::Prefix(prefix) => absolute.push(prefix.as_os_str()),
            Component::RootDir => absolute.push(Path::new(std::path::MAIN_SEPARATOR_STR)),
            Component::CurDir => {}
            Component::ParentDir => {
                return Err(CliError::new(format!(
                    "{label} contains a parent-directory component"
                )))
            }
            Component::Normal(name) => absolute.push(name),
        }
    }
    Ok(absolute)
}

fn read_exact_repository_file(
    repo_root: &Path,
    supplied: &Path,
    canonical_relative: &str,
    label: &str,
) -> Result<Vec<u8>> {
    let canonical = repo_root.join(canonical_relative);
    if absolute_without_parent(supplied, label)? != canonical {
        return Err(CliError::new(format!(
            "supplied {label} is not the canonical repository path {canonical_relative}"
        )));
    }
    let metadata = fs::symlink_metadata(&canonical)?;
    if metadata.file_type().is_symlink() || !metadata.is_file() {
        return Err(CliError::new(format!(
            "canonical {label} is not a regular non-symlink file"
        )));
    }
    Ok(fs::read(canonical)?)
}

impl FrozenBundle {
    fn load(
        repo_root: &Path,
        core_path: &Path,
        final_manifest_path: &Path,
        executable: &Path,
    ) -> Result<Self> {
        let repo_root = canonical_repository_root(repo_root)?;
        let supplied_core =
            read_exact_repository_file(&repo_root, core_path, MANIFEST_CORE_PATH, "core")?;
        let supplied_final = read_exact_repository_file(
            &repo_root,
            final_manifest_path,
            FINAL_MANIFEST_PATH,
            "final manifest",
        )?;
        let core = validate_core_manifest(&repo_root, &supplied_core)?;
        let final_manifest = validate_final_manifest(&repo_root, &supplied_core, &supplied_final)?;
        let catalog: FixtureCatalog = read_canonical_json(&repo_root.join(FIXTURE_CATALOG_PATH))?;
        let policy: PolicyConfig = read_canonical_json(&repo_root.join(POLICY_CONFIG_PATH))?;
        let reporting: ReportingPolicy =
            read_canonical_json(&repo_root.join(REPORTING_POLICY_PATH))?;
        let claims: ClaimContract = read_canonical_json(&repo_root.join(CLAIM_CONTRACT_PATH))?;
        let recipe: GenesisRecipe = read_canonical_json(&repo_root.join(GENESIS_RECIPE_PATH))?;
        validate_fixture_catalog(&catalog)?;
        validate_policy_config(&policy)?;
        validate_reporting_policy(&reporting, &policy)?;
        validate_claim_contract(&claims)?;
        validate_genesis_recipe(&recipe, &policy)?;
        if parse_positive_decimal_f64(
            "reporting exact-probability tolerance",
            &reporting.exact_probability_absolute_tolerance,
        )?
        .to_bits()
            != PROBABILITY_TOLERANCE.to_bits()
            || parse_positive_decimal_f64(
                "reporting KL tolerance",
                &reporting.kl_negative_tolerance_bits,
            )?
            .to_bits()
                != KL_NEGATIVE_TOLERANCE_BITS.to_bits()
            || parse_positive_decimal_f64(
                "reporting MFPT tolerance",
                &reporting.mfpt_bellman_absolute_tolerance,
            )?
            .to_bits()
                != MFPT_BELLMAN_TOLERANCE.to_bits()
            || parse_positive_decimal_f64(
                "reporting mixing threshold",
                &reporting.mixing_total_variation_threshold,
            )?
            .to_bits()
                != MIXING_TV_THRESHOLD.to_bits()
        {
            return Err(CliError::new(
                "analysis tolerances differ from the frozen reporting policy",
            ));
        }
        let analysis_component = core
            .components
            .get("analysis")
            .ok_or_else(|| CliError::new("core manifest has no analysis component"))?;
        let analysis_artifact =
            match_current_executable(executable, analysis_component, "analysis")?;
        Ok(Self {
            analysis_artifact,
            catalog,
            core_hash: raw_sha256_hex(&supplied_core),
            final_manifest_hash: raw_sha256_hex(&supplied_final),
            core,
            final_manifest,
            policy,
            reporting,
        })
    }
}

fn match_current_executable(
    executable: &Path,
    component: &ComponentIdentity,
    label: &str,
) -> Result<RawFileIdentity> {
    let metadata = fs::symlink_metadata(executable)?;
    if metadata.file_type().is_symlink() || !metadata.is_file() {
        return Err(CliError::new(format!(
            "running {label} executable is not a regular non-symlink file"
        )));
    }
    let bytes = fs::read(executable)?;
    let length = u64::try_from(bytes.len())
        .map_err(|_| CliError::new("running executable length exceeds u64"))?;
    let digest = raw_sha256_hex(&bytes);
    let matches = component
        .artifact_set
        .files
        .iter()
        .filter(|artifact| artifact.length_bytes == length && artifact.sha256 == digest)
        .cloned()
        .collect::<Vec<_>>();
    if matches.len() != 1 {
        return Err(CliError::new(format!(
            "running {label} executable bytes do not match exactly one frozen artifact"
        )));
    }
    Ok(matches[0].clone())
}

fn build_prediction(bundle: &FrozenBundle) -> Result<PredictionDocument> {
    let mut kernels = Vec::new();
    let mut category_count = 0u64;
    for fixture in &bundle.catalog.fixtures {
        for &horizon in &fixture.horizons {
            let schedule = bundle
                .policy
                .schedules
                .iter()
                .find(|row| row.fixture_id == fixture.fixture_id && row.horizon == horizon)
                .ok_or_else(|| CliError::new("missing fixture/horizon reporting schedule"))?;
            for (permutation_index, _) in fixture.permutations.iter().enumerate() {
                let kernel = build_kernel_prediction(
                    fixture,
                    horizon,
                    u8::try_from(permutation_index)
                        .map_err(|_| CliError::new("permutation index exceeds u8"))?,
                    schedule.episode_length,
                    &schedule.spectral_gap,
                    bundle.policy.action_quantum_microtau,
                )?;
                category_count = category_count
                    .checked_add(
                        kernel
                            .fixed_category_count
                            .parse::<u64>()
                            .map_err(|_| CliError::new("kernel category count is not u64"))?,
                    )
                    .ok_or_else(|| CliError::new("fixed category count overflow"))?;
                kernels.push(kernel);
            }
        }
    }
    let payload = PredictionPayload {
        fixed_category_count: category_count.to_string(),
        kernels,
        schema: PREDICTION_PAYLOAD_SCHEMA.to_owned(),
    };
    let payload_hash = raw_sha256_hex(&canonical_json_bytes(&payload)?);
    Ok(PredictionDocument {
        all_load_bearing_prediction_gates_passed: true,
        analysis_artifact: ReportFileIdentity::from(&bundle.analysis_artifact),
        core_hash: bundle.core_hash.clone(),
        decision_count: bundle.final_manifest.schedule.decision_count.to_string(),
        episode_count: bundle.final_manifest.schedule.episode_count.to_string(),
        final_manifest_hash: bundle.final_manifest_hash.clone(),
        fixture_catalog_hash: bundle.core.fixture_catalog_hash.clone(),
        genesis_recipe_hash: bundle.core.genesis_recipe_hash.clone(),
        payload,
        payload_hash,
        policy_config_hash: bundle.core.policy_config_hash.clone(),
        reporting_policy_hash: bundle.core.reporting_policy_hash.clone(),
        schedule_hash: raw_sha256_hex(&canonical_json_bytes(&bundle.final_manifest.schedule)?),
        schema: PREDICTION_DOCUMENT_SCHEMA.to_owned(),
        tolerances: ToleranceContractDoc {
            exact_probability_absolute_tolerance: F64Doc::from_value(PROBABILITY_TOLERANCE),
            kl_negative_tolerance_bits: F64Doc::from_value(KL_NEGATIVE_TOLERANCE_BITS),
            mfpt_bellman_absolute_tolerance: F64Doc::from_value(MFPT_BELLMAN_TOLERANCE),
            mixing_total_variation_threshold: F64Doc::from_value(MIXING_TV_THRESHOLD),
        },
    })
}

fn build_prediction_commitment_structure(
    prediction: &PredictionDocument,
    prediction_bytes: &[u8],
) -> Result<PredictionCommitment> {
    let regenerated_payload_hash = raw_sha256_hex(&canonical_json_bytes(&prediction.payload)?);
    if prediction.schema != PREDICTION_DOCUMENT_SCHEMA
        || prediction_bytes != canonical_json_bytes(prediction)?
        || prediction.payload_hash != regenerated_payload_hash
    {
        return Err(CliError::new(
            "prediction commitment input is not a canonical prediction document with a valid payload hash",
        ));
    }
    let commitment = PredictionCommitment {
        all_load_bearing_prediction_gates_passed: prediction
            .all_load_bearing_prediction_gates_passed,
        analysis_artifact: PredictionCommitmentFileIdentity {
            length_bytes: prediction.analysis_artifact.length_bytes.clone(),
            path: prediction.analysis_artifact.path.clone(),
            sha256: prediction.analysis_artifact.sha256.clone(),
        },
        canonical_document: PredictionCanonicalDocumentIdentity {
            length_bytes: prediction_bytes.len().to_string(),
            schema: prediction.schema.clone(),
            sha256: raw_sha256_hex(prediction_bytes),
        },
        commitment_domain: PREDICTION_COMMITMENT_DOMAIN.to_owned(),
        core_hash: prediction.core_hash.clone(),
        decision_count: prediction.decision_count.clone(),
        episode_count: prediction.episode_count.clone(),
        final_manifest_hash: prediction.final_manifest_hash.clone(),
        fixture_catalog_hash: prediction.fixture_catalog_hash.clone(),
        genesis_recipe_hash: prediction.genesis_recipe_hash.clone(),
        payload_hash: prediction.payload_hash.clone(),
        payload_schema: prediction.payload.schema.clone(),
        policy_config_hash: prediction.policy_config_hash.clone(),
        reporting_policy_hash: prediction.reporting_policy_hash.clone(),
        schedule_hash: prediction.schedule_hash.clone(),
        schema: PREDICTION_COMMITMENT_SCHEMA.to_owned(),
        tolerances: serde_json::to_value(&prediction.tolerances)?,
    };
    validate_prediction_commitment_structure(&commitment)?;
    Ok(commitment)
}

fn build_prediction_commitment(
    prediction: &PredictionDocument,
    prediction_bytes: &[u8],
) -> Result<PredictionCommitment> {
    let commitment = build_prediction_commitment_structure(prediction, prediction_bytes)?;
    validate_frozen_prediction_commitment(&commitment)?;
    Ok(commitment)
}

fn validate_regenerated_prediction_commitment_structure(
    supplied_commitment: &PredictionCommitment,
    supplied_commitment_bytes: &[u8],
    prediction: &PredictionDocument,
) -> Result<()> {
    let prediction_bytes = canonical_json_bytes(prediction)?;
    let expected_commitment = build_prediction_commitment_structure(prediction, &prediction_bytes)?;
    if supplied_commitment != &expected_commitment
        || supplied_commitment_bytes != canonical_json_bytes(&expected_commitment)?
    {
        return Err(CliError::new(
            "prediction document does not exactly regenerate to the canonical commitment under the frozen analysis apparatus",
        ));
    }
    Ok(())
}

fn validate_regenerated_prediction_commitment(
    supplied_commitment: &PredictionCommitment,
    supplied_commitment_bytes: &[u8],
    prediction: &PredictionDocument,
) -> Result<()> {
    validate_frozen_prediction_commitment(supplied_commitment)?;
    validate_regenerated_prediction_commitment_structure(
        supplied_commitment,
        supplied_commitment_bytes,
        prediction,
    )
}

fn spectral_gap_certificate_doc(certificate: &SpectralGapCertificate) -> SpectralGapCertificateDoc {
    SpectralGapCertificateDoc {
        gap_interval: SpectralIntervalDoc {
            lower_bound: F64Doc::from_value(certificate.gap_lower_bound),
            upper_bound: F64Doc::from_value(certificate.gap_upper_bound),
        },
        mode_modulus_intervals: certificate
            .mode_modulus_intervals
            .iter()
            .map(|interval| SpectralIntervalDoc {
                lower_bound: F64Doc::from_value(interval.lower_bound),
                upper_bound: F64Doc::from_value(interval.upper_bound),
            })
            .collect(),
        next_distinct_modulus_upper_bound: F64Doc::from_value(
            certificate.next_distinct_modulus_upper_bound,
        ),
        stationary_modulus_lower_bound: F64Doc::from_value(
            certificate.stationary_modulus_lower_bound,
        ),
        subdominant_cluster_indices: certificate
            .subdominant_cluster_indices
            .iter()
            .map(ToString::to_string)
            .collect(),
        subdominant_modulus_interval: SpectralIntervalDoc {
            lower_bound: F64Doc::from_value(certificate.subdominant_modulus_lower_bound),
            upper_bound: F64Doc::from_value(certificate.subdominant_modulus_upper_bound),
        },
    }
}

fn next_up_f64(value: f64) -> f64 {
    if value.is_nan() || value == f64::INFINITY {
        return value;
    }
    if value == 0.0 {
        return f64::from_bits(1);
    }
    if value > 0.0 {
        f64::from_bits(value.to_bits() + 1)
    } else {
        f64::from_bits(value.to_bits() - 1)
    }
}

fn next_down_f64(value: f64) -> f64 {
    if value.is_nan() || value == f64::NEG_INFINITY {
        return value;
    }
    if value == 0.0 {
        return -f64::from_bits(1);
    }
    if value > 0.0 {
        f64::from_bits(value.to_bits() - 1)
    } else {
        f64::from_bits(value.to_bits() + 1)
    }
}

fn multiply_up_nonnegative(left: f64, right: f64) -> f64 {
    if left == 0.0 || right == 0.0 {
        0.0
    } else {
        next_up_f64(left * right)
    }
}

fn multiply_down_nonnegative(left: f64, right: f64) -> f64 {
    if left == 0.0 || right == 0.0 {
        0.0
    } else {
        next_down_f64(left * right).max(0.0)
    }
}

fn require_frozen_episode_length_for_gap_interval(
    horizon: u32,
    frozen_episode_length: u64,
    gap_lower_bound: f64,
    gap_upper_bound: f64,
) -> Result<()> {
    if !gap_lower_bound.is_finite()
        || !gap_upper_bound.is_finite()
        || gap_lower_bound <= 0.0
        || gap_lower_bound > gap_upper_bound
    {
        return Err(CliError::new(
            "episode-length admission requires a finite positive ordered gap interval",
        ));
    }
    let horizon_floor = u64::from(horizon)
        .checked_mul(10)
        .ok_or_else(|| CliError::new("episode-length horizon floor overflow"))?;
    if frozen_episode_length < horizon_floor || frozen_episode_length == 0 {
        return Err(CliError::new(
            "frozen episode length is below the preregistered horizon floor",
        ));
    }
    if frozen_episode_length > (1_u64 << f64::MANTISSA_DIGITS) {
        return Err(CliError::new(
            "episode length is not exactly representable as f64",
        ));
    }
    let upper_step_bound = multiply_down_nonnegative(gap_lower_bound, frozen_episode_length as f64);
    if upper_step_bound < 10.0 {
        return Err(CliError::new(
            "certified gap interval exceeds the frozen episode length",
        ));
    }
    if frozen_episode_length > horizon_floor {
        let lower_step_bound = multiply_up_nonnegative(
            gap_upper_bound,
            frozen_episode_length.saturating_sub(1) as f64,
        );
        if lower_step_bound >= 10.0 {
            return Err(CliError::new(
                "certified gap interval falls below the frozen episode length",
            ));
        }
    }
    Ok(())
}

fn admit_spectral_schedule(
    canonical: &xypher_calorimeter_analysis::SpectralReport,
    relabelled: &xypher_calorimeter_analysis::SpectralReport,
    horizon: u32,
    frozen_episode_length: u64,
    declared_gap: f64,
) -> Result<SpectralScheduleAdmissionDoc> {
    let canonical_certificate = &canonical.spectral_gap_certificate;
    let relabelled_certificate = &relabelled.spectral_gap_certificate;
    let intersection_lower = canonical_certificate
        .gap_lower_bound
        .max(relabelled_certificate.gap_lower_bound);
    let intersection_upper = canonical_certificate
        .gap_upper_bound
        .min(relabelled_certificate.gap_upper_bound);
    if intersection_lower > intersection_upper
        || declared_gap < intersection_lower
        || declared_gap > intersection_upper
    {
        return Err(CliError::new(
            "declared schedule gap is outside the canonical/relabelled certified intersection",
        ));
    }

    require_frozen_episode_length_for_gap_interval(
        horizon,
        frozen_episode_length,
        canonical_certificate.gap_lower_bound,
        canonical_certificate.gap_upper_bound,
    )?;
    require_frozen_episode_length_for_gap_interval(
        horizon,
        frozen_episode_length,
        relabelled_certificate.gap_lower_bound,
        relabelled_certificate.gap_upper_bound,
    )?;
    for point in [
        declared_gap,
        canonical.spectral_gap,
        relabelled.spectral_gap,
    ] {
        require_frozen_episode_length_for_gap_interval(
            horizon,
            frozen_episode_length,
            point,
            point,
        )?;
    }

    Ok(SpectralScheduleAdmissionDoc {
        all_passed: true,
        canonical_gap_certificate: spectral_gap_certificate_doc(canonical_certificate),
        canonical_interval_episode_length: frozen_episode_length.to_string(),
        declared_gap: F64Doc::from_value(declared_gap),
        frozen_episode_length: frozen_episode_length.to_string(),
        intersection_gap_interval: SpectralIntervalDoc {
            lower_bound: F64Doc::from_value(intersection_lower),
            upper_bound: F64Doc::from_value(intersection_upper),
        },
        relabelled_gap_certificate: spectral_gap_certificate_doc(relabelled_certificate),
        relabelled_interval_episode_length: frozen_episode_length.to_string(),
    })
}

fn build_kernel_prediction(
    fixture: &ManifestFixture,
    horizon: u32,
    permutation_index: u8,
    episode_length: u64,
    declared_spectral_gap: &str,
    quantum: u64,
) -> Result<KernelPrediction> {
    if quantum == 0 || !fixture.inventory_microtau.is_multiple_of(quantum) {
        return Err(CliError::new(
            "fixture inventory is not an integral number of action quanta",
        ));
    }
    let permutation = fixture
        .permutations
        .get(usize::from(permutation_index))
        .ok_or_else(|| CliError::new("permutation index outside fixture"))?;
    let relabelled_edges = relabel_edges(&fixture.account_edges, &permutation.image_by_node)?;
    let inventory_units = u32::try_from(fixture.inventory_microtau / quantum)
        .map_err(|_| CliError::new("fixture inventory units exceed u32"))?;
    let analysis_fixture = AnalysisFixture::new(
        usize::try_from(fixture.node_count)
            .map_err(|_| CliError::new("node count exceeds usize"))?,
        zero_based_edges(&relabelled_edges)?,
        inventory_units,
    )?;
    let analysis = Analysis::build(
        analysis_fixture.clone(),
        usize::try_from(horizon).map_err(|_| CliError::new("horizon exceeds usize"))?,
    )?;
    let canonical_analysis = Analysis::build(
        AnalysisFixture::new(
            usize::try_from(fixture.node_count)
                .map_err(|_| CliError::new("node count exceeds usize"))?,
            zero_based_edges(&fixture.account_edges)?,
            inventory_units,
        )?,
        usize::try_from(horizon).map_err(|_| CliError::new("horizon exceeds usize"))?,
    )?;
    let declared_gap = parse_finite_positive_f64("declared spectral gap", declared_spectral_gap)?;
    let spectral_schedule_admission = admit_spectral_schedule(
        canonical_analysis.spectral(),
        analysis.spectral(),
        horizon,
        episode_length,
        declared_gap,
    )?;
    let h1_analysis = Analysis::build(analysis_fixture, 1)?;
    let h1 = h1_analysis.exact();
    let exact = analysis.exact();
    let shell = exact.shell();
    let state_shell = shell
        .states()
        .iter()
        .enumerate()
        .map(|(state_index, balances)| {
            Ok(StateDoc {
                balances_microtau: balances
                    .iter()
                    .map(|balance| units_to_microtau_string(*balance, quantum))
                    .collect::<Result<Vec<_>>>()?,
                state_index: u32::try_from(state_index)
                    .map_err(|_| CliError::new("state index exceeds u32"))?
                    .to_string(),
            })
        })
        .collect::<Result<Vec<_>>>()?;

    let mut action_rows = Vec::with_capacity(shell.state_count());
    let mut fixed_category_count = 0u64;
    for source in 0..shell.state_count() {
        let candidates = exact.candidate_weights(source)?;
        let h1_candidates = h1.candidate_weights(source)?;
        if candidates.len() != h1_candidates.len()
            || candidates.iter().zip(&h1_candidates).any(|(left, right)| {
                left.action != right.action || left.successor != right.successor
            })
        {
            return Err(CliError::new(
                "horizon-one control action row differs from the primary shell",
            ));
        }
        let primary_denominator = exact.path_count(exact.horizon(), source)?.clone();
        let h1_denominator = h1.path_count(1, source)?.clone();
        let maximum_weight = candidates
            .iter()
            .map(|candidate| &candidate.weight)
            .max()
            .ok_or_else(|| CliError::new("action row is empty"))?;
        let greedy_index = candidates
            .iter()
            .position(|candidate| &candidate.weight == maximum_weight)
            .ok_or_else(|| CliError::new("greedy action is absent"))?;
        let mut actions = Vec::with_capacity(candidates.len());
        for (index, candidate) in candidates.iter().enumerate() {
            let rotated = &candidates[(index + 1) % candidates.len()].weight;
            actions.push(ActionProbabilityDoc {
                action: ActionDoc::from_action(&candidate.action, quantum)?,
                continuation_weight: candidate.weight.to_str_radix(10),
                greedy_probability: ExactRatioDoc::from_ratio(&ExactRatio::new(
                    BigUint::from(u8::from(index == greedy_index)),
                    BigUint::from(1u8),
                )?),
                h1_probability: ExactRatioDoc::from_ratio(&ExactRatio::new(
                    h1_candidates[index].weight.clone(),
                    h1_denominator.clone(),
                )?),
                left_rotated_probability: ExactRatioDoc::from_ratio(&ExactRatio::new(
                    rotated.clone(),
                    primary_denominator.clone(),
                )?),
                multiplicity: "1".to_owned(),
                primary_probability: ExactRatioDoc::from_ratio(&ExactRatio::new(
                    candidate.weight.clone(),
                    primary_denominator.clone(),
                )?),
                successor_state: u32::try_from(candidate.successor)
                    .map_err(|_| CliError::new("successor state exceeds u32"))?
                    .to_string(),
            });
        }
        fixed_category_count = fixed_category_count
            .checked_add(
                u64::try_from(actions.len())
                    .map_err(|_| CliError::new("action count exceeds u64"))?,
            )
            .ok_or_else(|| CliError::new("kernel category count overflow"))?;
        let successor_probabilities = shell.adjacency()[source]
            .iter()
            .enumerate()
            .filter(|(_, multiplicity)| **multiplicity > 0)
            .map(|(successor, multiplicity)| {
                Ok(SuccessorProbabilityDoc {
                    multiplicity: multiplicity.to_string(),
                    probability: ExactRatioDoc::from_ratio(
                        &exact.transition_ratio(source, successor)?,
                    ),
                    successor_state: u32::try_from(successor)
                        .map_err(|_| CliError::new("successor state exceeds u32"))?
                        .to_string(),
                })
            })
            .collect::<Result<Vec<_>>>()?;
        action_rows.push(ActionRowDoc {
            actions,
            source_state: u32::try_from(source)
                .map_err(|_| CliError::new("source state exceeds u32"))?
                .to_string(),
            successor_probabilities,
        });
    }

    let path_counts = (0..=exact.horizon())
        .map(|depth| {
            Ok(PathCountDoc {
                counts: exact
                    .path_counts(depth)?
                    .iter()
                    .map(|value| value.to_str_radix(10))
                    .collect(),
                depth: u32::try_from(depth)
                    .map_err(|_| CliError::new("path-count depth exceeds u32"))?
                    .to_string(),
            })
        })
        .collect::<Result<Vec<_>>>()?;
    let checks = analysis.exact_checks();
    let exact_checks = ExactChecksDoc {
        balanced_basis_cycle_count: checks.cycle_balance.balanced_cycles.to_string(),
        basis_cycle_count: checks.cycle_balance.basis_cycles.to_string(),
        cycle_balance: checks.cycle_balance.all_balanced(),
        detailed_balance: checks.detailed_balance,
        path_count_recurrence: checks.path_count_recurrence,
        reverse_support: checks.reverse_support,
        row_stochasticity: checks.row_stochasticity,
        stationarity: checks.stationarity,
        unbalanced_cycles: checks
            .cycle_balance
            .unbalanced_cycles
            .iter()
            .map(|cycle| {
                cycle
                    .iter()
                    .map(|state| {
                        Ok(u32::try_from(*state)
                            .map_err(|_| CliError::new("cycle state exceeds u32"))?
                            .to_string())
                    })
                    .collect()
            })
            .collect::<Result<Vec<Vec<String>>>>()?,
    };
    if !checks.all_passed() {
        return Err(CliError::new("load-bearing exact prediction gate failed"));
    }

    let node_permutation = permutation
        .image_by_node
        .iter()
        .map(|node| {
            usize::try_from(node - 1).map_err(|_| CliError::new("node image exceeds usize"))
        })
        .collect::<Result<Vec<_>>>()?;
    let covariance = canonical_analysis
        .exact()
        .verify_permutation_covariance(&node_permutation)?;
    if !covariance.all_passed() {
        return Err(CliError::new(
            "load-bearing permutation covariance gate failed",
        ));
    }
    let permutation_covariance = PermutationCovarianceDoc {
        action_covariance: covariance.action_covariance,
        all_passed: covariance.all_passed(),
        candidate_weight_covariance: covariance.candidate_weight_covariance,
        path_count_covariance: covariance.path_count_covariance,
        state_covariance: covariance.state_covariance,
        state_mapping: covariance
            .state_mapping
            .iter()
            .map(|state| {
                Ok(u32::try_from(*state)
                    .map_err(|_| CliError::new("permuted state index exceeds u32"))?
                    .to_string())
            })
            .collect::<Result<Vec<_>>>()?,
        stationary_covariance: covariance.stationary_covariance,
        transition_covariance: covariance.transition_covariance,
    };

    let partitions = fixture
        .reporting_partitions
        .iter()
        .map(|partition| relabel_partition(partition, &permutation.image_by_node))
        .collect::<std::result::Result<Vec<_>, _>>()?;
    let partition_definitions = partitions
        .iter()
        .map(|partition| PartitionDefinitionDoc {
            left_nodes: partition.left_nodes.iter().map(u32::to_string).collect(),
            partition_id: partition.partition_id.clone(),
            right_nodes: partition.right_nodes.iter().map(u32::to_string).collect(),
        })
        .collect();
    let stationary_distribution = ExactDistributionDoc::from_parts(
        exact.stationary_weights(),
        exact.stationary_normalization(),
    );
    let stationary_partition_marginals = partitions
        .iter()
        .map(|partition| {
            partition_marginal(
                &partition.partition_id,
                &partition.left_nodes,
                shell.states(),
                exact.stationary_weights(),
                exact.stationary_normalization(),
                inventory_units,
                quantum,
            )
        })
        .collect::<Result<Vec<_>>>()?;

    let mut transients = Vec::new();
    for (start_index, initial) in fixture.initial_balances.iter().enumerate() {
        let relabelled = relabel_balances(initial, &permutation.image_by_node)?;
        let state_units = balances_to_units(&relabelled, quantum)?;
        let initial_state = shell
            .state_index(&state_units)
            .ok_or_else(|| CliError::new("initial allocation is absent from predicted shell"))?;
        let transient = analysis.transient_from_state(
            initial_state,
            usize::try_from(episode_length)
                .map_err(|_| CliError::new("episode length exceeds usize"))?,
        )?;
        let exact_points = transient
            .exact_delta_points
            .as_ref()
            .ok_or_else(|| CliError::new("delta transient lacks exact distributions"))?;
        let points = transient
            .points
            .iter()
            .zip(exact_points)
            .map(|(floating, exact_point)| {
                let opportunity = u64::try_from(floating.opportunity)
                    .map_err(|_| CliError::new("transient opportunity exceeds u64"))?
                    .to_string();
                Ok(TransientPointDoc {
                    endpoint_entropy_bits: F64Doc::from_value(floating.endpoint_entropy_bits),
                    exact_state_distribution: ExactDistributionDoc::from_distribution(
                        &exact_point.distribution,
                    ),
                    opportunity,
                    partition_marginals: partitions
                        .iter()
                        .map(|partition| {
                            partition_marginal(
                                &partition.partition_id,
                                &partition.left_nodes,
                                shell.states(),
                                exact_point.distribution.numerators(),
                                exact_point.distribution.denominator(),
                                inventory_units,
                                quantum,
                            )
                        })
                        .collect::<Result<Vec<_>>>()?,
                    relative_entropy_bits: F64Doc::from_value(floating.relative_entropy_bits),
                    total_variation_to_stationary: F64Doc::from_value(
                        floating.total_variation_to_stationary,
                    ),
                })
            })
            .collect::<Result<Vec<_>>>()?;
        transients.push(StartTransientDoc {
            first_below_mixing_threshold: transient
                .first_below_mixing_threshold
                .map_or_else(|| "undefined".to_owned(), |value| value.to_string()),
            initial_state: u32::try_from(initial_state)
                .map_err(|_| CliError::new("initial state exceeds u32"))?
                .to_string(),
            points,
            start_index: u32::try_from(start_index)
                .map_err(|_| CliError::new("start index exceeds u32"))?
                .to_string(),
        });
    }

    let spectral = analysis.spectral();
    let equilibrium = analysis.equilibrium();
    let entropy = analysis.entropy();
    let residuals = analysis.residuals();
    let first_passage = analysis.first_passage()?;
    let h1_comparison = compare_kernels(&h1_analysis, &analysis)?;
    let stationary_flows = stationary_flows(exact)?;
    if stationary_flows
        .iter()
        .any(|flow| flow.current_sign != "zero")
    {
        return Err(CliError::new(
            "reversible stationary probability current did not vanish",
        ));
    }
    let state_count = shell.state_count();
    let mean_first_passage = (0..state_count)
        .map(|source| {
            (0..state_count)
                .map(|target| {
                    first_passage
                        .mean_first_passage(source, target)
                        .map(F64Doc::from_value)
                        .map_err(Into::into)
                })
                .collect()
        })
        .collect::<Result<Vec<Vec<F64Doc>>>>()?;

    Ok(KernelPrediction {
        action_rows,
        edges: relabelled_edges
            .iter()
            .map(|[left, right]| [left.to_string(), right.to_string()])
            .collect(),
        entropy: EntropyDoc {
            entropy_rate_bits_per_step: F64Doc::from_value(entropy.entropy_rate_bits_per_step),
            entropy_rate_deficit_bits_per_step: F64Doc::from_value(
                entropy.entropy_rate_deficit_bits_per_step,
            ),
            maximum_path_entropy_bits: F64Doc::from_value(entropy.maximum_path_entropy_bits),
            minimum_path_entropy_bits: F64Doc::from_value(entropy.minimum_path_entropy_bits),
            stationary_mean_path_entropy_bits: F64Doc::from_value(
                entropy.stationary_mean_path_entropy_bits,
            ),
            topological_entropy_bits_per_step: F64Doc::from_value(
                entropy.topological_entropy_bits_per_step,
            ),
        },
        equilibrium: EquilibriumDoc {
            effective_state_count: F64Doc::from_value(equilibrium.effective_state_count),
            inverse_participation_ratio: F64Doc::from_value(
                equilibrium.inverse_participation_ratio,
            ),
            localization_excess: F64Doc::from_value(equilibrium.localization_excess),
            maximum_mass_states: equilibrium
                .maximum_mass_states
                .iter()
                .map(|state| {
                    u32::try_from(*state)
                        .map_err(|_| CliError::new("maximum-mass state exceeds u32"))
                        .map(|state| state.to_string())
                })
                .collect::<Result<Vec<_>>>()?,
            maximum_state_mass: F64Doc::from_value(equilibrium.maximum_state_mass),
            normalized_participation_ratio: F64Doc::from_value(
                equilibrium.normalized_participation_ratio,
            ),
            participation_ratio: F64Doc::from_value(equilibrium.participation_ratio),
            perron_square_limit: analysis
                .perron_square_limit()
                .iter()
                .copied()
                .map(F64Doc::from_value)
                .collect(),
            perron_square_total_variation: F64Doc::from_value(
                equilibrium.perron_square_total_variation,
            ),
            shannon_entropy_bits: F64Doc::from_value(equilibrium.shannon_entropy_bits),
        },
        episode_length: episode_length.to_string(),
        exact_checks,
        fixed_category_count: fixed_category_count.to_string(),
        fixture_id: fixture.fixture_id.clone(),
        h1_comparison: H1ComparisonDoc {
            entropy_rate_delta_bits_per_step: F64Doc::from_value(
                h1_comparison.entropy_rate_delta_bits_per_step,
            ),
            maximum_row_total_variation: F64Doc::from_value(
                h1_comparison.maximum_row_total_variation,
            ),
            spectral_gap_delta: F64Doc::from_value(h1_comparison.spectral_gap_delta),
            stationary_total_variation: F64Doc::from_value(
                h1_comparison.stationary_total_variation,
            ),
        },
        horizon: horizon.to_string(),
        inventory_microtau: fixture.inventory_microtau.to_string(),
        node_count: fixture.node_count.to_string(),
        numerical_residuals: NumericalResidualsDoc {
            maximum_detailed_balance_residual: F64Doc::from_value(
                residuals.maximum_detailed_balance_residual,
            ),
            maximum_row_sum_residual: F64Doc::from_value(residuals.maximum_row_sum_residual),
            maximum_stationarity_residual: F64Doc::from_value(
                residuals.maximum_stationarity_residual,
            ),
            symmetric_similarity_asymmetry: F64Doc::from_value(
                residuals.symmetric_similarity_asymmetry,
            ),
        },
        partition_definitions,
        path_counts,
        permutation_covariance,
        permutation_id: permutation.permutation_id.clone(),
        permutation_index: permutation_index.to_string(),
        schema: KERNEL_SCHEMA.to_owned(),
        schedule_spectral_gap: F64Doc::from_value(declared_gap),
        spectral: SpectralDoc {
            eigenvalues: spectral
                .eigenvalues
                .iter()
                .copied()
                .map(F64Doc::from_value)
                .collect(),
            eigenvector_norm_lower_bounds: spectral
                .eigenvector_norm_lower_bounds
                .iter()
                .copied()
                .map(F64Doc::from_value)
                .collect(),
            eigenvector_norm_upper_bounds: spectral
                .eigenvector_norm_upper_bounds
                .iter()
                .copied()
                .map(F64Doc::from_value)
                .collect(),
            global_eigenvalue_error_upper_bound: F64Doc::from_value(
                spectral.global_eigenvalue_error_upper_bound,
            ),
            jacobi_sweeps: spectral.jacobi_sweeps.to_string(),
            maximum_eigenpair_residual: F64Doc::from_value(spectral.maximum_eigenpair_residual),
            maximum_normalized_eigenpair_residual_upper_bound: F64Doc::from_value(
                spectral.maximum_normalized_eigenpair_residual_upper_bound,
            ),
            maximum_off_diagonal: F64Doc::from_value(spectral.maximum_off_diagonal),
            maximum_orthogonality_residual: F64Doc::from_value(
                spectral.maximum_orthogonality_residual,
            ),
            maximum_reconstruction_residual: F64Doc::from_value(
                spectral.maximum_reconstruction_residual,
            ),
            normalized_eigenpair_residual_upper_bounds: spectral
                .normalized_eigenpair_residual_upper_bounds
                .iter()
                .copied()
                .map(F64Doc::from_value)
                .collect(),
            orthogonality_frobenius_residual_upper_bound: F64Doc::from_value(
                spectral.orthogonality_frobenius_residual_upper_bound,
            ),
            relaxation_scale: F64Doc::from_value(spectral.relaxation_scale),
            spectral_gap: F64Doc::from_value(spectral.spectral_gap),
            spectral_gap_certificate: spectral_gap_certificate_doc(
                &spectral.spectral_gap_certificate,
            ),
            subdominant_eigenvalue: F64Doc::from_value(spectral.subdominant_eigenvalue),
        },
        spectral_schedule_admission,
        state_shell,
        stationary_distribution,
        stationary_flows,
        stationary_partition_marginals,
        transients,
        first_passage: FirstPassageDoc {
            kac_mean_return: first_passage
                .mean_return
                .iter()
                .copied()
                .map(F64Doc::from_value)
                .collect(),
            kac_mean_return_exact: first_passage
                .exact_mean_return
                .iter()
                .map(ExactRatioDoc::from_ratio)
                .collect(),
            maximum_bellman_residual: F64Doc::from_value(first_passage.maximum_bellman_residual),
            mean_first_passage,
        },
        unit_quantum_microtau: quantum.to_string(),
    })
}

fn balances_to_units(balances: &[u64], quantum: u64) -> Result<Vec<u32>> {
    if quantum == 0 {
        return Err(CliError::new("action quantum must be positive"));
    }
    balances
        .iter()
        .map(|balance| {
            if !(*balance).is_multiple_of(quantum) {
                return Err(CliError::new(
                    "balance is not an integral number of action quanta",
                ));
            }
            u32::try_from(balance / quantum).map_err(|_| CliError::new("balance units exceed u32"))
        })
        .collect()
}

fn zero_based_edges(edges: &[[u32; 2]]) -> Result<Vec<(usize, usize)>> {
    edges
        .iter()
        .map(|[left, right]| {
            if *left == 0 || *right == 0 {
                return Err(CliError::new("one-based edge endpoint is zero"));
            }
            Ok((
                usize::try_from(left - 1)
                    .map_err(|_| CliError::new("edge endpoint exceeds usize"))?,
                usize::try_from(right - 1)
                    .map_err(|_| CliError::new("edge endpoint exceeds usize"))?,
            ))
        })
        .collect()
}

fn units_to_microtau_string(units: u32, quantum: u64) -> Result<String> {
    u64::from(units)
        .checked_mul(quantum)
        .map(|value| value.to_string())
        .ok_or_else(|| CliError::new("balance conversion to MicroTau overflowed"))
}

fn partition_marginal(
    partition_id: &str,
    left_nodes: &[u32],
    states: &[Vec<u32>],
    numerators: &[BigUint],
    denominator: &BigUint,
    inventory_units: u32,
    quantum: u64,
) -> Result<PartitionMarginalDoc> {
    if states.len() != numerators.len() {
        return Err(CliError::new(
            "partition marginal state and probability shapes differ",
        ));
    }
    let left_indices = left_nodes
        .iter()
        .map(|node| {
            usize::try_from(node - 1)
                .map_err(|_| CliError::new("partition node index exceeds usize"))
        })
        .collect::<Result<Vec<_>>>()?;
    let mut marginal = vec![
        BigUint::zero();
        usize::try_from(inventory_units)
            .map_err(|_| CliError::new("inventory exceeds usize"))?
            + 1
    ];
    for (state, numerator) in states.iter().zip(numerators) {
        let left_units = left_indices.iter().try_fold(0u32, |sum, index| {
            sum.checked_add(
                *state
                    .get(*index)
                    .ok_or_else(|| CliError::new("partition node outside state"))?,
            )
            .ok_or_else(|| CliError::new("left inventory overflow"))
        })?;
        marginal[usize::try_from(left_units)
            .map_err(|_| CliError::new("left inventory exceeds usize"))?] += numerator;
    }
    if marginal
        .iter()
        .fold(BigUint::zero(), |sum, value| sum + value)
        != *denominator
    {
        return Err(CliError::new("partition marginal is not normalized"));
    }
    let mean_numerator = marginal
        .iter()
        .enumerate()
        .fold(BigUint::zero(), |sum, (units, mass)| {
            sum + BigUint::from(units) * BigUint::from(quantum) * mass
        });
    let second_numerator =
        marginal
            .iter()
            .enumerate()
            .fold(BigUint::zero(), |sum, (units, mass)| {
                let microtau = BigUint::from(units) * BigUint::from(quantum);
                sum + &microtau * &microtau * mass
            });
    let mean = ExactRatio::new(mean_numerator, denominator.clone())?;
    let second = ExactRatio::new(second_numerator, denominator.clone())?;
    let variance_numerator = second.numerator() * mean.denominator() * mean.denominator()
        - mean.numerator() * mean.numerator() * second.denominator();
    let variance_denominator = second.denominator() * mean.denominator() * mean.denominator();
    let variance = ExactRatio::new(variance_numerator, variance_denominator)?;
    let probabilities = marginal
        .iter()
        .map(|mass| ExactRatio::new(mass.clone(), denominator.clone())?.to_f64())
        .collect::<std::result::Result<Vec<_>, _>>()?;
    let entropy_bits = probabilities
        .iter()
        .filter(|probability| **probability > 0.0)
        .map(|probability| -probability * probability.log2())
        .sum();
    Ok(PartitionMarginalDoc {
        entropy_bits: F64Doc::from_value(entropy_bits),
        left_inventory_mean_microtau: F64Doc::from_value(mean.to_f64()?),
        left_inventory_mean_microtau_exact: ExactRatioDoc::from_ratio(&mean),
        left_inventory_variance_microtau_squared: F64Doc::from_value(variance.to_f64()?),
        left_inventory_variance_microtau_squared_exact: ExactRatioDoc::from_ratio(&variance),
        marginal: ExactDistributionDoc::from_parts(&marginal, denominator),
        partition_id: partition_id.to_owned(),
        support_microtau: (0..=inventory_units)
            .map(|units| units_to_microtau_string(units, quantum))
            .collect::<Result<Vec<_>>>()?,
    })
}

fn stationary_flows(exact: &ExactKernel) -> Result<Vec<StationaryFlowDoc>> {
    let state_count = exact.shell().state_count();
    let mut flows = Vec::new();
    for source in 0..state_count {
        for target in source..state_count {
            if exact.shell().adjacency()[source][target] == 0
                && exact.shell().adjacency()[target][source] == 0
            {
                continue;
            }
            let forward = exact
                .stationary_ratio(source)?
                .checked_multiply(&exact.transition_ratio(source, target)?)?;
            let reverse = exact
                .stationary_ratio(target)?
                .checked_multiply(&exact.transition_ratio(target, source)?)?;
            let left = forward.numerator() * reverse.denominator();
            let right = reverse.numerator() * forward.denominator();
            let raw_denominator = forward.denominator() * reverse.denominator();
            let (sign, magnitude) = match left.cmp(&right) {
                std::cmp::Ordering::Less => ("negative", right - left),
                std::cmp::Ordering::Equal => ("zero", BigUint::zero()),
                std::cmp::Ordering::Greater => ("positive", left - right),
            };
            let divisor = magnitude.gcd(&raw_denominator);
            let reduced_magnitude = &magnitude / &divisor;
            let reduced_denominator = &raw_denominator / divisor;
            flows.push(StationaryFlowDoc {
                current_denominator: reduced_denominator.to_str_radix(10),
                current_magnitude_numerator: reduced_magnitude.to_str_radix(10),
                current_sign: sign.to_owned(),
                forward_flux: ExactRatioDoc::from_ratio(&forward),
                reverse_flux: ExactRatioDoc::from_ratio(&reverse),
                source_state: u32::try_from(source)
                    .map_err(|_| CliError::new("stationary-flow source exceeds u32"))?
                    .to_string(),
                target_state: u32::try_from(target)
                    .map_err(|_| CliError::new("stationary-flow target exceeds u32"))?
                    .to_string(),
            });
        }
    }
    Ok(flows)
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct OutputFileIdentity {
    length_bytes: u64,
    relative_path: String,
    sha256: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct LocalRawFileIdentity {
    length_bytes: u64,
    path: String,
    sha256: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct CollectionIndexEpisode {
    episode_nonce: String,
    normalized: OutputFileIdentity,
    relative_dir: String,
    schedule_index: u32,
    terminal_block_hash: String,
    terminal_ledger_state_hash: String,
    trajectory: OutputFileIdentity,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct CollectionIndex {
    complete: bool,
    core_hash: String,
    decision_count: u64,
    episode_count: u32,
    episodes: Vec<CollectionIndexEpisode>,
    final_manifest_hash: String,
    observer_artifact: LocalRawFileIdentity,
    prediction: LocalRawFileIdentity,
    prediction_sidecar: LocalRawFileIdentity,
    provenance_caveat: String,
    provenance_label: String,
    schema: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct TrajectoryDocument {
    accounts: Vec<u32>,
    action_rows: Vec<[u64; 3]>,
    block_hashes: Vec<String>,
    contact_edges: Vec<[u32; 2]>,
    decision_hashes: Vec<String>,
    episode_length: u64,
    episode_nonce: String,
    fixture_id: String,
    horizon: u32,
    initial_kernel_view_hash: String,
    manifest_hash: String,
    permutation_index: u8,
    policy_hash: String,
    provenance_caveat: String,
    provenance_label: String,
    schedule_index: u32,
    schema: String,
    start_index: u32,
    states: Vec<Vec<u64>>,
    terminal_ledger_state_hash: String,
    unit_quantum: u64,
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
struct KernelKey {
    fixture_id: String,
    horizon: u32,
    permutation_index: u8,
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
struct TransitionKey {
    kernel: KernelKey,
    state: usize,
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
struct TransientKey {
    kernel: KernelKey,
    start_index: u32,
    opportunity: u64,
}

struct RuntimeKernel {
    analysis: Analysis,
    fixture: ManifestFixture,
    partitions: Vec<ReportingPartition>,
    quantum: u64,
}

#[derive(Default, Clone)]
struct ModelAccumulator {
    decisions: u64,
    finite_sum: f64,
    zero_probability_observations: u64,
}

impl ModelAccumulator {
    fn observe(&mut self, probability: &ExactRatio) -> Result<()> {
        self.decisions = self
            .decisions
            .checked_add(1)
            .ok_or_else(|| CliError::new("likelihood decision count overflow"))?;
        if probability.numerator().is_zero() {
            self.zero_probability_observations = self
                .zero_probability_observations
                .checked_add(1)
                .ok_or_else(|| CliError::new("zero-probability count overflow"))?;
        } else {
            self.finite_sum += probability.to_f64()?.log2();
        }
        Ok(())
    }
}

#[derive(Default, Clone)]
struct LikelihoodSet {
    greedy: ModelAccumulator,
    h1: ModelAccumulator,
    primary: ModelAccumulator,
    rotated: ModelAccumulator,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct AnalysisGates {
    collection_complete: bool,
    compact_trajectory_inventory_conservation: bool,
    compact_trajectory_transition_semantics: bool,
    exact_prediction_regenerated: bool,
    joined_observer_collection_admitted: bool,
    manifest_identity: bool,
    prediction_payload_hash: bool,
    provenance: bool,
    schedule_completeness: bool,
    self_executable_identity: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct EmpiricalPartitionDoc {
    empirical: PartitionMarginalDoc,
    partition_id: String,
    predicted: PartitionMarginalDoc,
    total_variation: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct EmpiricalTransientDoc {
    empirical_state_distribution: ExactDistributionDoc,
    episode_count: String,
    fixture_id: String,
    horizon: String,
    opportunity: String,
    partition_marginals: Vec<EmpiricalPartitionDoc>,
    permutation_index: String,
    predicted_state_distribution: ExactDistributionDoc,
    start_index: String,
    total_variation: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "status", rename_all = "snake_case")]
enum ReferenceBandDoc {
    Eligible { lower: F64Doc, upper: F64Doc },
    Ineligible,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct EmpiricalActionDoc {
    action: ActionDoc,
    count: String,
    expected_probability: ExactRatioDoc,
    observed_frequency: F64Doc,
    observed_frequency_exact: ExactObservedFrequencyDoc,
    reference_band_99_percent: ReferenceBandDoc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(untagged)]
enum ExactObservedFrequencyDoc {
    Exact(ExactRatioDoc),
    Undefined(String),
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct EmpiricalTransitionRowDoc {
    actions: Vec<EmpiricalActionDoc>,
    eligible_for_reference_band: bool,
    exposures: String,
    fixture_id: String,
    horizon: String,
    permutation_index: String,
    reference_band_radius: F64Doc,
    state: StateDoc,
    total_variation: F64Doc,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct LogLikelihoodDoc {
    decision_count: String,
    mean_bits_per_decision: F64Doc,
    model: String,
    total_bits: F64Doc,
    zero_probability_observations: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct LikelihoodGroupDoc {
    fixture_id: String,
    horizon: String,
    likelihoods: Vec<LogLikelihoodDoc>,
    permutation_index: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct EmpiricalAnalysisDocument {
    all_acceptance_gates_passed: bool,
    analysis_artifact: ReportFileIdentity,
    collection_index_hash: String,
    core_hash: String,
    decision_count: String,
    episode_count: String,
    final_manifest_hash: String,
    fixed_category_count: String,
    diagnostic_acceptance_role: String,
    evidence_boundary: String,
    gates: AnalysisGates,
    global_likelihoods: Vec<LogLikelihoodDoc>,
    grouped_likelihoods: Vec<LikelihoodGroupDoc>,
    observer_artifact: ReportFileIdentity,
    prediction_hash: String,
    prediction_identity: ReportFileIdentity,
    prediction_payload_hash: String,
    prediction_sidecar_identity: ReportFileIdentity,
    prediction_sidecar_hash: String,
    reference_band_family_confidence: String,
    reference_band_dependence_scope: String,
    reference_band_family_size: String,
    reference_band_randomness_scope: String,
    schedule_hash: String,
    schema: String,
    transient_cells: Vec<EmpiricalTransientDoc>,
    transition_rows: Vec<EmpiricalTransitionRowDoc>,
}

struct VerifiedPrediction {
    commitment: PredictionCommitment,
    commitment_identity: LocalRawFileIdentity,
    commitment_sidecar_bytes: Vec<u8>,
    commitment_sidecar_identity: LocalRawFileIdentity,
    document: PredictionDocument,
}

fn local_raw_identity_from_bytes(path: &str, bytes: &[u8]) -> Result<LocalRawFileIdentity> {
    Ok(LocalRawFileIdentity {
        length_bytes: u64::try_from(bytes.len())
            .map_err(|_| CliError::new("prediction identity length exceeds u64"))?,
        path: path.to_owned(),
        sha256: raw_sha256_hex(bytes),
    })
}

fn validate_expected_prediction_identities(
    commitment: &LocalRawFileIdentity,
    sidecar: &LocalRawFileIdentity,
    expected: &ExpectedPredictionIdentities,
) -> Result<()> {
    if commitment.length_bytes != expected.commitment_length_bytes
        || commitment.sha256 != expected.commitment_sha256
        || sidecar.length_bytes != expected.sidecar_length_bytes
        || sidecar.sha256 != expected.sidecar_sha256
    {
        return Err(CliError::new(
            "prediction commitment buffers differ from the caller-bound expected identities",
        ));
    }
    Ok(())
}

fn verify_prediction_document(
    bundle: &FrozenBundle,
    prediction_path: &Path,
    expected_identities: Option<&ExpectedPredictionIdentities>,
) -> Result<VerifiedPrediction> {
    let commitment_bytes = fs::read(prediction_path)?;
    let sidecar_bytes = fs::read(default_sidecar_path(prediction_path)?)?;
    let commitment_identity = local_raw_identity_from_bytes(PREDICTION_PATH, &commitment_bytes)?;
    let commitment_sidecar_identity =
        local_raw_identity_from_bytes(PREDICTION_SIDECAR_PATH, &sidecar_bytes)?;
    if let Some(expected) = expected_identities {
        validate_expected_prediction_identities(
            &commitment_identity,
            &commitment_sidecar_identity,
            expected,
        )?;
    }
    if sidecar_bytes != hash_sidecar_bytes(prediction_path, &commitment_bytes)? {
        return Err(CliError::new(
            "prediction commitment SHA-256 sidecar mismatch",
        ));
    }
    xypher_calorimeter_manifest::validate_canonical_json(&commitment_bytes)?;
    let supplied_commitment: PredictionCommitment = serde_json::from_slice(&commitment_bytes)?;
    validate_frozen_prediction_commitment(&supplied_commitment)?;

    let expected_prediction = build_prediction(bundle)?;
    validate_regenerated_prediction_commitment(
        &supplied_commitment,
        &commitment_bytes,
        &expected_prediction,
    )?;
    Ok(VerifiedPrediction {
        commitment: supplied_commitment,
        commitment_identity,
        commitment_sidecar_bytes: sidecar_bytes,
        commitment_sidecar_identity,
        document: expected_prediction,
    })
}

fn analyze_collection(
    bundle: &FrozenBundle,
    prediction_path: &Path,
    normalized_root: &Path,
) -> Result<EmpiricalAnalysisDocument> {
    let verified_prediction = verify_prediction_document(bundle, prediction_path, None)?;
    let supplied_prediction = verified_prediction.document;
    let prediction_commitment = verified_prediction.commitment;
    let prediction_identity = verified_prediction.commitment_identity;
    let prediction_sidecar_bytes = verified_prediction.commitment_sidecar_bytes;
    let prediction_sidecar_identity = verified_prediction.commitment_sidecar_identity;
    let payload_hash = supplied_prediction.payload_hash.clone();

    let index_path = normalized_root.join(COLLECTION_INDEX_FILE);
    let index_bytes = fs::read(&index_path)?;
    xypher_calorimeter_manifest::validate_canonical_json(&index_bytes)?;
    let index: CollectionIndex = serde_json::from_slice(&index_bytes)?;
    validate_collection_index(
        &index,
        bundle,
        &prediction_identity,
        &prediction_sidecar_identity,
    )?;
    validate_normalized_layout(normalized_root, &index, &bundle.final_manifest)?;
    let collection_index_hash = raw_sha256_hex(&index_bytes);
    let runtimes = build_runtime_kernels(bundle)?;
    let predicted_kernels = supplied_prediction
        .payload
        .kernels
        .iter()
        .map(|kernel| {
            Ok((
                KernelKey {
                    fixture_id: kernel.fixture_id.clone(),
                    horizon: parse_unsigned("prediction horizon", &kernel.horizon)?,
                    permutation_index: parse_unsigned(
                        "prediction permutation index",
                        &kernel.permutation_index,
                    )?,
                },
                kernel,
            ))
        })
        .collect::<Result<BTreeMap<_, _>>>()?;

    let category_count = supplied_prediction
        .payload
        .fixed_category_count
        .parse::<u64>()
        .map_err(|_| CliError::new("prediction category count is not u64"))?;
    if category_count == 0 {
        return Err(CliError::new("prediction category family is empty"));
    }
    let regenerated_category_count = supplied_prediction
        .payload
        .kernels
        .iter()
        .flat_map(|kernel| &kernel.action_rows)
        .try_fold(0u64, |sum, row| {
            sum.checked_add(
                u64::try_from(row.actions.len())
                    .map_err(|_| CliError::new("prediction action count exceeds u64"))?,
            )
            .ok_or_else(|| CliError::new("prediction category count overflow"))
        })?;
    if regenerated_category_count != category_count {
        return Err(CliError::new(
            "prediction fixed category count differs from action-labelled table",
        ));
    }
    let mut transition_counts = BTreeMap::<TransitionKey, Vec<u64>>::new();
    for (key, runtime) in &runtimes {
        for state in 0..runtime.analysis.exact().shell().state_count() {
            transition_counts.insert(
                TransitionKey {
                    kernel: key.clone(),
                    state,
                },
                vec![0; runtime.analysis.exact().shell().actions(state)?.len()],
            );
        }
    }
    let mut transient_counts = BTreeMap::<TransientKey, Vec<BigUint>>::new();
    let mut likelihoods_by_kernel = BTreeMap::<KernelKey, LikelihoodSet>::new();
    let mut global_likelihoods = LikelihoodSet::default();
    let mut observed_decisions = 0u64;

    for (descriptor, index_episode) in bundle
        .final_manifest
        .schedule
        .episodes
        .iter()
        .zip(&index.episodes)
    {
        let trajectory_bytes = verify_output_identity(normalized_root, &index_episode.trajectory)?;
        let _normalized_bytes = verify_output_identity(normalized_root, &index_episode.normalized)?;
        xypher_calorimeter_manifest::validate_canonical_json(&trajectory_bytes)?;
        let trajectory: TrajectoryDocument = serde_json::from_slice(&trajectory_bytes)?;
        let key = KernelKey {
            fixture_id: descriptor.fixture_id.clone(),
            horizon: descriptor.horizon,
            permutation_index: descriptor.permutation_index,
        };
        let runtime = runtimes
            .get(&key)
            .ok_or_else(|| CliError::new("trajectory references an unknown prediction kernel"))?;
        let predicted_kernel = predicted_kernels
            .get(&key)
            .ok_or_else(|| CliError::new("trajectory prediction kernel is absent"))?;
        validate_trajectory(&trajectory, descriptor, index_episode, runtime, bundle)?;

        for (opportunity, state) in trajectory.states.iter().enumerate() {
            let units = balances_to_units(state, runtime.quantum)?;
            let state_index = runtime
                .analysis
                .exact()
                .shell()
                .state_index(&units)
                .ok_or_else(|| CliError::new("trajectory state is outside predicted shell"))?;
            let transient_key = TransientKey {
                kernel: key.clone(),
                start_index: descriptor.start_index,
                opportunity: u64::try_from(opportunity)
                    .map_err(|_| CliError::new("opportunity exceeds u64"))?,
            };
            let counts = transient_counts.entry(transient_key).or_insert_with(|| {
                vec![BigUint::zero(); runtime.analysis.exact().shell().state_count()]
            });
            counts[state_index] += BigUint::from(1u8);
        }

        for opportunity in 0..trajectory.action_rows.len() {
            let pre_units = balances_to_units(&trajectory.states[opportunity], runtime.quantum)?;
            let state = runtime
                .analysis
                .exact()
                .shell()
                .state_index(&pre_units)
                .ok_or_else(|| CliError::new("pre-state is outside predicted shell"))?;
            let observed_action =
                decode_trajectory_action(trajectory.action_rows[opportunity], runtime.quantum)?;
            let candidates = runtime.analysis.exact().candidate_weights(state)?;
            let action_index = candidates
                .iter()
                .position(|candidate| candidate.action == observed_action)
                .ok_or_else(|| CliError::new("observed action is absent from predicted row"))?;
            let counts = transition_counts
                .get_mut(&TransitionKey {
                    kernel: key.clone(),
                    state,
                })
                .ok_or_else(|| CliError::new("predicted transition row is absent"))?;
            counts[action_index] = counts[action_index]
                .checked_add(1)
                .ok_or_else(|| CliError::new("empirical action count overflow"))?;
            observed_decisions = observed_decisions
                .checked_add(1)
                .ok_or_else(|| CliError::new("observed decision count overflow"))?;

            let predicted_row = predicted_kernel
                .action_rows
                .get(state)
                .filter(|row| row.source_state == state.to_string())
                .ok_or_else(|| CliError::new("sealed prediction action row is absent"))?;
            let predicted_action = predicted_row
                .actions
                .get(action_index)
                .ok_or_else(|| CliError::new("sealed prediction action category is absent"))?;
            if predicted_action.action != ActionDoc::from_action(&observed_action, runtime.quantum)?
            {
                return Err(CliError::new(
                    "sealed prediction action ordering differs from observed action",
                ));
            }
            let probabilities = ActionModelProbabilities {
                greedy: predicted_action.greedy_probability.to_ratio()?,
                h1: predicted_action.h1_probability.to_ratio()?,
                primary: predicted_action.primary_probability.to_ratio()?,
                rotated: predicted_action.left_rotated_probability.to_ratio()?,
            };
            let grouped = likelihoods_by_kernel.entry(key.clone()).or_default();
            observe_likelihoods(grouped, &probabilities)?;
            observe_likelihoods(&mut global_likelihoods, &probabilities)?;
        }
    }
    if observed_decisions != bundle.final_manifest.schedule.decision_count {
        return Err(CliError::new(
            "observed trajectory decision count differs from frozen schedule",
        ));
    }

    let transient_cells = empirical_transients(
        &transient_counts,
        &predicted_kernels,
        &runtimes,
        bundle.policy.episodes_per_cell,
    )?;
    let transition_rows = empirical_transition_rows(
        &transition_counts,
        &runtimes,
        category_count,
        bundle.reporting.minimum_transition_row_exposures,
        parse_unit_interval_f64(
            "reference-band confidence",
            &bundle.reporting.confidence_intervals.confidence_level,
        )?,
    )?;
    let grouped_likelihoods = likelihoods_by_kernel
        .into_iter()
        .map(|(key, likelihoods)| LikelihoodGroupDoc {
            fixture_id: key.fixture_id,
            horizon: key.horizon.to_string(),
            likelihoods: likelihood_docs(&likelihoods),
            permutation_index: key.permutation_index.to_string(),
        })
        .collect();

    Ok(EmpiricalAnalysisDocument {
        all_acceptance_gates_passed: true,
        analysis_artifact: ReportFileIdentity::from(&bundle.analysis_artifact),
        collection_index_hash,
        core_hash: bundle.core_hash.clone(),
        decision_count: observed_decisions.to_string(),
        episode_count: bundle.final_manifest.schedule.episode_count.to_string(),
        final_manifest_hash: bundle.final_manifest_hash.clone(),
        fixed_category_count: category_count.to_string(),
        diagnostic_acceptance_role: bundle
            .reporting
            .confidence_intervals
            .acceptance_role
            .clone(),
        evidence_boundary:
            "compact trajectories are independently checked here; full journal, consensus, ledger, receipt, and external-seal joins are admitted through the frozen joined-observer collection index"
                .to_owned(),
        gates: AnalysisGates {
            collection_complete: true,
            compact_trajectory_inventory_conservation: true,
            compact_trajectory_transition_semantics: true,
            exact_prediction_regenerated: true,
            joined_observer_collection_admitted: true,
            manifest_identity: true,
            prediction_payload_hash: true,
            provenance: true,
            schedule_completeness: true,
            self_executable_identity: true,
        },
        global_likelihoods: likelihood_docs(&global_likelihoods),
        grouped_likelihoods,
        observer_artifact: ReportFileIdentity::from(&index.observer_artifact),
        prediction_hash: prediction_commitment.canonical_document.sha256,
        prediction_identity: ReportFileIdentity::from(&prediction_identity),
        prediction_payload_hash: payload_hash,
        prediction_sidecar_identity: ReportFileIdentity::from(&prediction_sidecar_identity),
        prediction_sidecar_hash: raw_sha256_hex(&prediction_sidecar_bytes),
        reference_band_family_confidence: bundle
            .reporting
            .confidence_intervals
            .confidence_level
            .clone(),
        reference_band_dependence_scope: bundle
            .reporting
            .confidence_intervals
            .dependence_scope
            .clone(),
        reference_band_family_size: category_count.to_string(),
        reference_band_randomness_scope: bundle
            .reporting
            .confidence_intervals
            .randomness_scope
            .clone(),
        schedule_hash: supplied_prediction.schedule_hash.clone(),
        schema: ANALYSIS_SCHEMA.to_owned(),
        transient_cells,
        transition_rows,
    })
}

fn build_runtime_kernels(bundle: &FrozenBundle) -> Result<BTreeMap<KernelKey, RuntimeKernel>> {
    let mut runtimes = BTreeMap::new();
    let quantum = bundle.policy.action_quantum_microtau;
    for fixture in &bundle.catalog.fixtures {
        if quantum == 0 || !fixture.inventory_microtau.is_multiple_of(quantum) {
            return Err(CliError::new(
                "fixture inventory is not an integral number of action quanta",
            ));
        }
        let inventory_units = u32::try_from(fixture.inventory_microtau / quantum)
            .map_err(|_| CliError::new("inventory units exceed u32"))?;
        for &horizon in &fixture.horizons {
            for (permutation_index, permutation) in fixture.permutations.iter().enumerate() {
                let edges = relabel_edges(&fixture.account_edges, &permutation.image_by_node)?;
                let analysis_fixture = AnalysisFixture::new(
                    usize::try_from(fixture.node_count)
                        .map_err(|_| CliError::new("node count exceeds usize"))?,
                    zero_based_edges(&edges)?,
                    inventory_units,
                )?;
                let analysis = Analysis::build(
                    analysis_fixture.clone(),
                    usize::try_from(horizon).map_err(|_| CliError::new("horizon exceeds usize"))?,
                )?;
                let partitions = fixture
                    .reporting_partitions
                    .iter()
                    .map(|partition| relabel_partition(partition, &permutation.image_by_node))
                    .collect::<std::result::Result<Vec<_>, _>>()?;
                let key = KernelKey {
                    fixture_id: fixture.fixture_id.clone(),
                    horizon,
                    permutation_index: u8::try_from(permutation_index)
                        .map_err(|_| CliError::new("permutation index exceeds u8"))?,
                };
                if runtimes
                    .insert(
                        key,
                        RuntimeKernel {
                            analysis,
                            fixture: fixture.clone(),
                            partitions,
                            quantum,
                        },
                    )
                    .is_some()
                {
                    return Err(CliError::new("duplicate runtime kernel key"));
                }
            }
        }
    }
    Ok(runtimes)
}

fn validate_collection_prediction_identities(
    index_prediction: &LocalRawFileIdentity,
    index_prediction_sidecar: &LocalRawFileIdentity,
    verified_prediction: &LocalRawFileIdentity,
    verified_prediction_sidecar: &LocalRawFileIdentity,
) -> Result<()> {
    if index_prediction != verified_prediction
        || index_prediction_sidecar != verified_prediction_sidecar
    {
        return Err(CliError::new(
            "normalized collection does not bind the exact verified prediction commitment buffers",
        ));
    }
    Ok(())
}

fn validate_collection_index(
    index: &CollectionIndex,
    bundle: &FrozenBundle,
    verified_prediction: &LocalRawFileIdentity,
    verified_prediction_sidecar: &LocalRawFileIdentity,
) -> Result<()> {
    if !index.complete
        || index.schema != COLLECTION_INDEX_SCHEMA
        || index.core_hash != bundle.core_hash
        || index.final_manifest_hash != bundle.final_manifest_hash
        || index.episode_count != bundle.final_manifest.schedule.episode_count
        || index.decision_count != bundle.final_manifest.schedule.decision_count
        || index.provenance_label != PROVENANCE_LABEL
        || index.provenance_caveat != PROVENANCE_CAVEAT
        || index.episodes.len() != bundle.final_manifest.schedule.episodes.len()
    {
        return Err(CliError::new(
            "normalized collection index identity, completeness, or provenance mismatch",
        ));
    }
    let observer_matches = bundle
        .core
        .components
        .get("observer")
        .ok_or_else(|| CliError::new("core manifest has no observer component"))?
        .artifact_set
        .files
        .iter()
        .filter(|observer| {
            index.observer_artifact.length_bytes == observer.length_bytes
                && index.observer_artifact.path == observer.path
                && index.observer_artifact.sha256 == observer.sha256
        })
        .count();
    if observer_matches != 1 {
        return Err(CliError::new(
            "normalized collection observer artifact does not match exactly one frozen artifact",
        ));
    }
    validate_collection_prediction_identities(
        &index.prediction,
        &index.prediction_sidecar,
        verified_prediction,
        verified_prediction_sidecar,
    )?;
    let mut seen = BTreeSet::new();
    for (descriptor, episode) in bundle
        .final_manifest
        .schedule
        .episodes
        .iter()
        .zip(&index.episodes)
    {
        if episode.schedule_index != descriptor.schedule_index
            || episode.episode_nonce != descriptor.episode_nonce
            || episode.relative_dir != descriptor.relative_dir
            || episode.trajectory.relative_path
                != format!("episodes/{}/trajectory.json", descriptor.relative_dir)
            || episode.normalized.relative_path
                != format!("episodes/{}/normalized.bin", descriptor.relative_dir)
            || !seen.insert(episode.schedule_index)
        {
            return Err(CliError::new(
                "normalized collection episode order or identity mismatch",
            ));
        }
        validate_lower_hex("terminal block hash", &episode.terminal_block_hash, 64)?;
        validate_lower_hex(
            "terminal ledger-state hash",
            &episode.terminal_ledger_state_hash,
            64,
        )?;
    }
    Ok(())
}

fn validate_normalized_layout(
    root: &Path,
    index: &CollectionIndex,
    manifest: &FinalManifest,
) -> Result<()> {
    let allowed_top = BTreeSet::from(["collection-index.json", "episodes"]);
    for entry in fs::read_dir(root)? {
        let entry = entry?;
        let name = entry
            .file_name()
            .into_string()
            .map_err(|_| CliError::new("normalized top-level entry is not UTF-8"))?;
        if !allowed_top.contains(name.as_str())
            || (name == "episodes" && !entry.file_type()?.is_dir())
            || (name == "collection-index.json" && !entry.file_type()?.is_file())
        {
            return Err(CliError::new(format!(
                "unexpected normalized top-level entry: {name}"
            )));
        }
    }
    let expected_dirs = manifest
        .schedule
        .episodes
        .iter()
        .map(|episode| episode.relative_dir.as_str())
        .collect::<BTreeSet<_>>();
    let episodes_root = root.join("episodes");
    if !episodes_root.is_dir() {
        return Err(CliError::new(
            "normalized collection lacks the episodes directory",
        ));
    }
    let mut seen_dirs = BTreeSet::new();
    for entry in fs::read_dir(&episodes_root)? {
        let entry = entry?;
        let name = entry
            .file_name()
            .into_string()
            .map_err(|_| CliError::new("normalized episode directory is not UTF-8"))?;
        if !entry.file_type()?.is_dir()
            || !expected_dirs.contains(name.as_str())
            || !seen_dirs.insert(name.clone())
        {
            return Err(CliError::new(format!(
                "unexpected normalized episode directory: {name}"
            )));
        }
        let mut files = BTreeSet::new();
        for file in fs::read_dir(entry.path())? {
            let file = file?;
            let file_name = file
                .file_name()
                .into_string()
                .map_err(|_| CliError::new("normalized episode filename is not UTF-8"))?;
            if !file.file_type()?.is_file()
                || !matches!(file_name.as_str(), "normalized.bin" | "trajectory.json")
                || !files.insert(file_name.clone())
            {
                return Err(CliError::new(format!(
                    "unexpected normalized episode file: {name}/{file_name}"
                )));
            }
        }
        if files != BTreeSet::from(["normalized.bin".to_owned(), "trajectory.json".to_owned()]) {
            return Err(CliError::new(format!(
                "normalized episode file set is incomplete: {name}"
            )));
        }
    }
    if seen_dirs != expected_dirs.into_iter().map(str::to_owned).collect() {
        return Err(CliError::new(
            "normalized episode directory set differs from the complete schedule",
        ));
    }
    if index.episodes.len() != seen_dirs.len() {
        return Err(CliError::new(
            "normalized collection index and directory counts differ",
        ));
    }
    Ok(())
}

fn verify_output_identity(root: &Path, identity: &OutputFileIdentity) -> Result<Vec<u8>> {
    let path = secure_relative_file(root, &identity.relative_path)?;
    let bytes = fs::read(&path)?;
    let length = u64::try_from(bytes.len())
        .map_err(|_| CliError::new("normalized output file length exceeds u64"))?;
    if length != identity.length_bytes || raw_sha256_hex(&bytes) != identity.sha256 {
        return Err(CliError::new(format!(
            "normalized output identity mismatch for {}",
            identity.relative_path
        )));
    }
    Ok(bytes)
}

fn secure_relative_file(root: &Path, relative: &str) -> Result<PathBuf> {
    if relative.is_empty() || relative.contains('\\') || Path::new(relative).is_absolute() {
        return Err(CliError::new("normalized relative path is not canonical"));
    }
    let canonical_root = fs::canonicalize(root)?;
    let mut current = canonical_root.clone();
    let mut components = Path::new(relative).components().peekable();
    let mut spelling = Vec::new();
    while let Some(component) = components.next() {
        let Component::Normal(name) = component else {
            return Err(CliError::new("normalized relative path is not canonical"));
        };
        let name_text = name
            .to_str()
            .ok_or_else(|| CliError::new("normalized relative path is not UTF-8"))?;
        spelling.push(name_text);
        current.push(name);
        let metadata = fs::symlink_metadata(&current)?;
        if metadata.file_type().is_symlink() {
            return Err(CliError::new("normalized output path contains a symlink"));
        }
        if components.peek().is_some() {
            if !metadata.is_dir() {
                return Err(CliError::new("normalized output parent is not a directory"));
            }
        } else if !metadata.is_file() {
            return Err(CliError::new(
                "normalized output target is not a regular file",
            ));
        }
    }
    if spelling.join("/") != relative {
        return Err(CliError::new(
            "normalized relative path spelling is not canonical",
        ));
    }
    let canonical_target = fs::canonicalize(&current)?;
    if !canonical_target.starts_with(&canonical_root) {
        return Err(CliError::new(
            "normalized output path escapes collection root",
        ));
    }
    Ok(canonical_target)
}

fn validate_trajectory(
    trajectory: &TrajectoryDocument,
    descriptor: &FinalEpisodeDescriptor,
    index_episode: &CollectionIndexEpisode,
    runtime: &RuntimeKernel,
    bundle: &FrozenBundle,
) -> Result<()> {
    if trajectory.schema != TRAJECTORY_SCHEMA
        || trajectory.provenance_label != PROVENANCE_LABEL
        || trajectory.provenance_caveat != PROVENANCE_CAVEAT
        || trajectory.schedule_index != descriptor.schedule_index
        || trajectory.episode_nonce != descriptor.episode_nonce
        || trajectory.fixture_id != descriptor.fixture_id
        || trajectory.horizon != descriptor.horizon
        || trajectory.start_index != descriptor.start_index
        || trajectory.permutation_index != descriptor.permutation_index
        || trajectory.episode_length != descriptor.episode_length
        || trajectory.initial_kernel_view_hash != descriptor.initial_kernel_view_hash
        || trajectory.manifest_hash != bundle.final_manifest_hash
        || trajectory.policy_hash != bundle.core.policy_config_hash
        || trajectory.terminal_ledger_state_hash != index_episode.terminal_ledger_state_hash
        || trajectory.block_hashes.last().map(String::as_str)
            != Some(index_episode.terminal_block_hash.as_str())
        || trajectory.unit_quantum != runtime.quantum
    {
        return Err(CliError::new(
            "trajectory identity, schedule coordinate, or provenance mismatch",
        ));
    }
    let expected_accounts = (1..=runtime.fixture.node_count).collect::<Vec<_>>();
    let permutation = runtime
        .fixture
        .permutations
        .get(usize::from(descriptor.permutation_index))
        .ok_or_else(|| CliError::new("trajectory permutation is outside fixture"))?;
    let expected_edges = relabel_edges(&runtime.fixture.account_edges, &permutation.image_by_node)?;
    if trajectory.accounts != expected_accounts || trajectory.contact_edges != expected_edges {
        return Err(CliError::new(
            "trajectory fixed account or contact-edge coordinates mismatch",
        ));
    }
    let expected_initial = relabel_balances(
        runtime
            .fixture
            .initial_balances
            .get(
                usize::try_from(descriptor.start_index)
                    .map_err(|_| CliError::new("start index exceeds usize"))?,
            )
            .ok_or_else(|| CliError::new("trajectory start index outside fixture"))?,
        &permutation.image_by_node,
    )?;
    let length = usize::try_from(descriptor.episode_length)
        .map_err(|_| CliError::new("episode length exceeds usize"))?;
    if trajectory.states.len() != length + 1
        || trajectory.action_rows.len() != length
        || trajectory.block_hashes.len() != length
        || trajectory.decision_hashes.len() != length
        || trajectory.states.first() != Some(&expected_initial)
    {
        return Err(CliError::new(
            "trajectory boundary/action lengths or initial state mismatch",
        ));
    }
    for hash in &trajectory.block_hashes {
        validate_lower_hex("trajectory block hash", hash, 64)?;
    }
    for hash in &trajectory.decision_hashes {
        validate_lower_hex("trajectory decision hash", hash, 64)?;
    }
    let inventory = runtime.fixture.inventory_microtau;
    for state in &trajectory.states {
        if state.len()
            != usize::try_from(runtime.fixture.node_count)
                .map_err(|_| CliError::new("node count exceeds usize"))?
            || state
                .iter()
                .try_fold(0u64, |sum, balance| sum.checked_add(*balance))
                != Some(inventory)
        {
            return Err(CliError::new(
                "trajectory state violates closed inventory conservation",
            ));
        }
        balances_to_units(state, runtime.quantum)?;
    }
    let edge_set = trajectory
        .contact_edges
        .iter()
        .map(|[left, right]| (*left.min(right), *left.max(right)))
        .collect::<BTreeSet<_>>();
    for opportunity in 0..length {
        let pre = &trajectory.states[opportunity];
        let post = &trajectory.states[opportunity + 1];
        match trajectory.action_rows[opportunity] {
            [0, 0, 0] => {
                if pre != post {
                    return Err(CliError::new("WAIT changed the allocation state"));
                }
            }
            [1, from, to] => {
                let from = u32::try_from(from)
                    .map_err(|_| CliError::new("transfer source exceeds u32"))?;
                let to =
                    u32::try_from(to).map_err(|_| CliError::new("transfer target exceeds u32"))?;
                if from == 0
                    || to == 0
                    || from == to
                    || !edge_set.contains(&(from.min(to), from.max(to)))
                {
                    return Err(CliError::new(
                        "trajectory transfer is outside the fixed contact graph",
                    ));
                }
                let from_index = usize::try_from(from - 1)
                    .map_err(|_| CliError::new("transfer source exceeds usize"))?;
                let to_index = usize::try_from(to - 1)
                    .map_err(|_| CliError::new("transfer target exceeds usize"))?;
                if pre.get(from_index).copied().unwrap_or(0) < runtime.quantum {
                    return Err(CliError::new(
                        "trajectory transfer spends an unavailable quantum",
                    ));
                }
                let mut expected = pre.clone();
                expected[from_index] -= runtime.quantum;
                expected[to_index] = expected[to_index]
                    .checked_add(runtime.quantum)
                    .ok_or_else(|| CliError::new("trajectory transfer balance overflow"))?;
                if &expected != post {
                    return Err(CliError::new(
                        "trajectory transfer post-state is not the exact unit update",
                    ));
                }
            }
            _ => return Err(CliError::new("trajectory contains an unknown action row")),
        }
    }
    Ok(())
}

fn validate_lower_hex(label: &str, value: &str, length: usize) -> Result<()> {
    if value.len() != length
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
    {
        return Err(CliError::new(format!(
            "{label} must be {length} lowercase hexadecimal characters"
        )));
    }
    Ok(())
}

fn decode_trajectory_action(row: [u64; 3], quantum: u64) -> Result<Action> {
    match row {
        [0, 0, 0] => Ok(Action::Wait),
        [1, from, to] if from > 0 && to > 0 && from != to => {
            let _ = quantum;
            Ok(Action::Transfer {
                from: usize::try_from(from - 1)
                    .map_err(|_| CliError::new("action source exceeds usize"))?,
                to: usize::try_from(to - 1)
                    .map_err(|_| CliError::new("action target exceeds usize"))?,
            })
        }
        _ => Err(CliError::new("invalid compact trajectory action row")),
    }
}

struct ActionModelProbabilities {
    greedy: ExactRatio,
    h1: ExactRatio,
    primary: ExactRatio,
    rotated: ExactRatio,
}

fn observe_likelihoods(
    accumulators: &mut LikelihoodSet,
    probabilities: &ActionModelProbabilities,
) -> Result<()> {
    accumulators.primary.observe(&probabilities.primary)?;
    accumulators.h1.observe(&probabilities.h1)?;
    accumulators.greedy.observe(&probabilities.greedy)?;
    accumulators.rotated.observe(&probabilities.rotated)?;
    Ok(())
}

fn likelihood_docs(likelihoods: &LikelihoodSet) -> Vec<LogLikelihoodDoc> {
    [
        (MODEL_PRIMARY, &likelihoods.primary),
        (MODEL_H1, &likelihoods.h1),
        (MODEL_GREEDY, &likelihoods.greedy),
        (MODEL_ROTATED, &likelihoods.rotated),
    ]
    .into_iter()
    .map(|(model, accumulator)| {
        let total = if accumulator.zero_probability_observations > 0 {
            f64::NEG_INFINITY
        } else {
            accumulator.finite_sum
        };
        let mean = if accumulator.decisions == 0 || accumulator.zero_probability_observations > 0 {
            f64::NAN
        } else {
            total / accumulator.decisions as f64
        };
        LogLikelihoodDoc {
            decision_count: accumulator.decisions.to_string(),
            mean_bits_per_decision: F64Doc::from_value(mean),
            model: model.to_owned(),
            total_bits: F64Doc::from_value(total),
            zero_probability_observations: accumulator.zero_probability_observations.to_string(),
        }
    })
    .collect()
}

fn empirical_transients(
    counts: &BTreeMap<TransientKey, Vec<BigUint>>,
    predicted: &BTreeMap<KernelKey, &KernelPrediction>,
    runtimes: &BTreeMap<KernelKey, RuntimeKernel>,
    episodes_per_cell: u32,
) -> Result<Vec<EmpiricalTransientDoc>> {
    let expected_cell_count = predicted
        .values()
        .flat_map(|kernel| &kernel.transients)
        .map(|transient| transient.points.len())
        .sum::<usize>();
    if counts.len() != expected_cell_count {
        return Err(CliError::new(
            "empirical transient cell set differs from the complete prediction",
        ));
    }
    let denominator = BigUint::from(episodes_per_cell);
    let mut documents = Vec::with_capacity(counts.len());
    for (key, observed_counts) in counts {
        if observed_counts
            .iter()
            .fold(BigUint::zero(), |sum, value| sum + value)
            != denominator
        {
            return Err(CliError::new(
                "transient cell does not contain the frozen episode count",
            ));
        }
        let kernel = predicted
            .get(&key.kernel)
            .ok_or_else(|| CliError::new("predicted transient kernel is absent"))?;
        let transient = kernel
            .transients
            .iter()
            .find(|transient| transient.start_index == key.start_index.to_string())
            .ok_or_else(|| CliError::new("predicted transient start is absent"))?;
        let point = transient
            .points
            .iter()
            .find(|point| point.opportunity == key.opportunity.to_string())
            .ok_or_else(|| CliError::new("predicted transient opportunity is absent"))?;
        let empirical = ExactDistributionDoc::from_parts(observed_counts, &denominator);
        let empirical_probabilities = empirical.probabilities()?;
        let predicted_probabilities = point.exact_state_distribution.probabilities()?;
        let state_total_variation =
            total_variation(&empirical_probabilities, &predicted_probabilities)?;
        let runtime = runtimes
            .get(&key.kernel)
            .ok_or_else(|| CliError::new("runtime transient kernel is absent"))?;
        let partition_marginals = runtime
            .partitions
            .iter()
            .map(|partition| {
                let empirical_partition = partition_marginal(
                    &partition.partition_id,
                    &partition.left_nodes,
                    runtime.analysis.exact().shell().states(),
                    observed_counts,
                    &denominator,
                    runtime.analysis.exact().shell().fixture().inventory(),
                    runtime.quantum,
                )?;
                let predicted_partition = point
                    .partition_marginals
                    .iter()
                    .find(|candidate| candidate.partition_id == partition.partition_id)
                    .ok_or_else(|| CliError::new("predicted partition marginal is absent"))?;
                let tv = total_variation(
                    &empirical_partition.marginal.probabilities()?,
                    &predicted_partition.marginal.probabilities()?,
                )?;
                Ok(EmpiricalPartitionDoc {
                    empirical: empirical_partition,
                    partition_id: partition.partition_id.clone(),
                    predicted: predicted_partition.clone(),
                    total_variation: F64Doc::from_value(tv),
                })
            })
            .collect::<Result<Vec<_>>>()?;
        documents.push(EmpiricalTransientDoc {
            empirical_state_distribution: empirical,
            episode_count: episodes_per_cell.to_string(),
            fixture_id: key.kernel.fixture_id.clone(),
            horizon: key.kernel.horizon.to_string(),
            opportunity: key.opportunity.to_string(),
            partition_marginals,
            permutation_index: key.kernel.permutation_index.to_string(),
            predicted_state_distribution: point.exact_state_distribution.clone(),
            start_index: key.start_index.to_string(),
            total_variation: F64Doc::from_value(state_total_variation),
        });
    }
    Ok(documents)
}

fn empirical_transition_rows(
    counts: &BTreeMap<TransitionKey, Vec<u64>>,
    runtimes: &BTreeMap<KernelKey, RuntimeKernel>,
    category_count: u64,
    minimum_exposures: u64,
    confidence_level: f64,
) -> Result<Vec<EmpiricalTransitionRowDoc>> {
    let family_alpha = 1.0 - confidence_level;
    let mut rows = Vec::with_capacity(counts.len());
    for (key, action_counts) in counts {
        let runtime = runtimes
            .get(&key.kernel)
            .ok_or_else(|| CliError::new("empirical transition kernel is absent"))?;
        let candidates = runtime.analysis.exact().candidate_weights(key.state)?;
        if candidates.len() != action_counts.len() {
            return Err(CliError::new(
                "empirical transition action shape differs from prediction",
            ));
        }
        let exposures = action_counts.iter().try_fold(0u64, |sum, count| {
            sum.checked_add(*count)
                .ok_or_else(|| CliError::new("transition exposure count overflow"))
        })?;
        let eligible = exposures >= minimum_exposures;
        let radius = if eligible {
            ((2.0 * category_count as f64 / family_alpha).ln() / (2.0 * exposures as f64)).sqrt()
        } else {
            f64::NAN
        };
        let denominator = runtime
            .analysis
            .exact()
            .path_count(runtime.analysis.exact().horizon(), key.state)?
            .clone();
        let mut empirical_probabilities = Vec::with_capacity(candidates.len());
        let mut expected_probabilities = Vec::with_capacity(candidates.len());
        let mut actions = Vec::with_capacity(candidates.len());
        for (candidate, count) in candidates.iter().zip(action_counts) {
            let observed = if exposures == 0 {
                f64::NAN
            } else {
                *count as f64 / exposures as f64
            };
            let observed_exact = if exposures == 0 {
                ExactObservedFrequencyDoc::Undefined("undefined".to_owned())
            } else {
                ExactObservedFrequencyDoc::Exact(ExactRatioDoc::from_ratio(&ExactRatio::new(
                    BigUint::from(*count),
                    BigUint::from(exposures),
                )?))
            };
            let expected = ExactRatio::new(candidate.weight.clone(), denominator.clone())?;
            empirical_probabilities.push(observed);
            expected_probabilities.push(expected.to_f64()?);
            actions.push(EmpiricalActionDoc {
                action: ActionDoc::from_action(&candidate.action, runtime.quantum)?,
                count: count.to_string(),
                expected_probability: ExactRatioDoc::from_ratio(&expected),
                observed_frequency: F64Doc::from_value(observed),
                observed_frequency_exact: observed_exact,
                reference_band_99_percent: if eligible {
                    ReferenceBandDoc::Eligible {
                        lower: F64Doc::from_value((observed - radius).max(0.0)),
                        upper: F64Doc::from_value((observed + radius).min(1.0)),
                    }
                } else {
                    ReferenceBandDoc::Ineligible
                },
            });
        }
        let tv = if exposures == 0 {
            f64::NAN
        } else {
            total_variation(&empirical_probabilities, &expected_probabilities)?
        };
        let balances = runtime.analysis.exact().shell().state(key.state)?;
        rows.push(EmpiricalTransitionRowDoc {
            actions,
            eligible_for_reference_band: eligible,
            exposures: exposures.to_string(),
            fixture_id: key.kernel.fixture_id.clone(),
            horizon: key.kernel.horizon.to_string(),
            permutation_index: key.kernel.permutation_index.to_string(),
            reference_band_radius: F64Doc::from_value(radius),
            state: StateDoc {
                balances_microtau: balances
                    .iter()
                    .map(|balance| units_to_microtau_string(*balance, runtime.quantum))
                    .collect::<Result<Vec<_>>>()?,
                state_index: u32::try_from(key.state)
                    .map_err(|_| CliError::new("state index exceeds u32"))?
                    .to_string(),
            },
            total_variation: F64Doc::from_value(tv),
        });
    }
    Ok(rows)
}

fn total_variation(left: &[f64], right: &[f64]) -> Result<f64> {
    if left.len() != right.len()
        || left
            .iter()
            .chain(right)
            .any(|value| !value.is_finite() || *value < 0.0)
    {
        return Err(CliError::new(
            "total-variation inputs have invalid shape or entries",
        ));
    }
    Ok(0.5
        * left
            .iter()
            .zip(right)
            .map(|(left, right)| (left - right).abs())
            .sum::<f64>())
}

fn write_new_bytes(path: &Path, bytes: &[u8]) -> Result<()> {
    let parent = path
        .parent()
        .ok_or_else(|| CliError::new("output path has no parent"))?;
    if !parent.is_dir() {
        return Err(CliError::new("output parent is not an existing directory"));
    }
    let name = path
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or_else(|| CliError::new("output filename is not UTF-8"))?;
    if path.exists() {
        return Err(CliError::new(format!(
            "refusing to replace existing output {}",
            path.display()
        )));
    }
    let temporary = parent.join(format!(
        ".{name}.tmp-{}-{}",
        std::process::id(),
        raw_sha256_hex(bytes)
    ));
    let write_result = (|| -> Result<()> {
        let mut file = OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(&temporary)?;
        file.write_all(bytes)?;
        file.sync_all()?;
        fs::hard_link(&temporary, path)?;
        fs::remove_file(&temporary)?;
        File::open(parent)?.sync_all()?;
        Ok(())
    })();
    if write_result.is_err() {
        let _ = fs::remove_file(&temporary);
    }
    write_result
}

fn write_new_canonical_with_sidecar<T: Serialize>(path: &Path, value: &T) -> Result<()> {
    let bytes = canonical_json_bytes(value)?;
    let sidecar = default_sidecar_path(path)?;
    let sidecar_bytes = hash_sidecar_bytes(path, &bytes)?;
    match fs::symlink_metadata(path) {
        Ok(_) => {
            return Err(CliError::new(
                "refusing to replace an existing canonical report path",
            ))
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => return Err(error.into()),
    }
    match fs::symlink_metadata(&sidecar) {
        Ok(metadata) => {
            if metadata.file_type().is_symlink()
                || !metadata.is_file()
                || fs::read(&sidecar)? != sidecar_bytes
            {
                return Err(CliError::new(
                    "existing report sidecar does not match the pending canonical report",
                ));
            }
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            write_new_bytes(&sidecar, &sidecar_bytes)?;
        }
        Err(error) => return Err(error.into()),
    }
    write_new_bytes(path, &bytes)?;
    if fs::read(path)? != bytes || fs::read(&sidecar)? != sidecar_bytes {
        return Err(CliError::new(
            "published report or sidecar differs from the canonical bytes",
        ));
    }
    Ok(())
}

#[cfg(test)]
fn write_new_prediction_commitment_structure(
    path: &Path,
    prediction: &PredictionDocument,
) -> Result<()> {
    let prediction_bytes = canonical_json_bytes(prediction)?;
    let commitment = build_prediction_commitment_structure(prediction, &prediction_bytes)?;
    write_new_canonical_with_sidecar(path, &commitment)
}

fn write_new_prediction_commitment(path: &Path, prediction: &PredictionDocument) -> Result<()> {
    let prediction_bytes = canonical_json_bytes(prediction)?;
    let commitment = build_prediction_commitment(prediction, &prediction_bytes)?;
    write_new_canonical_with_sidecar(path, &commitment)
}

fn prospective_canonical_path(path: &Path) -> Result<PathBuf> {
    if path.exists() {
        return Ok(fs::canonicalize(path)?);
    }
    let parent = path
        .parent()
        .ok_or_else(|| CliError::new("path has no parent"))?;
    let canonical_parent = fs::canonicalize(parent)?;
    let name = path
        .file_name()
        .ok_or_else(|| CliError::new("path has no filename"))?;
    Ok(canonical_parent.join(name))
}

fn ensure_output_separation(
    output: &Path,
    file_inputs: &[&Path],
    forbidden_directory: Option<&Path>,
) -> Result<()> {
    let output_target = prospective_canonical_path(output)?;
    let sidecar_target = prospective_canonical_path(&default_sidecar_path(output)?)?;
    for input in file_inputs {
        let canonical_input = fs::canonicalize(input)?;
        if output_target == canonical_input || sidecar_target == canonical_input {
            return Err(CliError::new(
                "output report or sidecar overlaps an input artifact",
            ));
        }
    }
    if let Some(directory) = forbidden_directory {
        let canonical_directory = fs::canonicalize(directory)?;
        if output_target.starts_with(&canonical_directory)
            || sidecar_target.starts_with(&canonical_directory)
        {
            return Err(CliError::new(
                "analysis output may not be written inside the normalized collection",
            ));
        }
    }
    Ok(())
}

fn require_canonical_prediction_output(repo_root: &Path, output: &Path) -> Result<()> {
    let repo_root = canonical_repository_root(repo_root)?;
    let expected = repo_root.join(PREDICTION_PATH);
    if absolute_without_parent(output, "prediction commitment output")? != expected
        || absolute_without_parent(
            &default_sidecar_path(output)?,
            "prediction commitment sidecar output",
        )? != repo_root.join(PREDICTION_SIDECAR_PATH)
    {
        return Err(CliError::new(format!(
            "predict output must be the canonical repository commitment path {PREDICTION_PATH}"
        )));
    }
    Ok(())
}

fn require_canonical_prediction_input_path(repo_root: &Path, predictions: &Path) -> Result<()> {
    let repo_root = canonical_repository_root(repo_root)?;
    read_exact_repository_file(
        &repo_root,
        predictions,
        PREDICTION_PATH,
        "prediction commitment",
    )?;
    read_exact_repository_file(
        &repo_root,
        &default_sidecar_path(predictions)?,
        PREDICTION_SIDECAR_PATH,
        "prediction commitment sidecar",
    )?;
    Ok(())
}

fn run(command: Command) -> Result<()> {
    match command {
        Command::Predict {
            repo_root,
            core,
            manifest,
            output,
        } => {
            require_canonical_prediction_output(&repo_root, &output)?;
            ensure_output_separation(&output, &[&core, &manifest], None)?;
            let executable = env::current_exe()?;
            let bundle = FrozenBundle::load(&repo_root, &core, &manifest, &executable)?;
            let prediction = build_prediction(&bundle)?;
            write_new_prediction_commitment(&output, &prediction)
        }
        Command::VerifyPrediction {
            repo_root,
            core,
            manifest,
            predictions,
            expected_identities,
        } => {
            require_canonical_prediction_input_path(&repo_root, &predictions)?;
            let executable = env::current_exe()?;
            let bundle = FrozenBundle::load(&repo_root, &core, &manifest, &executable)?;
            verify_prediction_document(&bundle, &predictions, Some(&expected_identities))
                .map(|_| ())
        }
        Command::Analyze {
            repo_root,
            core,
            manifest,
            predictions,
            normalized,
            output,
        } => {
            let prediction_sidecar = default_sidecar_path(&predictions)?;
            require_canonical_prediction_input_path(&repo_root, &predictions)?;
            ensure_output_separation(
                &output,
                &[&core, &manifest, &predictions, &prediction_sidecar],
                Some(&normalized),
            )?;
            let executable = env::current_exe()?;
            let bundle = FrozenBundle::load(&repo_root, &core, &manifest, &executable)?;
            let report = analyze_collection(&bundle, &predictions, &normalized)?;
            write_new_canonical_with_sidecar(&output, &report)
        }
    }
}

fn main() {
    let result = parse_from(env::args().skip(1)).and_then(run);
    if let Err(error) = result {
        eprintln!("{error}");
        std::process::exit(2);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use xypher_calorimeter_analysis::StateShell;

    fn predict_args() -> Vec<String> {
        [
            "predict",
            "--repo-root",
            ".",
            "--core",
            "core.json",
            "--manifest",
            "final.json",
            "--output",
            "prediction.json",
        ]
        .into_iter()
        .map(str::to_owned)
        .collect()
    }

    fn analyze_args() -> Vec<String> {
        [
            "analyze",
            "--repo-root",
            ".",
            "--core",
            "core.json",
            "--manifest",
            "final.json",
            "--predictions",
            "prediction.json",
            "--normalized",
            "normalized",
            "--output",
            "analysis.json",
        ]
        .into_iter()
        .map(str::to_owned)
        .collect()
    }

    fn verify_args() -> Vec<String> {
        [
            "verify-prediction",
            "--repo-root",
            ".",
            "--core",
            "core.json",
            "--manifest",
            "final.json",
            "--predictions",
            "prediction.json",
            "--expected-commitment-length-bytes",
            "123",
            "--expected-commitment-sha256",
            "1111111111111111111111111111111111111111111111111111111111111111",
            "--expected-sidecar-length-bytes",
            "99",
            "--expected-sidecar-sha256",
            "2222222222222222222222222222222222222222222222222222222222222222",
        ]
        .into_iter()
        .map(str::to_owned)
        .collect()
    }

    fn development_prediction_document() -> PredictionDocument {
        let payload = PredictionPayload {
            fixed_category_count: "1".to_owned(),
            kernels: Vec::new(),
            schema: PREDICTION_PAYLOAD_SCHEMA.to_owned(),
        };
        PredictionDocument {
            all_load_bearing_prediction_gates_passed: true,
            analysis_artifact: ReportFileIdentity {
                length_bytes: "1".to_owned(),
                path: "development/analysis".to_owned(),
                sha256: "00".repeat(32),
            },
            core_hash: "11".repeat(32),
            decision_count: "1".to_owned(),
            episode_count: "1".to_owned(),
            final_manifest_hash: "22".repeat(32),
            fixture_catalog_hash: "33".repeat(32),
            genesis_recipe_hash: "44".repeat(32),
            payload_hash: raw_sha256_hex(&canonical_json_bytes(&payload).expect("payload")),
            payload,
            policy_config_hash: "55".repeat(32),
            reporting_policy_hash: "66".repeat(32),
            schedule_hash: "77".repeat(32),
            schema: PREDICTION_DOCUMENT_SCHEMA.to_owned(),
            tolerances: ToleranceContractDoc {
                exact_probability_absolute_tolerance: F64Doc::from_value(PROBABILITY_TOLERANCE),
                kl_negative_tolerance_bits: F64Doc::from_value(KL_NEGATIVE_TOLERANCE_BITS),
                mfpt_bellman_absolute_tolerance: F64Doc::from_value(MFPT_BELLMAN_TOLERANCE),
                mixing_total_variation_threshold: F64Doc::from_value(MIXING_TV_THRESHOLD),
            },
        }
    }

    #[test]
    fn parser_accepts_only_the_three_complete_commands() {
        assert!(matches!(
            parse_from(predict_args()).expect("predict"),
            Command::Predict { .. }
        ));
        assert!(matches!(
            parse_from(verify_args()).expect("verify"),
            Command::VerifyPrediction { .. }
        ));
        assert!(matches!(
            parse_from(analyze_args()).expect("analyze"),
            Command::Analyze { .. }
        ));
    }

    #[test]
    fn parser_rejects_filters_seeds_unknown_commands_and_duplicates() {
        for option in ["--fixture", "--episode", "--seed", "--horizon"] {
            let mut args = predict_args();
            args.extend([option.to_owned(), "x".to_owned()]);
            assert!(parse_from(args).is_err());
        }
        assert!(parse_from(["status".to_owned()]).is_err());
        let mut duplicated = analyze_args();
        duplicated.extend(["--output".to_owned(), "other.json".to_owned()]);
        assert!(parse_from(duplicated).is_err());
        let mut write_attempt = verify_args();
        write_attempt.extend(["--output".to_owned(), "forbidden.json".to_owned()]);
        assert!(parse_from(write_attempt).is_err());
    }

    #[test]
    fn canonical_repository_inputs_reject_identical_copies() {
        let directory = tempfile::tempdir().expect("tempdir");
        let repo = directory.path().join("repo");
        let canonical = repo.join(FINAL_MANIFEST_PATH);
        fs::create_dir_all(canonical.parent().expect("canonical parent")).expect("parents");
        fs::write(&canonical, b"canonical\n").expect("canonical file");
        let repo = canonical_repository_root(&repo).expect("canonical repo");
        let canonical = repo.join(FINAL_MANIFEST_PATH);
        assert_eq!(
            read_exact_repository_file(&repo, &canonical, FINAL_MANIFEST_PATH, "final manifest",)
                .expect("canonical input"),
            b"canonical\n"
        );

        let copy = directory.path().join("copy.json");
        fs::write(&copy, b"canonical\n").expect("copy");
        assert!(
            read_exact_repository_file(&repo, &copy, FINAL_MANIFEST_PATH, "final manifest")
                .is_err()
        );
    }

    #[cfg(unix)]
    #[test]
    fn canonical_prediction_input_rejects_symlink_aliases() {
        use std::os::unix::fs::symlink;

        let directory = tempfile::tempdir().expect("tempdir");
        let repo = directory.path().join("repo");
        let prediction = repo.join(PREDICTION_PATH);
        fs::create_dir_all(prediction.parent().expect("prediction parent")).expect("parents");
        fs::write(&prediction, b"{}\n").expect("prediction");
        let sidecar = repo.join(PREDICTION_SIDECAR_PATH);
        fs::write(
            &sidecar,
            hash_sidecar_bytes(&prediction, b"{}\n").expect("sidecar bytes"),
        )
        .expect("sidecar");
        let repo = canonical_repository_root(&repo).expect("canonical repo");
        let prediction = repo.join(PREDICTION_PATH);
        require_canonical_prediction_input_path(&repo, &prediction).expect("canonical input");

        let alias = directory.path().join("prediction-alias.json");
        symlink(&prediction, &alias).expect("symlink alias");
        symlink(
            repo.join(PREDICTION_SIDECAR_PATH),
            default_sidecar_path(&alias).expect("alias sidecar path"),
        )
        .expect("sidecar alias");
        assert!(require_canonical_prediction_input_path(&repo, &alias).is_err());
    }

    #[test]
    fn floating_encoding_round_trips_bits_and_names_nonfinite_values() {
        let finite = F64Doc::from_value(-0.0);
        assert_eq!(
            finite,
            F64Doc::Finite(FiniteF64 {
                bits: "8000000000000000".to_owned(),
                decimal: "-0".to_owned(),
            })
        );
        assert_eq!(
            F64Doc::from_value(f64::INFINITY),
            F64Doc::Special("positive_infinity".to_owned())
        );
        assert_eq!(
            F64Doc::from_value(f64::NEG_INFINITY),
            F64Doc::Special("negative_infinity".to_owned())
        );
        assert_eq!(
            F64Doc::from_value(f64::NAN),
            F64Doc::Special("undefined".to_owned())
        );
    }

    #[test]
    fn exact_distribution_and_ratio_documents_use_decimal_strings() {
        let ratio = ExactRatio::new(BigUint::from(12u8), BigUint::from(18u8)).expect("ratio");
        let document = ExactRatioDoc::from_ratio(&ratio);
        assert_eq!(document.numerator, "2");
        assert_eq!(document.denominator, "3");
        assert_eq!(document.to_ratio().expect("round trip"), ratio);
        assert!(parse_biguint("test", "1e3").is_err());
    }

    #[test]
    fn zero_exposure_exact_frequency_is_explicitly_undefined() {
        let encoded =
            serde_json::to_value(ExactObservedFrequencyDoc::Undefined("undefined".to_owned()))
                .expect("encode undefined exact frequency");
        assert_eq!(encoded, serde_json::Value::String("undefined".to_owned()));
    }

    #[test]
    fn prediction_commitment_binds_exact_regenerated_bytes_and_rejects_tampering() {
        let prediction = development_prediction_document();
        let mut invalid_payload_hash = prediction.clone();
        invalid_payload_hash.payload_hash = "ff".repeat(32);
        let invalid_bytes =
            canonical_json_bytes(&invalid_payload_hash).expect("invalid prediction bytes");
        assert!(
            build_prediction_commitment_structure(&invalid_payload_hash, &invalid_bytes).is_err()
        );

        let prediction_bytes = canonical_json_bytes(&prediction).expect("prediction bytes");
        let commitment = build_prediction_commitment_structure(&prediction, &prediction_bytes)
            .expect("commitment");
        assert_eq!(
            commitment.canonical_document.length_bytes,
            prediction_bytes.len().to_string()
        );
        assert_eq!(
            commitment.canonical_document.sha256,
            raw_sha256_hex(&prediction_bytes)
        );
        assert_eq!(commitment.payload_hash, prediction.payload_hash);
        let commitment_bytes = canonical_json_bytes(&commitment).expect("commitment bytes");
        validate_regenerated_prediction_commitment_structure(
            &commitment,
            &commitment_bytes,
            &prediction,
        )
        .expect("exact regeneration");
        assert!(validate_frozen_prediction_commitment(&commitment).is_err());

        let mut malformed = commitment.clone();
        malformed.canonical_document.length_bytes = "01".to_owned();
        assert!(validate_prediction_commitment_structure(&malformed).is_err());

        let mut tampered = commitment;
        tampered.canonical_document.sha256 = "ff".repeat(32);
        validate_prediction_commitment_structure(&tampered).expect("structurally valid tamper");
        assert!(validate_regenerated_prediction_commitment_structure(
            &tampered,
            &canonical_json_bytes(&tampered).expect("tampered bytes"),
            &prediction,
        )
        .is_err());
    }

    #[test]
    fn prediction_writer_publishes_only_the_compact_commitment_and_sidecar() {
        let directory = tempfile::tempdir().expect("tempdir");
        let output = directory.path().join("prediction.commitment.json");
        write_new_prediction_commitment_structure(&output, &development_prediction_document())
            .expect("write commitment");
        let sidecar = default_sidecar_path(&output).expect("sidecar");
        xypher_calorimeter_manifest::validate_hash_sidecar(&output, &sidecar)
            .expect("valid commitment sidecar");
        let bytes = fs::read(&output).expect("commitment bytes");
        let commitment: PredictionCommitment =
            serde_json::from_slice(&bytes).expect("commitment document");
        validate_prediction_commitment_structure(&commitment).expect("valid commitment");

        let mut names = fs::read_dir(directory.path())
            .expect("directory")
            .map(|entry| {
                entry
                    .expect("entry")
                    .file_name()
                    .to_str()
                    .expect("UTF-8")
                    .to_owned()
            })
            .collect::<Vec<_>>();
        names.sort();
        assert_eq!(
            names,
            vec![
                "prediction.commitment.json".to_owned(),
                "prediction.commitment.json.sha256".to_owned(),
            ]
        );
        assert!(!directory.path().join("prediction.json").exists());

        let frozen_output = directory.path().join("frozen.commitment.json");
        assert!(write_new_prediction_commitment(
            &frozen_output,
            &development_prediction_document()
        )
        .is_err());
        assert!(!frozen_output.exists());
    }

    #[test]
    fn verifier_expected_identities_and_collection_binding_use_the_exact_read_buffers() {
        let commitment =
            local_raw_identity_from_bytes(PREDICTION_PATH, b"commitment-a").expect("commitment");
        let sidecar =
            local_raw_identity_from_bytes(PREDICTION_SIDECAR_PATH, b"sidecar-a").expect("sidecar");
        let expected = ExpectedPredictionIdentities {
            commitment_length_bytes: commitment.length_bytes,
            commitment_sha256: commitment.sha256.clone(),
            sidecar_length_bytes: sidecar.length_bytes,
            sidecar_sha256: sidecar.sha256.clone(),
        };
        validate_expected_prediction_identities(&commitment, &sidecar, &expected)
            .expect("matching expected identities");
        validate_collection_prediction_identities(&commitment, &sidecar, &commitment, &sidecar)
            .expect("matching collection identities");

        let replacement =
            local_raw_identity_from_bytes(PREDICTION_PATH, b"commitment-b").expect("replacement");
        assert!(
            validate_expected_prediction_identities(&replacement, &sidecar, &expected).is_err()
        );
        assert!(validate_collection_prediction_identities(
            &replacement,
            &sidecar,
            &commitment,
            &sidecar,
        )
        .is_err());
    }

    #[test]
    fn likelihood_controls_keep_zero_probability_as_negative_infinity() {
        let mut accumulator = ModelAccumulator::default();
        accumulator.observe(&ExactRatio::zero()).expect("zero");
        let set = LikelihoodSet {
            greedy: accumulator,
            ..LikelihoodSet::default()
        };
        let greedy = likelihood_docs(&set)
            .into_iter()
            .find(|document| document.model == MODEL_GREEDY)
            .expect("greedy");
        assert_eq!(
            greedy.total_bits,
            F64Doc::Special("negative_infinity".to_owned())
        );
        assert_eq!(greedy.zero_probability_observations, "1");
        assert_eq!(
            greedy.mean_bits_per_decision,
            F64Doc::Special("undefined".to_owned())
        );
    }

    #[test]
    fn no_clobber_writer_preserves_existing_bytes_and_emits_a_valid_sidecar() {
        let directory = tempfile::tempdir().expect("tempdir");
        let existing = directory.path().join("existing.json");
        fs::write(&existing, b"sealed bytes").expect("seed");
        assert!(write_new_bytes(&existing, b"replacement").is_err());
        assert_eq!(fs::read(&existing).expect("existing"), b"sealed bytes");

        let output = directory.path().join("report.json");
        let document = BTreeMap::from([("schema", "development-report.v1")]);
        write_new_canonical_with_sidecar(&output, &document).expect("write");
        let sidecar = default_sidecar_path(&output).expect("sidecar path");
        xypher_calorimeter_manifest::validate_hash_sidecar(&output, &sidecar)
            .expect("valid sidecar");
        assert!(write_new_canonical_with_sidecar(&output, &document).is_err());

        let resumed = directory.path().join("resumed.json");
        let resumed_bytes = canonical_json_bytes(&document).expect("canonical");
        let resumed_sidecar = default_sidecar_path(&resumed).expect("sidecar path");
        fs::write(
            &resumed_sidecar,
            hash_sidecar_bytes(&resumed, &resumed_bytes).expect("sidecar bytes"),
        )
        .expect("seed sidecar-only crash state");
        write_new_canonical_with_sidecar(&resumed, &document).expect("resume sidecar-first write");
        xypher_calorimeter_manifest::validate_hash_sidecar(&resumed, &resumed_sidecar)
            .expect("resumed sidecar");

        let report_only = directory.path().join("report-only.json");
        fs::write(&report_only, &resumed_bytes).expect("seed report-only corruption");
        assert!(write_new_canonical_with_sidecar(&report_only, &document).is_err());
        assert!(!default_sidecar_path(&report_only)
            .expect("report-only sidecar path")
            .exists());
    }

    #[cfg(unix)]
    #[test]
    fn report_writer_rejects_a_symlinked_sidecar_even_with_matching_bytes() {
        use std::os::unix::fs::symlink;

        let directory = tempfile::tempdir().expect("tempdir");
        let output = directory.path().join("report.json");
        let document = BTreeMap::from([("schema", "development-report.v1")]);
        let bytes = canonical_json_bytes(&document).expect("canonical");
        let sidecar = default_sidecar_path(&output).expect("sidecar path");
        let target = directory.path().join("sidecar-target");
        fs::write(
            &target,
            hash_sidecar_bytes(&output, &bytes).expect("sidecar bytes"),
        )
        .expect("sidecar target");
        symlink(&target, &sidecar).expect("sidecar symlink");

        assert!(write_new_canonical_with_sidecar(&output, &document).is_err());
        assert!(!output.exists());
    }

    #[test]
    fn development_partition_marginal_is_exact_and_conservative() {
        let fixture = AnalysisFixture::new(3, [(0, 1), (1, 2), (0, 2)], 2).expect("fixture");
        let shell = StateShell::enumerate(fixture).expect("shell");
        let kernel = ExactKernel::build(shell, 2).expect("kernel");
        let marginal = partition_marginal(
            "development_partition",
            &[1],
            kernel.shell().states(),
            kernel.stationary_weights(),
            kernel.stationary_normalization(),
            2,
            1,
        )
        .expect("marginal");
        assert_eq!(
            marginal
                .marginal
                .numerators
                .iter()
                .map(|value| parse_biguint("mass", value).expect("mass"))
                .fold(BigUint::zero(), |sum, value| sum + value),
            parse_biguint("denominator", &marginal.marginal.denominator).expect("denominator")
        );
    }

    fn assert_contains_no_json_number(value: &serde_json::Value) {
        match value {
            serde_json::Value::Number(number) => {
                panic!("report contains a JSON number: {number}")
            }
            serde_json::Value::Array(values) => {
                for value in values {
                    assert_contains_no_json_number(value);
                }
            }
            serde_json::Value::Object(values) => {
                for value in values.values() {
                    assert_contains_no_json_number(value);
                }
            }
            serde_json::Value::Null => panic!("report contains JSON null"),
            serde_json::Value::Bool(_) | serde_json::Value::String(_) => {}
        }
    }

    #[test]
    fn development_prediction_kernel_contains_no_json_numbers() {
        let fixture = ManifestFixture {
            account_edges: vec![[1, 2], [1, 3], [2, 3]],
            fixture_id: "development_complete_graph".to_owned(),
            horizons: vec![2],
            initial_balances: vec![vec![2, 0, 0], vec![1, 1, 0]],
            inventory_microtau: 2,
            node_count: 3,
            permutations: vec![xypher_calorimeter_manifest::LabelPermutation {
                image_by_node: vec![1, 2, 3],
                permutation_id: "development_identity".to_owned(),
            }],
            reporting_partitions: vec![ReportingPartition {
                left_nodes: vec![1],
                partition_id: "development_one_plus_two".to_owned(),
                right_nodes: vec![2, 3],
            }],
        };
        let gap = Analysis::build(
            AnalysisFixture::new(3, [(0, 1), (0, 2), (1, 2)], 2).expect("fixture"),
            2,
        )
        .expect("analysis")
        .spectral()
        .spectral_gap;
        let length = (20.0_f64).max(10.0 / gap).ceil() as u64;
        let kernel = build_kernel_prediction(&fixture, 2, 0, length, &gap.to_string(), 1)
            .expect("prediction");
        let payload = PredictionPayload {
            fixed_category_count: kernel.fixed_category_count.clone(),
            kernels: vec![kernel],
            schema: PREDICTION_PAYLOAD_SCHEMA.to_owned(),
        };
        let prediction = PredictionDocument {
            all_load_bearing_prediction_gates_passed: true,
            analysis_artifact: ReportFileIdentity {
                length_bytes: "123".to_owned(),
                path: "development/analysis".to_owned(),
                sha256: "00".repeat(32),
            },
            core_hash: "11".repeat(32),
            decision_count: length.to_string(),
            episode_count: "1".to_owned(),
            final_manifest_hash: "22".repeat(32),
            fixture_catalog_hash: "33".repeat(32),
            genesis_recipe_hash: "44".repeat(32),
            payload_hash: raw_sha256_hex(&canonical_json_bytes(&payload).expect("payload")),
            payload,
            policy_config_hash: "55".repeat(32),
            reporting_policy_hash: "66".repeat(32),
            schedule_hash: "77".repeat(32),
            schema: PREDICTION_DOCUMENT_SCHEMA.to_owned(),
            tolerances: ToleranceContractDoc {
                exact_probability_absolute_tolerance: F64Doc::from_value(PROBABILITY_TOLERANCE),
                kl_negative_tolerance_bits: F64Doc::from_value(KL_NEGATIVE_TOLERANCE_BITS),
                mfpt_bellman_absolute_tolerance: F64Doc::from_value(MFPT_BELLMAN_TOLERANCE),
                mixing_total_variation_threshold: F64Doc::from_value(MIXING_TV_THRESHOLD),
            },
        };
        assert_contains_no_json_number(
            &serde_json::to_value(&prediction).expect("prediction JSON"),
        );
        let prediction_bytes = canonical_json_bytes(&prediction).expect("prediction bytes");
        let commitment = build_prediction_commitment_structure(&prediction, &prediction_bytes)
            .expect("commitment");
        assert_contains_no_json_number(&serde_json::to_value(commitment).expect("commitment JSON"));
    }

    #[test]
    fn episode_length_interval_gate_checks_both_preregistered_boundaries() {
        require_frozen_episode_length_for_gap_interval(2, 54, 0.1870, 0.1872)
            .expect("stable interval");
        assert!(require_frozen_episode_length_for_gap_interval(2, 54, 0.18, 0.1872).is_err());
        assert!(require_frozen_episode_length_for_gap_interval(2, 54, 0.1870, 0.19).is_err());
        require_frozen_episode_length_for_gap_interval(5, 50, 0.25, 0.26).expect("horizon floor");
        assert!(require_frozen_episode_length_for_gap_interval(5, 50, 0.19, 0.26).is_err());
    }

    #[test]
    fn frozen_schedule_passes_cluster_aware_spectral_admission_for_every_relabelling() {
        let catalog = xypher_calorimeter_manifest::frozen_catalog();
        let policy = xypher_calorimeter_manifest::frozen_policy();
        for fixture in &catalog.fixtures {
            let inventory_units =
                u32::try_from(fixture.inventory_microtau / policy.action_quantum_microtau)
                    .expect("inventory units");
            for &horizon in &fixture.horizons {
                let schedule = policy
                    .schedules
                    .iter()
                    .find(|schedule| {
                        schedule.fixture_id == fixture.fixture_id && schedule.horizon == horizon
                    })
                    .expect("schedule");
                let canonical = Analysis::build(
                    AnalysisFixture::new(
                        usize::try_from(fixture.node_count).expect("node count"),
                        zero_based_edges(&fixture.account_edges).expect("canonical edges"),
                        inventory_units,
                    )
                    .expect("canonical fixture"),
                    usize::try_from(horizon).expect("horizon"),
                )
                .expect("canonical analysis");

                for permutation in &fixture.permutations {
                    let relabelled_edges =
                        relabel_edges(&fixture.account_edges, &permutation.image_by_node)
                            .expect("relabelled edges");
                    let relabelled = Analysis::build(
                        AnalysisFixture::new(
                            usize::try_from(fixture.node_count).expect("node count"),
                            zero_based_edges(&relabelled_edges).expect("zero-based edges"),
                            inventory_units,
                        )
                        .expect("relabelled fixture"),
                        usize::try_from(horizon).expect("horizon"),
                    )
                    .expect("relabelled analysis");
                    let declared_gap =
                        parse_finite_positive_f64("declared spectral gap", &schedule.spectral_gap)
                            .expect("declared gap");
                    let admission = admit_spectral_schedule(
                        canonical.spectral(),
                        relabelled.spectral(),
                        horizon,
                        schedule.episode_length,
                        declared_gap,
                    )
                    .expect("spectral schedule admission");
                    assert!(admission.all_passed);

                    let node_permutation = permutation
                        .image_by_node
                        .iter()
                        .map(|node| usize::try_from(node - 1).expect("node image"))
                        .collect::<Vec<_>>();
                    assert!(canonical
                        .exact()
                        .verify_permutation_covariance(&node_permutation)
                        .expect("exact covariance")
                        .all_passed());
                }
            }
        }
    }
}
