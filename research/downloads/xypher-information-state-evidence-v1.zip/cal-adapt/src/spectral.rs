use crate::{AnalysisError, Result};

// THUMB td-fbdd6c: deterministic numerical QA bounds, not model parameters.
const JACOBI_RELATIVE_TOLERANCE: f64 = 2.0e-14;
const SPECTRAL_ACCEPTANCE_RELATIVE_TOLERANCE: f64 = 5.0e-12;
const JACOBI_MINIMUM_SWEEPS: usize = 32;
const JACOBI_SWEEPS_PER_STATE: usize = 4;

#[derive(Clone, Debug, PartialEq)]
pub struct DenseMatrix {
    size: usize,
    values: Vec<f64>,
}

impl DenseMatrix {
    pub fn from_rows(rows: Vec<Vec<f64>>) -> Result<Self> {
        if rows.is_empty() {
            return Err(AnalysisError::new("matrix must not be empty"));
        }
        let size = rows.len();
        if rows.iter().any(|row| row.len() != size) {
            return Err(AnalysisError::new("matrix must be square"));
        }
        let values: Vec<f64> = rows.into_iter().flatten().collect();
        if values.iter().any(|value| !value.is_finite()) {
            return Err(AnalysisError::new("matrix contains a non-finite entry"));
        }
        Ok(Self { size, values })
    }

    pub fn zeros(size: usize) -> Result<Self> {
        if size == 0 {
            return Err(AnalysisError::new("matrix must not be empty"));
        }
        Ok(Self {
            size,
            values: vec![0.0; size * size],
        })
    }

    pub fn identity(size: usize) -> Result<Self> {
        let mut matrix = Self::zeros(size)?;
        for index in 0..size {
            matrix.set(index, index, 1.0);
        }
        Ok(matrix)
    }

    pub fn size(&self) -> usize {
        self.size
    }

    pub fn get(&self, row: usize, column: usize) -> f64 {
        self.values[row * self.size + column]
    }

    pub fn row(&self, row: usize) -> &[f64] {
        let start = row * self.size;
        &self.values[start..start + self.size]
    }

    pub fn rows(&self) -> impl Iterator<Item = &[f64]> {
        self.values.chunks_exact(self.size)
    }

    pub fn multiply_row_vector(&self, vector: &[f64]) -> Result<Vec<f64>> {
        if vector.len() != self.size {
            return Err(AnalysisError::new(
                "row-vector and matrix shapes do not match",
            ));
        }
        let mut product = vec![0.0; self.size];
        for (source, &mass) in vector.iter().enumerate() {
            if mass == 0.0 {
                continue;
            }
            for (target, value) in product.iter_mut().enumerate() {
                *value += mass * self.get(source, target);
            }
        }
        Ok(product)
    }

    pub(crate) fn set(&mut self, row: usize, column: usize, value: f64) {
        self.values[row * self.size + column] = value;
    }

    pub(crate) fn max_abs(&self) -> f64 {
        self.values
            .iter()
            .fold(0.0_f64, |maximum, value| maximum.max(value.abs()))
    }

    pub(crate) fn max_asymmetry(&self) -> f64 {
        let mut maximum = 0.0_f64;
        for row in 0..self.size {
            for column in (row + 1)..self.size {
                maximum = maximum.max((self.get(row, column) - self.get(column, row)).abs());
            }
        }
        maximum
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct SymmetricSpectrum {
    pub eigenvalues: Vec<f64>,
    eigenvectors: DenseMatrix,
    pub eigenvector_norm_lower_bounds: Vec<f64>,
    pub eigenvector_norm_upper_bounds: Vec<f64>,
    pub normalized_eigenpair_residual_upper_bounds: Vec<f64>,
    pub sweeps: usize,
    pub global_eigenvalue_error_upper_bound: f64,
    pub maximum_off_diagonal: f64,
    pub maximum_eigenpair_residual: f64,
    pub maximum_normalized_eigenpair_residual_upper_bound: f64,
    pub maximum_orthogonality_residual: f64,
    pub orthogonality_frobenius_residual_upper_bound: f64,
    pub maximum_reconstruction_residual: f64,
}

impl SymmetricSpectrum {
    pub fn eigenvector(&self, eigenvalue_index: usize) -> Result<Vec<f64>> {
        if eigenvalue_index >= self.eigenvalues.len() {
            return Err(AnalysisError::new("eigenvalue index is out of range"));
        }
        Ok((0..self.eigenvalues.len())
            .map(|row| self.eigenvectors.get(row, eigenvalue_index))
            .collect())
    }
}

pub fn symmetric_eigendecomposition(matrix: &DenseMatrix) -> Result<SymmetricSpectrum> {
    let symmetry_tolerance =
        JACOBI_RELATIVE_TOLERANCE * matrix.max_abs().max(1.0) * matrix.size() as f64;
    if matrix.max_asymmetry() > symmetry_tolerance {
        return Err(AnalysisError::new(
            "symmetric eigensolver received an asymmetric matrix",
        ));
    }

    let size = matrix.size();
    let mut diagonalized = matrix.clone();
    for row in 0..size {
        for column in (row + 1)..size {
            let average = 0.5 * (diagonalized.get(row, column) + diagonalized.get(column, row));
            diagonalized.set(row, column, average);
            diagonalized.set(column, row, average);
        }
    }
    let mut eigenvectors = DenseMatrix::identity(size)?;
    let scale = diagonalized.max_abs().max(1.0);
    let tolerance = JACOBI_RELATIVE_TOLERANCE * scale;
    let maximum_sweeps = JACOBI_MINIMUM_SWEEPS.max(size.saturating_mul(JACOBI_SWEEPS_PER_STATE));

    let mut completed_sweeps = 0;
    let mut maximum_off_diagonal = max_off_diagonal(&diagonalized);
    while completed_sweeps < maximum_sweeps && maximum_off_diagonal > tolerance {
        for pivot in 0..size {
            for target in (pivot + 1)..size {
                if diagonalized.get(pivot, target).abs() > tolerance {
                    jacobi_rotate(&mut diagonalized, &mut eigenvectors, pivot, target);
                }
            }
        }
        completed_sweeps += 1;
        maximum_off_diagonal = max_off_diagonal(&diagonalized);
    }

    if maximum_off_diagonal > tolerance {
        return Err(AnalysisError::new(format!(
            "Jacobi eigensolver did not converge: off-diagonal {maximum_off_diagonal:.3e}"
        )));
    }

    let mut ordering: Vec<usize> = (0..size).collect();
    ordering.sort_by(|&left, &right| {
        diagonalized
            .get(right, right)
            .total_cmp(&diagonalized.get(left, left))
            .then_with(|| left.cmp(&right))
    });
    let eigenvalues: Vec<f64> = ordering
        .iter()
        .map(|&index| diagonalized.get(index, index))
        .collect();
    let mut sorted_vectors = DenseMatrix::zeros(size)?;
    for (new_column, &old_column) in ordering.iter().enumerate() {
        let sign = deterministic_column_sign(&eigenvectors, old_column);
        for row in 0..size {
            sorted_vectors.set(row, new_column, sign * eigenvectors.get(row, old_column));
        }
    }

    let eigenpair_residuals = eigenpair_residuals(matrix, &eigenvalues, &sorted_vectors)?;
    let maximum_eigenpair_residual = eigenpair_residuals.maximum_component_residual;
    let maximum_normalized_eigenpair_residual_upper_bound = eigenpair_residuals
        .normalized_upper_bounds
        .iter()
        .copied()
        .fold(0.0_f64, f64::max);
    let orthogonality_residuals = orthogonality_residuals(&sorted_vectors)?;
    let maximum_orthogonality_residual = orthogonality_residuals.maximum_component_residual;
    let maximum_reconstruction_residual =
        maximum_reconstruction_residual(matrix, &eigenvalues, &sorted_vectors);
    let global_eigenvalue_error_upper_bound = global_eigenvalue_error_upper_bound(
        eigenpair_residuals.residual_frobenius_upper_bound,
        orthogonality_residuals.frobenius_upper_bound,
    )?;
    let matrix_acceptance = SPECTRAL_ACCEPTANCE_RELATIVE_TOLERANCE * scale * size.max(1) as f64;
    let orthogonality_acceptance = SPECTRAL_ACCEPTANCE_RELATIVE_TOLERANCE * size.max(1) as f64;
    let normalization_failed = eigenpair_residuals
        .vector_norm_lower_bounds
        .iter()
        .zip(&eigenpair_residuals.vector_norm_upper_bounds)
        .any(|(&lower, &upper)| {
            lower < 1.0 - orthogonality_acceptance || upper > 1.0 + orthogonality_acceptance
        });
    if maximum_eigenpair_residual > matrix_acceptance
        || maximum_normalized_eigenpair_residual_upper_bound > matrix_acceptance
        || maximum_reconstruction_residual > matrix_acceptance
        || maximum_orthogonality_residual > orthogonality_acceptance
        || global_eigenvalue_error_upper_bound > matrix_acceptance
        || normalization_failed
    {
        return Err(AnalysisError::new(format!(
            "Jacobi residual gate failed: eigenpair={maximum_eigenpair_residual:.3e}, \
             normalized_eigenpair={maximum_normalized_eigenpair_residual_upper_bound:.3e}, \
             orthogonality={maximum_orthogonality_residual:.3e}, \
             reconstruction={maximum_reconstruction_residual:.3e}, \
             global_eigenvalue={global_eigenvalue_error_upper_bound:.3e}"
        )));
    }

    Ok(SymmetricSpectrum {
        eigenvalues,
        eigenvectors: sorted_vectors,
        eigenvector_norm_lower_bounds: eigenpair_residuals.vector_norm_lower_bounds,
        eigenvector_norm_upper_bounds: eigenpair_residuals.vector_norm_upper_bounds,
        normalized_eigenpair_residual_upper_bounds: eigenpair_residuals.normalized_upper_bounds,
        sweeps: completed_sweeps,
        global_eigenvalue_error_upper_bound,
        maximum_off_diagonal,
        maximum_eigenpair_residual,
        maximum_normalized_eigenpair_residual_upper_bound,
        maximum_orthogonality_residual,
        orthogonality_frobenius_residual_upper_bound: orthogonality_residuals.frobenius_upper_bound,
        maximum_reconstruction_residual,
    })
}

fn jacobi_rotate(
    matrix: &mut DenseMatrix,
    eigenvectors: &mut DenseMatrix,
    pivot: usize,
    target: usize,
) {
    let off_diagonal = matrix.get(pivot, target);
    if off_diagonal == 0.0 {
        return;
    }
    let pivot_value = matrix.get(pivot, pivot);
    let target_value = matrix.get(target, target);
    let tau = (target_value - pivot_value) / (2.0 * off_diagonal);
    let tangent = if tau == 0.0 {
        1.0
    } else {
        tau.signum() / (tau.abs() + (1.0 + tau * tau).sqrt())
    };
    let cosine = 1.0 / (1.0 + tangent * tangent).sqrt();
    let sine = tangent * cosine;

    for index in 0..matrix.size() {
        if index == pivot || index == target {
            continue;
        }
        let index_pivot = matrix.get(index, pivot);
        let index_target = matrix.get(index, target);
        let rotated_pivot = cosine * index_pivot - sine * index_target;
        let rotated_target = sine * index_pivot + cosine * index_target;
        matrix.set(index, pivot, rotated_pivot);
        matrix.set(pivot, index, rotated_pivot);
        matrix.set(index, target, rotated_target);
        matrix.set(target, index, rotated_target);
    }

    let twice_cross = 2.0 * sine * cosine * off_diagonal;
    matrix.set(
        pivot,
        pivot,
        cosine * cosine * pivot_value - twice_cross + sine * sine * target_value,
    );
    matrix.set(
        target,
        target,
        sine * sine * pivot_value + twice_cross + cosine * cosine * target_value,
    );
    matrix.set(pivot, target, 0.0);
    matrix.set(target, pivot, 0.0);

    for row in 0..eigenvectors.size() {
        let row_pivot = eigenvectors.get(row, pivot);
        let row_target = eigenvectors.get(row, target);
        eigenvectors.set(row, pivot, cosine * row_pivot - sine * row_target);
        eigenvectors.set(row, target, sine * row_pivot + cosine * row_target);
    }
}

fn deterministic_column_sign(matrix: &DenseMatrix, column: usize) -> f64 {
    for row in 0..matrix.size() {
        let value = matrix.get(row, column);
        if value.abs() > JACOBI_RELATIVE_TOLERANCE {
            return if value < 0.0 { -1.0 } else { 1.0 };
        }
    }
    1.0
}

fn max_off_diagonal(matrix: &DenseMatrix) -> f64 {
    let mut maximum = 0.0_f64;
    for row in 0..matrix.size() {
        for column in (row + 1)..matrix.size() {
            maximum = maximum.max(matrix.get(row, column).abs());
        }
    }
    maximum
}

struct EigenpairResiduals {
    maximum_component_residual: f64,
    normalized_upper_bounds: Vec<f64>,
    residual_frobenius_upper_bound: f64,
    vector_norm_lower_bounds: Vec<f64>,
    vector_norm_upper_bounds: Vec<f64>,
}

fn eigenpair_residuals(
    matrix: &DenseMatrix,
    eigenvalues: &[f64],
    eigenvectors: &DenseMatrix,
) -> Result<EigenpairResiduals> {
    let mut maximum_component_residual = 0.0_f64;
    let mut normalized_upper_bounds = Vec::with_capacity(eigenvalues.len());
    let mut residual_frobenius_squared_upper = 0.0_f64;
    let mut vector_norm_lower_bounds = Vec::with_capacity(eigenvalues.len());
    let mut vector_norm_upper_bounds = Vec::with_capacity(eigenvalues.len());
    let dot_product_roundoff = rounding_gamma(matrix.size().saturating_mul(2).saturating_add(3))?;

    for (column, &eigenvalue) in eigenvalues.iter().enumerate() {
        let mut vector_norm_squared_lower = 0.0_f64;
        let mut vector_norm_squared_upper = 0.0_f64;
        let mut residual_norm_squared_upper = 0.0_f64;
        for row in 0..matrix.size() {
            let vector_entry = eigenvectors.get(row, column);
            let vector_square = vector_entry * vector_entry;
            vector_norm_squared_lower =
                add_down(vector_norm_squared_lower, next_down(vector_square));
            vector_norm_squared_upper = add_up(vector_norm_squared_upper, next_up(vector_square));

            let projected: f64 = (0..matrix.size())
                .map(|inner| matrix.get(row, inner) * eigenvectors.get(inner, column))
                .sum();
            let scaled = eigenvalue * vector_entry;
            let residual = projected - scaled;
            maximum_component_residual = maximum_component_residual.max(residual.abs());

            let mut magnitude_upper = 0.0_f64;
            for inner in 0..matrix.size() {
                magnitude_upper = add_up(
                    magnitude_upper,
                    next_up((matrix.get(row, inner) * eigenvectors.get(inner, column)).abs()),
                );
            }
            magnitude_upper = add_up(magnitude_upper, next_up(scaled.abs()));
            let component_upper = add_up(
                residual.abs(),
                next_up(dot_product_roundoff * magnitude_upper),
            );
            residual_norm_squared_upper = add_up(
                residual_norm_squared_upper,
                next_up(component_upper * component_upper),
            );
            residual_frobenius_squared_upper = add_up(
                residual_frobenius_squared_upper,
                next_up(component_upper * component_upper),
            );
        }
        let vector_norm_lower = next_down(vector_norm_squared_lower.sqrt());
        let vector_norm_upper = next_up(vector_norm_squared_upper.sqrt());
        if !vector_norm_lower.is_finite() || vector_norm_lower <= 0.0 {
            return Err(AnalysisError::new(
                "Jacobi eigenvector has no positive finite norm lower bound",
            ));
        }
        let residual_norm_upper = next_up(residual_norm_squared_upper.sqrt());
        let normalized_upper = next_up(residual_norm_upper / vector_norm_lower);
        if !vector_norm_upper.is_finite() || !normalized_upper.is_finite() {
            return Err(AnalysisError::new(
                "Jacobi eigenpair residual bound is non-finite",
            ));
        }
        vector_norm_lower_bounds.push(vector_norm_lower);
        vector_norm_upper_bounds.push(vector_norm_upper);
        normalized_upper_bounds.push(normalized_upper);
    }
    Ok(EigenpairResiduals {
        maximum_component_residual,
        normalized_upper_bounds,
        residual_frobenius_upper_bound: next_up(residual_frobenius_squared_upper.sqrt()),
        vector_norm_lower_bounds,
        vector_norm_upper_bounds,
    })
}

fn rounding_gamma(operation_count: usize) -> Result<f64> {
    let accumulated = mul_up(operation_count as f64, f64::EPSILON / 2.0);
    if !accumulated.is_finite() || accumulated >= 1.0 {
        return Err(AnalysisError::new(
            "floating residual operation count is too large",
        ));
    }
    let denominator = sub_down(1.0, accumulated);
    Ok(div_up(accumulated, denominator))
}

fn next_up(value: f64) -> f64 {
    if value.is_nan() || value == f64::INFINITY {
        return value;
    }
    if value == -0.0 {
        return f64::from_bits(1);
    }
    if value >= 0.0 {
        f64::from_bits(value.to_bits() + 1)
    } else {
        f64::from_bits(value.to_bits() - 1)
    }
}

fn next_down(value: f64) -> f64 {
    if value.is_nan() || value == f64::NEG_INFINITY {
        return value;
    }
    if value == 0.0 {
        return -f64::from_bits(1);
    }
    if value > 0.0 {
        f64::from_bits(value.to_bits() - 1)
    } else {
        f64::from_bits(value.to_bits() + 1)
    }
}

fn add_up(left: f64, right: f64) -> f64 {
    next_up(left + right)
}

fn add_down(left: f64, right: f64) -> f64 {
    next_down(left + right)
}

fn mul_up(left: f64, right: f64) -> f64 {
    if left == 0.0 || right == 0.0 {
        0.0
    } else {
        next_up(left * right)
    }
}

fn div_up(numerator: f64, denominator: f64) -> f64 {
    next_up(numerator / denominator)
}

fn sub_down(left: f64, right: f64) -> f64 {
    next_down(left - right)
}

struct MatrixResiduals {
    frobenius_upper_bound: f64,
    maximum_component_residual: f64,
}

fn orthogonality_residuals(eigenvectors: &DenseMatrix) -> Result<MatrixResiduals> {
    let mut maximum_component_residual = 0.0_f64;
    let mut frobenius_squared_upper = 0.0_f64;
    let dot_product_roundoff =
        rounding_gamma(eigenvectors.size().saturating_mul(2).saturating_add(2))?;
    for left in 0..eigenvectors.size() {
        for right in 0..eigenvectors.size() {
            let inner_product: f64 = (0..eigenvectors.size())
                .map(|row| eigenvectors.get(row, left) * eigenvectors.get(row, right))
                .sum();
            let expected = if left == right { 1.0 } else { 0.0 };
            let residual = inner_product - expected;
            maximum_component_residual = maximum_component_residual.max(residual.abs());

            let mut magnitude_upper = expected;
            for row in 0..eigenvectors.size() {
                magnitude_upper = add_up(
                    magnitude_upper,
                    next_up((eigenvectors.get(row, left) * eigenvectors.get(row, right)).abs()),
                );
            }
            let component_upper = add_up(
                residual.abs(),
                mul_up(dot_product_roundoff, magnitude_upper),
            );
            frobenius_squared_upper = add_up(
                frobenius_squared_upper,
                mul_up(component_upper, component_upper),
            );
        }
    }
    Ok(MatrixResiduals {
        frobenius_upper_bound: next_up(frobenius_squared_upper.sqrt()),
        maximum_component_residual,
    })
}

fn global_eigenvalue_error_upper_bound(
    residual_frobenius_upper_bound: f64,
    orthogonality_frobenius_upper_bound: f64,
) -> Result<f64> {
    if !residual_frobenius_upper_bound.is_finite()
        || !orthogonality_frobenius_upper_bound.is_finite()
        || orthogonality_frobenius_upper_bound >= 1.0
    {
        return Err(AnalysisError::new(
            "full-basis spectral residual bound is invalid",
        ));
    }
    let minimum_gram_eigenvalue = sub_down(1.0, orthogonality_frobenius_upper_bound);
    if minimum_gram_eigenvalue <= 0.0 {
        return Err(AnalysisError::new(
            "Jacobi eigenvector basis is not certified invertible",
        ));
    }
    let minimum_singular_value = next_down(minimum_gram_eigenvalue.sqrt());
    if minimum_singular_value <= 0.0 {
        return Err(AnalysisError::new(
            "Jacobi eigenvector singular-value bound is not positive",
        ));
    }
    Ok(div_up(
        residual_frobenius_upper_bound,
        minimum_singular_value,
    ))
}

fn maximum_reconstruction_residual(
    matrix: &DenseMatrix,
    eigenvalues: &[f64],
    eigenvectors: &DenseMatrix,
) -> f64 {
    let mut maximum = 0.0_f64;
    for row in 0..matrix.size() {
        for column in 0..matrix.size() {
            let reconstructed: f64 = (0..matrix.size())
                .map(|mode| {
                    eigenvectors.get(row, mode) * eigenvalues[mode] * eigenvectors.get(column, mode)
                })
                .sum();
            maximum = maximum.max((reconstructed - matrix.get(row, column)).abs());
        }
    }
    maximum
}
