use crate::{AnalysisError, ExactRatio, Result};
use num_bigint::BigUint;
use num_traits::{One, Zero};
use std::cmp::Ordering;
use std::collections::{BTreeMap, VecDeque};

pub const FROZEN_NODE_COUNT: usize = 9;
pub const FROZEN_STATE_COUNT: usize = 1 << FROZEN_NODE_COUNT;
pub const FROZEN_SLOT_COUNT: usize = 23;

const T2_NODES: [usize; 2] = [0, 1];
const T3_NODES: [usize; 3] = [2, 3, 4];
const T4_NODES: [usize; 4] = [5, 6, 7, 8];

const INTERNAL_EDGES: [(usize, usize); 8] = [
    (0, 1),
    (2, 3),
    (3, 4),
    (2, 4),
    (5, 6),
    (6, 7),
    (7, 8),
    (8, 5),
];

pub const FROZEN_AFFORDANCE_SLOTS: [FrozenAffordanceSlot; FROZEN_SLOT_COUNT] = [
    FrozenAffordanceSlot::Wait,
    FrozenAffordanceSlot::Attempt { from: 0, to: 1 },
    FrozenAffordanceSlot::Attempt { from: 1, to: 0 },
    FrozenAffordanceSlot::Attempt { from: 2, to: 3 },
    FrozenAffordanceSlot::Attempt { from: 3, to: 2 },
    FrozenAffordanceSlot::Attempt { from: 3, to: 4 },
    FrozenAffordanceSlot::Attempt { from: 4, to: 3 },
    FrozenAffordanceSlot::Attempt { from: 2, to: 4 },
    FrozenAffordanceSlot::Attempt { from: 4, to: 2 },
    FrozenAffordanceSlot::Attempt { from: 5, to: 6 },
    FrozenAffordanceSlot::Attempt { from: 6, to: 5 },
    FrozenAffordanceSlot::Attempt { from: 6, to: 7 },
    FrozenAffordanceSlot::Attempt { from: 7, to: 6 },
    FrozenAffordanceSlot::Attempt { from: 7, to: 8 },
    FrozenAffordanceSlot::Attempt { from: 8, to: 7 },
    FrozenAffordanceSlot::Attempt { from: 8, to: 5 },
    FrozenAffordanceSlot::Attempt { from: 5, to: 8 },
    FrozenAffordanceSlot::Attempt { from: 1, to: 2 },
    FrozenAffordanceSlot::Attempt { from: 2, to: 1 },
    FrozenAffordanceSlot::Attempt { from: 4, to: 5 },
    FrozenAffordanceSlot::Attempt { from: 5, to: 4 },
    FrozenAffordanceSlot::Attempt { from: 0, to: 8 },
    FrozenAffordanceSlot::Attempt { from: 8, to: 0 },
];

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum FrozenBody {
    T2,
    T3,
    T4,
}

impl FrozenBody {
    pub const ALL: [Self; 3] = [Self::T2, Self::T3, Self::T4];

    pub fn nodes(self) -> &'static [usize] {
        match self {
            Self::T2 => &T2_NODES,
            Self::T3 => &T3_NODES,
            Self::T4 => &T4_NODES,
        }
    }

    pub fn node_count(self) -> usize {
        self.nodes().len()
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum FrozenContactPair {
    T2T3,
    T3T4,
    T2T4,
}

impl FrozenContactPair {
    pub const ALL: [Self; 3] = [Self::T2T3, Self::T3T4, Self::T2T4];

    pub fn left(self) -> FrozenBody {
        match self {
            Self::T2T3 | Self::T2T4 => FrozenBody::T2,
            Self::T3T4 => FrozenBody::T3,
        }
    }

    pub fn right(self) -> FrozenBody {
        match self {
            Self::T2T3 => FrozenBody::T3,
            Self::T3T4 | Self::T2T4 => FrozenBody::T4,
        }
    }

    pub fn spectator(self) -> FrozenBody {
        match self {
            Self::T2T3 => FrozenBody::T4,
            Self::T3T4 => FrozenBody::T2,
            Self::T2T4 => FrozenBody::T3,
        }
    }

    pub fn bridge(self) -> (usize, usize) {
        match self {
            Self::T2T3 => (1, 2),
            Self::T3T4 => (4, 5),
            Self::T2T4 => (0, 8),
        }
    }

    pub fn active_node_count(self) -> usize {
        self.left().node_count() + self.right().node_count()
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum FrozenContactMode {
    Isolated,
    Pair(FrozenContactPair),
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum FrozenAffordanceSlot {
    Wait,
    Attempt { from: usize, to: usize },
}

impl FrozenAffordanceSlot {
    pub fn is_internal(self) -> bool {
        match self {
            Self::Wait => false,
            Self::Attempt { from, to } => undirected_edge_is_internal(from, to),
        }
    }

    pub fn reversed(self) -> Self {
        match self {
            Self::Wait => Self::Wait,
            Self::Attempt { from, to } => Self::Attempt { from: to, to: from },
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct FrozenBinaryState {
    bits: u16,
}

impl FrozenBinaryState {
    pub fn from_index(index: usize) -> Result<Self> {
        if index >= FROZEN_STATE_COUNT {
            return Err(AnalysisError::new(
                "fixed-affordance state index is out of range",
            ));
        }
        Ok(Self { bits: index as u16 })
    }

    pub fn index(self) -> usize {
        usize::from(self.bits)
    }

    pub fn bits(self) -> u16 {
        self.bits
    }

    pub fn occupied(self, node: usize) -> Result<bool> {
        if node >= FROZEN_NODE_COUNT {
            return Err(AnalysisError::new(
                "fixed-affordance node index is out of range",
            ));
        }
        Ok(self.occupied_unchecked(node))
    }

    pub fn total_occupation(self) -> usize {
        self.bits.count_ones() as usize
    }

    pub fn body_occupation(self, body: FrozenBody) -> usize {
        body.nodes()
            .iter()
            .filter(|&&node| self.occupied_unchecked(node))
            .count()
    }

    fn occupied_unchecked(self, node: usize) -> bool {
        self.bits & (1_u16 << node) != 0
    }

    fn transferred(self, from: usize, to: usize) -> Self {
        Self {
            bits: (self.bits & !(1_u16 << from)) | (1_u16 << to),
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct FrozenChannelInstance {
    pub state: FrozenBinaryState,
    pub slot: FrozenAffordanceSlot,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FrozenChannelOutcome {
    pub instance: FrozenChannelInstance,
    pub successor: FrozenBinaryState,
    pub realized_transfer: bool,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FrozenFixedAffordanceKernel {
    mode: FrozenContactMode,
}

impl FrozenFixedAffordanceKernel {
    pub fn new(mode: FrozenContactMode) -> Self {
        Self { mode }
    }

    pub fn mode(self) -> FrozenContactMode {
        self.mode
    }

    pub fn channel_probability(&self) -> Result<ExactRatio> {
        ExactRatio::new(BigUint::one(), BigUint::from(FROZEN_SLOT_COUNT))
    }

    pub fn outcome(&self, instance: FrozenChannelInstance) -> Result<FrozenChannelOutcome> {
        validate_slot(instance.slot)?;
        let successor = match instance.slot {
            FrozenAffordanceSlot::Wait => instance.state,
            FrozenAffordanceSlot::Attempt { from, to }
                if self.edge_is_active(from, to)
                    && instance.state.occupied_unchecked(from)
                    && !instance.state.occupied_unchecked(to) =>
            {
                instance.state.transferred(from, to)
            }
            FrozenAffordanceSlot::Attempt { .. } => instance.state,
        };
        Ok(FrozenChannelOutcome {
            instance,
            successor,
            realized_transfer: successor != instance.state,
        })
    }

    pub fn reverse_instance(
        &self,
        instance: FrozenChannelInstance,
    ) -> Result<FrozenChannelInstance> {
        let outcome = self.outcome(instance)?;
        if !outcome.realized_transfer {
            return Ok(instance);
        }
        Ok(FrozenChannelInstance {
            state: outcome.successor,
            slot: instance.slot.reversed(),
        })
    }

    fn edge_is_active(&self, from: usize, to: usize) -> bool {
        if undirected_edge_is_internal(from, to) {
            return true;
        }
        match self.mode {
            FrozenContactMode::Isolated => false,
            FrozenContactMode::Pair(pair) => same_undirected_edge((from, to), pair.bridge()),
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct FrozenComponentKey {
    pub contacted_occupation: usize,
    pub spectator_occupation: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrozenComponentReport {
    pub key: FrozenComponentKey,
    pub observed_state_count: usize,
    pub expected_state_count: BigUint,
    pub count_matches: bool,
    pub closed: bool,
    pub irreducible: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrozenKernelChecks {
    pub mode: FrozenContactMode,
    pub state_count: usize,
    pub channel_instance_count: usize,
    pub row_regular: bool,
    pub symmetric_adjacency: bool,
    pub exact_energy_closure: bool,
    pub instance_reverse_involution: bool,
}

impl FrozenKernelChecks {
    pub fn all_passed(&self) -> bool {
        self.state_count == FROZEN_STATE_COUNT
            && self.channel_instance_count == FROZEN_STATE_COUNT * FROZEN_SLOT_COUNT
            && self.row_regular
            && self.symmetric_adjacency
            && self.exact_energy_closure
            && self.instance_reverse_involution
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FrozenCurrentDirection {
    LeftToRight,
    Zero,
    RightToLeft,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrozenCurrentReport {
    pub pair: FrozenContactPair,
    pub left_occupancy: ExactRatio,
    pub right_occupancy: ExactRatio,
    pub forward_flux: ExactRatio,
    pub reverse_flux: ExactRatio,
    pub direction: FrozenCurrentDirection,
    pub net_magnitude: ExactRatio,
    pub expected_net_magnitude: ExactRatio,
    pub exact_prediction: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrozenPairConstructibilityReport {
    pub pair: FrozenContactPair,
    pub kernel: FrozenKernelChecks,
    pub internal_channel_instances_checked: usize,
    pub internal_hazards_preserved: bool,
    pub expected_component_count: usize,
    pub components: Vec<FrozenComponentReport>,
    pub component_count_matches: bool,
    pub all_component_counts_match: bool,
    pub all_components_closed: bool,
    pub all_components_irreducible: bool,
    pub common_preparation_normalized: bool,
    pub common_product_invariant: bool,
    pub fresh_clone_current: FrozenCurrentReport,
    pub ordered_preparation_normalized: bool,
    pub ordered_current: FrozenCurrentReport,
}

impl FrozenPairConstructibilityReport {
    pub fn all_passed(&self) -> bool {
        let expected_component_count = frozen_component_count(self.pair);
        let components_match = self.expected_component_count == expected_component_count
            && self.components.len() == expected_component_count
            && self
                .components
                .iter()
                .map(|component| component.observed_state_count)
                .sum::<usize>()
                == FROZEN_STATE_COUNT
            && (0..=self.pair.active_node_count()).all(|contacted_occupation| {
                (0..=self.pair.spectator().node_count()).all(|spectator_occupation| {
                    self.components
                        .iter()
                        .filter(|component| {
                            component.key
                                == (FrozenComponentKey {
                                    contacted_occupation,
                                    spectator_occupation,
                                })
                        })
                        .count()
                        == 1
                })
            })
            && self.components.iter().all(|component| {
                let expected_state_count = binomial(
                    self.pair.active_node_count(),
                    component.key.contacted_occupation,
                ) * binomial(
                    self.pair.spectator().node_count(),
                    component.key.spectator_occupation,
                );
                component.expected_state_count == expected_state_count
                    && BigUint::from(component.observed_state_count) == expected_state_count
                    && component.count_matches
                    && component.closed
                    && component.irreducible
            });

        self.kernel.mode == FrozenContactMode::Pair(self.pair)
            && self.fresh_clone_current.pair == self.pair
            && self.ordered_current.pair == self.pair
            && self.kernel.all_passed()
            && self.internal_channel_instances_checked
                == FROZEN_STATE_COUNT * INTERNAL_EDGES.len() * 2
            && self.internal_hazards_preserved
            && self.expected_component_count == frozen_component_count(self.pair)
            && self.component_count_matches
            && self.all_component_counts_match
            && self.all_components_closed
            && self.all_components_irreducible
            && components_match
            && self.common_preparation_normalized
            && self.common_product_invariant
            && fresh_current_matches_literal(&self.fresh_clone_current, self.pair)
            && self.ordered_preparation_normalized
            && ordered_current_matches_literal(&self.ordered_current, self.pair)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrozenConstructibilityReport {
    pub node_count: usize,
    pub state_count: usize,
    pub slot_count: usize,
    pub universal_channel_probability: ExactRatio,
    pub isolated_kernel: FrozenKernelChecks,
    pub pairs: Vec<FrozenPairConstructibilityReport>,
}

impl FrozenConstructibilityReport {
    pub fn all_passed(&self) -> bool {
        self.node_count == FROZEN_NODE_COUNT
            && self.state_count == FROZEN_STATE_COUNT
            && self.slot_count == FROZEN_SLOT_COUNT
            && ratio_matches(&self.universal_channel_probability, 1, 23)
            && self.isolated_kernel.mode == FrozenContactMode::Isolated
            && self.isolated_kernel.all_passed()
            && self.pairs.len() == FrozenContactPair::ALL.len()
            && FrozenContactPair::ALL.iter().all(|pair| {
                self.pairs
                    .iter()
                    .filter(|report| report.pair == *pair)
                    .count()
                    == 1
            })
            && self
                .pairs
                .iter()
                .all(FrozenPairConstructibilityReport::all_passed)
    }
}

pub fn frozen_constructibility_report() -> Result<FrozenConstructibilityReport> {
    let isolated = FrozenFixedAffordanceKernel::new(FrozenContactMode::Isolated);
    let isolated_kernel = verify_kernel(isolated)?;
    let common_preparation = FrozenProductPreparation::common_one_third()?;
    let ordered_preparation = FrozenProductPreparation::ordered()?;
    let common_preparation_normalized = common_preparation.is_normalized();
    let ordered_preparation_normalized = ordered_preparation.is_normalized();

    let pairs = FrozenContactPair::ALL
        .into_iter()
        .map(|pair| {
            verify_pair(
                pair,
                isolated,
                &common_preparation,
                common_preparation_normalized,
                &ordered_preparation,
                ordered_preparation_normalized,
            )
        })
        .collect::<Result<Vec<_>>>()?;

    Ok(FrozenConstructibilityReport {
        node_count: FROZEN_NODE_COUNT,
        state_count: FROZEN_STATE_COUNT,
        slot_count: FROZEN_SLOT_COUNT,
        universal_channel_probability: isolated.channel_probability()?,
        isolated_kernel,
        pairs,
    })
}

fn verify_pair(
    pair: FrozenContactPair,
    isolated: FrozenFixedAffordanceKernel,
    common_preparation: &FrozenProductPreparation,
    common_preparation_normalized: bool,
    ordered_preparation: &FrozenProductPreparation,
    ordered_preparation_normalized: bool,
) -> Result<FrozenPairConstructibilityReport> {
    let kernel = FrozenFixedAffordanceKernel::new(FrozenContactMode::Pair(pair));
    let kernel_checks = verify_kernel(kernel)?;
    let (internal_channel_instances_checked, internal_hazards_preserved) =
        verify_internal_no_quench(isolated, kernel)?;
    let components = verify_components(pair, kernel)?;
    let expected_component_count = frozen_component_count(pair);
    let component_count_matches = components.len() == expected_component_count;
    let all_component_counts_match = components.iter().all(|report| report.count_matches);
    let all_components_closed = components.iter().all(|report| report.closed);
    let all_components_irreducible = components.iter().all(|report| report.irreducible);
    let common_product_invariant = verify_product_invariance(kernel, common_preparation)?;
    let fresh_clone_current = current_report(pair, kernel, common_preparation)?;
    let ordered_current = current_report(pair, kernel, ordered_preparation)?;

    Ok(FrozenPairConstructibilityReport {
        pair,
        kernel: kernel_checks,
        internal_channel_instances_checked,
        internal_hazards_preserved,
        expected_component_count,
        components,
        component_count_matches,
        all_component_counts_match,
        all_components_closed,
        all_components_irreducible,
        common_preparation_normalized,
        common_product_invariant,
        fresh_clone_current,
        ordered_preparation_normalized,
        ordered_current,
    })
}

fn verify_kernel(kernel: FrozenFixedAffordanceKernel) -> Result<FrozenKernelChecks> {
    let mut rows = Vec::with_capacity(FROZEN_STATE_COUNT);
    let mut exact_energy_closure = true;
    let mut instance_reverse_involution = true;

    for state_index in 0..FROZEN_STATE_COUNT {
        let state = FrozenBinaryState::from_index(state_index)?;
        let mut row = BTreeMap::<usize, usize>::new();
        for slot in FROZEN_AFFORDANCE_SLOTS {
            let instance = FrozenChannelInstance { state, slot };
            let outcome = kernel.outcome(instance)?;
            *row.entry(outcome.successor.index()).or_default() += 1;
            exact_energy_closure &=
                state.total_occupation() == outcome.successor.total_occupation();

            let reverse = kernel.reverse_instance(instance)?;
            let reverse_outcome = kernel.outcome(reverse)?;
            let reverse_reverse = kernel.reverse_instance(reverse)?;
            instance_reverse_involution &= reverse_outcome.successor == state
                && reverse_reverse == instance
                && (!outcome.realized_transfer || reverse_outcome.realized_transfer);
        }
        rows.push(row);
    }

    let row_regular = rows
        .iter()
        .all(|row| row.values().copied().sum::<usize>() == FROZEN_SLOT_COUNT);
    let symmetric_adjacency = rows.iter().enumerate().all(|(source, row)| {
        row.iter().all(|(&target, &multiplicity)| {
            rows[target].get(&source).copied().unwrap_or_default() == multiplicity
        })
    });

    Ok(FrozenKernelChecks {
        mode: kernel.mode(),
        state_count: rows.len(),
        channel_instance_count: rows.len() * FROZEN_SLOT_COUNT,
        row_regular,
        symmetric_adjacency,
        exact_energy_closure,
        instance_reverse_involution,
    })
}

fn verify_internal_no_quench(
    isolated: FrozenFixedAffordanceKernel,
    contacted: FrozenFixedAffordanceKernel,
) -> Result<(usize, bool)> {
    let mut checked = 0;
    let mut preserved = true;
    let isolated_probability = isolated.channel_probability()?;
    let contacted_probability = contacted.channel_probability()?;

    for state_index in 0..FROZEN_STATE_COUNT {
        let state = FrozenBinaryState::from_index(state_index)?;
        for slot in FROZEN_AFFORDANCE_SLOTS
            .into_iter()
            .filter(|slot| slot.is_internal())
        {
            checked += 1;
            let instance = FrozenChannelInstance { state, slot };
            preserved &= isolated.outcome(instance)? == contacted.outcome(instance)?
                && isolated.reverse_instance(instance)? == contacted.reverse_instance(instance)?
                && isolated_probability == contacted_probability;
        }
    }
    Ok((checked, preserved))
}

fn verify_components(
    pair: FrozenContactPair,
    kernel: FrozenFixedAffordanceKernel,
) -> Result<Vec<FrozenComponentReport>> {
    let mut members = BTreeMap::<FrozenComponentKey, Vec<usize>>::new();
    for state_index in 0..FROZEN_STATE_COUNT {
        let state = FrozenBinaryState::from_index(state_index)?;
        let key = FrozenComponentKey {
            contacted_occupation: state.body_occupation(pair.left())
                + state.body_occupation(pair.right()),
            spectator_occupation: state.body_occupation(pair.spectator()),
        };
        members.entry(key).or_default().push(state_index);
    }

    members
        .into_iter()
        .map(|(key, states)| {
            let expected_state_count = binomial(pair.active_node_count(), key.contacted_occupation)
                * binomial(pair.spectator().node_count(), key.spectator_occupation);
            let count_matches = expected_state_count == BigUint::from(states.len());
            let (closed, irreducible) = component_closure_and_irreducibility(kernel, &states)?;
            Ok(FrozenComponentReport {
                key,
                observed_state_count: states.len(),
                expected_state_count,
                count_matches,
                closed,
                irreducible,
            })
        })
        .collect()
}

fn component_closure_and_irreducibility(
    kernel: FrozenFixedAffordanceKernel,
    members: &[usize],
) -> Result<(bool, bool)> {
    let Some(&start) = members.first() else {
        return Ok((false, false));
    };
    let mut in_component = vec![false; FROZEN_STATE_COUNT];
    for &state in members {
        in_component[state] = true;
    }

    let mut closed = true;
    for &state_index in members {
        let state = FrozenBinaryState::from_index(state_index)?;
        for slot in FROZEN_AFFORDANCE_SLOTS {
            let successor = kernel
                .outcome(FrozenChannelInstance { state, slot })?
                .successor
                .index();
            closed &= in_component[successor];
        }
    }

    let mut visited = vec![false; FROZEN_STATE_COUNT];
    let mut queue = VecDeque::from([start]);
    visited[start] = true;
    while let Some(state_index) = queue.pop_front() {
        let state = FrozenBinaryState::from_index(state_index)?;
        for slot in FROZEN_AFFORDANCE_SLOTS {
            let outcome = kernel.outcome(FrozenChannelInstance { state, slot })?;
            let successor = outcome.successor.index();
            if in_component[successor] && !visited[successor] {
                visited[successor] = true;
                queue.push_back(successor);
            }
        }
    }
    Ok((closed, members.iter().all(|&state| visited[state])))
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct FrozenProductPreparation {
    occupancy: BTreeMap<FrozenBody, ExactRatio>,
    denominator: BigUint,
    weights: Vec<BigUint>,
}

impl FrozenProductPreparation {
    fn common_one_third() -> Result<Self> {
        Self::new([
            (FrozenBody::T2, ratio(1, 3)?),
            (FrozenBody::T3, ratio(1, 3)?),
            (FrozenBody::T4, ratio(1, 3)?),
        ])
    }

    fn ordered() -> Result<Self> {
        Self::new([
            (FrozenBody::T2, ratio(1, 2)?),
            (FrozenBody::T3, ratio(1, 3)?),
            (FrozenBody::T4, ratio(1, 5)?),
        ])
    }

    fn new(occupancy: [(FrozenBody, ExactRatio); 3]) -> Result<Self> {
        let occupancy = BTreeMap::from(occupancy);
        if occupancy.len() != FrozenBody::ALL.len() {
            return Err(AnalysisError::new(
                "fixed-affordance preparation does not name every body",
            ));
        }

        let denominator = FrozenBody::ALL
            .iter()
            .fold(BigUint::one(), |product, body| {
                let probability = &occupancy[body];
                product * probability.denominator().pow(body.node_count() as u32)
            });
        let weights = (0..FROZEN_STATE_COUNT)
            .map(|state_index| {
                let state = FrozenBinaryState::from_index(state_index)?;
                let weight = FrozenBody::ALL
                    .iter()
                    .fold(BigUint::one(), |product, body| {
                        let probability = &occupancy[body];
                        body.nodes().iter().fold(product, |body_product, &node| {
                            let factor = if state.occupied_unchecked(node) {
                                probability.numerator().clone()
                            } else {
                                probability.denominator() - probability.numerator()
                            };
                            body_product * factor
                        })
                    });
                Ok(weight)
            })
            .collect::<Result<Vec<_>>>()?;

        Ok(Self {
            occupancy,
            denominator,
            weights,
        })
    }

    fn is_normalized(&self) -> bool {
        self.weights
            .iter()
            .fold(BigUint::zero(), |sum, weight| sum + weight)
            == self.denominator
    }

    fn occupancy(&self, body: FrozenBody) -> &ExactRatio {
        &self.occupancy[&body]
    }
}

fn verify_product_invariance(
    kernel: FrozenFixedAffordanceKernel,
    preparation: &FrozenProductPreparation,
) -> Result<bool> {
    let mut incoming = vec![BigUint::zero(); FROZEN_STATE_COUNT];
    for state_index in 0..FROZEN_STATE_COUNT {
        let state = FrozenBinaryState::from_index(state_index)?;
        for slot in FROZEN_AFFORDANCE_SLOTS {
            let successor = kernel
                .outcome(FrozenChannelInstance { state, slot })?
                .successor
                .index();
            incoming[successor] += &preparation.weights[state_index];
        }
    }
    Ok(incoming
        .iter()
        .zip(&preparation.weights)
        .all(|(observed, expected)| observed == &(expected * BigUint::from(FROZEN_SLOT_COUNT))))
}

fn current_report(
    pair: FrozenContactPair,
    kernel: FrozenFixedAffordanceKernel,
    preparation: &FrozenProductPreparation,
) -> Result<FrozenCurrentReport> {
    let (left_port, right_port) = pair.bridge();
    let forward_slot = FrozenAffordanceSlot::Attempt {
        from: left_port,
        to: right_port,
    };
    let reverse_slot = forward_slot.reversed();
    let mut forward_weight = BigUint::zero();
    let mut reverse_weight = BigUint::zero();

    for state_index in 0..FROZEN_STATE_COUNT {
        let state = FrozenBinaryState::from_index(state_index)?;
        if kernel
            .outcome(FrozenChannelInstance {
                state,
                slot: forward_slot,
            })?
            .realized_transfer
        {
            forward_weight += &preparation.weights[state_index];
        }
        if kernel
            .outcome(FrozenChannelInstance {
                state,
                slot: reverse_slot,
            })?
            .realized_transfer
        {
            reverse_weight += &preparation.weights[state_index];
        }
    }

    let flux_denominator = &preparation.denominator * BigUint::from(FROZEN_SLOT_COUNT);
    let forward_flux = ExactRatio::new(forward_weight, flux_denominator.clone())?;
    let reverse_flux = ExactRatio::new(reverse_weight, flux_denominator)?;
    let direction = ratio_order(&forward_flux, &reverse_flux);
    let net_magnitude = ratio_absolute_difference(&forward_flux, &reverse_flux)?;
    let left_occupancy = preparation.occupancy(pair.left()).clone();
    let right_occupancy = preparation.occupancy(pair.right()).clone();
    let expected_direction = ratio_order(&left_occupancy, &right_occupancy);
    let expected_net_magnitude = ratio_absolute_difference(&left_occupancy, &right_occupancy)?
        .checked_multiply(&ratio(1, FROZEN_SLOT_COUNT)?)?;
    let expected_forward_flux = left_occupancy
        .checked_multiply(&one_minus(&right_occupancy)?)?
        .checked_multiply(&ratio(1, FROZEN_SLOT_COUNT)?)?;
    let expected_reverse_flux = right_occupancy
        .checked_multiply(&one_minus(&left_occupancy)?)?
        .checked_multiply(&ratio(1, FROZEN_SLOT_COUNT)?)?;

    Ok(FrozenCurrentReport {
        pair,
        left_occupancy,
        right_occupancy,
        forward_flux: forward_flux.clone(),
        reverse_flux: reverse_flux.clone(),
        direction,
        net_magnitude: net_magnitude.clone(),
        expected_net_magnitude: expected_net_magnitude.clone(),
        exact_prediction: direction == expected_direction
            && forward_flux == expected_forward_flux
            && reverse_flux == expected_reverse_flux
            && net_magnitude == expected_net_magnitude,
    })
}

fn frozen_component_count(pair: FrozenContactPair) -> usize {
    (pair.active_node_count() + 1) * (pair.spectator().node_count() + 1)
}

fn fresh_current_matches_literal(current: &FrozenCurrentReport, pair: FrozenContactPair) -> bool {
    current.pair == pair
        && ratio_matches(&current.left_occupancy, 1, 3)
        && ratio_matches(&current.right_occupancy, 1, 3)
        && ratio_matches(&current.forward_flux, 2, 207)
        && ratio_matches(&current.reverse_flux, 2, 207)
        && current.direction == FrozenCurrentDirection::Zero
        && ratio_matches(&current.net_magnitude, 0, 1)
        && ratio_matches(&current.expected_net_magnitude, 0, 1)
        && current.exact_prediction
}

fn ordered_current_matches_literal(current: &FrozenCurrentReport, pair: FrozenContactPair) -> bool {
    let (left_numerator, left_denominator, right_numerator, right_denominator) = match pair {
        FrozenContactPair::T2T3 => (1, 2, 1, 3),
        FrozenContactPair::T3T4 => (1, 3, 1, 5),
        FrozenContactPair::T2T4 => (1, 2, 1, 5),
    };
    let (
        forward_numerator,
        forward_denominator,
        reverse_numerator,
        reverse_denominator,
        net_numerator,
        net_denominator,
    ) = match pair {
        FrozenContactPair::T2T3 => (1, 69, 1, 138, 1, 138),
        FrozenContactPair::T3T4 => (4, 345, 2, 345, 2, 345),
        FrozenContactPair::T2T4 => (2, 115, 1, 230, 3, 230),
    };

    current.pair == pair
        && ratio_matches(&current.left_occupancy, left_numerator, left_denominator)
        && ratio_matches(&current.right_occupancy, right_numerator, right_denominator)
        && ratio_matches(
            &current.forward_flux,
            forward_numerator,
            forward_denominator,
        )
        && ratio_matches(
            &current.reverse_flux,
            reverse_numerator,
            reverse_denominator,
        )
        && current.direction == FrozenCurrentDirection::LeftToRight
        && ratio_matches(&current.net_magnitude, net_numerator, net_denominator)
        && ratio_matches(
            &current.expected_net_magnitude,
            net_numerator,
            net_denominator,
        )
        && current.exact_prediction
}

fn ratio_matches(value: &ExactRatio, numerator: usize, denominator: usize) -> bool {
    value.numerator() == &BigUint::from(numerator)
        && value.denominator() == &BigUint::from(denominator)
}

fn validate_slot(slot: FrozenAffordanceSlot) -> Result<()> {
    if FROZEN_AFFORDANCE_SLOTS.contains(&slot) {
        Ok(())
    } else {
        Err(AnalysisError::new(
            "channel is outside the frozen fixed-affordance alphabet",
        ))
    }
}

fn same_undirected_edge(left: (usize, usize), right: (usize, usize)) -> bool {
    left == right || left == (right.1, right.0)
}

fn undirected_edge_is_internal(from: usize, to: usize) -> bool {
    INTERNAL_EDGES
        .iter()
        .copied()
        .any(|edge| same_undirected_edge((from, to), edge))
}

fn binomial(n: usize, k: usize) -> BigUint {
    if k > n {
        return BigUint::zero();
    }
    let k = k.min(n - k);
    (0..k).fold(BigUint::one(), |value, index| {
        value * BigUint::from(n - index) / BigUint::from(index + 1)
    })
}

fn ratio(numerator: usize, denominator: usize) -> Result<ExactRatio> {
    ExactRatio::new(BigUint::from(numerator), BigUint::from(denominator))
}

fn one_minus(value: &ExactRatio) -> Result<ExactRatio> {
    if value.numerator() > value.denominator() {
        return Err(AnalysisError::new("occupancy probability exceeds one"));
    }
    ExactRatio::new(
        value.denominator() - value.numerator(),
        value.denominator().clone(),
    )
}

fn ratio_order(left: &ExactRatio, right: &ExactRatio) -> FrozenCurrentDirection {
    match (left.numerator() * right.denominator()).cmp(&(right.numerator() * left.denominator())) {
        Ordering::Greater => FrozenCurrentDirection::LeftToRight,
        Ordering::Equal => FrozenCurrentDirection::Zero,
        Ordering::Less => FrozenCurrentDirection::RightToLeft,
    }
}

fn ratio_absolute_difference(left: &ExactRatio, right: &ExactRatio) -> Result<ExactRatio> {
    let left_scaled = left.numerator() * right.denominator();
    let right_scaled = right.numerator() * left.denominator();
    let numerator = match left_scaled.cmp(&right_scaled) {
        Ordering::Greater | Ordering::Equal => left_scaled - right_scaled,
        Ordering::Less => right_scaled - left_scaled,
    };
    ExactRatio::new(numerator, left.denominator() * right.denominator())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn frozen_constructibility_report_passes_every_exact_gate() {
        let report = frozen_constructibility_report().expect("constructibility report");
        assert!(report.all_passed());
        assert_eq!(report.node_count, 9);
        assert_eq!(report.state_count, 512);
        assert_eq!(report.slot_count, 23);
        assert_eq!(report.universal_channel_probability, ratio(1, 23).unwrap());
    }

    #[test]
    fn component_counts_match_the_frozen_pair_partitions() {
        let report = frozen_constructibility_report().expect("constructibility report");
        let expected = [
            (FrozenContactPair::T2T3, 30, 60),
            (FrozenContactPair::T3T4, 24, 70),
            (FrozenContactPair::T2T4, 28, 60),
        ];
        for (pair, component_count, largest_component) in expected {
            let pair_report = report
                .pairs
                .iter()
                .find(|candidate| candidate.pair == pair)
                .expect("pair report");
            assert_eq!(pair_report.components.len(), component_count);
            assert_eq!(
                pair_report
                    .components
                    .iter()
                    .map(|component| component.observed_state_count)
                    .max(),
                Some(largest_component)
            );
            assert_eq!(
                pair_report
                    .components
                    .iter()
                    .map(|component| component.observed_state_count)
                    .sum::<usize>(),
                FROZEN_STATE_COUNT
            );
        }
    }

    #[test]
    fn ordered_currents_equal_the_frozen_rational_predictions() {
        let report = frozen_constructibility_report().expect("constructibility report");
        let expected = [
            (FrozenContactPair::T2T3, ratio(1, 138).unwrap()),
            (FrozenContactPair::T3T4, ratio(2, 345).unwrap()),
            (FrozenContactPair::T2T4, ratio(3, 230).unwrap()),
        ];
        for (pair, current) in expected {
            let pair_report = report
                .pairs
                .iter()
                .find(|candidate| candidate.pair == pair)
                .expect("pair report");
            assert_eq!(pair_report.ordered_current.net_magnitude, current);
            assert_eq!(
                pair_report.ordered_current.direction,
                FrozenCurrentDirection::LeftToRight
            );
            assert_eq!(
                pair_report.fresh_clone_current.net_magnitude,
                ExactRatio::zero()
            );
            assert_eq!(
                pair_report.fresh_clone_current.direction,
                FrozenCurrentDirection::Zero
            );
        }
    }

    #[test]
    fn reverse_identity_is_resolved_per_state_channel_instance() {
        let kernel =
            FrozenFixedAffordanceKernel::new(FrozenContactMode::Pair(FrozenContactPair::T2T3));
        let original = FrozenBinaryState::from_index(1 << 2).unwrap();
        let unavailable = FrozenChannelInstance {
            state: original,
            slot: FrozenAffordanceSlot::Attempt { from: 1, to: 2 },
        };
        assert_eq!(kernel.reverse_instance(unavailable).unwrap(), unavailable);

        let successful = FrozenChannelInstance {
            state: original,
            slot: FrozenAffordanceSlot::Attempt { from: 2, to: 1 },
        };
        let reverse = kernel.reverse_instance(successful).unwrap();
        assert_eq!(reverse.state.index(), 1 << 1);
        assert_eq!(
            reverse.slot,
            FrozenAffordanceSlot::Attempt { from: 1, to: 2 }
        );
        assert_eq!(kernel.reverse_instance(reverse).unwrap(), successful);
    }

    #[test]
    fn rejects_states_and_channels_outside_the_frozen_universe() {
        assert!(FrozenBinaryState::from_index(FROZEN_STATE_COUNT).is_err());
        let kernel = FrozenFixedAffordanceKernel::new(FrozenContactMode::Isolated);
        let state = FrozenBinaryState::from_index(0).unwrap();
        assert!(kernel
            .outcome(FrozenChannelInstance {
                state,
                slot: FrozenAffordanceSlot::Attempt { from: 0, to: 2 },
            })
            .is_err());
    }

    #[test]
    fn top_level_admission_rejects_literal_mode_and_coverage_forgeries() {
        let baseline = frozen_constructibility_report().expect("constructibility report");

        let mut wrong_probability = baseline.clone();
        wrong_probability.universal_channel_probability = ratio(2, 23).unwrap();
        assert!(!wrong_probability.all_passed());

        let mut wrong_isolated_mode = baseline.clone();
        wrong_isolated_mode.isolated_kernel.mode = FrozenContactMode::Pair(FrozenContactPair::T2T3);
        assert!(!wrong_isolated_mode.all_passed());

        let mut duplicate_pair = baseline;
        duplicate_pair.pairs[2] = duplicate_pair.pairs[0].clone();
        assert!(!duplicate_pair.all_passed());
    }

    #[test]
    fn pair_admission_rejects_kernel_and_current_identity_forgeries() {
        let baseline = frozen_constructibility_report().expect("constructibility report");
        let pair = baseline.pairs[0].clone();

        let mut wrong_kernel = pair.clone();
        wrong_kernel.kernel.mode = FrozenContactMode::Pair(FrozenContactPair::T3T4);
        assert!(!wrong_kernel.all_passed());

        let mut wrong_fresh_identity = pair.clone();
        wrong_fresh_identity.fresh_clone_current.pair = FrozenContactPair::T3T4;
        assert!(!wrong_fresh_identity.all_passed());

        let mut wrong_ordered_identity = pair;
        wrong_ordered_identity.ordered_current.pair = FrozenContactPair::T2T4;
        assert!(!wrong_ordered_identity.all_passed());
    }

    #[test]
    fn pair_admission_rejects_forged_current_literals_and_component_summaries() {
        let baseline = frozen_constructibility_report().expect("constructibility report");
        let pair = baseline.pairs[0].clone();

        let mut forged_fresh_flux = pair.clone();
        forged_fresh_flux.fresh_clone_current.forward_flux = ratio(3, 207).unwrap();
        forged_fresh_flux.fresh_clone_current.exact_prediction = true;
        assert!(!forged_fresh_flux.all_passed());

        let mut forged_ordered_net = pair.clone();
        forged_ordered_net.ordered_current.net_magnitude = ratio(2, 138).unwrap();
        forged_ordered_net.ordered_current.expected_net_magnitude = ratio(2, 138).unwrap();
        forged_ordered_net.ordered_current.exact_prediction = true;
        assert!(!forged_ordered_net.all_passed());

        let mut forged_component = pair;
        forged_component.components[0].observed_state_count += 1;
        forged_component.components[0].count_matches = true;
        forged_component.component_count_matches = true;
        forged_component.all_component_counts_match = true;
        assert!(!forged_component.all_passed());
    }
}
