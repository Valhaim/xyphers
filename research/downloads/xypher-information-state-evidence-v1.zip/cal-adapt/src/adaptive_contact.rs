use crate::{AnalysisError, ExactRatio, Result};
use num_bigint::{BigInt, BigUint};
use num_traits::{One, Zero};
use std::collections::{BTreeMap, BTreeSet, VecDeque};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum GateVerdict {
    Passed,
    Failed,
    NotApplicable,
}

impl GateVerdict {
    fn from_bool(value: bool) -> Self {
        if value {
            Self::Passed
        } else {
            Self::Failed
        }
    }

    pub fn passed(self) -> bool {
        self == Self::Passed
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum BalanceFiber {
    A,
    B,
}

impl BalanceFiber {
    const ALL: [Self; 2] = [Self::A, Self::B];

    fn index(self) -> usize {
        match self {
            Self::A => 0,
            Self::B => 1,
        }
    }

    fn opposite(self) -> Self {
        match self {
            Self::A => Self::B,
            Self::B => Self::A,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdaptiveState {
    pub id: String,
    pub balance: BalanceFiber,
    pub memory: u32,
    pub monotone_coordinate: u64,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DiscreteChannelClass {
    Wait,
    Transfer,
    Memory,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DiscreteChannel {
    pub id: String,
    pub reverse_id: String,
    pub source: usize,
    pub target: usize,
    pub probability: ExactRatio,
    pub multiplicity: u32,
    pub class: DiscreteChannelClass,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DiscreteKernel {
    states: Vec<AdaptiveState>,
    channels: Vec<DiscreteChannel>,
    reference: Vec<ExactRatio>,
}

impl DiscreteKernel {
    pub fn states(&self) -> &[AdaptiveState] {
        &self.states
    }

    pub fn channels(&self) -> &[DiscreteChannel] {
        &self.channels
    }

    pub fn reference(&self) -> &[ExactRatio] {
        &self.reference
    }

    pub fn verify(&self) -> Result<DiscreteContactReport> {
        verify_discrete(self)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LumpabilityWitness {
    pub left_state: String,
    pub right_state: String,
    pub destination: BalanceFiber,
    pub left_probability: ExactRatio,
    pub right_probability: ExactRatio,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProjectedKernel {
    pub rows: Vec<Vec<ExactRatio>>,
}

impl ProjectedKernel {
    pub fn probability(&self, source: BalanceFiber, target: BalanceFiber) -> &ExactRatio {
        &self.rows[source.index()][target.index()]
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CommunicatingClassReport {
    pub states: Vec<String>,
    pub closed: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DiscreteContactReport {
    pub state_count: usize,
    pub channel_count: usize,
    pub row_normalization: GateVerdict,
    pub channel_metadata_complete: GateVerdict,
    pub full_reverse_support: GateVerdict,
    pub missing_reverse_ids: Vec<String>,
    pub monotone_non_decreasing: bool,
    pub strict_monotone_channel_count: usize,
    pub monotone_reverse_obstruction: bool,
    pub strong_lumpability: GateVerdict,
    pub lumpability_witness: Option<LumpabilityWitness>,
    pub existential_fiber_support_reciprocal: bool,
    pub projected_kernel: Option<ProjectedKernel>,
    pub projected_reverse_support: GateVerdict,
    pub reference_positive: GateVerdict,
    pub reference_normalized: GateVerdict,
    pub reference_stationary: GateVerdict,
    pub reference_detailed_balance: GateVerdict,
    pub projected_reference_stationary: GateVerdict,
    pub projected_reference_detailed_balance: GateVerdict,
    pub communicating_classes: Vec<CommunicatingClassReport>,
    pub transient_states: Vec<String>,
    pub full_support_stationary_exists: bool,
    pub stationary_law_unique: bool,
    pub continuous_generator_conservation: GateVerdict,
    pub continuous_generator_lumpability: GateVerdict,
    pub internal_rate_no_quench: GateVerdict,
    pub causal_stack_identities: GateVerdict,
}

impl DiscreteContactReport {
    pub fn all_applicable_positive_gates_passed(&self) -> bool {
        [
            self.row_normalization,
            self.channel_metadata_complete,
            self.full_reverse_support,
            self.strong_lumpability,
            self.projected_reverse_support,
            self.reference_positive,
            self.reference_normalized,
            self.reference_stationary,
            self.reference_detailed_balance,
            self.projected_reference_stationary,
            self.projected_reference_detailed_balance,
        ]
        .into_iter()
        .all(GateVerdict::passed)
            && self.continuous_generator_conservation == GateVerdict::NotApplicable
            && self.continuous_generator_lumpability == GateVerdict::NotApplicable
            && self.internal_rate_no_quench == GateVerdict::NotApplicable
            && self.causal_stack_identities == GateVerdict::NotApplicable
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SquareAblation {
    None,
    RemoveMaReverse,
    RemoveMbReverse,
}

pub fn monotone_full_state_fixture() -> Result<DiscreteKernel> {
    discrete_fixture(
        vec![
            state("z0", BalanceFiber::A, 0),
            state("z1", BalanceFiber::B, 1),
        ],
        vec![
            discrete_channel(
                "advance",
                "rewind",
                0,
                1,
                1,
                1,
                DiscreteChannelClass::Transfer,
            )?,
            discrete_channel("wait-z1", "wait-z1", 1, 1, 1, 1, DiscreteChannelClass::Wait)?,
        ],
    )
}

pub fn apparent_reciprocity_fixture() -> Result<DiscreteKernel> {
    discrete_fixture(
        four_states(),
        vec![
            discrete_channel(
                "advance-a",
                "rewind-a",
                0,
                3,
                1,
                1,
                DiscreteChannelClass::Transfer,
            )?,
            discrete_channel(
                "advance-b",
                "rewind-b",
                1,
                2,
                1,
                1,
                DiscreteChannelClass::Transfer,
            )?,
            discrete_channel("wait-a1", "wait-a1", 2, 2, 1, 1, DiscreteChannelClass::Wait)?,
            discrete_channel("wait-b1", "wait-b1", 3, 3, 1, 1, DiscreteChannelClass::Wait)?,
        ],
    )
}

pub fn lumpable_hidden_state_fixture() -> Result<DiscreteKernel> {
    discrete_fixture(
        four_states(),
        vec![
            discrete_channel("t0+", "t0-", 0, 1, 1, 1, DiscreteChannelClass::Transfer)?,
            discrete_channel("t0-", "t0+", 1, 0, 1, 1, DiscreteChannelClass::Transfer)?,
            discrete_channel("t1+", "t1-", 2, 3, 1, 1, DiscreteChannelClass::Transfer)?,
            discrete_channel("t1-", "t1+", 3, 2, 1, 1, DiscreteChannelClass::Transfer)?,
        ],
    )
}

pub fn reversible_memory_square_fixture(ablation: SquareAblation) -> Result<DiscreteKernel> {
    let mut channels = vec![
        discrete_channel("T0+", "T0-", 0, 1, 1, 3, DiscreteChannelClass::Transfer)?,
        discrete_channel("T0-", "T0+", 1, 0, 1, 3, DiscreteChannelClass::Transfer)?,
        discrete_channel("T1+", "T1-", 2, 3, 1, 3, DiscreteChannelClass::Transfer)?,
        discrete_channel("T1-", "T1+", 3, 2, 1, 3, DiscreteChannelClass::Transfer)?,
        discrete_channel("MA+", "MA-", 0, 2, 1, 3, DiscreteChannelClass::Memory)?,
        discrete_channel("MA-", "MA+", 2, 0, 1, 3, DiscreteChannelClass::Memory)?,
        discrete_channel("MB+", "MB-", 1, 3, 1, 3, DiscreteChannelClass::Memory)?,
        discrete_channel("MB-", "MB+", 3, 1, 1, 3, DiscreteChannelClass::Memory)?,
        discrete_channel("WAIT-A0", "WAIT-A0", 0, 0, 1, 3, DiscreteChannelClass::Wait)?,
        discrete_channel("WAIT-B0", "WAIT-B0", 1, 1, 1, 3, DiscreteChannelClass::Wait)?,
        discrete_channel("WAIT-A1", "WAIT-A1", 2, 2, 1, 3, DiscreteChannelClass::Wait)?,
        discrete_channel("WAIT-B1", "WAIT-B1", 3, 3, 1, 3, DiscreteChannelClass::Wait)?,
    ];

    match ablation {
        SquareAblation::None => {}
        SquareAblation::RemoveMaReverse => {
            channels.retain(|channel| channel.id != "MA-");
            channels.push(discrete_channel(
                "WAIT-A1-extra",
                "WAIT-A1-extra",
                2,
                2,
                1,
                3,
                DiscreteChannelClass::Wait,
            )?);
        }
        SquareAblation::RemoveMbReverse => {
            channels.retain(|channel| channel.id != "MB-");
            channels.push(discrete_channel(
                "WAIT-B1-extra",
                "WAIT-B1-extra",
                3,
                3,
                1,
                3,
                DiscreteChannelClass::Wait,
            )?);
        }
    }

    discrete_fixture(four_states(), channels)
}

fn state(id: &str, balance: BalanceFiber, memory: u32) -> AdaptiveState {
    AdaptiveState {
        id: id.to_owned(),
        balance,
        memory,
        monotone_coordinate: u64::from(memory),
    }
}

fn four_states() -> Vec<AdaptiveState> {
    vec![
        state("A0", BalanceFiber::A, 0),
        state("B0", BalanceFiber::B, 0),
        state("A1", BalanceFiber::A, 1),
        state("B1", BalanceFiber::B, 1),
    ]
}

fn discrete_fixture(
    states: Vec<AdaptiveState>,
    channels: Vec<DiscreteChannel>,
) -> Result<DiscreteKernel> {
    let reference = uniform_reference(states.len())?;
    Ok(DiscreteKernel {
        states,
        channels,
        reference,
    })
}

fn discrete_channel(
    id: &str,
    reverse_id: &str,
    source: usize,
    target: usize,
    numerator: u64,
    denominator: u64,
    class: DiscreteChannelClass,
) -> Result<DiscreteChannel> {
    Ok(DiscreteChannel {
        id: id.to_owned(),
        reverse_id: reverse_id.to_owned(),
        source,
        target,
        probability: ratio(numerator, denominator)?,
        multiplicity: 1,
        class,
    })
}

fn verify_discrete(kernel: &DiscreteKernel) -> Result<DiscreteContactReport> {
    let state_count = kernel.states.len();
    if state_count == 0 {
        return Err(AnalysisError::new("adaptive kernel has no states"));
    }
    if kernel.reference.len() != state_count {
        return Err(AnalysisError::new(
            "adaptive reference length differs from the state count",
        ));
    }

    let state_ids = kernel
        .states
        .iter()
        .map(|state| state.id.as_str())
        .collect::<BTreeSet<_>>();
    let mut channel_by_id = BTreeMap::new();
    let mut metadata_complete =
        state_ids.len() == state_count && kernel.states.iter().all(|state| !state.id.is_empty());
    for (index, channel) in kernel.channels.iter().enumerate() {
        metadata_complete &= !channel.id.is_empty()
            && !channel.reverse_id.is_empty()
            && channel.source < state_count
            && channel.target < state_count
            && channel.multiplicity > 0
            && !channel.probability.numerator().is_zero()
            && discrete_channel_class_is_typed(kernel, channel);
        if channel_by_id.insert(channel.id.clone(), index).is_some() {
            metadata_complete = false;
        }
    }

    let matrix = discrete_matrix(kernel)?;
    let row_normalized = matrix
        .iter()
        .all(|row| sum_ratios(row).is_ok_and(|sum| sum == ExactRatio::one()));

    let mut missing_reverse_ids = Vec::new();
    for channel in &kernel.channels {
        let reverse_valid = channel_by_id
            .get(&channel.reverse_id)
            .and_then(|&index| kernel.channels.get(index))
            .is_some_and(|reverse| {
                reverse.reverse_id == channel.id
                    && reverse.source == channel.target
                    && reverse.target == channel.source
                    && reverse.multiplicity == channel.multiplicity
                    && reverse.class == channel.class
                    && !reverse.probability.numerator().is_zero()
            });
        if !reverse_valid {
            missing_reverse_ids.push(channel.reverse_id.clone());
        }
    }
    missing_reverse_ids.sort();
    missing_reverse_ids.dedup();

    let monotone_non_decreasing = kernel.channels.iter().all(|channel| {
        kernel.states[channel.target].monotone_coordinate
            >= kernel.states[channel.source].monotone_coordinate
    });
    let strict_monotone_channel_count = kernel
        .channels
        .iter()
        .filter(|channel| {
            kernel.states[channel.target].monotone_coordinate
                > kernel.states[channel.source].monotone_coordinate
        })
        .count();

    let (projected_kernel, lumpability_witness) = project_discrete(kernel, &matrix)?;
    let strong_lumpability = projected_kernel.is_some();
    let existential_fiber_support_reciprocal = existential_fiber_support_reciprocal(kernel);
    let projected_reverse_support = projected_kernel
        .as_ref()
        .map_or(GateVerdict::NotApplicable, |projected| {
            GateVerdict::from_bool(projected_has_reverse_support(projected))
        });

    let reference_positive = kernel
        .reference
        .iter()
        .all(|weight| !weight.numerator().is_zero());
    let reference_normalized = sum_ratios(&kernel.reference)? == ExactRatio::one();
    let reference_stationary = stationary_for_discrete(&kernel.reference, &matrix)?;
    let reference_detailed_balance =
        channel_detailed_balance_discrete(kernel, &channel_by_id, &kernel.reference)?;

    let (projected_reference_stationary, projected_reference_detailed_balance) =
        if let Some(projected) = &projected_kernel {
            let projected_reference = aggregate_reference(kernel)?;
            (
                GateVerdict::from_bool(stationary_for_discrete(
                    &projected_reference,
                    &projected.rows,
                )?),
                GateVerdict::from_bool(endpoint_detailed_balance(
                    &projected_reference,
                    &projected.rows,
                )?),
            )
        } else {
            (GateVerdict::NotApplicable, GateVerdict::NotApplicable)
        };

    let (communicating_classes, transient_states) = communicating_classes(
        &kernel
            .states
            .iter()
            .map(|state| state.id.clone())
            .collect::<Vec<_>>(),
        &matrix,
    );
    let closed_count = communicating_classes
        .iter()
        .filter(|component| component.closed)
        .count();

    Ok(DiscreteContactReport {
        state_count,
        channel_count: kernel.channels.len(),
        row_normalization: GateVerdict::from_bool(row_normalized),
        channel_metadata_complete: GateVerdict::from_bool(metadata_complete),
        full_reverse_support: GateVerdict::from_bool(missing_reverse_ids.is_empty()),
        missing_reverse_ids,
        monotone_non_decreasing,
        strict_monotone_channel_count,
        monotone_reverse_obstruction: monotone_non_decreasing && strict_monotone_channel_count > 0,
        strong_lumpability: GateVerdict::from_bool(strong_lumpability),
        lumpability_witness,
        existential_fiber_support_reciprocal,
        projected_kernel,
        projected_reverse_support,
        reference_positive: GateVerdict::from_bool(reference_positive),
        reference_normalized: GateVerdict::from_bool(reference_normalized),
        reference_stationary: GateVerdict::from_bool(reference_stationary),
        reference_detailed_balance: GateVerdict::from_bool(reference_detailed_balance),
        projected_reference_stationary,
        projected_reference_detailed_balance,
        communicating_classes,
        transient_states: transient_states.clone(),
        full_support_stationary_exists: transient_states.is_empty(),
        stationary_law_unique: closed_count == 1,
        continuous_generator_conservation: GateVerdict::NotApplicable,
        continuous_generator_lumpability: GateVerdict::NotApplicable,
        internal_rate_no_quench: GateVerdict::NotApplicable,
        causal_stack_identities: GateVerdict::NotApplicable,
    })
}

fn discrete_matrix(kernel: &DiscreteKernel) -> Result<Vec<Vec<ExactRatio>>> {
    let mut matrix = zero_ratio_matrix(kernel.states.len());
    for channel in &kernel.channels {
        if channel.source >= kernel.states.len() || channel.target >= kernel.states.len() {
            return Err(AnalysisError::new(
                "adaptive channel endpoint is out of range",
            ));
        }
        if channel.multiplicity == 0 || channel.probability.numerator().is_zero() {
            return Err(AnalysisError::new(
                "adaptive channels require positive values and multiplicities",
            ));
        }
        let contribution = scale_ratio(&channel.probability, channel.multiplicity)?;
        matrix[channel.source][channel.target] =
            matrix[channel.source][channel.target].checked_add(&contribution)?;
    }
    Ok(matrix)
}

fn discrete_channel_class_is_typed(kernel: &DiscreteKernel, channel: &DiscreteChannel) -> bool {
    if channel.source >= kernel.states.len() || channel.target >= kernel.states.len() {
        return false;
    }
    match channel.class {
        DiscreteChannelClass::Wait => {
            channel.source == channel.target && channel.id == channel.reverse_id
        }
        DiscreteChannelClass::Transfer => {
            kernel.states[channel.source].balance != kernel.states[channel.target].balance
        }
        DiscreteChannelClass::Memory => {
            kernel.states[channel.source].balance == kernel.states[channel.target].balance
                && channel.source != channel.target
        }
    }
}

fn project_discrete(
    kernel: &DiscreteKernel,
    matrix: &[Vec<ExactRatio>],
) -> Result<(Option<ProjectedKernel>, Option<LumpabilityWitness>)> {
    for source_fiber in BalanceFiber::ALL {
        let source_states = kernel
            .states
            .iter()
            .enumerate()
            .filter_map(|(index, state)| (state.balance == source_fiber).then_some(index))
            .collect::<Vec<_>>();
        for left_offset in 0..source_states.len() {
            for right_offset in (left_offset + 1)..source_states.len() {
                let left = source_states[left_offset];
                let right = source_states[right_offset];
                for destination in [source_fiber.opposite(), source_fiber] {
                    let left_probability = fiber_sum(kernel, matrix, left, destination)?;
                    let right_probability = fiber_sum(kernel, matrix, right, destination)?;
                    if left_probability != right_probability {
                        return Ok((
                            None,
                            Some(LumpabilityWitness {
                                left_state: kernel.states[left].id.clone(),
                                right_state: kernel.states[right].id.clone(),
                                destination,
                                left_probability,
                                right_probability,
                            }),
                        ));
                    }
                }
            }
        }
    }

    let mut rows = zero_ratio_matrix(BalanceFiber::ALL.len());
    for source in BalanceFiber::ALL {
        let representative = kernel
            .states
            .iter()
            .position(|state| state.balance == source)
            .ok_or_else(|| AnalysisError::new("balance projection omits a source fiber"))?;
        for target in BalanceFiber::ALL {
            rows[source.index()][target.index()] =
                fiber_sum(kernel, matrix, representative, target)?;
        }
    }
    Ok((Some(ProjectedKernel { rows }), None))
}

fn fiber_sum(
    kernel: &DiscreteKernel,
    matrix: &[Vec<ExactRatio>],
    source: usize,
    destination: BalanceFiber,
) -> Result<ExactRatio> {
    sum_ratios(
        &matrix[source]
            .iter()
            .enumerate()
            .filter_map(|(target, value)| {
                (kernel.states[target].balance == destination).then_some(value.clone())
            })
            .collect::<Vec<_>>(),
    )
}

fn existential_fiber_support_reciprocal(kernel: &DiscreteKernel) -> bool {
    let support = kernel
        .channels
        .iter()
        .filter(|channel| !channel.probability.numerator().is_zero())
        .map(|channel| {
            (
                kernel.states[channel.source].balance,
                kernel.states[channel.target].balance,
            )
        })
        .collect::<BTreeSet<_>>();
    support
        .iter()
        .all(|&(source, target)| source == target || support.contains(&(target, source)))
}

fn projected_has_reverse_support(kernel: &ProjectedKernel) -> bool {
    BalanceFiber::ALL.into_iter().all(|source| {
        BalanceFiber::ALL.into_iter().all(|target| {
            source == target
                || kernel.probability(source, target).numerator().is_zero()
                || !kernel.probability(target, source).numerator().is_zero()
        })
    })
}

fn aggregate_reference(kernel: &DiscreteKernel) -> Result<Vec<ExactRatio>> {
    let mut result = vec![ExactRatio::zero(); BalanceFiber::ALL.len()];
    for (state, weight) in kernel.states.iter().zip(&kernel.reference) {
        result[state.balance.index()] = result[state.balance.index()].checked_add(weight)?;
    }
    Ok(result)
}

fn channel_detailed_balance_discrete(
    kernel: &DiscreteKernel,
    channel_by_id: &BTreeMap<String, usize>,
    reference: &[ExactRatio],
) -> Result<bool> {
    for channel in &kernel.channels {
        let Some(reverse) = channel_by_id
            .get(&channel.reverse_id)
            .and_then(|&index| kernel.channels.get(index))
        else {
            return Ok(false);
        };
        if reverse.reverse_id != channel.id
            || reverse.source != channel.target
            || reverse.target != channel.source
            || reverse.class != channel.class
        {
            return Ok(false);
        }
        let forward = reference[channel.source]
            .checked_multiply(&scale_ratio(&channel.probability, channel.multiplicity)?)?;
        let backward = reference[channel.target]
            .checked_multiply(&scale_ratio(&reverse.probability, reverse.multiplicity)?)?;
        if forward != backward {
            return Ok(false);
        }
    }
    Ok(true)
}

fn stationary_for_discrete(reference: &[ExactRatio], matrix: &[Vec<ExactRatio>]) -> Result<bool> {
    if reference.len() != matrix.len() || matrix.iter().any(|row| row.len() != matrix.len()) {
        return Ok(false);
    }
    for target in 0..matrix.len() {
        let mut incoming = ExactRatio::zero();
        for source in 0..matrix.len() {
            incoming = incoming
                .checked_add(&reference[source].checked_multiply(&matrix[source][target])?)?;
        }
        if incoming != reference[target] {
            return Ok(false);
        }
    }
    Ok(true)
}

fn endpoint_detailed_balance(reference: &[ExactRatio], matrix: &[Vec<ExactRatio>]) -> Result<bool> {
    for source in 0..matrix.len() {
        for target in 0..matrix.len() {
            let forward = reference[source].checked_multiply(&matrix[source][target])?;
            let reverse = reference[target].checked_multiply(&matrix[target][source])?;
            if forward != reverse {
                return Ok(false);
            }
        }
    }
    Ok(true)
}

fn communicating_classes(
    state_ids: &[String],
    matrix: &[Vec<ExactRatio>],
) -> (Vec<CommunicatingClassReport>, Vec<String>) {
    let reachability = (0..matrix.len())
        .map(|source| reachable_from(source, matrix))
        .collect::<Vec<_>>();
    let mut assigned = vec![false; matrix.len()];
    let mut components = Vec::new();

    for source in 0..matrix.len() {
        if assigned[source] {
            continue;
        }
        let members = (0..matrix.len())
            .filter(|&target| reachability[source][target] && reachability[target][source])
            .collect::<Vec<_>>();
        for &member in &members {
            assigned[member] = true;
        }
        let member_set = members.iter().copied().collect::<BTreeSet<_>>();
        let closed = members.iter().all(|&member| {
            matrix[member]
                .iter()
                .enumerate()
                .all(|(target, probability)| {
                    probability.numerator().is_zero() || member_set.contains(&target)
                })
        });
        components.push(CommunicatingClassReport {
            states: members
                .iter()
                .map(|&member| state_ids[member].clone())
                .collect(),
            closed,
        });
    }

    let recurrent = components
        .iter()
        .filter(|component| component.closed)
        .flat_map(|component| component.states.iter().cloned())
        .collect::<BTreeSet<_>>();
    let transient = state_ids
        .iter()
        .filter(|state| !recurrent.contains(*state))
        .cloned()
        .collect();
    (components, transient)
}

fn reachable_from(source: usize, matrix: &[Vec<ExactRatio>]) -> Vec<bool> {
    let mut visited = vec![false; matrix.len()];
    let mut queue = VecDeque::from([source]);
    visited[source] = true;
    while let Some(state) = queue.pop_front() {
        for (target, probability) in matrix[state].iter().enumerate() {
            if !probability.numerator().is_zero() && !visited[target] {
                visited[target] = true;
                queue.push_back(target);
            }
        }
    }
    visited
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct StackState {
    pub id: String,
    pub energy_level: usize,
    pub symbols: Vec<u32>,
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum ContinuousChannelClass {
    Replace { position: usize, from: u32, to: u32 },
    Pop { symbol: u32 },
    Append { symbol: u32 },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContinuousChannel {
    pub id: String,
    pub reverse_id: String,
    pub source: usize,
    pub target: usize,
    pub rate: BigUint,
    pub multiplicity: u32,
    pub class: ContinuousChannelClass,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContinuousGenerator {
    alphabet_size: u32,
    depth: usize,
    states: Vec<StackState>,
    isolated_channels: Vec<ContinuousChannel>,
    contacted_channels: Vec<ContinuousChannel>,
}

impl ContinuousGenerator {
    pub fn alphabet_size(&self) -> u32 {
        self.alphabet_size
    }

    pub fn depth(&self) -> usize {
        self.depth
    }

    pub fn states(&self) -> &[StackState] {
        &self.states
    }

    pub fn isolated_channels(&self) -> &[ContinuousChannel] {
        &self.isolated_channels
    }

    pub fn contacted_channels(&self) -> &[ContinuousChannel] {
        &self.contacted_channels
    }

    pub fn signed_matrix(&self) -> Result<Vec<Vec<BigInt>>> {
        let rates = continuous_rate_matrix(self.states.len(), &self.contacted_channels)?;
        Ok(signed_generator_matrix(&rates))
    }

    pub fn verify(&self) -> Result<CausalStackReport> {
        verify_causal_stack(self)
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SignedValueSign {
    Negative,
    Zero,
    Positive,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SignedExactValue {
    pub sign: SignedValueSign,
    pub magnitude: ExactRatio,
}

impl SignedExactValue {
    fn zero() -> Self {
        Self {
            sign: SignedValueSign::Zero,
            magnitude: ExactRatio::zero(),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CausalStackReport {
    pub alphabet_size: u32,
    pub depth: usize,
    pub state_count: usize,
    pub isolated_replacement_count: usize,
    pub replacement_count: usize,
    pub pop_count: usize,
    pub append_count: usize,
    pub contacted_channel_count: usize,
    pub row_normalization: GateVerdict,
    pub discrete_lumpability: GateVerdict,
    pub projected_discrete_detailed_balance: GateVerdict,
    pub channel_metadata_complete: GateVerdict,
    pub generator_conservation: GateVerdict,
    pub full_reverse_support: GateVerdict,
    pub connected: GateVerdict,
    pub generator_lumpability: GateVerdict,
    pub reference_stationary: GateVerdict,
    pub reference_detailed_balance: GateVerdict,
    pub internal_rate_no_quench: GateVerdict,
    pub energy_closure: GateVerdict,
    pub formula_counts_match: GateVerdict,
    pub fixed_b_identities: GateVerdict,
    pub macro_multiplicities: Vec<BigUint>,
    pub macro_stationary: Vec<ExactRatio>,
    pub boltzmann_factor: ExactRatio,
    pub macro_up_rates: Vec<BigUint>,
    pub macro_down_rates: Vec<BigUint>,
    pub diagonal_exit_rates: Vec<BigUint>,
    pub exit_rates_by_level: Vec<BigUint>,
    pub low_energy_currents: Vec<SignedExactValue>,
    pub high_energy_currents: Vec<SignedExactValue>,
    pub equilibrium_currents: Vec<SignedExactValue>,
}

impl CausalStackReport {
    pub fn all_applicable_positive_gates_passed(&self) -> bool {
        [
            self.channel_metadata_complete,
            self.generator_conservation,
            self.full_reverse_support,
            self.connected,
            self.generator_lumpability,
            self.reference_stationary,
            self.reference_detailed_balance,
            self.internal_rate_no_quench,
            self.energy_closure,
            self.formula_counts_match,
            self.fixed_b_identities,
        ]
        .into_iter()
        .all(GateVerdict::passed)
            && self.row_normalization == GateVerdict::NotApplicable
            && self.discrete_lumpability == GateVerdict::NotApplicable
            && self.projected_discrete_detailed_balance == GateVerdict::NotApplicable
    }
}

pub fn causal_stack_generator(alphabet_size: u32, depth: usize) -> Result<ContinuousGenerator> {
    if alphabet_size < 2 {
        return Err(AnalysisError::new(
            "causal-stack alphabet must contain at least two symbols",
        ));
    }
    if depth == 0 {
        return Err(AnalysisError::new(
            "causal-stack depth must contain at least one energy gap",
        ));
    }

    let mut states = Vec::new();
    for energy_level in 0..=depth {
        let symbol_count = depth - energy_level;
        for symbols in enumerate_words(alphabet_size, symbol_count)? {
            states.push(StackState {
                id: stack_state_id(energy_level, &symbols),
                energy_level,
                symbols,
            });
        }
    }
    let state_indices = states
        .iter()
        .enumerate()
        .map(|(index, state)| ((state.energy_level, state.symbols.clone()), index))
        .collect::<BTreeMap<_, _>>();

    let mut isolated_channels = Vec::new();
    for (source, state) in states.iter().enumerate() {
        for position in 0..state.symbols.len() {
            let from = state.symbols[position];
            for to in 0..alphabet_size {
                if to == from {
                    continue;
                }
                let mut successor_symbols = state.symbols.clone();
                successor_symbols[position] = to;
                let target = state_index(&state_indices, state.energy_level, &successor_symbols)?;
                let id = replace_channel_id(&state.id, position, from, to);
                let reverse_id = replace_channel_id(&states[target].id, position, to, from);
                isolated_channels.push(ContinuousChannel {
                    id,
                    reverse_id,
                    source,
                    target,
                    rate: BigUint::one(),
                    multiplicity: 1,
                    class: ContinuousChannelClass::Replace { position, from, to },
                });
            }
        }
    }

    let mut contacted_channels = isolated_channels.clone();
    for (source, state) in states.iter().enumerate() {
        if state.energy_level < depth {
            let mut successor_symbols = state.symbols.clone();
            let symbol = successor_symbols
                .pop()
                .ok_or_else(|| AnalysisError::new("POP source has an empty stack"))?;
            let target = state_index(&state_indices, state.energy_level + 1, &successor_symbols)?;
            contacted_channels.push(ContinuousChannel {
                id: pop_channel_id(&state.id, symbol),
                reverse_id: append_channel_id(&states[target].id, symbol),
                source,
                target,
                rate: BigUint::one(),
                multiplicity: 1,
                class: ContinuousChannelClass::Pop { symbol },
            });
        }
        if state.energy_level > 0 {
            for symbol in 0..alphabet_size {
                let mut successor_symbols = state.symbols.clone();
                successor_symbols.push(symbol);
                let target =
                    state_index(&state_indices, state.energy_level - 1, &successor_symbols)?;
                contacted_channels.push(ContinuousChannel {
                    id: append_channel_id(&state.id, symbol),
                    reverse_id: pop_channel_id(&states[target].id, symbol),
                    source,
                    target,
                    rate: BigUint::one(),
                    multiplicity: 1,
                    class: ContinuousChannelClass::Append { symbol },
                });
            }
        }
    }

    Ok(ContinuousGenerator {
        alphabet_size,
        depth,
        states,
        isolated_channels,
        contacted_channels,
    })
}

fn verify_causal_stack(generator: &ContinuousGenerator) -> Result<CausalStackReport> {
    let state_count = generator.states.len();
    let state_ids = generator
        .states
        .iter()
        .map(|state| state.id.as_str())
        .collect::<BTreeSet<_>>();
    let mut channel_by_id = BTreeMap::new();
    let mut metadata_complete = state_ids.len() == state_count
        && generator.states.iter().all(|state| {
            !state.id.is_empty()
                && state.energy_level <= generator.depth
                && state.symbols.len() + state.energy_level == generator.depth
                && state
                    .symbols
                    .iter()
                    .all(|&symbol| symbol < generator.alphabet_size)
        });
    for (index, channel) in generator.contacted_channels.iter().enumerate() {
        metadata_complete &= !channel.id.is_empty()
            && !channel.reverse_id.is_empty()
            && channel.source < state_count
            && channel.target < state_count
            && channel.source != channel.target
            && channel.multiplicity == 1
            && channel.rate == BigUint::one();
        if channel_by_id.insert(channel.id.clone(), index).is_some() {
            metadata_complete = false;
        }
    }

    let mut reverse_support = true;
    for channel in &generator.contacted_channels {
        reverse_support &= channel_by_id
            .get(&channel.reverse_id)
            .and_then(|&index| generator.contacted_channels.get(index))
            .is_some_and(|reverse| {
                reverse.reverse_id == channel.id
                    && reverse.source == channel.target
                    && reverse.target == channel.source
                    && reverse.rate == channel.rate
                    && reverse.multiplicity == channel.multiplicity
                    && continuous_classes_are_reverses(&channel.class, &reverse.class)
            });
    }

    let rate_matrix = continuous_rate_matrix(state_count, &generator.contacted_channels)?;
    let exit_rates = rate_matrix
        .iter()
        .map(|row| row.iter().fold(BigUint::zero(), |sum, value| sum + value))
        .collect::<Vec<_>>();
    let signed_generator = signed_generator_matrix(&rate_matrix);
    let generator_conservation = signed_generator.iter().enumerate().all(|(source, row)| {
        row.iter().fold(BigInt::zero(), |sum, value| sum + value) == BigInt::zero()
            && row[source] == -BigInt::from(exit_rates[source].clone())
    });
    let connected = continuous_connected(&rate_matrix);

    let uniform_stationary = (0..state_count).all(|target| {
        let incoming = (0..state_count).fold(BigUint::zero(), |sum, source| {
            sum + &rate_matrix[source][target]
        });
        incoming == exit_rates[target]
    });
    let uniform_detailed_balance = generator.contacted_channels.iter().all(|channel| {
        channel_by_id
            .get(&channel.reverse_id)
            .and_then(|&index| generator.contacted_channels.get(index))
            .is_some_and(|reverse| {
                reverse.source == channel.target
                    && reverse.target == channel.source
                    && reverse.rate == channel.rate
                    && reverse.multiplicity == channel.multiplicity
                    && continuous_classes_are_reverses(&channel.class, &reverse.class)
            })
    });

    let (generator_lumpable, macro_rates) = generator_projection(generator, &rate_matrix)?;
    let internal_rate_no_quench = retained_internal_rates_unchanged(generator);
    let energy_closure = generator
        .contacted_channels
        .iter()
        .all(|channel| channel_preserves_total_energy(generator, channel));

    let replacement_count = generator
        .contacted_channels
        .iter()
        .filter(|channel| matches!(channel.class, ContinuousChannelClass::Replace { .. }))
        .map(|channel| channel.multiplicity as usize)
        .sum();
    let pop_count = generator
        .contacted_channels
        .iter()
        .filter(|channel| matches!(channel.class, ContinuousChannelClass::Pop { .. }))
        .map(|channel| channel.multiplicity as usize)
        .sum();
    let append_count = generator
        .contacted_channels
        .iter()
        .filter(|channel| matches!(channel.class, ContinuousChannelClass::Append { .. }))
        .map(|channel| channel.multiplicity as usize)
        .sum();

    let macro_multiplicities = (0..=generator.depth)
        .map(|level| {
            BigUint::from(
                generator
                    .states
                    .iter()
                    .filter(|state| state.energy_level == level)
                    .count(),
            )
        })
        .collect::<Vec<_>>();
    let total_states = BigUint::from(state_count);
    let macro_stationary = macro_multiplicities
        .iter()
        .map(|count| ExactRatio::new(count.clone(), total_states.clone()))
        .collect::<Result<Vec<_>>>()?;
    let boltzmann_factor = ExactRatio::new(BigUint::one(), BigUint::from(generator.alphabet_size))?;

    let macro_up_rates = (0..generator.depth)
        .map(|level| macro_rates[level][level + 1].clone())
        .collect::<Vec<_>>();
    let macro_down_rates = (1..=generator.depth)
        .map(|level| macro_rates[level][level - 1].clone())
        .collect::<Vec<_>>();

    let mut exit_rates_by_level = Vec::new();
    let mut layer_exit_consistent = true;
    for level in 0..=generator.depth {
        let values = generator
            .states
            .iter()
            .enumerate()
            .filter_map(|(index, state)| {
                (state.energy_level == level).then_some(exit_rates[index].clone())
            })
            .collect::<Vec<_>>();
        let representative = values.first().cloned().unwrap_or_else(BigUint::zero);
        layer_exit_consistent &= values.iter().all(|value| value == &representative);
        exit_rates_by_level.push(representative);
    }

    let expected_state_count = geometric_state_count(generator.alphabet_size, generator.depth)?;
    let expected_pop = geometric_nonempty_count(generator.alphabet_size, generator.depth)?;
    let expected_replacements =
        replacement_instance_count(generator.alphabet_size, generator.depth)?;
    let formula_counts_match = state_count == expected_state_count
        && pop_count == expected_pop
        && append_count == expected_pop
        && replacement_count == expected_replacements
        && generator
            .isolated_channels
            .iter()
            .map(|channel| channel.multiplicity as usize)
            .sum::<usize>()
            == expected_replacements;

    let squared_boltzmann_factor = boltzmann_factor.checked_multiply(&boltzmann_factor)?;
    let fixed_b_identities = (0..generator.depth).all(|level| {
        ratio_divide(&macro_stationary[level + 1], &macro_stationary[level])
            .is_ok_and(|observed| observed == boltzmann_factor)
            && macro_up_rates[level] == BigUint::one()
            && macro_down_rates[level] == BigUint::from(generator.alphabet_size)
    }) && if generator.depth >= 2 {
        ratio_divide(&macro_stationary[2], &macro_stationary[0])
            .is_ok_and(|observed| observed == squared_boltzmann_factor)
    } else {
        true
    };

    let low_preparation = (0..=generator.depth)
        .map(|level| {
            if level == 0 {
                ExactRatio::one()
            } else {
                ExactRatio::zero()
            }
        })
        .collect::<Vec<_>>();
    let high_preparation = (0..=generator.depth)
        .map(|level| {
            if level == generator.depth {
                ExactRatio::one()
            } else {
                ExactRatio::zero()
            }
        })
        .collect::<Vec<_>>();
    let low_energy_currents = macro_currents(&low_preparation, &macro_up_rates, &macro_down_rates)?;
    let high_energy_currents =
        macro_currents(&high_preparation, &macro_up_rates, &macro_down_rates)?;
    let equilibrium_currents =
        macro_currents(&macro_stationary, &macro_up_rates, &macro_down_rates)?;

    Ok(CausalStackReport {
        alphabet_size: generator.alphabet_size,
        depth: generator.depth,
        state_count,
        isolated_replacement_count: generator
            .isolated_channels
            .iter()
            .map(|channel| channel.multiplicity as usize)
            .sum(),
        replacement_count,
        pop_count,
        append_count,
        contacted_channel_count: generator
            .contacted_channels
            .iter()
            .map(|channel| channel.multiplicity as usize)
            .sum(),
        row_normalization: GateVerdict::NotApplicable,
        discrete_lumpability: GateVerdict::NotApplicable,
        projected_discrete_detailed_balance: GateVerdict::NotApplicable,
        channel_metadata_complete: GateVerdict::from_bool(metadata_complete),
        generator_conservation: GateVerdict::from_bool(generator_conservation),
        full_reverse_support: GateVerdict::from_bool(reverse_support),
        connected: GateVerdict::from_bool(connected),
        generator_lumpability: GateVerdict::from_bool(generator_lumpable),
        reference_stationary: GateVerdict::from_bool(uniform_stationary),
        reference_detailed_balance: GateVerdict::from_bool(uniform_detailed_balance),
        internal_rate_no_quench: GateVerdict::from_bool(internal_rate_no_quench),
        energy_closure: GateVerdict::from_bool(energy_closure),
        formula_counts_match: GateVerdict::from_bool(formula_counts_match),
        fixed_b_identities: GateVerdict::from_bool(fixed_b_identities),
        macro_multiplicities,
        macro_stationary,
        boltzmann_factor,
        macro_up_rates,
        macro_down_rates,
        diagonal_exit_rates: exit_rates,
        exit_rates_by_level: if layer_exit_consistent {
            exit_rates_by_level
        } else {
            Vec::new()
        },
        low_energy_currents,
        high_energy_currents,
        equilibrium_currents,
    })
}

fn continuous_rate_matrix(
    state_count: usize,
    channels: &[ContinuousChannel],
) -> Result<Vec<Vec<BigUint>>> {
    let mut matrix = vec![vec![BigUint::zero(); state_count]; state_count];
    for channel in channels {
        if channel.source >= state_count
            || channel.target >= state_count
            || channel.source == channel.target
            || channel.rate.is_zero()
            || channel.multiplicity == 0
        {
            return Err(AnalysisError::new("continuous channel metadata is invalid"));
        }
        matrix[channel.source][channel.target] +=
            &channel.rate * BigUint::from(channel.multiplicity);
    }
    Ok(matrix)
}

fn signed_generator_matrix(rate_matrix: &[Vec<BigUint>]) -> Vec<Vec<BigInt>> {
    rate_matrix
        .iter()
        .enumerate()
        .map(|(source, row)| {
            let exit = row.iter().fold(BigUint::zero(), |sum, rate| sum + rate);
            row.iter()
                .enumerate()
                .map(|(target, rate)| {
                    if source == target {
                        -BigInt::from(exit.clone())
                    } else {
                        BigInt::from(rate.clone())
                    }
                })
                .collect()
        })
        .collect()
}

fn continuous_connected(matrix: &[Vec<BigUint>]) -> bool {
    if matrix.is_empty() {
        return false;
    }
    let mut visited = vec![false; matrix.len()];
    let mut queue = VecDeque::from([0]);
    visited[0] = true;
    while let Some(source) = queue.pop_front() {
        for target in 0..matrix.len() {
            if (!matrix[source][target].is_zero() || !matrix[target][source].is_zero())
                && !visited[target]
            {
                visited[target] = true;
                queue.push_back(target);
            }
        }
    }
    visited.into_iter().all(|seen| seen)
}

fn generator_projection(
    generator: &ContinuousGenerator,
    rate_matrix: &[Vec<BigUint>],
) -> Result<(bool, Vec<Vec<BigUint>>)> {
    let macro_count = generator.depth + 1;
    let mut macro_rates = vec![vec![BigUint::zero(); macro_count]; macro_count];
    for source_level in 0..macro_count {
        let states = generator
            .states
            .iter()
            .enumerate()
            .filter_map(|(index, state)| (state.energy_level == source_level).then_some(index))
            .collect::<Vec<_>>();
        let Some(&representative) = states.first() else {
            return Ok((false, macro_rates));
        };
        for target_level in 0..macro_count {
            if target_level == source_level {
                continue;
            }
            let expected = rate_to_level(generator, rate_matrix, representative, target_level);
            if states.iter().any(|&source| {
                rate_to_level(generator, rate_matrix, source, target_level) != expected
            }) {
                return Ok((false, macro_rates));
            }
            macro_rates[source_level][target_level] = expected;
        }
    }
    Ok((true, macro_rates))
}

fn rate_to_level(
    generator: &ContinuousGenerator,
    rate_matrix: &[Vec<BigUint>],
    source: usize,
    target_level: usize,
) -> BigUint {
    generator
        .states
        .iter()
        .enumerate()
        .filter(|(_, state)| state.energy_level == target_level)
        .fold(BigUint::zero(), |sum, (target, _)| {
            sum + &rate_matrix[source][target]
        })
}

fn retained_internal_rates_unchanged(generator: &ContinuousGenerator) -> bool {
    let isolated = generator
        .isolated_channels
        .iter()
        .map(|channel| (channel.id.as_str(), channel))
        .collect::<BTreeMap<_, _>>();
    let contacted = generator
        .contacted_channels
        .iter()
        .filter(|channel| matches!(channel.class, ContinuousChannelClass::Replace { .. }))
        .map(|channel| (channel.id.as_str(), channel))
        .collect::<BTreeMap<_, _>>();
    isolated.len() == generator.isolated_channels.len()
        && contacted.len()
            == generator
                .contacted_channels
                .iter()
                .filter(|channel| matches!(channel.class, ContinuousChannelClass::Replace { .. }))
                .count()
        && isolated.len() == contacted.len()
        && isolated.iter().all(|(id, before)| {
            contacted.get(id).is_some_and(|after| {
                after.reverse_id == before.reverse_id
                    && after.source == before.source
                    && after.target == before.target
                    && after.rate == before.rate
                    && after.multiplicity == before.multiplicity
                    && after.class == before.class
            })
        })
}

fn channel_preserves_total_energy(
    generator: &ContinuousGenerator,
    channel: &ContinuousChannel,
) -> bool {
    let source = &generator.states[channel.source];
    let target = &generator.states[channel.target];
    source.energy_level + source.symbols.len() == generator.depth
        && target.energy_level + target.symbols.len() == generator.depth
        && match channel.class {
            ContinuousChannelClass::Replace { position, from, to } => {
                source.energy_level == target.energy_level
                    && source.symbols.len() == target.symbols.len()
                    && position < source.symbols.len()
                    && from != to
                    && source.symbols[position] == from
                    && target.symbols[position] == to
                    && source
                        .symbols
                        .iter()
                        .zip(&target.symbols)
                        .enumerate()
                        .all(|(index, (left, right))| index == position || left == right)
            }
            ContinuousChannelClass::Pop { symbol } => {
                target.energy_level == source.energy_level + 1
                    && target.symbols.len() + 1 == source.symbols.len()
                    && source.symbols.last() == Some(&symbol)
                    && target.symbols == source.symbols[..source.symbols.len() - 1]
            }
            ContinuousChannelClass::Append { symbol } => {
                source.energy_level == target.energy_level + 1
                    && source.symbols.len() + 1 == target.symbols.len()
                    && target.symbols.last() == Some(&symbol)
                    && source.symbols == target.symbols[..target.symbols.len() - 1]
            }
        }
}

fn continuous_classes_are_reverses(
    forward: &ContinuousChannelClass,
    reverse: &ContinuousChannelClass,
) -> bool {
    match (forward, reverse) {
        (
            ContinuousChannelClass::Replace {
                position: left_position,
                from: left_from,
                to: left_to,
            },
            ContinuousChannelClass::Replace {
                position: right_position,
                from: right_from,
                to: right_to,
            },
        ) => left_position == right_position && left_from == right_to && left_to == right_from,
        (
            ContinuousChannelClass::Pop { symbol: left },
            ContinuousChannelClass::Append { symbol: right },
        )
        | (
            ContinuousChannelClass::Append { symbol: left },
            ContinuousChannelClass::Pop { symbol: right },
        ) => left == right,
        _ => false,
    }
}

fn macro_currents(
    preparation: &[ExactRatio],
    up_rates: &[BigUint],
    down_rates: &[BigUint],
) -> Result<Vec<SignedExactValue>> {
    if preparation.len() != up_rates.len() + 1 || up_rates.len() != down_rates.len() {
        return Err(AnalysisError::new(
            "macro preparation and boundary rates have incompatible lengths",
        ));
    }
    (0..up_rates.len())
        .map(|level| {
            let forward = scale_ratio_big(&preparation[level], &up_rates[level])?;
            let reverse = scale_ratio_big(&preparation[level + 1], &down_rates[level])?;
            signed_difference(&forward, &reverse)
        })
        .collect()
}

fn signed_difference(left: &ExactRatio, right: &ExactRatio) -> Result<SignedExactValue> {
    let left_cross = left.numerator() * right.denominator();
    let right_cross = right.numerator() * left.denominator();
    let denominator = left.denominator() * right.denominator();
    match left_cross.cmp(&right_cross) {
        std::cmp::Ordering::Less => Ok(SignedExactValue {
            sign: SignedValueSign::Negative,
            magnitude: ExactRatio::new(right_cross - left_cross, denominator)?,
        }),
        std::cmp::Ordering::Equal => Ok(SignedExactValue::zero()),
        std::cmp::Ordering::Greater => Ok(SignedExactValue {
            sign: SignedValueSign::Positive,
            magnitude: ExactRatio::new(left_cross - right_cross, denominator)?,
        }),
    }
}

fn enumerate_words(alphabet_size: u32, length: usize) -> Result<Vec<Vec<u32>>> {
    let count = checked_power_usize(alphabet_size, length)?;
    let base = usize::try_from(alphabet_size)
        .map_err(|_| AnalysisError::new("causal-stack alphabet exceeds usize"))?;
    let mut words = Vec::with_capacity(count);
    for mut code in 0..count {
        let mut word = vec![0_u32; length];
        for position in (0..length).rev() {
            word[position] = u32::try_from(code % base)
                .map_err(|_| AnalysisError::new("causal-stack symbol exceeds u32"))?;
            code /= base;
        }
        words.push(word);
    }
    Ok(words)
}

fn checked_power_usize(base: u32, exponent: usize) -> Result<usize> {
    let base = usize::try_from(base)
        .map_err(|_| AnalysisError::new("causal-stack alphabet exceeds usize"))?;
    (0..exponent).try_fold(1_usize, |value, _| {
        value
            .checked_mul(base)
            .ok_or_else(|| AnalysisError::new("causal-stack state count exceeds usize"))
    })
}

fn geometric_state_count(alphabet_size: u32, depth: usize) -> Result<usize> {
    (0..=depth).try_fold(0_usize, |sum, exponent| {
        sum.checked_add(checked_power_usize(alphabet_size, exponent)?)
            .ok_or_else(|| AnalysisError::new("causal-stack state count exceeds usize"))
    })
}

fn geometric_nonempty_count(alphabet_size: u32, depth: usize) -> Result<usize> {
    (1..=depth).try_fold(0_usize, |sum, exponent| {
        sum.checked_add(checked_power_usize(alphabet_size, exponent)?)
            .ok_or_else(|| AnalysisError::new("causal-stack channel count exceeds usize"))
    })
}

fn replacement_instance_count(alphabet_size: u32, depth: usize) -> Result<usize> {
    let alternatives = usize::try_from(alphabet_size - 1)
        .map_err(|_| AnalysisError::new("causal-stack alphabet exceeds usize"))?;
    (1..=depth).try_fold(0_usize, |sum, length| {
        let at_length = checked_power_usize(alphabet_size, length)?
            .checked_mul(length)
            .and_then(|value| value.checked_mul(alternatives))
            .ok_or_else(|| AnalysisError::new("replacement count exceeds usize"))?;
        sum.checked_add(at_length)
            .ok_or_else(|| AnalysisError::new("replacement count exceeds usize"))
    })
}

fn state_index(
    indices: &BTreeMap<(usize, Vec<u32>), usize>,
    energy_level: usize,
    symbols: &[u32],
) -> Result<usize> {
    indices
        .get(&(energy_level, symbols.to_vec()))
        .copied()
        .ok_or_else(|| AnalysisError::new("causal-stack successor is outside the state shell"))
}

fn stack_state_id(energy_level: usize, symbols: &[u32]) -> String {
    let suffix = symbols
        .iter()
        .map(u32::to_string)
        .collect::<Vec<_>>()
        .join(",");
    format!("n{energy_level}:[{suffix}]")
}

fn replace_channel_id(state_id: &str, position: usize, from: u32, to: u32) -> String {
    format!("replace:{state_id}:{position}:{from}>{to}")
}

fn pop_channel_id(state_id: &str, symbol: u32) -> String {
    format!("pop:{state_id}:{symbol}")
}

fn append_channel_id(state_id: &str, symbol: u32) -> String {
    format!("append:{state_id}:{symbol}")
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrozenAdaptiveContactReport {
    pub monotone: DiscreteContactReport,
    pub apparent_reciprocity: DiscreteContactReport,
    pub lumpable_control: DiscreteContactReport,
    pub reversible_square: DiscreteContactReport,
    pub ma_ablation: DiscreteContactReport,
    pub mb_ablation: DiscreteContactReport,
    pub binary_stack: CausalStackReport,
    pub ternary_stack: CausalStackReport,
    pub metamorphic_stack: CausalStackReport,
}

impl FrozenAdaptiveContactReport {
    pub fn matches_preregistered_predictions(&self) -> bool {
        let monotone_matches = self.monotone.state_count == 2
            && self.monotone.channel_count == 2
            && self.monotone.row_normalization.passed()
            && discrete_negative_common_gates_match(&self.monotone)
            && self.monotone.full_reverse_support == GateVerdict::Failed
            && self.monotone.monotone_reverse_obstruction
            && self.monotone.strict_monotone_channel_count == 1
            && self.monotone.strong_lumpability.passed()
            && self.monotone.projected_reverse_support == GateVerdict::Failed
            && self.monotone.reference_positive.passed()
            && self.monotone.reference_normalized.passed()
            && self.monotone.reference_stationary == GateVerdict::Failed
            && self.monotone.reference_detailed_balance == GateVerdict::Failed
            && self.monotone.projected_reference_stationary == GateVerdict::Failed
            && self.monotone.projected_reference_detailed_balance == GateVerdict::Failed
            && self.monotone.transient_states == ["z0"]
            && !self.monotone.full_support_stationary_exists
            && self.monotone.stationary_law_unique;

        let apparent_witness_matches = self
            .apparent_reciprocity
            .lumpability_witness
            .as_ref()
            .is_some_and(|witness| {
                witness.left_state == "A0"
                    && witness.right_state == "A1"
                    && witness.destination == BalanceFiber::B
                    && witness.left_probability == ExactRatio::one()
                    && witness.right_probability == ExactRatio::zero()
            });
        let apparent_matches = self.apparent_reciprocity.state_count == 4
            && self.apparent_reciprocity.row_normalization.passed()
            && discrete_negative_common_gates_match(&self.apparent_reciprocity)
            && self.apparent_reciprocity.full_reverse_support == GateVerdict::Failed
            && self.apparent_reciprocity.monotone_reverse_obstruction
            && self
                .apparent_reciprocity
                .existential_fiber_support_reciprocal
            && self.apparent_reciprocity.strong_lumpability == GateVerdict::Failed
            && apparent_witness_matches
            && self.apparent_reciprocity.projected_kernel.is_none()
            && self.apparent_reciprocity.projected_reverse_support == GateVerdict::NotApplicable
            && self.apparent_reciprocity.projected_reference_stationary
                == GateVerdict::NotApplicable
            && self
                .apparent_reciprocity
                .projected_reference_detailed_balance
                == GateVerdict::NotApplicable
            && self.apparent_reciprocity.reference_stationary == GateVerdict::Failed
            && self.apparent_reciprocity.reference_detailed_balance == GateVerdict::Failed
            && self.apparent_reciprocity.transient_states == ["A0", "B0"]
            && !self.apparent_reciprocity.full_support_stationary_exists
            && !self.apparent_reciprocity.stationary_law_unique;

        let lumpable_projected_matches = self
            .lumpable_control
            .projected_kernel
            .as_ref()
            .is_some_and(|kernel| {
                kernel.probability(BalanceFiber::A, BalanceFiber::B) == &ExactRatio::one()
                    && kernel.probability(BalanceFiber::B, BalanceFiber::A) == &ExactRatio::one()
                    && kernel.probability(BalanceFiber::A, BalanceFiber::A) == &ExactRatio::zero()
                    && kernel.probability(BalanceFiber::B, BalanceFiber::B) == &ExactRatio::zero()
            });
        let lumpable_matches = self.lumpable_control.state_count == 4
            && self.lumpable_control.channel_count == 4
            && self.lumpable_control.all_applicable_positive_gates_passed()
            && lumpable_projected_matches
            && self.lumpable_control.communicating_classes.len() == 2
            && self
                .lumpable_control
                .communicating_classes
                .iter()
                .all(|component| component.closed)
            && self.lumpable_control.transient_states.is_empty()
            && self.lumpable_control.full_support_stationary_exists
            && !self.lumpable_control.stationary_law_unique;

        let square_projected_matches = self
            .reversible_square
            .projected_kernel
            .as_ref()
            .is_some_and(|kernel| {
                ratio_matches(kernel.probability(BalanceFiber::A, BalanceFiber::B), 1, 3)
                    && ratio_matches(kernel.probability(BalanceFiber::B, BalanceFiber::A), 1, 3)
                    && ratio_matches(kernel.probability(BalanceFiber::A, BalanceFiber::A), 2, 3)
                    && ratio_matches(kernel.probability(BalanceFiber::B, BalanceFiber::B), 2, 3)
            });
        let square_matches = self.reversible_square.state_count == 4
            && self.reversible_square.channel_count == 12
            && self
                .reversible_square
                .all_applicable_positive_gates_passed()
            && square_projected_matches
            && self.reversible_square.communicating_classes.len() == 1
            && self.reversible_square.communicating_classes[0].closed
            && self.reversible_square.stationary_law_unique;

        let ablations_match = [&self.ma_ablation, &self.mb_ablation]
            .into_iter()
            .all(|report| {
                report.channel_count == 12
                    && report.row_normalization.passed()
                    && discrete_negative_common_gates_match(report)
                    && report.full_reverse_support == GateVerdict::Failed
                    && report.strong_lumpability.passed()
                    && report.projected_reverse_support.passed()
                    && report.projected_reference_stationary.passed()
                    && report.projected_reference_detailed_balance.passed()
                    && report.reference_stationary == GateVerdict::Failed
                    && report.reference_detailed_balance == GateVerdict::Failed
            })
            && self.ma_ablation.missing_reverse_ids == ["MA-"]
            && self.mb_ablation.missing_reverse_ids == ["MB-"];

        monotone_matches
            && apparent_matches
            && lumpable_matches
            && square_matches
            && ablations_match
            && stack_primary_matches(&self.binary_stack)
            && stack_extrapolation_matches(&self.ternary_stack)
            && self.metamorphic_stack.alphabet_size == 2
            && self.metamorphic_stack.depth == 3
            && self.metamorphic_stack.state_count == 15
            && self.metamorphic_stack.contacted_channel_count == 62
            && self
                .metamorphic_stack
                .all_applicable_positive_gates_passed()
    }
}

fn discrete_negative_common_gates_match(report: &DiscreteContactReport) -> bool {
    report.channel_metadata_complete.passed()
        && report.reference_positive.passed()
        && report.reference_normalized.passed()
        && report.continuous_generator_conservation == GateVerdict::NotApplicable
        && report.continuous_generator_lumpability == GateVerdict::NotApplicable
        && report.internal_rate_no_quench == GateVerdict::NotApplicable
        && report.causal_stack_identities == GateVerdict::NotApplicable
}

pub fn frozen_adaptive_contact_report() -> Result<FrozenAdaptiveContactReport> {
    Ok(FrozenAdaptiveContactReport {
        monotone: monotone_full_state_fixture()?.verify()?,
        apparent_reciprocity: apparent_reciprocity_fixture()?.verify()?,
        lumpable_control: lumpable_hidden_state_fixture()?.verify()?,
        reversible_square: reversible_memory_square_fixture(SquareAblation::None)?.verify()?,
        ma_ablation: reversible_memory_square_fixture(SquareAblation::RemoveMaReverse)?.verify()?,
        mb_ablation: reversible_memory_square_fixture(SquareAblation::RemoveMbReverse)?.verify()?,
        binary_stack: causal_stack_generator(2, 2)?.verify()?,
        ternary_stack: causal_stack_generator(3, 2)?.verify()?,
        metamorphic_stack: causal_stack_generator(2, 3)?.verify()?,
    })
}

fn stack_primary_matches(report: &CausalStackReport) -> bool {
    report.alphabet_size == 2
        && report.depth == 2
        && report.state_count == 7
        && report.replacement_count == 10
        && report.pop_count == 6
        && report.append_count == 6
        && report.contacted_channel_count == 22
        && report.macro_multiplicities == [BigUint::from(4_u8), BigUint::from(2_u8), BigUint::one()]
        && report.macro_stationary
            == [
                ratio_literal(4, 7),
                ratio_literal(2, 7),
                ratio_literal(1, 7),
            ]
        && report.boltzmann_factor == ratio_literal(1, 2)
        && report.macro_up_rates == [BigUint::one(), BigUint::one()]
        && report.macro_down_rates == [BigUint::from(2_u8), BigUint::from(2_u8)]
        && report.exit_rates_by_level
            == [
                BigUint::from(3_u8),
                BigUint::from(4_u8),
                BigUint::from(2_u8),
            ]
        && signed_matches(&report.low_energy_currents[0], SignedValueSign::Positive, 1)
        && signed_matches(&report.low_energy_currents[1], SignedValueSign::Zero, 0)
        && signed_matches(&report.high_energy_currents[0], SignedValueSign::Zero, 0)
        && signed_matches(
            &report.high_energy_currents[1],
            SignedValueSign::Negative,
            2,
        )
        && report
            .equilibrium_currents
            .iter()
            .all(|current| current.sign == SignedValueSign::Zero)
        && report.all_applicable_positive_gates_passed()
}

fn stack_extrapolation_matches(report: &CausalStackReport) -> bool {
    report.alphabet_size == 3
        && report.depth == 2
        && report.state_count == 13
        && report.replacement_count == 42
        && report.pop_count == 12
        && report.append_count == 12
        && report.contacted_channel_count == 66
        && report.macro_multiplicities == [BigUint::from(9_u8), BigUint::from(3_u8), BigUint::one()]
        && report.macro_stationary
            == [
                ratio_literal(9, 13),
                ratio_literal(3, 13),
                ratio_literal(1, 13),
            ]
        && report.boltzmann_factor == ratio_literal(1, 3)
        && report.macro_up_rates == [BigUint::one(), BigUint::one()]
        && report.macro_down_rates == [BigUint::from(3_u8), BigUint::from(3_u8)]
        && report.exit_rates_by_level
            == [
                BigUint::from(5_u8),
                BigUint::from(6_u8),
                BigUint::from(3_u8),
            ]
        && report.all_applicable_positive_gates_passed()
}

fn signed_matches(current: &SignedExactValue, sign: SignedValueSign, magnitude: u64) -> bool {
    current.sign == sign && current.magnitude == ratio_literal(magnitude, 1)
}

fn uniform_reference(state_count: usize) -> Result<Vec<ExactRatio>> {
    if state_count == 0 {
        return Err(AnalysisError::new(
            "uniform reference requires at least one state",
        ));
    }
    let weight = ExactRatio::new(BigUint::one(), BigUint::from(state_count))?;
    Ok(vec![weight; state_count])
}

fn zero_ratio_matrix(size: usize) -> Vec<Vec<ExactRatio>> {
    vec![vec![ExactRatio::zero(); size]; size]
}

fn sum_ratios(values: &[ExactRatio]) -> Result<ExactRatio> {
    values
        .iter()
        .try_fold(ExactRatio::zero(), |sum, value| sum.checked_add(value))
}

fn ratio(numerator: u64, denominator: u64) -> Result<ExactRatio> {
    ExactRatio::new(BigUint::from(numerator), BigUint::from(denominator))
}

fn ratio_literal(numerator: u64, denominator: u64) -> ExactRatio {
    ratio(numerator, denominator).expect("nonzero frozen denominator")
}

fn ratio_matches(value: &ExactRatio, numerator: u64, denominator: u64) -> bool {
    value == &ratio_literal(numerator, denominator)
}

fn scale_ratio(value: &ExactRatio, multiplier: u32) -> Result<ExactRatio> {
    scale_ratio_big(value, &BigUint::from(multiplier))
}

fn scale_ratio_big(value: &ExactRatio, multiplier: &BigUint) -> Result<ExactRatio> {
    ExactRatio::new(value.numerator() * multiplier, value.denominator().clone())
}

fn ratio_divide(numerator: &ExactRatio, denominator: &ExactRatio) -> Result<ExactRatio> {
    if denominator.numerator().is_zero() {
        return Err(AnalysisError::new("cannot divide by a zero exact ratio"));
    }
    ExactRatio::new(
        numerator.numerator() * denominator.denominator(),
        numerator.denominator() * denominator.numerator(),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn energy_gate_rejects_a_false_pop_symbol() {
        let mut generator = causal_stack_generator(2, 2).expect("binary stack");
        let channel = generator
            .contacted_channels
            .iter_mut()
            .find(|channel| matches!(channel.class, ContinuousChannelClass::Pop { .. }))
            .expect("POP channel");
        let ContinuousChannelClass::Pop { symbol } = &mut channel.class else {
            unreachable!();
        };
        *symbol = (*symbol + 1) % 2;

        let report = generator.verify().expect("mutated stack report");
        assert_eq!(report.energy_closure, GateVerdict::Failed);
    }

    #[test]
    fn energy_gate_rejects_a_rewired_replace_position() {
        let mut generator = causal_stack_generator(2, 2).expect("binary stack");
        let states = generator.states.clone();
        let channel = generator
            .contacted_channels
            .iter_mut()
            .find(|channel| {
                states[channel.source].symbols == [0, 0]
                    && matches!(
                        channel.class,
                        ContinuousChannelClass::Replace { position: 0, .. }
                    )
            })
            .expect("length-two replacement");
        let ContinuousChannelClass::Replace { position, .. } = &mut channel.class else {
            unreachable!();
        };
        *position = 1;

        let report = generator.verify().expect("mutated stack report");
        assert_eq!(report.energy_closure, GateVerdict::Failed);
    }

    #[test]
    fn causal_stack_rejects_nonunit_channel_instances() {
        let mut generator = causal_stack_generator(2, 2).expect("binary stack");
        for channel in &mut generator.isolated_channels {
            channel.multiplicity = 2;
            channel.rate = BigUint::from(2_u8);
        }
        for channel in &mut generator.contacted_channels {
            if matches!(channel.class, ContinuousChannelClass::Replace { .. }) {
                channel.multiplicity = 2;
                channel.rate = BigUint::from(2_u8);
            }
        }

        let report = generator.verify().expect("mutated stack report");
        assert_eq!(report.channel_metadata_complete, GateVerdict::Failed);
        assert_eq!(report.formula_counts_match, GateVerdict::Failed);
        assert!(!report.all_applicable_positive_gates_passed());
    }

    #[test]
    fn no_quench_rejects_a_duplicated_isolated_channel_id() {
        let mut generator = causal_stack_generator(2, 2).expect("binary stack");
        generator.isolated_channels[1] = generator.isolated_channels[0].clone();

        let report = generator.verify().expect("mutated stack report");
        assert_eq!(report.internal_rate_no_quench, GateVerdict::Failed);
        assert!(!report.all_applicable_positive_gates_passed());
    }

    #[test]
    fn discrete_typed_channels_reject_a_memory_edge_relabeled_as_transfer() {
        let mut kernel =
            reversible_memory_square_fixture(SquareAblation::None).expect("reversible square");
        for channel in &mut kernel.channels {
            if channel.id == "MA+" || channel.id == "MA-" {
                channel.class = DiscreteChannelClass::Transfer;
            }
        }

        let report = kernel.verify().expect("mutated square report");
        assert_eq!(report.channel_metadata_complete, GateVerdict::Failed);
        assert_eq!(report.full_reverse_support, GateVerdict::Passed);
        assert_eq!(report.row_normalization, GateVerdict::Passed);
    }

    #[test]
    fn frozen_aggregate_rejects_malformed_negative_control_metadata() {
        let mut report = frozen_adaptive_contact_report().expect("frozen report");
        assert!(report.matches_preregistered_predictions());
        report.ma_ablation.channel_metadata_complete = GateVerdict::Failed;
        assert!(!report.matches_preregistered_predictions());
    }

    #[test]
    fn signed_generator_rows_conserve_exactly() {
        let generator = causal_stack_generator(3, 2).expect("ternary stack");
        let matrix = generator.signed_matrix().expect("signed generator");
        let report = generator.verify().expect("generator report");
        for (source, row) in matrix.iter().enumerate() {
            assert_eq!(
                row.iter().fold(BigInt::zero(), |sum, value| sum + value),
                BigInt::zero()
            );
            assert_eq!(
                row[source],
                -BigInt::from(report.diagonal_exit_rates[source].clone())
            );
        }
        assert_eq!(report.generator_conservation, GateVerdict::Passed);
    }
}
