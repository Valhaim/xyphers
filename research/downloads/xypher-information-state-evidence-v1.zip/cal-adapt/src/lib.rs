//! Independent finite-state analysis for the frozen Xypher Calorimeter.
//!
//! This crate is an analysis instrument, not a runtime actor. It constructs
//! the allocation state shell and action-labelled adjacency matrix from a
//! generic fixture, then derives the receding-horizon kernel by explicit
//! matrix-vector products.

mod adaptive_contact;
mod compatibility;
mod exact;
mod fixed_affordance;
mod fixture;
mod markov;
mod native_clock;
mod spectral;
mod weak_contact;
mod zero_range_contact;

pub use adaptive_contact::{
    apparent_reciprocity_fixture, causal_stack_generator, frozen_adaptive_contact_report,
    lumpable_hidden_state_fixture, monotone_full_state_fixture, reversible_memory_square_fixture,
    AdaptiveState, BalanceFiber, CausalStackReport, CommunicatingClassReport, ContinuousChannel,
    ContinuousChannelClass, ContinuousGenerator, DiscreteChannel, DiscreteChannelClass,
    DiscreteContactReport, DiscreteKernel, FrozenAdaptiveContactReport, GateVerdict,
    LumpabilityWitness, ProjectedKernel, SignedExactValue, SignedValueSign, SquareAblation,
    StackState,
};
pub use compatibility::{
    check_exists_beta_compatibility, check_fixed_beta_compatibility,
    check_qh_channel_compatibility, BetaSign, BetaStatus, CompatibilityFailure, CoordinateOrigin,
    ExactQhChannelWitness, ExactSlopeWitness, ExistsBetaCompatibilityReport,
    FixedBetaCompatibilityReport, QhChannelCompatibilityFailure, QhChannelCompatibilityReport,
    StateResolution, StationaryCompatibilityProfile,
};
pub use exact::{
    CandidateWeight, CycleBalanceReport, ExactChecks, ExactDistribution, ExactKernel, ExactRatio,
    ExactTransientPoint, PermutationCovarianceReport,
};
pub use fixed_affordance::{
    frozen_constructibility_report, FrozenAffordanceSlot, FrozenBinaryState, FrozenBody,
    FrozenChannelInstance, FrozenChannelOutcome, FrozenComponentKey, FrozenComponentReport,
    FrozenConstructibilityReport, FrozenContactMode, FrozenContactPair, FrozenCurrentDirection,
    FrozenCurrentReport, FrozenFixedAffordanceKernel, FrozenKernelChecks,
    FrozenPairConstructibilityReport, FROZEN_AFFORDANCE_SLOTS, FROZEN_NODE_COUNT,
    FROZEN_SLOT_COUNT, FROZEN_STATE_COUNT,
};
pub use fixture::{Action, ActionStep, Fixture, StateShell};
pub use markov::{
    compare_kernels, Analysis, EntropyMetrics, EquilibriumMetrics, FirstPassageReport,
    KernelComparison, NumericalResiduals, SpectralGapCertificate, SpectralInterval, SpectralReport,
    TransientPoint, TransientReport, KL_NEGATIVE_TOLERANCE_BITS, MFPT_BELLMAN_TOLERANCE,
    MIXING_TV_THRESHOLD, PROBABILITY_TOLERANCE,
};
pub use native_clock::{
    frozen_native_clock_report, verify_bundle_additivity, verify_cycle_affinity,
    verify_exact_rate_tetrads, BundleAdditivityReport, BundleAdditivityWitness, ClockGaugeReport,
    ContactClockReport, CycleAffinityReport, EmbeddedClockEquivalenceReport, ExactCycleAffinity,
    FrozenNativeClockReport, GraphFixtureKind, HiddenStateClockReport, LoadEquivalenceCase,
    NativeDepartureLaw, NativeGraphClock, SourceOddsCase, TetradReport, TetradWitness,
    ThinningFactorization, ThinningGaugeReport,
};
pub use spectral::{symmetric_eigendecomposition, DenseMatrix, SymmetricSpectrum};
pub use weak_contact::{
    compare_qh_weak_contact, ExactDifferenceSign, RetainedTransferChannelComparison,
    SignedExactRatio, TransferChannelLabel, WeakContactComparison,
};
pub use zero_range_contact::{
    compare_retained_zero_range_rates, edge_clock_spec, enumerate_labeled_projection_counts,
    integer_rate_matrix, linear_departure, normalized_node_clock_spec, occupied_site_departure,
    ExactSignedRatio, RetainedZeroRangeRate, RetainedZeroRangeRateReport, ZeroRangeChannel,
    ZeroRangeChannelLabel, ZeroRangeCommunicatingClass, ZeroRangeGenerator,
    ZeroRangePermutationReport, ZeroRangeReport, ZeroRangeSpec,
};

use std::fmt;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AnalysisError {
    message: String,
}

impl AnalysisError {
    pub(crate) fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}

impl fmt::Display for AnalysisError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.message.fmt(formatter)
    }
}

impl std::error::Error for AnalysisError {}

pub type Result<T> = std::result::Result<T, AnalysisError>;
