use crate::{Action, AnalysisError, ExactKernel, ExactRatio, Result};
use num_bigint::BigUint;
use num_integer::Integer;
use num_traits::{One, Zero};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ExactDifferenceSign {
    Negative,
    Zero,
    Positive,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SignedExactRatio {
    pub sign: ExactDifferenceSign,
    pub numerator: BigUint,
    pub denominator: BigUint,
}

impl SignedExactRatio {
    pub fn is_zero(&self) -> bool {
        self.sign == ExactDifferenceSign::Zero
    }

    fn difference(joined: &ExactRatio, isolated: &ExactRatio) -> Self {
        let joined_cross = joined.numerator() * isolated.denominator();
        let isolated_cross = isolated.numerator() * joined.denominator();
        let denominator = joined.denominator() * isolated.denominator();

        match joined_cross.cmp(&isolated_cross) {
            std::cmp::Ordering::Less => Self::reduced(
                ExactDifferenceSign::Negative,
                isolated_cross - joined_cross,
                denominator,
            ),
            std::cmp::Ordering::Equal => Self {
                sign: ExactDifferenceSign::Zero,
                numerator: BigUint::zero(),
                denominator: BigUint::one(),
            },
            std::cmp::Ordering::Greater => Self::reduced(
                ExactDifferenceSign::Positive,
                joined_cross - isolated_cross,
                denominator,
            ),
        }
    }

    fn reduced(sign: ExactDifferenceSign, numerator: BigUint, denominator: BigUint) -> Self {
        let divisor = numerator.gcd(&denominator);
        Self {
            sign,
            numerator: numerator / &divisor,
            denominator: denominator / divisor,
        }
    }
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct TransferChannelLabel {
    pub from: usize,
    pub to: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RetainedTransferChannelComparison {
    pub source_state: usize,
    pub source_allocation: Vec<u32>,
    pub label: TransferChannelLabel,
    pub reverse_label: TransferChannelLabel,
    pub successor_state: usize,
    pub successor_allocation: Vec<u32>,
    pub isolated_probability: ExactRatio,
    pub joined_probability: ExactRatio,
    pub isolated_numerator_times_joined_denominator: BigUint,
    pub joined_numerator_times_isolated_denominator: BigUint,
    pub joined_minus_isolated: SignedExactRatio,
    pub unchanged: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WeakContactComparison {
    pub horizon: usize,
    pub state_count: usize,
    pub retained_channel_count: usize,
    pub unchanged_channel_count: usize,
    pub changed_channel_count: usize,
    pub channels: Vec<RetainedTransferChannelComparison>,
}

impl WeakContactComparison {
    pub fn all_retained_channels_unchanged(&self) -> bool {
        self.changed_channel_count == 0
    }
}

pub fn compare_qh_weak_contact(
    isolated: &ExactKernel,
    joined: &ExactKernel,
) -> Result<WeakContactComparison> {
    if isolated.horizon() != joined.horizon() {
        return Err(AnalysisError::new(
            "weak-contact kernels use different horizons",
        ));
    }
    if isolated.shell().states() != joined.shell().states() {
        return Err(AnalysisError::new(
            "weak-contact kernels use different exact state universes",
        ));
    }
    if !isolated
        .shell()
        .fixture()
        .edges()
        .iter()
        .all(|edge| joined.shell().fixture().edges().contains(edge))
    {
        return Err(AnalysisError::new(
            "joined support does not retain every isolated edge",
        ));
    }

    let horizon = isolated.horizon();
    let mut channels = Vec::new();
    for source_state in 0..isolated.shell().state_count() {
        let isolated_candidates = isolated.candidate_weights(source_state)?;
        let joined_candidates = joined.candidate_weights(source_state)?;
        for isolated_candidate in isolated_candidates {
            let Action::Transfer { from, to } = isolated_candidate.action else {
                continue;
            };
            let label = TransferChannelLabel { from, to };
            let reverse_label = TransferChannelLabel { from: to, to: from };
            validate_reverse_channel(
                isolated,
                isolated_candidate.successor,
                &reverse_label,
                source_state,
                "isolated",
            )?;

            let joined_candidate =
                unique_candidate(&joined_candidates, &label, source_state, "joined")?;
            if joined_candidate.successor != isolated_candidate.successor {
                return Err(AnalysisError::new(format!(
                    "joined channel {}->{} at state {source_state} changed successor",
                    label.from, label.to
                )));
            }
            validate_reverse_channel(
                joined,
                joined_candidate.successor,
                &reverse_label,
                source_state,
                "joined",
            )?;

            let isolated_probability = ExactRatio::new(
                isolated_candidate.weight,
                isolated.path_count(horizon, source_state)?.clone(),
            )?;
            let joined_probability = ExactRatio::new(
                joined_candidate.weight.clone(),
                joined.path_count(horizon, source_state)?.clone(),
            )?;
            let isolated_cross =
                isolated_probability.numerator() * joined_probability.denominator();
            let joined_cross = joined_probability.numerator() * isolated_probability.denominator();
            let joined_minus_isolated =
                SignedExactRatio::difference(&joined_probability, &isolated_probability);
            let unchanged = isolated_cross == joined_cross;
            if unchanged != joined_minus_isolated.is_zero() {
                return Err(AnalysisError::new(
                    "exact weak-contact difference disagrees with its cross products",
                ));
            }

            channels.push(RetainedTransferChannelComparison {
                source_state,
                source_allocation: isolated.shell().state(source_state)?.to_vec(),
                label,
                reverse_label,
                successor_state: isolated_candidate.successor,
                successor_allocation: isolated
                    .shell()
                    .state(isolated_candidate.successor)?
                    .to_vec(),
                isolated_probability,
                joined_probability,
                isolated_numerator_times_joined_denominator: isolated_cross,
                joined_numerator_times_isolated_denominator: joined_cross,
                joined_minus_isolated,
                unchanged,
            });
        }
    }

    let retained_channel_count = channels.len();
    let unchanged_channel_count = channels.iter().filter(|channel| channel.unchanged).count();
    let changed_channel_count = retained_channel_count - unchanged_channel_count;
    Ok(WeakContactComparison {
        horizon,
        state_count: isolated.shell().state_count(),
        retained_channel_count,
        unchanged_channel_count,
        changed_channel_count,
        channels,
    })
}

fn unique_candidate<'a>(
    candidates: &'a [crate::CandidateWeight],
    label: &TransferChannelLabel,
    state: usize,
    side: &str,
) -> Result<&'a crate::CandidateWeight> {
    let mut matching = candidates.iter().filter(|candidate| {
        candidate.action
            == (Action::Transfer {
                from: label.from,
                to: label.to,
            })
    });
    let candidate = matching.next().ok_or_else(|| {
        AnalysisError::new(format!(
            "{side} kernel lacks retained channel {}->{} at state {state}",
            label.from, label.to
        ))
    })?;
    if matching.next().is_some() {
        return Err(AnalysisError::new(format!(
            "{side} kernel duplicates channel {}->{} at state {state}",
            label.from, label.to
        )));
    }
    Ok(candidate)
}

fn validate_reverse_channel(
    kernel: &ExactKernel,
    successor: usize,
    reverse_label: &TransferChannelLabel,
    expected_successor: usize,
    side: &str,
) -> Result<()> {
    let candidates = kernel.candidate_weights(successor)?;
    let reverse = unique_candidate(&candidates, reverse_label, successor, side)?;
    if reverse.successor != expected_successor {
        return Err(AnalysisError::new(format!(
            "{side} reverse channel {}->{} at state {successor} does not return to state {expected_successor}",
            reverse_label.from, reverse_label.to
        )));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Fixture, StateShell};

    fn contact_kernels(horizon: usize) -> (ExactKernel, ExactKernel) {
        let isolated =
            Fixture::new_disconnected_support(4, [(0, 1), (2, 3)], 2).expect("isolated fixture");
        let joined = Fixture::new(4, [(0, 1), (1, 2), (2, 3)], 2).expect("joined fixture");
        (
            ExactKernel::build(
                StateShell::enumerate(isolated).expect("isolated shell"),
                horizon,
            )
            .expect("isolated kernel"),
            ExactKernel::build(
                StateShell::enumerate(joined).expect("joined shell"),
                horizon,
            )
            .expect("joined kernel"),
        )
    }

    fn witness<'a>(
        report: &'a WeakContactComparison,
        allocation: &[u32],
        from: usize,
        to: usize,
    ) -> &'a RetainedTransferChannelComparison {
        report
            .channels
            .iter()
            .find(|channel| {
                channel.source_allocation == allocation
                    && channel.label == (TransferChannelLabel { from, to })
            })
            .expect("witness channel")
    }

    fn assert_ratio(ratio: &ExactRatio, numerator: u32, denominator: u32) {
        assert_eq!(ratio.numerator(), &BigUint::from(numerator));
        assert_eq!(ratio.denominator(), &BigUint::from(denominator));
    }

    #[test]
    fn frozen_bridge_fixture_changes_the_exact_predicted_channel_counts() {
        for (horizon, expected_changed) in [(1, 12), (2, 16), (5, 16)] {
            let (isolated, joined) = contact_kernels(horizon);
            let report = compare_qh_weak_contact(&isolated, &joined).expect("comparison");
            assert_eq!(report.state_count, 10);
            assert_eq!(report.retained_channel_count, 16);
            assert_eq!(report.changed_channel_count, expected_changed);
            assert_eq!(report.unchanged_channel_count, 16_usize - expected_changed);
            assert!(!report.all_retained_channels_unchanged());
        }
    }

    #[test]
    fn frozen_bridge_fixture_reproduces_all_three_exact_witnesses() {
        let expected: [(usize, u32, u32, ExactDifferenceSign, u32, u32); 3] = [
            (1, 1, 4, ExactDifferenceSign::Negative, 4, 3),
            (2, 5, 16, ExactDifferenceSign::Negative, 16, 15),
            (5, 281, 835, ExactDifferenceSign::Positive, 835, 843),
        ];
        for (horizon, joined_numerator, joined_denominator, sign, isolated_cross, joined_cross) in
            expected
        {
            let (isolated, joined) = contact_kernels(horizon);
            let report = compare_qh_weak_contact(&isolated, &joined).expect("comparison");
            let channel = witness(&report, &[1, 0, 1, 0], 0, 1);
            assert_ratio(&channel.isolated_probability, 1, 3);
            assert_ratio(
                &channel.joined_probability,
                joined_numerator,
                joined_denominator,
            );
            assert_eq!(channel.joined_minus_isolated.sign, sign);
            assert_eq!(
                channel.isolated_numerator_times_joined_denominator,
                BigUint::from(isolated_cross)
            );
            assert_eq!(
                channel.joined_numerator_times_isolated_denominator,
                BigUint::from(joined_cross)
            );
            assert!(!channel.unchanged);
        }
    }

    #[test]
    fn comparison_rejects_different_clocks_or_lost_internal_support() {
        let (isolated_h1, joined_h1) = contact_kernels(1);
        let (_, joined_h2) = contact_kernels(2);
        assert!(compare_qh_weak_contact(&isolated_h1, &joined_h2).is_err());

        let lost_edge = Fixture::new_disconnected_support(4, [(0, 1)], 2).expect("fixture");
        let lost_edge = ExactKernel::build(StateShell::enumerate(lost_edge).expect("shell"), 1)
            .expect("kernel");
        assert!(compare_qh_weak_contact(&isolated_h1, &lost_edge).is_err());
        assert!(compare_qh_weak_contact(&isolated_h1, &joined_h1).is_ok());
    }
}
