use crate::{AnalysisError, Result};
use std::collections::{BTreeMap, VecDeque};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Fixture {
    node_count: usize,
    edges: Vec<(usize, usize)>,
    inventory: u32,
    connectivity: ConnectivityRequirement,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ConnectivityRequirement {
    Connected,
    DisconnectedAllowed,
}

impl Fixture {
    pub fn new(
        node_count: usize,
        edges: impl IntoIterator<Item = (usize, usize)>,
        inventory: u32,
    ) -> Result<Self> {
        Self::construct(
            node_count,
            edges,
            inventory,
            ConnectivityRequirement::Connected,
        )
    }

    pub fn new_disconnected_support(
        node_count: usize,
        edges: impl IntoIterator<Item = (usize, usize)>,
        inventory: u32,
    ) -> Result<Self> {
        Self::construct(
            node_count,
            edges,
            inventory,
            ConnectivityRequirement::DisconnectedAllowed,
        )
    }

    fn construct(
        node_count: usize,
        edges: impl IntoIterator<Item = (usize, usize)>,
        inventory: u32,
        connectivity: ConnectivityRequirement,
    ) -> Result<Self> {
        if node_count == 0 {
            return Err(AnalysisError::new("fixture must contain at least one node"));
        }
        if inventory == 0 {
            return Err(AnalysisError::new("fixture inventory must be positive"));
        }

        let mut canonical_edges = Vec::new();
        for (left, right) in edges {
            if left >= node_count || right >= node_count {
                return Err(AnalysisError::new("fixture edge endpoint is out of range"));
            }
            if left == right {
                return Err(AnalysisError::new("fixture graph must be simple"));
            }
            canonical_edges.push(if left < right {
                (left, right)
            } else {
                (right, left)
            });
        }
        canonical_edges.sort_unstable();
        if canonical_edges.windows(2).any(|pair| pair[0] == pair[1]) {
            return Err(AnalysisError::new("fixture graph contains a parallel edge"));
        }

        if connectivity == ConnectivityRequirement::Connected && node_count > 1 {
            let mut neighbors = vec![Vec::new(); node_count];
            for &(left, right) in &canonical_edges {
                neighbors[left].push(right);
                neighbors[right].push(left);
            }
            let mut visited = vec![false; node_count];
            let mut queue = VecDeque::from([0]);
            visited[0] = true;
            while let Some(node) = queue.pop_front() {
                for &neighbor in &neighbors[node] {
                    if !visited[neighbor] {
                        visited[neighbor] = true;
                        queue.push_back(neighbor);
                    }
                }
            }
            if visited.iter().any(|seen| !seen) {
                return Err(AnalysisError::new("fixture graph must be connected"));
            }
        }

        Ok(Self {
            node_count,
            edges: canonical_edges,
            inventory,
            connectivity,
        })
    }

    pub fn node_count(&self) -> usize {
        self.node_count
    }

    pub fn edges(&self) -> &[(usize, usize)] {
        &self.edges
    }

    pub fn inventory(&self) -> u32 {
        self.inventory
    }

    /// Relabels nodes with `old_node -> new_node`.
    pub fn permuted(&self, node_permutation: &[usize]) -> Result<Self> {
        validate_node_permutation(self.node_count, node_permutation)?;
        Self::construct(
            self.node_count,
            self.edges
                .iter()
                .map(|&(left, right)| (node_permutation[left], node_permutation[right])),
            self.inventory,
            self.connectivity,
        )
    }

    pub fn permute_state(&self, state: &[u32], node_permutation: &[usize]) -> Result<Vec<u32>> {
        validate_node_permutation(self.node_count, node_permutation)?;
        if state.len() != self.node_count
            || state.iter().copied().map(u64::from).sum::<u64>() != u64::from(self.inventory)
        {
            return Err(AnalysisError::new(
                "state does not belong to the fixture allocation shell",
            ));
        }
        let mut permuted = vec![0; self.node_count];
        for (old_node, &balance) in state.iter().enumerate() {
            permuted[node_permutation[old_node]] = balance;
        }
        Ok(permuted)
    }

    pub(crate) fn neighbors(&self) -> Vec<Vec<usize>> {
        let mut neighbors = vec![Vec::new(); self.node_count];
        for &(left, right) in &self.edges {
            neighbors[left].push(right);
            neighbors[right].push(left);
        }
        for row in &mut neighbors {
            row.sort_unstable();
        }
        neighbors
    }
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum Action {
    Wait,
    Transfer { from: usize, to: usize },
}

impl Action {
    pub fn permuted(&self, node_permutation: &[usize]) -> Result<Self> {
        validate_node_permutation(node_permutation.len(), node_permutation)?;
        match self {
            Self::Wait => Ok(Self::Wait),
            Self::Transfer { from, to } => {
                let mapped_from = node_permutation
                    .get(*from)
                    .copied()
                    .ok_or_else(|| AnalysisError::new("action source is outside permutation"))?;
                let mapped_to = node_permutation
                    .get(*to)
                    .copied()
                    .ok_or_else(|| AnalysisError::new("action target is outside permutation"))?;
                Ok(Self::Transfer {
                    from: mapped_from,
                    to: mapped_to,
                })
            }
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ActionStep {
    pub action: Action,
    pub successor: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StateShell {
    fixture: Fixture,
    states: Vec<Vec<u32>>,
    actions: Vec<Vec<ActionStep>>,
    adjacency: Vec<Vec<u32>>,
}

impl StateShell {
    pub fn enumerate(fixture: Fixture) -> Result<Self> {
        let mut states = Vec::new();
        let mut prefix = Vec::with_capacity(fixture.node_count);
        enumerate_weak_compositions(
            fixture.inventory,
            fixture.node_count,
            &mut prefix,
            &mut states,
        );

        let state_indices: BTreeMap<Vec<u32>, usize> = states
            .iter()
            .cloned()
            .enumerate()
            .map(|(index, state)| (state, index))
            .collect();
        let neighbors = fixture.neighbors();
        let state_count = states.len();
        let mut actions = Vec::with_capacity(state_count);
        let mut adjacency = vec![vec![0_u32; state_count]; state_count];

        for (state_index, state) in states.iter().enumerate() {
            let mut row = vec![ActionStep {
                action: Action::Wait,
                successor: state_index,
            }];
            for from in 0..fixture.node_count {
                if state[from] == 0 {
                    continue;
                }
                for &to in &neighbors[from] {
                    let mut successor = state.clone();
                    successor[from] -= 1;
                    successor[to] += 1;
                    let successor_index =
                        state_indices.get(&successor).copied().ok_or_else(|| {
                            AnalysisError::new("legal transfer left the allocation shell")
                        })?;
                    row.push(ActionStep {
                        action: Action::Transfer { from, to },
                        successor: successor_index,
                    });
                }
            }
            row.sort_by(|left, right| left.action.cmp(&right.action));
            for step in &row {
                adjacency[state_index][step.successor] = adjacency[state_index][step.successor]
                    .checked_add(1)
                    .ok_or_else(|| AnalysisError::new("action multiplicity overflow"))?;
            }
            actions.push(row);
        }

        Ok(Self {
            fixture,
            states,
            actions,
            adjacency,
        })
    }

    pub fn fixture(&self) -> &Fixture {
        &self.fixture
    }

    pub fn states(&self) -> &[Vec<u32>] {
        &self.states
    }

    pub fn state(&self, index: usize) -> Result<&[u32]> {
        self.states
            .get(index)
            .map(Vec::as_slice)
            .ok_or_else(|| AnalysisError::new("state index is out of range"))
    }

    pub fn state_index(&self, state: &[u32]) -> Option<usize> {
        self.states
            .binary_search_by(|candidate| candidate.as_slice().cmp(state))
            .ok()
    }

    pub fn actions(&self, state: usize) -> Result<&[ActionStep]> {
        self.actions
            .get(state)
            .map(Vec::as_slice)
            .ok_or_else(|| AnalysisError::new("state index is out of range"))
    }

    pub fn adjacency(&self) -> &[Vec<u32>] {
        &self.adjacency
    }

    pub fn state_count(&self) -> usize {
        self.states.len()
    }
}

fn enumerate_weak_compositions(
    remaining: u32,
    slots: usize,
    prefix: &mut Vec<u32>,
    out: &mut Vec<Vec<u32>>,
) {
    if slots == 1 {
        prefix.push(remaining);
        out.push(prefix.clone());
        prefix.pop();
        return;
    }
    for value in 0..=remaining {
        prefix.push(value);
        enumerate_weak_compositions(remaining - value, slots - 1, prefix, out);
        prefix.pop();
    }
}

fn validate_node_permutation(node_count: usize, node_permutation: &[usize]) -> Result<()> {
    if node_permutation.len() != node_count {
        return Err(AnalysisError::new("node permutation has the wrong length"));
    }
    let mut seen = vec![false; node_count];
    for &mapped in node_permutation {
        if mapped >= node_count || seen[mapped] {
            return Err(AnalysisError::new("node permutation is not a bijection"));
        }
        seen[mapped] = true;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn disconnected_support_requires_the_explicit_constructor() {
        assert!(Fixture::new(4, [(0, 1), (2, 3)], 2).is_err());

        let fixture = Fixture::new_disconnected_support(4, [(0, 1), (2, 3)], 2).expect("fixture");
        assert_eq!(fixture.edges(), &[(0, 1), (2, 3)]);
        assert_eq!(fixture.inventory(), 2);
    }

    #[test]
    fn permutation_preserves_disconnected_support_admission() {
        let fixture = Fixture::new_disconnected_support(4, [(0, 1), (2, 3)], 2).expect("fixture");
        let permuted = fixture.permuted(&[2, 3, 0, 1]).expect("permuted fixture");

        assert_eq!(permuted.edges(), &[(0, 1), (2, 3)]);
        assert_eq!(
            permuted.connectivity,
            ConnectivityRequirement::DisconnectedAllowed
        );
        assert!(permuted.permuted(&[2, 3, 0, 1]).is_ok());
    }
}
