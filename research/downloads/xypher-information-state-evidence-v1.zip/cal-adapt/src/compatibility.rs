use crate::{Action, AnalysisError, ExactKernel, ExactRatio, Result};
use num_bigint::BigUint;
use num_traits::Zero;
use std::cmp::Ordering;
use std::collections::{BTreeMap, VecDeque};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CoordinateOrigin {
    Predeclared,
    IndependentCalibration,
    FittedFromStationaryWeights,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StateResolution {
    ExactLabeledState,
    StronglyLumpableMacrostate,
    ConditionallyAveragedMacrostate,
    UnqualifiedMacrostate,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BetaSign {
    Negative,
    Zero,
    Positive,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactSlopeWitness {
    pub component_index: usize,
    pub lower_state: usize,
    pub upper_state: usize,
    pub energy_gap: u64,
    pub upper_over_lower_reduced_weight: ExactRatio,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum BetaStatus {
    Incompatible,
    Unidentified,
    Identified {
        sign: BetaSign,
        witness: ExactSlopeWitness,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CompatibilityFailure {
    EqualEnergyMismatch {
        component_index: usize,
        reference_state: usize,
        state: usize,
        reference_reduced_weight: ExactRatio,
        state_reduced_weight: ExactRatio,
    },
    ComponentSlopeMismatch {
        component_index: usize,
        lower_anchor: usize,
        upper_anchor: usize,
        state: usize,
        left_power: ExactRatio,
        right_power: ExactRatio,
    },
    SharedSlopeMismatch {
        reference_component: usize,
        component_index: usize,
        left_power: ExactRatio,
        right_power: ExactRatio,
    },
    FixedBoltzmannMismatch {
        component_index: usize,
        anchor_state: usize,
        state: usize,
        observed_ratio: ExactRatio,
        expected_ratio: ExactRatio,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExistsBetaCompatibilityReport {
    pub status: BetaStatus,
    pub reduced_weights: Vec<ExactRatio>,
    pub component_slopes: Vec<ExactSlopeWitness>,
    pub failures: Vec<CompatibilityFailure>,
}

impl ExistsBetaCompatibilityReport {
    pub fn compatible(&self) -> bool {
        !matches!(self.status, BetaStatus::Incompatible)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FixedBetaCompatibilityReport {
    pub compatible: bool,
    pub beta_sign: BetaSign,
    pub informative_energy_gap: bool,
    pub boltzmann_factor: ExactRatio,
    pub reduced_weights: Vec<ExactRatio>,
    pub failures: Vec<CompatibilityFailure>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactQhChannelWitness {
    pub source: usize,
    pub action: Action,
    pub successor: usize,
    pub reverse_action: Action,
    pub forward_base_weight: BigUint,
    pub reverse_base_weight: BigUint,
    pub forward_probability: ExactRatio,
    pub reverse_probability: ExactRatio,
    pub observed_ratio: ExactRatio,
    pub theorem_ratio: ExactRatio,
    pub fixed_boltzmann_ratio: ExactRatio,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum QhChannelCompatibilityFailure {
    MissingReverseInstance {
        source: usize,
        action: Action,
        successor: usize,
        reverse_action: Action,
    },
    AmbiguousReverseInstance {
        source: usize,
        action: Action,
        successor: usize,
        reverse_action: Action,
        matching_instances: usize,
    },
    ReverseSuccessorMismatch {
        source: usize,
        action: Action,
        successor: usize,
        reverse_action: Action,
        reverse_successor: usize,
    },
    UnequalReverseBaseWeight {
        source: usize,
        action: Action,
        successor: usize,
        reverse_action: Action,
        forward_base_weight: BigUint,
        reverse_base_weight: BigUint,
    },
    TheoremRatioMismatch {
        source: usize,
        action: Action,
        successor: usize,
        observed_ratio: ExactRatio,
        theorem_ratio: ExactRatio,
    },
    FixedBoltzmannRatioMismatch {
        source: usize,
        action: Action,
        successor: usize,
        observed_ratio: ExactRatio,
        expected_ratio: ExactRatio,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct QhChannelCompatibilityReport {
    pub channel_instance_count: usize,
    pub resolved_reverse_instance_count: usize,
    pub theorem_compatible: bool,
    pub fixed_beta_compatible: bool,
    pub boltzmann_factor: ExactRatio,
    pub witnesses: Vec<ExactQhChannelWitness>,
    pub failures: Vec<QhChannelCompatibilityFailure>,
}

impl QhChannelCompatibilityReport {
    pub fn compatible(&self) -> bool {
        self.theorem_compatible && self.fixed_beta_compatible
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StationaryCompatibilityProfile {
    stationary_weights: Vec<BigUint>,
    energy_quanta: Vec<i64>,
    degeneracies: Vec<ExactRatio>,
    connected_components: Vec<Vec<usize>>,
    coordinate_origin: CoordinateOrigin,
    state_resolution: StateResolution,
}

impl StationaryCompatibilityProfile {
    pub fn from_exact_kernel(
        kernel: &ExactKernel,
        energy_quanta: Vec<i64>,
        degeneracies: Vec<ExactRatio>,
        coordinate_origin: CoordinateOrigin,
        state_resolution: StateResolution,
    ) -> Result<Self> {
        Self::new(
            kernel.stationary_weights().to_vec(),
            energy_quanta,
            degeneracies,
            support_components(kernel.shell().adjacency()),
            coordinate_origin,
            state_resolution,
        )
    }

    pub fn new(
        stationary_weights: Vec<BigUint>,
        energy_quanta: Vec<i64>,
        degeneracies: Vec<ExactRatio>,
        mut connected_components: Vec<Vec<usize>>,
        coordinate_origin: CoordinateOrigin,
        state_resolution: StateResolution,
    ) -> Result<Self> {
        let state_count = stationary_weights.len();
        if state_count == 0 {
            return Err(AnalysisError::new(
                "compatibility profile must contain at least one state",
            ));
        }
        if energy_quanta.len() != state_count || degeneracies.len() != state_count {
            return Err(AnalysisError::new(
                "compatibility profile vectors have different lengths",
            ));
        }
        if stationary_weights.iter().any(BigUint::is_zero) {
            return Err(AnalysisError::new(
                "compatibility profile stationary weights must be positive",
            ));
        }
        if degeneracies
            .iter()
            .any(|degeneracy| degeneracy.numerator().is_zero())
        {
            return Err(AnalysisError::new(
                "compatibility profile degeneracies must be positive",
            ));
        }
        if coordinate_origin == CoordinateOrigin::FittedFromStationaryWeights {
            return Err(AnalysisError::new(
                "compatibility coordinates were fitted from stationary weights",
            ));
        }
        if state_resolution == StateResolution::UnqualifiedMacrostate {
            return Err(AnalysisError::new(
                "coarse compatibility profile lacks a declared qualification",
            ));
        }
        canonicalize_component_partition(&mut connected_components, state_count)?;

        Ok(Self {
            stationary_weights,
            energy_quanta,
            degeneracies,
            connected_components,
            coordinate_origin,
            state_resolution,
        })
    }

    pub fn stationary_weights(&self) -> &[BigUint] {
        &self.stationary_weights
    }

    pub fn energy_quanta(&self) -> &[i64] {
        &self.energy_quanta
    }

    pub fn degeneracies(&self) -> &[ExactRatio] {
        &self.degeneracies
    }

    pub fn connected_components(&self) -> &[Vec<usize>] {
        &self.connected_components
    }

    pub fn coordinate_origin(&self) -> CoordinateOrigin {
        self.coordinate_origin
    }

    pub fn state_resolution(&self) -> StateResolution {
        self.state_resolution
    }

    pub fn require_coordinate_origin(&self, expected: CoordinateOrigin) -> Result<()> {
        if self.coordinate_origin != expected {
            return Err(AnalysisError::new(
                "compatibility profile coordinate origin differs from the frozen contract",
            ));
        }
        Ok(())
    }

    pub fn require_state_resolution(&self, expected: StateResolution) -> Result<()> {
        if self.state_resolution != expected {
            return Err(AnalysisError::new(
                "compatibility profile state resolution differs from the frozen contract",
            ));
        }
        Ok(())
    }
}

pub fn check_exists_beta_compatibility(
    profile: &StationaryCompatibilityProfile,
) -> Result<ExistsBetaCompatibilityReport> {
    let reduced_weights = reduced_weights(profile)?;
    let mut failures = Vec::new();
    let mut component_slopes = Vec::new();

    for (component_index, component) in profile.connected_components.iter().enumerate() {
        let mut energy_references = BTreeMap::<i64, usize>::new();
        for &state in component {
            let energy = profile.energy_quanta[state];
            if let Some(&reference_state) = energy_references.get(&energy) {
                if reduced_weights[state] != reduced_weights[reference_state] {
                    failures.push(CompatibilityFailure::EqualEnergyMismatch {
                        component_index,
                        reference_state,
                        state,
                        reference_reduced_weight: reduced_weights[reference_state].clone(),
                        state_reduced_weight: reduced_weights[state].clone(),
                    });
                }
            } else {
                energy_references.insert(energy, state);
            }
        }

        let Some((&lower_energy, &lower_state)) = energy_references.first_key_value() else {
            return Err(AnalysisError::new(
                "compatibility component unexpectedly contains no states",
            ));
        };
        let (&upper_energy, &upper_state) = energy_references
            .last_key_value()
            .expect("nonempty compatibility component has a final energy");
        if lower_energy == upper_energy {
            continue;
        }

        let energy_gap = lower_energy.abs_diff(upper_energy);
        let anchor_ratio =
            checked_divide(&reduced_weights[upper_state], &reduced_weights[lower_state])?;
        for &state in component {
            let state_gap = lower_energy.abs_diff(profile.energy_quanta[state]);
            let state_ratio =
                checked_divide(&reduced_weights[state], &reduced_weights[lower_state])?;
            let left_power = checked_pow(&state_ratio, energy_gap)?;
            let right_power = checked_pow(&anchor_ratio, state_gap)?;
            if left_power != right_power {
                failures.push(CompatibilityFailure::ComponentSlopeMismatch {
                    component_index,
                    lower_anchor: lower_state,
                    upper_anchor: upper_state,
                    state,
                    left_power,
                    right_power,
                });
            }
        }
        component_slopes.push(ExactSlopeWitness {
            component_index,
            lower_state,
            upper_state,
            energy_gap,
            upper_over_lower_reduced_weight: anchor_ratio,
        });
    }

    if let Some(reference) = component_slopes.first() {
        for slope in component_slopes.iter().skip(1) {
            let left_power =
                checked_pow(&reference.upper_over_lower_reduced_weight, slope.energy_gap)?;
            let right_power =
                checked_pow(&slope.upper_over_lower_reduced_weight, reference.energy_gap)?;
            if left_power != right_power {
                failures.push(CompatibilityFailure::SharedSlopeMismatch {
                    reference_component: reference.component_index,
                    component_index: slope.component_index,
                    left_power,
                    right_power,
                });
            }
        }
    }

    let status = if !failures.is_empty() {
        BetaStatus::Incompatible
    } else if let Some(witness) = component_slopes.first().cloned() {
        BetaStatus::Identified {
            sign: beta_sign(&witness.upper_over_lower_reduced_weight),
            witness,
        }
    } else {
        BetaStatus::Unidentified
    };

    Ok(ExistsBetaCompatibilityReport {
        status,
        reduced_weights,
        component_slopes,
        failures,
    })
}

pub fn check_fixed_beta_compatibility(
    profile: &StationaryCompatibilityProfile,
    boltzmann_factor: &ExactRatio,
) -> Result<FixedBetaCompatibilityReport> {
    if boltzmann_factor.numerator().is_zero() {
        return Err(AnalysisError::new(
            "fixed Boltzmann factor must be positive",
        ));
    }
    let reduced_weights = reduced_weights(profile)?;
    let mut failures = Vec::new();
    let mut informative_energy_gap = false;

    for (component_index, component) in profile.connected_components.iter().enumerate() {
        let (anchor_state, anchor_energy) = component
            .iter()
            .map(|&state| (state, profile.energy_quanta[state]))
            .min_by_key(|&(state, energy)| (energy, state))
            .expect("validated compatibility component is nonempty");
        for &state in component {
            let energy_gap = anchor_energy.abs_diff(profile.energy_quanta[state]);
            informative_energy_gap |= energy_gap > 0;
            let observed_ratio =
                checked_divide(&reduced_weights[state], &reduced_weights[anchor_state])?;
            let expected_ratio = checked_pow(boltzmann_factor, energy_gap)?;
            if observed_ratio != expected_ratio {
                failures.push(CompatibilityFailure::FixedBoltzmannMismatch {
                    component_index,
                    anchor_state,
                    state,
                    observed_ratio,
                    expected_ratio,
                });
            }
        }
    }

    Ok(FixedBetaCompatibilityReport {
        compatible: failures.is_empty(),
        beta_sign: beta_sign(boltzmann_factor),
        informative_energy_gap,
        boltzmann_factor: boltzmann_factor.clone(),
        reduced_weights,
        failures,
    })
}

pub fn check_qh_channel_compatibility(
    kernel: &ExactKernel,
    profile: &StationaryCompatibilityProfile,
    boltzmann_factor: &ExactRatio,
) -> Result<QhChannelCompatibilityReport> {
    if boltzmann_factor.numerator().is_zero() {
        return Err(AnalysisError::new(
            "fixed Boltzmann factor must be positive",
        ));
    }
    if profile.stationary_weights != kernel.stationary_weights() {
        return Err(AnalysisError::new(
            "compatibility profile stationary weights do not belong to the exact kernel",
        ));
    }
    if profile.connected_components != support_components(kernel.shell().adjacency()) {
        return Err(AnalysisError::new(
            "compatibility profile components do not match the exact kernel support",
        ));
    }
    profile.require_state_resolution(StateResolution::ExactLabeledState)?;

    let channels = exact_qh_channel_instances(kernel)?;
    check_qh_channel_instances(
        &channels,
        profile,
        kernel.stationary_weights(),
        boltzmann_factor,
    )
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct ExactQhChannelInstance {
    source: usize,
    action: Action,
    successor: usize,
    base_weight: BigUint,
    probability: ExactRatio,
}

fn exact_qh_channel_instances(kernel: &ExactKernel) -> Result<Vec<ExactQhChannelInstance>> {
    let mut channels = Vec::new();
    for source in 0..kernel.shell().state_count() {
        let denominator = kernel.path_count(kernel.horizon(), source)?.clone();
        for step in kernel.shell().actions(source)? {
            channels.push(ExactQhChannelInstance {
                source,
                action: step.action.clone(),
                successor: step.successor,
                base_weight: BigUint::from(1_u8),
                probability: ExactRatio::new(
                    kernel
                        .path_count(kernel.horizon() - 1, step.successor)?
                        .clone(),
                    denominator.clone(),
                )?,
            });
        }
    }
    Ok(channels)
}

fn check_qh_channel_instances(
    channels: &[ExactQhChannelInstance],
    profile: &StationaryCompatibilityProfile,
    stationary_weights: &[BigUint],
    boltzmann_factor: &ExactRatio,
) -> Result<QhChannelCompatibilityReport> {
    let mut witnesses = Vec::new();
    let mut failures = Vec::new();
    let mut resolved_reverse_instance_count = 0;

    for channel in channels {
        let reverse_action = reverse_action(&channel.action);
        let reverse_matches: Vec<_> = channels
            .iter()
            .filter(|candidate| {
                candidate.source == channel.successor && candidate.action == reverse_action
            })
            .collect();
        let reverse = match reverse_matches.as_slice() {
            [] => {
                failures.push(QhChannelCompatibilityFailure::MissingReverseInstance {
                    source: channel.source,
                    action: channel.action.clone(),
                    successor: channel.successor,
                    reverse_action,
                });
                continue;
            }
            [reverse] => *reverse,
            matches => {
                failures.push(QhChannelCompatibilityFailure::AmbiguousReverseInstance {
                    source: channel.source,
                    action: channel.action.clone(),
                    successor: channel.successor,
                    reverse_action,
                    matching_instances: matches.len(),
                });
                continue;
            }
        };
        resolved_reverse_instance_count += 1;

        if reverse.successor != channel.source {
            failures.push(QhChannelCompatibilityFailure::ReverseSuccessorMismatch {
                source: channel.source,
                action: channel.action.clone(),
                successor: channel.successor,
                reverse_action,
                reverse_successor: reverse.successor,
            });
            continue;
        }
        if channel.base_weight != reverse.base_weight {
            failures.push(QhChannelCompatibilityFailure::UnequalReverseBaseWeight {
                source: channel.source,
                action: channel.action.clone(),
                successor: channel.successor,
                reverse_action: reverse_action.clone(),
                forward_base_weight: channel.base_weight.clone(),
                reverse_base_weight: reverse.base_weight.clone(),
            });
        }

        let observed_ratio = checked_divide(&channel.probability, &reverse.probability)?;
        let theorem_ratio = ExactRatio::new(
            stationary_weights[channel.successor].clone(),
            stationary_weights[channel.source].clone(),
        )?;
        if observed_ratio != theorem_ratio {
            failures.push(QhChannelCompatibilityFailure::TheoremRatioMismatch {
                source: channel.source,
                action: channel.action.clone(),
                successor: channel.successor,
                observed_ratio: observed_ratio.clone(),
                theorem_ratio: theorem_ratio.clone(),
            });
        }

        let degeneracy_ratio = checked_divide(
            &profile.degeneracies[channel.successor],
            &profile.degeneracies[channel.source],
        )?;
        let energy_factor = checked_signed_pow(
            boltzmann_factor,
            profile.energy_quanta[channel.successor],
            profile.energy_quanta[channel.source],
        )?;
        let fixed_boltzmann_ratio = degeneracy_ratio.checked_multiply(&energy_factor)?;
        if observed_ratio != fixed_boltzmann_ratio {
            failures.push(QhChannelCompatibilityFailure::FixedBoltzmannRatioMismatch {
                source: channel.source,
                action: channel.action.clone(),
                successor: channel.successor,
                observed_ratio: observed_ratio.clone(),
                expected_ratio: fixed_boltzmann_ratio.clone(),
            });
        }

        witnesses.push(ExactQhChannelWitness {
            source: channel.source,
            action: channel.action.clone(),
            successor: channel.successor,
            reverse_action,
            forward_base_weight: channel.base_weight.clone(),
            reverse_base_weight: reverse.base_weight.clone(),
            forward_probability: channel.probability.clone(),
            reverse_probability: reverse.probability.clone(),
            observed_ratio,
            theorem_ratio,
            fixed_boltzmann_ratio,
        });
    }

    let theorem_compatible = !failures.iter().any(|failure| {
        matches!(
            failure,
            QhChannelCompatibilityFailure::MissingReverseInstance { .. }
                | QhChannelCompatibilityFailure::AmbiguousReverseInstance { .. }
                | QhChannelCompatibilityFailure::ReverseSuccessorMismatch { .. }
                | QhChannelCompatibilityFailure::UnequalReverseBaseWeight { .. }
                | QhChannelCompatibilityFailure::TheoremRatioMismatch { .. }
        )
    });
    let fixed_beta_compatible = theorem_compatible
        && !failures.iter().any(|failure| {
            matches!(
                failure,
                QhChannelCompatibilityFailure::FixedBoltzmannRatioMismatch { .. }
            )
        });

    Ok(QhChannelCompatibilityReport {
        channel_instance_count: channels.len(),
        resolved_reverse_instance_count,
        theorem_compatible,
        fixed_beta_compatible,
        boltzmann_factor: boltzmann_factor.clone(),
        witnesses,
        failures,
    })
}

fn reverse_action(action: &Action) -> Action {
    match action {
        Action::Wait => Action::Wait,
        Action::Transfer { from, to } => Action::Transfer {
            from: *to,
            to: *from,
        },
    }
}

fn canonicalize_component_partition(
    components: &mut [Vec<usize>],
    state_count: usize,
) -> Result<()> {
    if components.is_empty() || components.iter().any(Vec::is_empty) {
        return Err(AnalysisError::new(
            "connected-component partition contains no components or an empty component",
        ));
    }
    for component in components.iter_mut() {
        component.sort_unstable();
        if component.windows(2).any(|pair| pair[0] == pair[1]) {
            return Err(AnalysisError::new(
                "connected-component partition repeats a state",
            ));
        }
    }
    components.sort_by_key(|component| component[0]);

    let mut seen = vec![false; state_count];
    for component in components.iter() {
        for &state in component {
            let Some(slot) = seen.get_mut(state) else {
                return Err(AnalysisError::new(
                    "connected-component partition contains an out-of-range state",
                ));
            };
            if *slot {
                return Err(AnalysisError::new(
                    "connected-component partition assigns a state more than once",
                ));
            }
            *slot = true;
        }
    }
    if seen.iter().any(|covered| !covered) {
        return Err(AnalysisError::new(
            "connected-component partition does not cover every state",
        ));
    }
    Ok(())
}

fn support_components(adjacency: &[Vec<u32>]) -> Vec<Vec<usize>> {
    let mut components = Vec::new();
    let mut seen = vec![false; adjacency.len()];
    for root in 0..adjacency.len() {
        if seen[root] {
            continue;
        }
        let mut component = Vec::new();
        let mut queue = VecDeque::from([root]);
        seen[root] = true;
        while let Some(source) = queue.pop_front() {
            component.push(source);
            for target in 0..adjacency.len() {
                if !seen[target] && (adjacency[source][target] > 0 || adjacency[target][source] > 0)
                {
                    seen[target] = true;
                    queue.push_back(target);
                }
            }
        }
        component.sort_unstable();
        components.push(component);
    }
    components
}

fn reduced_weights(profile: &StationaryCompatibilityProfile) -> Result<Vec<ExactRatio>> {
    profile
        .stationary_weights
        .iter()
        .zip(&profile.degeneracies)
        .map(|(weight, degeneracy)| {
            ExactRatio::new(
                weight * degeneracy.denominator(),
                degeneracy.numerator().clone(),
            )
        })
        .collect()
}

fn checked_divide(numerator: &ExactRatio, denominator: &ExactRatio) -> Result<ExactRatio> {
    if denominator.numerator().is_zero() {
        return Err(AnalysisError::new("cannot divide by a zero exact ratio"));
    }
    ExactRatio::new(
        numerator.numerator() * denominator.denominator(),
        numerator.denominator() * denominator.numerator(),
    )
}

fn checked_pow(base: &ExactRatio, mut exponent: u64) -> Result<ExactRatio> {
    let mut result = ExactRatio::one();
    let mut factor = base.clone();
    while exponent > 0 {
        if exponent & 1 == 1 {
            result = result.checked_multiply(&factor)?;
        }
        exponent >>= 1;
        if exponent > 0 {
            factor = factor.checked_multiply(&factor)?;
        }
    }
    Ok(result)
}

fn checked_signed_pow(base: &ExactRatio, exponent: i64, origin: i64) -> Result<ExactRatio> {
    let magnitude = exponent.abs_diff(origin);
    let power = checked_pow(base, magnitude)?;
    if exponent >= origin {
        Ok(power)
    } else {
        checked_divide(&ExactRatio::one(), &power)
    }
}

fn beta_sign(boltzmann_factor: &ExactRatio) -> BetaSign {
    match boltzmann_factor
        .numerator()
        .cmp(boltzmann_factor.denominator())
    {
        Ordering::Less => BetaSign::Positive,
        Ordering::Equal => BetaSign::Zero,
        Ordering::Greater => BetaSign::Negative,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use num_traits::One;

    fn ratio(numerator: u64, denominator: u64) -> ExactRatio {
        ExactRatio::new(BigUint::from(numerator), BigUint::from(denominator))
            .expect("positive literal ratio")
    }

    fn profile(
        stationary_weights: &[u64],
        energy_quanta: &[i64],
        degeneracies: &[(u64, u64)],
        components: &[&[usize]],
    ) -> StationaryCompatibilityProfile {
        StationaryCompatibilityProfile::new(
            stationary_weights
                .iter()
                .copied()
                .map(BigUint::from)
                .collect(),
            energy_quanta.to_vec(),
            degeneracies
                .iter()
                .map(|&(numerator, denominator)| ratio(numerator, denominator))
                .collect(),
            components
                .iter()
                .map(|component| component.to_vec())
                .collect(),
            CoordinateOrigin::Predeclared,
            StateResolution::ExactLabeledState,
        )
        .expect("valid literal compatibility profile")
    }

    fn triangle_kernel(inventory: u32, horizon: usize) -> ExactKernel {
        let fixture =
            crate::Fixture::new(3, [(0, 1), (0, 2), (1, 2)], inventory).expect("triangle fixture");
        ExactKernel::build(
            crate::StateShell::enumerate(fixture).expect("triangle shell"),
            horizon,
        )
        .expect("triangle kernel")
    }

    #[test]
    fn frozen_fixed_beta_literal_passes_exactly() {
        let profile = profile(
            &[2, 3, 1],
            &[0, 1, 2],
            &[(1, 1), (3, 1), (2, 1)],
            &[&[0, 1, 2]],
        );

        let structural = check_exists_beta_compatibility(&profile).expect("structural report");
        assert!(structural.compatible());
        assert!(matches!(
            structural.status,
            BetaStatus::Identified {
                sign: BetaSign::Positive,
                ..
            }
        ));

        let fixed =
            check_fixed_beta_compatibility(&profile, &ratio(1, 2)).expect("fixed-beta report");
        assert!(fixed.compatible);
        assert!(fixed.informative_energy_gap);
        assert_eq!(fixed.beta_sign, BetaSign::Positive);
    }

    #[test]
    fn frozen_triangle_kernel_converts_to_an_exact_rejection_profile() {
        let kernel = triangle_kernel(3, 2);
        let x = kernel
            .shell()
            .state_index(&[3, 0, 0])
            .expect("named state x");
        let y = kernel
            .shell()
            .state_index(&[2, 1, 0])
            .expect("named state y");
        let profile = StationaryCompatibilityProfile::from_exact_kernel(
            &kernel,
            vec![0; kernel.shell().state_count()],
            vec![ExactRatio::one(); kernel.shell().state_count()],
            CoordinateOrigin::Predeclared,
            StateResolution::ExactLabeledState,
        )
        .expect("triangle compatibility profile");

        let report = check_exists_beta_compatibility(&profile).expect("triangle report");
        assert!(!report.compatible());
        assert_eq!(report.reduced_weights[x], ratio(39, 1));
        assert_eq!(report.reduced_weights[y], ratio(125, 1));

        let channels = check_qh_channel_compatibility(&kernel, &profile, &ExactRatio::one())
            .expect("triangle channel report");
        assert!(channels.theorem_compatible);
        assert!(!channels.fixed_beta_compatible);
        assert!(!channels.compatible());
        let witness = channels
            .witnesses
            .iter()
            .find(|witness| {
                witness.source == x
                    && witness.action == Action::Transfer { from: 0, to: 1 }
                    && witness.successor == y
            })
            .expect("frozen x-to-y channel witness");
        assert_eq!(witness.forward_probability, ratio(5, 13));
        assert_eq!(witness.reverse_probability, ratio(3, 25));
        assert_eq!(witness.observed_ratio, ratio(125, 39));
        assert_eq!(witness.theorem_ratio, ratio(125, 39));
        assert_eq!(witness.fixed_boltzmann_ratio, ExactRatio::one());
    }

    #[test]
    fn regular_triangle_channels_pass_theorem_and_fixed_beta_exactly() {
        let kernel = triangle_kernel(1, 2);
        let profile = StationaryCompatibilityProfile::from_exact_kernel(
            &kernel,
            vec![0; kernel.shell().state_count()],
            vec![ExactRatio::one(); kernel.shell().state_count()],
            CoordinateOrigin::Predeclared,
            StateResolution::ExactLabeledState,
        )
        .expect("regular triangle profile");

        let report = check_qh_channel_compatibility(&kernel, &profile, &ratio(1, 7))
            .expect("regular triangle channel report");
        assert!(report.compatible());
        assert_eq!(report.channel_instance_count, 9);
        assert_eq!(report.resolved_reverse_instance_count, 9);
        assert_eq!(report.witnesses.len(), 9);
        assert!(report.failures.is_empty());
    }

    #[test]
    fn channel_checker_exercises_exact_reciprocal_energy_powers() {
        let kernel = triangle_kernel(1, 2);
        let profile = StationaryCompatibilityProfile::from_exact_kernel(
            &kernel,
            vec![0, 1, 2],
            vec![ratio(1, 1), ratio(2, 1), ratio(4, 1)],
            CoordinateOrigin::Predeclared,
            StateResolution::ExactLabeledState,
        )
        .expect("energy-graded regular triangle profile");

        let report = check_qh_channel_compatibility(&kernel, &profile, &ratio(1, 2))
            .expect("reciprocal-power channel report");
        assert!(report.compatible());
        assert!(report.witnesses.iter().any(|witness| {
            profile.energy_quanta()[witness.successor] < profile.energy_quanta()[witness.source]
                && witness.fixed_boltzmann_ratio == ExactRatio::one()
        }));
    }

    #[test]
    fn channel_checker_rejects_a_missing_reverse_instance() {
        let kernel = triangle_kernel(1, 2);
        let profile = StationaryCompatibilityProfile::from_exact_kernel(
            &kernel,
            vec![0; kernel.shell().state_count()],
            vec![ExactRatio::one(); kernel.shell().state_count()],
            CoordinateOrigin::Predeclared,
            StateResolution::ExactLabeledState,
        )
        .expect("regular triangle profile");
        let source = kernel
            .shell()
            .state_index(&[0, 1, 0])
            .expect("reverse source");
        let mut channels = exact_qh_channel_instances(&kernel).expect("exact channels");
        channels.retain(|channel| {
            !(channel.source == source && channel.action == Action::Transfer { from: 1, to: 0 })
        });

        let report = check_qh_channel_instances(
            &channels,
            &profile,
            kernel.stationary_weights(),
            &ExactRatio::one(),
        )
        .expect("missing-reverse report");
        assert!(!report.theorem_compatible);
        assert!(report.failures.iter().any(|failure| matches!(
            failure,
            QhChannelCompatibilityFailure::MissingReverseInstance { .. }
        )));
    }

    #[test]
    fn channel_checker_rejects_unequal_reverse_base_weights() {
        let kernel = triangle_kernel(1, 2);
        let profile = StationaryCompatibilityProfile::from_exact_kernel(
            &kernel,
            vec![0; kernel.shell().state_count()],
            vec![ExactRatio::one(); kernel.shell().state_count()],
            CoordinateOrigin::Predeclared,
            StateResolution::ExactLabeledState,
        )
        .expect("regular triangle profile");
        let source = kernel
            .shell()
            .state_index(&[0, 1, 0])
            .expect("reverse source");
        let mut channels = exact_qh_channel_instances(&kernel).expect("exact channels");
        channels
            .iter_mut()
            .find(|channel| {
                channel.source == source && channel.action == Action::Transfer { from: 1, to: 0 }
            })
            .expect("reverse channel")
            .base_weight = BigUint::from(2_u8);

        let report = check_qh_channel_instances(
            &channels,
            &profile,
            kernel.stationary_weights(),
            &ExactRatio::one(),
        )
        .expect("unequal-reverse report");
        assert!(!report.theorem_compatible);
        assert!(report.failures.iter().any(|failure| matches!(
            failure,
            QhChannelCompatibilityFailure::UnequalReverseBaseWeight { .. }
        )));
    }

    #[test]
    fn frozen_constant_energy_degeneracy_literal_leaves_beta_unidentified() {
        let profile = profile(
            &[2, 4, 6],
            &[0, 0, 0],
            &[(1, 1), (2, 1), (3, 1)],
            &[&[0, 1, 2]],
        );

        let report = check_exists_beta_compatibility(&profile).expect("structural report");
        assert!(report.compatible());
        assert_eq!(report.status, BetaStatus::Unidentified);

        let fixed =
            check_fixed_beta_compatibility(&profile, &ratio(1, 2)).expect("fixed-beta report");
        assert!(fixed.compatible);
        assert!(!fixed.informative_energy_gap);
    }

    #[test]
    fn frozen_equal_energy_literal_is_rejected() {
        let profile = profile(&[1, 2], &[0, 0], &[(1, 1), (1, 1)], &[&[0, 1]]);

        let report = check_exists_beta_compatibility(&profile).expect("structural report");
        assert!(!report.compatible());
        assert_eq!(report.status, BetaStatus::Incompatible);
        assert!(matches!(
            report.failures.as_slice(),
            [CompatibilityFailure::EqualEnergyMismatch { .. }]
        ));
    }

    #[test]
    fn frozen_inconsistent_slope_literal_is_rejected() {
        let profile = profile(
            &[4, 2, 2],
            &[0, 1, 2],
            &[(1, 1), (1, 1), (1, 1)],
            &[&[0, 1, 2]],
        );

        let report = check_exists_beta_compatibility(&profile).expect("structural report");
        assert!(!report.compatible());
        assert!(report
            .failures
            .iter()
            .any(|failure| matches!(failure, CompatibilityFailure::ComponentSlopeMismatch { .. })));
        assert!(
            !check_fixed_beta_compatibility(&profile, &ratio(1, 2))
                .expect("fixed-beta report")
                .compatible
        );
    }

    #[test]
    fn shared_slope_is_compared_across_disconnected_components() {
        let compatible = profile(
            &[4, 2, 8, 2],
            &[0, 1, 0, 2],
            &[(1, 1); 4],
            &[&[0, 1], &[2, 3]],
        );
        assert!(check_exists_beta_compatibility(&compatible)
            .expect("shared-slope report")
            .compatible());

        let incompatible = profile(
            &[4, 2, 8, 4],
            &[0, 1, 0, 2],
            &[(1, 1); 4],
            &[&[0, 1], &[2, 3]],
        );
        let report = check_exists_beta_compatibility(&incompatible).expect("shared-slope report");
        assert!(!report.compatible());
        assert!(report
            .failures
            .iter()
            .any(|failure| matches!(failure, CompatibilityFailure::SharedSlopeMismatch { .. })));
    }

    #[test]
    fn beta_sign_is_exact_for_zero_and_negative_beta() {
        let zero = profile(&[3, 3], &[0, 1], &[(1, 1); 2], &[&[0, 1]]);
        assert!(matches!(
            check_exists_beta_compatibility(&zero)
                .expect("zero-beta report")
                .status,
            BetaStatus::Identified {
                sign: BetaSign::Zero,
                ..
            }
        ));

        let negative = profile(&[1, 2], &[0, 1], &[(1, 1); 2], &[&[0, 1]]);
        assert!(matches!(
            check_exists_beta_compatibility(&negative)
                .expect("negative-beta report")
                .status,
            BetaStatus::Identified {
                sign: BetaSign::Negative,
                ..
            }
        ));
    }

    #[test]
    fn profile_validation_rejects_nonindependent_or_unqualified_coordinates() {
        let fitted = StationaryCompatibilityProfile::new(
            vec![BigUint::one()],
            vec![0],
            vec![ExactRatio::one()],
            vec![vec![0]],
            CoordinateOrigin::FittedFromStationaryWeights,
            StateResolution::ExactLabeledState,
        );
        assert!(fitted.is_err());

        let coarse = StationaryCompatibilityProfile::new(
            vec![BigUint::one()],
            vec![0],
            vec![ExactRatio::one()],
            vec![vec![0]],
            CoordinateOrigin::Predeclared,
            StateResolution::UnqualifiedMacrostate,
        );
        assert!(coarse.is_err());
    }

    #[test]
    fn profile_validation_rejects_zero_values_and_invalid_partitions() {
        assert!(StationaryCompatibilityProfile::new(
            vec![BigUint::zero()],
            vec![0],
            vec![ExactRatio::one()],
            vec![vec![0]],
            CoordinateOrigin::Predeclared,
            StateResolution::ExactLabeledState,
        )
        .is_err());
        assert!(StationaryCompatibilityProfile::new(
            vec![BigUint::one()],
            vec![0],
            vec![ExactRatio::zero()],
            vec![vec![0]],
            CoordinateOrigin::Predeclared,
            StateResolution::ExactLabeledState,
        )
        .is_err());
        assert!(StationaryCompatibilityProfile::new(
            vec![BigUint::one(), BigUint::one()],
            vec![0, 0],
            vec![ExactRatio::one(), ExactRatio::one()],
            vec![vec![0]],
            CoordinateOrigin::Predeclared,
            StateResolution::ExactLabeledState,
        )
        .is_err());
    }

    #[test]
    fn frozen_metadata_contract_can_require_exact_predeclared_coordinates() {
        let profile = StationaryCompatibilityProfile::new(
            vec![BigUint::one()],
            vec![0],
            vec![ExactRatio::one()],
            vec![vec![0]],
            CoordinateOrigin::IndependentCalibration,
            StateResolution::StronglyLumpableMacrostate,
        )
        .expect("qualified profile");

        assert!(profile
            .require_coordinate_origin(CoordinateOrigin::Predeclared)
            .is_err());
        assert!(profile
            .require_state_resolution(StateResolution::ExactLabeledState)
            .is_err());
    }
}
