use crate::adaptive_contact::{
    apparent_reciprocity_fixture, lumpable_hidden_state_fixture, BalanceFiber, GateVerdict,
    LumpabilityWitness,
};
use crate::zero_range_contact::{
    edge_clock_spec, linear_departure, normalized_node_clock_spec, occupied_site_departure,
    ZeroRangeGenerator,
};
use crate::{AnalysisError, ExactRatio, Result};
use num_bigint::BigUint;
use num_traits::Zero;

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum NativeDepartureLaw {
    PerUnit,
    OccupiedSite,
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum NativeGraphClock {
    RawEdge,
    NormalizedNode,
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum GraphFixtureKind {
    UnitPath,
    WeightedPath,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EmbeddedClockEquivalenceReport {
    pub raw_kernel: Vec<Vec<ExactRatio>>,
    pub normalized_kernel: Vec<Vec<ExactRatio>>,
    pub raw_exit_rates: Vec<ExactRatio>,
    pub normalized_exit_rates: Vec<ExactRatio>,
    pub kernels_equal: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LoadEquivalenceCase {
    pub graph: GraphFixtureKind,
    pub clock: NativeGraphClock,
    pub per_unit_kernel: Vec<Vec<ExactRatio>>,
    pub occupied_site_kernel: Vec<Vec<ExactRatio>>,
    pub kernels_equal: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceOddsCase {
    pub departure: NativeDepartureLaw,
    pub clock: NativeGraphClock,
    pub plus: ExactRatio,
    pub minus: ExactRatio,
    pub quotient: ExactRatio,
    pub product: ExactRatio,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ClockGaugeReport {
    pub base_kernel: Vec<Vec<ExactRatio>>,
    pub transformed_kernel: Vec<Vec<ExactRatio>>,
    pub base_exit_rates: Vec<ExactRatio>,
    pub transformed_exit_rates: Vec<ExactRatio>,
    pub multiplied_state: usize,
    pub kernels_equal: bool,
    pub changed_exit_states: Vec<usize>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ThinningFactorization {
    pub opportunity_intensity: ExactRatio,
    pub retention_probability: ExactRatio,
    pub accepted_intensity: ExactRatio,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ThinningGaugeReport {
    pub direct: ThinningFactorization,
    pub thinned: ThinningFactorization,
    pub accepted_intensities_equal: bool,
    pub homogeneous_poisson_laws_equal: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TetradWitness {
    pub first_row: usize,
    pub second_row: usize,
    pub first_column: usize,
    pub second_column: usize,
    pub diagonal_product: ExactRatio,
    pub off_diagonal_product: ExactRatio,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TetradReport {
    pub row_count: usize,
    pub column_count: usize,
    pub rectangle_count: usize,
    pub balanced: bool,
    pub first_imbalance: Option<TetradWitness>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BundleAdditivityWitness {
    pub left_bundle: usize,
    pub right_bundle: usize,
    pub combined_hazard: BigUint,
    pub separate_hazard: BigUint,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BundleAdditivityReport {
    pub maximum_occupancy: usize,
    pub identity_count: usize,
    pub additive: bool,
    pub first_failure: Option<BundleAdditivityWitness>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContactClockReport {
    pub raw_retained_ratio: ExactRatio,
    pub raw_control_ratio: ExactRatio,
    pub raw_ratio_in_ratios: ExactRatio,
    pub normalized_retained_ratio: ExactRatio,
    pub normalized_control_ratio: ExactRatio,
    pub normalized_ratio_in_ratios: ExactRatio,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ExactCycleAffinity {
    Zero,
    LogRatio(ExactRatio),
    MissingReverse,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CycleAffinityReport {
    pub global_reverse_support: bool,
    pub global_missing_reverse_channels: Vec<(usize, usize)>,
    pub selected_cycle_reverse_support: bool,
    pub selected_unsupported_edges: Vec<(usize, usize)>,
    pub cycle_ratio: Option<ExactRatio>,
    pub affinity: ExactCycleAffinity,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HiddenStateClockReport {
    pub lumpable_control: GateVerdict,
    pub apparent_reciprocity: GateVerdict,
    pub apparent_reciprocity_witness: Option<LumpabilityWitness>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrozenNativeClockReport {
    pub k1_graph_clock: EmbeddedClockEquivalenceReport,
    pub k2_load_laws: Vec<LoadEquivalenceCase>,
    pub k3_source_odds: Vec<SourceOddsCase>,
    pub state_clock_gauge: ClockGaugeReport,
    pub thinning_gauge: ThinningGaugeReport,
    pub separable_tetrads: TetradReport,
    pub nonseparable_tetrads: TetradReport,
    pub additive_bundle: BundleAdditivityReport,
    pub occupied_site_bundle: BundleAdditivityReport,
    pub graph_contact: ContactClockReport,
    pub symmetric_cycle: CycleAffinityReport,
    pub biased_cycle: CycleAffinityReport,
    pub missing_reverse_cycle: CycleAffinityReport,
    pub hidden_state: HiddenStateClockReport,
}

impl FrozenNativeClockReport {
    pub fn all_preregistered_predictions_match(&self) -> bool {
        self.fixture_a_matches()
            && self.fixture_b_matches()
            && self.fixture_c_matches()
            && self.fixture_d_matches()
            && self.fixture_e_matches()
            && self.fixture_f_matches()
    }

    fn fixture_a_matches(&self) -> bool {
        let expected_kernel = vec![
            vec![ratio(0, 1), ratio(1, 1), ratio(0, 1)],
            vec![ratio(1, 2), ratio(0, 1), ratio(1, 2)],
            vec![ratio(0, 1), ratio(1, 1), ratio(0, 1)],
        ];
        self.k1_graph_clock
            == EmbeddedClockEquivalenceReport {
                raw_kernel: expected_kernel.clone(),
                normalized_kernel: expected_kernel,
                raw_exit_rates: vec![ratio(1, 1), ratio(2, 1), ratio(1, 1)],
                normalized_exit_rates: vec![ratio(1, 1), ratio(1, 1), ratio(1, 1)],
                kernels_equal: true,
            }
    }

    fn fixture_b_matches(&self) -> bool {
        let expected_cases = [
            (GraphFixtureKind::UnitPath, NativeGraphClock::RawEdge),
            (GraphFixtureKind::UnitPath, NativeGraphClock::NormalizedNode),
            (GraphFixtureKind::WeightedPath, NativeGraphClock::RawEdge),
            (
                GraphFixtureKind::WeightedPath,
                NativeGraphClock::NormalizedNode,
            ),
        ];
        if self.k2_load_laws.len() != expected_cases.len() {
            return false;
        }
        for (graph, clock) in expected_cases {
            let mut matching = self
                .k2_load_laws
                .iter()
                .filter(|case| case.graph == graph && case.clock == clock);
            let Some(case) = matching.next() else {
                return false;
            };
            if matching.next().is_some() || !load_case_matches_frozen_kernel(case) {
                return false;
            }
        }
        true
    }

    fn fixture_c_matches(&self) -> bool {
        let expected_cases = [
            (
                NativeDepartureLaw::PerUnit,
                NativeGraphClock::RawEdge,
                ratio(1, 1),
                ratio(1, 4),
                ratio(4, 1),
                ratio(1, 4),
            ),
            (
                NativeDepartureLaw::OccupiedSite,
                NativeGraphClock::RawEdge,
                ratio(1, 2),
                ratio(1, 2),
                ratio(1, 1),
                ratio(1, 4),
            ),
            (
                NativeDepartureLaw::PerUnit,
                NativeGraphClock::NormalizedNode,
                ratio(2, 1),
                ratio(1, 2),
                ratio(4, 1),
                ratio(1, 1),
            ),
            (
                NativeDepartureLaw::OccupiedSite,
                NativeGraphClock::NormalizedNode,
                ratio(1, 1),
                ratio(1, 1),
                ratio(1, 1),
                ratio(1, 1),
            ),
        ];
        if self.k3_source_odds.len() != expected_cases.len() {
            return false;
        }
        for (departure, clock, plus, minus, quotient, product) in expected_cases {
            let mut matching = self
                .k3_source_odds
                .iter()
                .filter(|case| case.departure == departure && case.clock == clock);
            let Some(case) = matching.next() else {
                return false;
            };
            if matching.next().is_some()
                || case.plus != plus
                || case.minus != minus
                || case.quotient != quotient
                || case.product != product
            {
                return false;
            }
        }
        true
    }

    fn fixture_d_matches(&self) -> bool {
        let Ok(expected_gauge) = frozen_state_clock_gauge() else {
            return false;
        };
        self.state_clock_gauge == expected_gauge
            && self.thinning_gauge
                == ThinningGaugeReport {
                    direct: ThinningFactorization {
                        opportunity_intensity: ratio(1, 1),
                        retention_probability: ratio(1, 1),
                        accepted_intensity: ratio(1, 1),
                    },
                    thinned: ThinningFactorization {
                        opportunity_intensity: ratio(2, 1),
                        retention_probability: ratio(1, 2),
                        accepted_intensity: ratio(1, 1),
                    },
                    accepted_intensities_equal: true,
                    homogeneous_poisson_laws_equal: true,
                }
    }

    fn fixture_e_matches(&self) -> bool {
        self.separable_tetrads
            == TetradReport {
                row_count: 2,
                column_count: 2,
                rectangle_count: 1,
                balanced: true,
                first_imbalance: None,
            }
            && self.nonseparable_tetrads
                == TetradReport {
                    row_count: 2,
                    column_count: 2,
                    rectangle_count: 1,
                    balanced: false,
                    first_imbalance: Some(TetradWitness {
                        first_row: 0,
                        second_row: 1,
                        first_column: 0,
                        second_column: 1,
                        diagonal_product: ratio(3, 1),
                        off_diagonal_product: ratio(2, 1),
                    }),
                }
            && self.additive_bundle
                == BundleAdditivityReport {
                    maximum_occupancy: 3,
                    identity_count: 10,
                    additive: true,
                    first_failure: None,
                }
            && self.occupied_site_bundle
                == BundleAdditivityReport {
                    maximum_occupancy: 3,
                    identity_count: 10,
                    additive: false,
                    first_failure: Some(BundleAdditivityWitness {
                        left_bundle: 1,
                        right_bundle: 1,
                        combined_hazard: BigUint::from(1_u8),
                        separate_hazard: BigUint::from(2_u8),
                    }),
                }
            && self.graph_contact
                == ContactClockReport {
                    raw_retained_ratio: ratio(1, 1),
                    raw_control_ratio: ratio(1, 1),
                    raw_ratio_in_ratios: ratio(1, 1),
                    normalized_retained_ratio: ratio(1, 2),
                    normalized_control_ratio: ratio(1, 1),
                    normalized_ratio_in_ratios: ratio(1, 2),
                }
    }

    fn fixture_f_matches(&self) -> bool {
        self.symmetric_cycle
            == CycleAffinityReport {
                global_reverse_support: true,
                global_missing_reverse_channels: Vec::new(),
                selected_cycle_reverse_support: true,
                selected_unsupported_edges: Vec::new(),
                cycle_ratio: Some(ratio(1, 1)),
                affinity: ExactCycleAffinity::Zero,
            }
            && self.biased_cycle
                == CycleAffinityReport {
                    global_reverse_support: true,
                    global_missing_reverse_channels: Vec::new(),
                    selected_cycle_reverse_support: true,
                    selected_unsupported_edges: Vec::new(),
                    cycle_ratio: Some(ratio(8, 1)),
                    affinity: ExactCycleAffinity::LogRatio(ratio(8, 1)),
                }
            && self.missing_reverse_cycle
                == CycleAffinityReport {
                    global_reverse_support: false,
                    global_missing_reverse_channels: vec![(0, 1)],
                    selected_cycle_reverse_support: false,
                    selected_unsupported_edges: vec![(0, 1)],
                    cycle_ratio: None,
                    affinity: ExactCycleAffinity::MissingReverse,
                }
            && self.hidden_state
                == HiddenStateClockReport {
                    lumpable_control: GateVerdict::Passed,
                    apparent_reciprocity: GateVerdict::Failed,
                    apparent_reciprocity_witness: Some(LumpabilityWitness {
                        left_state: "A0".to_string(),
                        right_state: "A1".to_string(),
                        destination: BalanceFiber::B,
                        left_probability: ratio(1, 1),
                        right_probability: ratio(0, 1),
                    }),
                }
    }
}

fn load_case_matches_frozen_kernel(case: &LoadEquivalenceCase) -> bool {
    let adjacency = match case.graph {
        GraphFixtureKind::UnitPath => adjacency(&[&[0, 1, 0], &[1, 0, 1], &[0, 1, 0]]),
        GraphFixtureKind::WeightedPath => adjacency(&[&[0, 2, 0], &[2, 0, 1], &[0, 1, 0]]),
    };
    let Ok(per_unit) = generator(
        2,
        adjacency.clone(),
        NativeDepartureLaw::PerUnit,
        case.clock,
    ) else {
        return false;
    };
    let Ok(occupied_site) = generator(2, adjacency, NativeDepartureLaw::OccupiedSite, case.clock)
    else {
        return false;
    };
    let Ok(per_unit_kernel) = per_unit.embedded_jump_kernel() else {
        return false;
    };
    let Ok(occupied_site_kernel) = occupied_site.embedded_jump_kernel() else {
        return false;
    };
    case.kernels_equal
        && case.kernels_equal == (case.per_unit_kernel == case.occupied_site_kernel)
        && case.per_unit_kernel == per_unit_kernel
        && case.occupied_site_kernel == occupied_site_kernel
}

pub fn verify_exact_rate_tetrads(table: &[Vec<ExactRatio>]) -> Result<TetradReport> {
    if table.len() < 2 {
        return Err(AnalysisError::new(
            "native-clock tetrad table requires at least two rows",
        ));
    }
    let column_count = table[0].len();
    if column_count < 2 || table.iter().any(|row| row.len() != column_count) {
        return Err(AnalysisError::new(
            "native-clock tetrad table must be rectangular with at least two columns",
        ));
    }
    if table
        .iter()
        .flat_map(|row| row.iter())
        .any(|value| value.numerator().is_zero())
    {
        return Err(AnalysisError::new(
            "native-clock tetrad table requires positive rates",
        ));
    }

    let mut rectangle_count = 0;
    let mut first_imbalance = None;
    for first_row in 0..table.len() {
        for second_row in first_row + 1..table.len() {
            for first_column in 0..column_count {
                for second_column in first_column + 1..column_count {
                    rectangle_count += 1;
                    let diagonal_product = table[first_row][first_column]
                        .checked_multiply(&table[second_row][second_column])?;
                    let off_diagonal_product = table[first_row][second_column]
                        .checked_multiply(&table[second_row][first_column])?;
                    if diagonal_product != off_diagonal_product && first_imbalance.is_none() {
                        first_imbalance = Some(TetradWitness {
                            first_row,
                            second_row,
                            first_column,
                            second_column,
                            diagonal_product,
                            off_diagonal_product,
                        });
                    }
                }
            }
        }
    }
    Ok(TetradReport {
        row_count: table.len(),
        column_count,
        rectangle_count,
        balanced: first_imbalance.is_none(),
        first_imbalance,
    })
}

pub fn verify_bundle_additivity(departure: &[BigUint]) -> Result<BundleAdditivityReport> {
    if departure.len() < 3 || !departure[0].is_zero() {
        return Err(AnalysisError::new(
            "native-clock bundle law must cover zero through at least two and have u(0)=0",
        ));
    }
    let maximum_occupancy = departure.len() - 1;
    let mut identity_count = 0;
    let mut first_failure = None;
    for left_bundle in 0..=maximum_occupancy {
        for right_bundle in 0..=maximum_occupancy - left_bundle {
            identity_count += 1;
            let combined_hazard = departure[left_bundle + right_bundle].clone();
            let separate_hazard = &departure[left_bundle] + &departure[right_bundle];
            if combined_hazard != separate_hazard && first_failure.is_none() {
                first_failure = Some(BundleAdditivityWitness {
                    left_bundle,
                    right_bundle,
                    combined_hazard,
                    separate_hazard,
                });
            }
        }
    }
    Ok(BundleAdditivityReport {
        maximum_occupancy,
        identity_count,
        additive: first_failure.is_none(),
        first_failure,
    })
}

pub fn verify_cycle_affinity(
    rates: &[Vec<ExactRatio>],
    cycle: &[usize],
) -> Result<CycleAffinityReport> {
    if rates.len() < 2
        || rates.iter().any(|row| row.len() != rates.len())
        || cycle.len() < 2
        || cycle.iter().any(|&state| state >= rates.len())
    {
        return Err(AnalysisError::new(
            "native-clock affinity requires a square rate matrix and a valid cycle",
        ));
    }
    let mut global_missing_reverse_channels = Vec::new();
    for (source, row) in rates.iter().enumerate() {
        if !row[source].numerator().is_zero() {
            return Err(AnalysisError::new(
                "native-clock affinity rate matrix must have a zero diagonal",
            ));
        }
        for (target, rate) in row.iter().enumerate() {
            if source != target
                && !rate.numerator().is_zero()
                && rates[target][source].numerator().is_zero()
            {
                global_missing_reverse_channels.push((source, target));
            }
        }
    }

    let mut selected_unsupported_edges = Vec::new();
    for position in 0..cycle.len() {
        let source = cycle[position];
        let target = cycle[(position + 1) % cycle.len()];
        if rates[source][target].numerator().is_zero()
            || rates[target][source].numerator().is_zero()
        {
            selected_unsupported_edges.push((source, target));
        }
    }

    let selected_cycle_reverse_support = selected_unsupported_edges.is_empty();
    let cycle_ratio = if !selected_cycle_reverse_support {
        None
    } else {
        let mut forward = ExactRatio::one();
        let mut reverse = ExactRatio::one();
        for position in 0..cycle.len() {
            let source = cycle[position];
            let target = cycle[(position + 1) % cycle.len()];
            forward = forward.checked_multiply(&rates[source][target])?;
            reverse = reverse.checked_multiply(&rates[target][source])?;
        }
        Some(divide_ratios(&forward, &reverse)?)
    };
    let affinity = if !selected_cycle_reverse_support {
        ExactCycleAffinity::MissingReverse
    } else if cycle_ratio.as_ref() == Some(&ExactRatio::one()) {
        ExactCycleAffinity::Zero
    } else {
        ExactCycleAffinity::LogRatio(cycle_ratio.clone().expect("positive cycle ratio"))
    };
    Ok(CycleAffinityReport {
        global_reverse_support: global_missing_reverse_channels.is_empty(),
        global_missing_reverse_channels,
        selected_cycle_reverse_support,
        selected_unsupported_edges,
        cycle_ratio,
        affinity,
    })
}

pub fn frozen_native_clock_report() -> Result<FrozenNativeClockReport> {
    let unit_path = adjacency(&[&[0, 1, 0], &[1, 0, 1], &[0, 1, 0]]);
    let weighted_path = adjacency(&[&[0, 2, 0], &[2, 0, 1], &[0, 1, 0]]);
    let triangle = adjacency(&[&[0, 1, 1], &[1, 0, 1], &[1, 1, 0]]);

    let raw_k1 = generator(
        1,
        unit_path.clone(),
        NativeDepartureLaw::PerUnit,
        NativeGraphClock::RawEdge,
    )?;
    let normalized_k1 = generator(
        1,
        unit_path.clone(),
        NativeDepartureLaw::PerUnit,
        NativeGraphClock::NormalizedNode,
    )?;
    let raw_kernel = raw_k1.embedded_jump_kernel()?;
    let normalized_kernel = normalized_k1.embedded_jump_kernel()?;
    let k1_graph_clock = EmbeddedClockEquivalenceReport {
        kernels_equal: raw_kernel == normalized_kernel,
        raw_kernel,
        normalized_kernel,
        raw_exit_rates: exit_rates(&raw_k1)?,
        normalized_exit_rates: exit_rates(&normalized_k1)?,
    };

    let mut k2_load_laws = Vec::new();
    for (graph, adjacency) in [
        (GraphFixtureKind::UnitPath, unit_path.clone()),
        (GraphFixtureKind::WeightedPath, weighted_path),
    ] {
        for clock in [NativeGraphClock::RawEdge, NativeGraphClock::NormalizedNode] {
            let per_unit = generator(2, adjacency.clone(), NativeDepartureLaw::PerUnit, clock)?;
            let occupied_site = generator(
                2,
                adjacency.clone(),
                NativeDepartureLaw::OccupiedSite,
                clock,
            )?;
            let per_unit_kernel = per_unit.embedded_jump_kernel()?;
            let occupied_site_kernel = occupied_site.embedded_jump_kernel()?;
            k2_load_laws.push(LoadEquivalenceCase {
                graph,
                clock,
                kernels_equal: per_unit_kernel == occupied_site_kernel,
                per_unit_kernel,
                occupied_site_kernel,
            });
        }
    }

    let plus = [2, 1, 0];
    let minus = [1, 2, 0];
    let mut k3_source_odds = Vec::new();
    for departure in [
        NativeDepartureLaw::PerUnit,
        NativeDepartureLaw::OccupiedSite,
    ] {
        for clock in [NativeGraphClock::RawEdge, NativeGraphClock::NormalizedNode] {
            let candidate = generator(3, unit_path.clone(), departure, clock)?;
            let plus_odds = source_odds(&candidate, &plus, 0, 1)?;
            let minus_odds = source_odds(&candidate, &minus, 0, 1)?;
            k3_source_odds.push(SourceOddsCase {
                departure,
                clock,
                quotient: divide_ratios(&plus_odds, &minus_odds)?,
                product: plus_odds.checked_multiply(&minus_odds)?,
                plus: plus_odds,
                minus: minus_odds,
            });
        }
    }

    let state_clock_gauge = frozen_state_clock_gauge()?;

    let direct = thinning_factorization(ratio(1, 1), ratio(1, 1))?;
    let thinned = thinning_factorization(ratio(2, 1), ratio(1, 2))?;
    let accepted_intensities_equal = direct.accepted_intensity == thinned.accepted_intensity;
    let thinning_gauge = ThinningGaugeReport {
        homogeneous_poisson_laws_equal: accepted_intensities_equal,
        accepted_intensities_equal,
        direct,
        thinned,
    };

    let separable_tetrads = verify_exact_rate_tetrads(&[
        vec![ratio(1, 1), ratio(2, 1)],
        vec![ratio(3, 1), ratio(6, 1)],
    ])?;
    let nonseparable_tetrads = verify_exact_rate_tetrads(&[
        vec![ratio(1, 1), ratio(2, 1)],
        vec![ratio(1, 1), ratio(3, 1)],
    ])?;
    let additive_bundle = verify_bundle_additivity(&linear_departure(3))?;
    let occupied_site_bundle = verify_bundle_additivity(&occupied_site_departure(3))?;

    let raw_before = generator(
        3,
        unit_path.clone(),
        NativeDepartureLaw::PerUnit,
        NativeGraphClock::RawEdge,
    )?;
    let raw_after = generator(
        3,
        triangle.clone(),
        NativeDepartureLaw::PerUnit,
        NativeGraphClock::RawEdge,
    )?;
    let normalized_before = generator(
        3,
        unit_path,
        NativeDepartureLaw::PerUnit,
        NativeGraphClock::NormalizedNode,
    )?;
    let normalized_after = generator(
        3,
        triangle,
        NativeDepartureLaw::PerUnit,
        NativeGraphClock::NormalizedNode,
    )?;
    let allocation = [1, 1, 1];
    let raw_retained_ratio = channel_ratio(&raw_before, &raw_after, &allocation, 0, 1)?;
    let raw_control_ratio = channel_ratio(&raw_before, &raw_after, &allocation, 1, 0)?;
    let normalized_retained_ratio =
        channel_ratio(&normalized_before, &normalized_after, &allocation, 0, 1)?;
    let normalized_control_ratio =
        channel_ratio(&normalized_before, &normalized_after, &allocation, 1, 0)?;
    let graph_contact = ContactClockReport {
        raw_ratio_in_ratios: divide_ratios(&raw_retained_ratio, &raw_control_ratio)?,
        normalized_ratio_in_ratios: divide_ratios(
            &normalized_retained_ratio,
            &normalized_control_ratio,
        )?,
        raw_retained_ratio,
        raw_control_ratio,
        normalized_retained_ratio,
        normalized_control_ratio,
    };

    let symmetric_cycle = verify_cycle_affinity(
        &integer_ratios(&[&[0, 1, 1], &[1, 0, 1], &[1, 1, 0]]),
        &[0, 1, 2],
    )?;
    let biased_cycle = verify_cycle_affinity(
        &integer_ratios(&[&[0, 2, 1], &[1, 0, 2], &[2, 1, 0]]),
        &[0, 1, 2],
    )?;
    let missing_reverse_cycle = verify_cycle_affinity(
        &integer_ratios(&[&[0, 2, 1], &[0, 0, 2], &[2, 1, 0]]),
        &[0, 1, 2],
    )?;

    let lumpable = lumpable_hidden_state_fixture()?.verify()?;
    let apparent = apparent_reciprocity_fixture()?.verify()?;
    let hidden_state = HiddenStateClockReport {
        lumpable_control: lumpable.strong_lumpability,
        apparent_reciprocity: apparent.strong_lumpability,
        apparent_reciprocity_witness: apparent.lumpability_witness,
    };

    Ok(FrozenNativeClockReport {
        k1_graph_clock,
        k2_load_laws,
        k3_source_odds,
        state_clock_gauge,
        thinning_gauge,
        separable_tetrads,
        nonseparable_tetrads,
        additive_bundle,
        occupied_site_bundle,
        graph_contact,
        symmetric_cycle,
        biased_cycle,
        missing_reverse_cycle,
        hidden_state,
    })
}

fn frozen_state_clock_gauge() -> Result<ClockGaugeReport> {
    let gauge_generator = generator(
        3,
        adjacency(&[&[0, 1, 0], &[1, 0, 1], &[0, 1, 0]]),
        NativeDepartureLaw::PerUnit,
        NativeGraphClock::RawEdge,
    )?;
    let multiplied_state = gauge_generator
        .state_index(&[2, 1, 0])
        .ok_or_else(|| AnalysisError::new("native-clock gauge state is absent"))?;
    let mut multipliers = vec![ExactRatio::one(); gauge_generator.states().len()];
    multipliers[multiplied_state] = ratio(2, 1);
    let base_kernel = gauge_generator.embedded_jump_kernel()?;
    let base_exit_rates = exit_rates(&gauge_generator)?;
    let (transformed_kernel, transformed_exit_rates) =
        transformed_jump_law(&gauge_generator, &multipliers)?;
    let changed_exit_states = base_exit_rates
        .iter()
        .zip(&transformed_exit_rates)
        .enumerate()
        .filter_map(|(state, (base, transformed))| (base != transformed).then_some(state))
        .collect();
    Ok(ClockGaugeReport {
        kernels_equal: base_kernel == transformed_kernel,
        base_kernel,
        transformed_kernel,
        base_exit_rates,
        transformed_exit_rates,
        multiplied_state,
        changed_exit_states,
    })
}

fn generator(
    inventory: u32,
    adjacency: Vec<Vec<BigUint>>,
    departure: NativeDepartureLaw,
    clock: NativeGraphClock,
) -> Result<ZeroRangeGenerator> {
    let departure = match departure {
        NativeDepartureLaw::PerUnit => linear_departure(inventory),
        NativeDepartureLaw::OccupiedSite => occupied_site_departure(inventory),
    };
    let spec = match clock {
        NativeGraphClock::RawEdge => edge_clock_spec(inventory, adjacency, departure)?,
        NativeGraphClock::NormalizedNode => {
            normalized_node_clock_spec(inventory, adjacency, departure)?
        }
    };
    ZeroRangeGenerator::from_spec(spec)
}

fn source_odds(
    generator: &ZeroRangeGenerator,
    allocation: &[u32],
    first_source: usize,
    second_source: usize,
) -> Result<ExactRatio> {
    let state = generator
        .state_index(allocation)
        .ok_or_else(|| AnalysisError::new("native-clock odds allocation is absent"))?;
    let first = sum_ratios(
        generator
            .channels()
            .iter()
            .filter(|channel| channel.source == state && channel.from == first_source)
            .map(|channel| channel.rate.clone()),
    )?;
    let second = sum_ratios(
        generator
            .channels()
            .iter()
            .filter(|channel| channel.source == state && channel.from == second_source)
            .map(|channel| channel.rate.clone()),
    )?;
    divide_ratios(&first, &second)
}

fn transformed_jump_law(
    generator: &ZeroRangeGenerator,
    multipliers: &[ExactRatio],
) -> Result<(Vec<Vec<ExactRatio>>, Vec<ExactRatio>)> {
    if multipliers.len() != generator.states().len()
        || multipliers
            .iter()
            .any(|multiplier| multiplier.numerator().is_zero())
    {
        return Err(AnalysisError::new(
            "native-clock state multipliers must be positive and cover every state",
        ));
    }
    let mut rate_matrix = zero_ratio_matrix(generator.states().len());
    for channel in generator.channels() {
        let transformed = channel
            .rate
            .checked_multiply(&multipliers[channel.source])?;
        rate_matrix[channel.source][channel.target] =
            rate_matrix[channel.source][channel.target].checked_add(&transformed)?;
    }
    let exit_rates = rate_matrix
        .iter()
        .map(|row| sum_ratios(row.iter().cloned()))
        .collect::<Result<Vec<_>>>()?;
    let mut kernel = zero_ratio_matrix(generator.states().len());
    for (source, row) in rate_matrix.iter().enumerate() {
        if exit_rates[source].numerator().is_zero() {
            kernel[source][source] = ExactRatio::one();
            continue;
        }
        for (target, rate) in row.iter().enumerate() {
            if !rate.numerator().is_zero() {
                kernel[source][target] = divide_ratios(rate, &exit_rates[source])?;
            }
        }
    }
    Ok((kernel, exit_rates))
}

fn thinning_factorization(
    opportunity_intensity: ExactRatio,
    retention_probability: ExactRatio,
) -> Result<ThinningFactorization> {
    if opportunity_intensity.numerator().is_zero()
        || retention_probability.numerator().is_zero()
        || !ratio_at_most_one(&retention_probability)
    {
        return Err(AnalysisError::new(
            "native-clock thinning requires positive intensity and retention in (0,1]",
        ));
    }
    let accepted_intensity = opportunity_intensity.checked_multiply(&retention_probability)?;
    Ok(ThinningFactorization {
        opportunity_intensity,
        retention_probability,
        accepted_intensity,
    })
}

fn channel_ratio(
    before: &ZeroRangeGenerator,
    after: &ZeroRangeGenerator,
    allocation: &[u32],
    from: usize,
    to: usize,
) -> Result<ExactRatio> {
    divide_ratios(
        &after.channel_rate(allocation, from, to)?,
        &before.channel_rate(allocation, from, to)?,
    )
}

fn exit_rates(generator: &ZeroRangeGenerator) -> Result<Vec<ExactRatio>> {
    (0..generator.states().len())
        .map(|state| generator.exit_rate(state))
        .collect()
}

fn divide_ratios(numerator: &ExactRatio, denominator: &ExactRatio) -> Result<ExactRatio> {
    if denominator.numerator().is_zero() {
        return Err(AnalysisError::new(
            "native-clock exact division has a zero divisor",
        ));
    }
    ExactRatio::new(
        numerator.numerator() * denominator.denominator(),
        numerator.denominator() * denominator.numerator(),
    )
}

fn sum_ratios(values: impl IntoIterator<Item = ExactRatio>) -> Result<ExactRatio> {
    values
        .into_iter()
        .try_fold(ExactRatio::zero(), |sum, value| sum.checked_add(&value))
}

fn ratio_at_most_one(value: &ExactRatio) -> bool {
    value.numerator() <= value.denominator()
}

fn ratio(numerator: u64, denominator: u64) -> ExactRatio {
    ExactRatio::new(BigUint::from(numerator), BigUint::from(denominator))
        .expect("nonzero native-clock fixture denominator")
}

fn adjacency(rows: &[&[u64]]) -> Vec<Vec<BigUint>> {
    rows.iter()
        .map(|row| row.iter().copied().map(BigUint::from).collect())
        .collect()
}

fn integer_ratios(rows: &[&[u64]]) -> Vec<Vec<ExactRatio>> {
    rows.iter()
        .map(|row| row.iter().map(|&value| ratio(value, 1)).collect())
        .collect()
}

fn zero_ratio_matrix(size: usize) -> Vec<Vec<ExactRatio>> {
    vec![vec![ExactRatio::zero(); size]; size]
}
