# Xypher Calorimeter Analysis

Independent finite-state analysis for the frozen Layer-B Xypher Calorimeter.

The crate constructs an allocation shell directly from a generic undirected
account graph and fixed inventory. It independently enumerates weak
compositions, canonical WAIT and unit-transfer actions, the action-labelled
adjacency matrix, and explicit matrix products `A^h 1`.

It intentionally has:

- no dependency on the runtime actor or its path-count implementation;
- no dependency on the runner, joined observer, ledger, or consensus crates;
- no confirmatory fixture definitions; and
- no production sampling code.

Only derivation fixtures appear in tests. Confirmatory fixtures must be
supplied later as external frozen data after the analysis source is hashed.

## Frozen CLI

The binary exposes exactly three commands:

```text
predict --repo-root <path> --core <path> --manifest <path> --output <path>
verify-prediction --repo-root <path> --core <path> --manifest <path> \
  --predictions <path> \
  --expected-commitment-length-bytes <u64> \
  --expected-commitment-sha256 <hex> \
  --expected-sidecar-length-bytes <u64> \
  --expected-sidecar-sha256 <hex>
analyze --repo-root <path> --core <path> --manifest <path> \
  --predictions <path> --normalized <path> --output <path>
```

`predict` accepts no fixture, horizon, episode, or seed filters. Its output
must be the canonical repository prediction-commitment path. It verifies its
own bytes against the analysis artifact in the manifest core, regenerates
every frozen shell and exact law, canonically serializes the complete
prediction document in memory, and writes only a compact new-only commitment
plus SHA-256 sidecar. The commitment binds the complete document schema,
length, raw SHA-256, payload hash, frozen envelope, tolerance contract, and
all-gates-passed flag. Before publication it recomputes the payload bytes and
requires the payload SHA-256 frozen by the transport-only amendment. The full
prediction document is not a repository artifact and is never written by this
command. Publication is sidecar-first:
a crash can leave only the matching sidecar, which a retry safely completes,
but never a visible commitment without its checksum.

`verify-prediction` is a no-write pre-actor gate. It self-verifies the frozen
analysis executable, requires the canonical repository commitment and
sidecar, and first requires the exact buffers it read to match the four
caller-bound length/SHA-256 values. It then regenerates the complete prediction
document and succeeds only when its canonical length, raw SHA-256, frozen
transport-only payload SHA-256, envelope, and tolerances exactly reproduce the
commitment. Binding the identities inside the verifier prevents a
commitment-A/commitment-B replacement from passing through a before/after
pathname check.

`analyze` requires the canonical commitment and sidecar byte-for-byte,
regenerates the complete prediction document again, admits only the complete
joined-observer collection, independently checks the compact trajectory
projection, and scores observed action labels from the regenerated table
whose exact bytes were committed before actor execution. Its report is also
new-only canonical JSON with a SHA-256 sidecar. Full journal, consensus,
ledger, receipt, and external-seal validation remain evidence supplied by the
separately frozen joined observer; the analysis report does not claim to
re-decode those binary artifacts.

The normalized collection must bind the identities computed directly from the
same commitment and sidecar buffers that passed regeneration. Analysis never
re-reads the pathname to establish that join.

In the empirical report, `prediction_hash` is the committed SHA-256 of the
complete regenerated prediction document. `prediction_identity` and
`prediction_sidecar_identity` identify the compact repository commitment and
its sidecar.

## API

- `Fixture` validates a connected, undirected, simple account graph and fixed
  positive inventory.
- `StateShell` enumerates weak compositions and canonical WAIT/unit-transfer
  action labels.
- `ExactKernel` computes `c_h = A^h 1`, `Q_H`, stationary weights, and exact
  recurrence, stationarity, detailed-balance, cycle-balance, node-permutation
  covariance, and rational delta-state transients.
- `StationaryCompatibilityProfile` and the compatibility reports test exact
  stationary and action-resolved `Q_H` laws against independently declared
  energy, degeneracy, and rational Boltzmann factors.
- `compare_qh_weak_contact` compares every retained non-WAIT transfer channel
  before and after bridge insertion on the same state universe and clock.
- `frozen_constructibility_report` exhaustively checks the 512-state,
  23-slot fixed-affordance microcanonical exchange control.
- `Analysis` reports the reversible spectrum, equilibrium localization,
  entropy rates, matrix-propagated transients, and all ordered-pair
  first-passage and return-time predictions.

## CAL-COMPAT exact frontier test

The theorem and frozen predictions are documented in
`../derivable/xypher-qh-thermodynamic-compatibility.md`. Run the public exact
experiment with:

```text
cargo test --locked --test thermodynamic_compatibility -- --nocapture
```

This test generates no trajectory corpus. It rejects the unmodified `Q_H`
candidate analytically when the independent Gibbs or same-clock contact
identities fail, then exhaustively verifies the separately classified
fixed-affordance constructibility control. A passing control is not evidence
of native Xypher emergence.

The regenerated prediction document and committed envelope contain no JSON
numbers or nulls. Arbitrary-precision integers and every other exact integer
are unsigned decimal strings; rational probabilities are
numerator/denominator string pairs; finite `f64` results carry both the
shortest round-tripping decimal and exact lowercase bit pattern. Non-finite
values use explicit names.

For an empirical row with zero exposure, both the floating and exact observed
frequency are explicitly `undefined`; zero is not inferred from absence.

## Numerical boundary

Path counts and theorem identities use arbitrary-precision integers. Spectra,
entropies, and off-diagonal first-passage times use `f64` only after the exact
checks pass. Declared delta-state transients are propagated as exact rational
matrix powers before conversion to TV, KL, and endpoint entropy; arbitrary
user-supplied floating initial distributions remain a separate descriptive
API.

The reported reversible spectral gap uses the absolute convention
`1 - max(k >= 2) |lambda_k|`. The cyclic Jacobi solver reports and gates
eigenpair, eigenvector-normalization, orthogonality, and reconstruction
residuals. Per-mode normalized 2-norm residual upper bounds remain diagnostics.
The load-bearing full-spectrum radius instead uses the complete approximate
basis `V`: an outward Frobenius bound on `R = A V - V Lambda`, together with
an outward Frobenius bound on `V^T V - I`, bounds `||V^-1 R||`. Bauer-Fike
then encloses the complete numerical spectrum with multiplicity. Overlapping
modulus intervals are retained as clusters; the subdominant cluster must be
separated from both the stationary mode and the next distinct modulus
cluster.

The preregistered schedule gaps are approximate design scalars, not
bit-authoritative eigensolver outputs. Prediction admission requires each
declared scalar to lie in the intersection of the canonical and relabelled
residual-derived gap intervals. The complete canonical and relabelled
intervals, the declared scalar, and both Jacobi point estimates must all
satisfy the exact boundary inequalities for the same frozen
`ceil(max(10H, 10 / spectral_gap))` episode length. Exact kernel relabelling
covariance remains a separate zero-tolerance gate. This is a numerical
consistency certificate for the finite binary64 projection, backed by a
full-basis eigenvalue-count bound; it is not a proof that binary64 equals the
exact rational kernel spectrum.

One Jacobi sweep costs `O(S^3)` for `S` allocation states; the deterministic
safety cap grows linearly with `S`, giving a conservative `O(S^4)` worst case,
although the development shells converge in a few sweeps. Solving one
absorbing system per target also makes the complete first-passage table
`O(S^4)`; its Bellman residual is an acceptance gate. KL values below the
frozen negative tolerance are rejected, while only negative roundoff inside
that tolerance is reported as zero. This is therefore a bounded-shell
research instrument rather than a production kernel.
